<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\dashboard\Login;
// use App\Http\Controllers\icons\MdiIcons;
use App\Http\Controllers\lead_management\ManageLead;
use App\Http\Controllers\lead_management\ManageRawLead;
use App\Http\Controllers\branch_management\ManageBranch;
use App\Http\Controllers\branch_management\ManageCompany;
use App\Http\Controllers\branch_management\ManageEntity;
use App\Http\Controllers\lead_management\ManageRequirements;
use App\Http\Controllers\lead_management\ManageProposal;
use App\Http\Controllers\customer_management\ManageInvoice;
use App\Http\Controllers\customer_management\ManageNDA;
use App\Http\Controllers\customer_management\ManageCustomer;
use App\Http\Controllers\hr_management\Staff;
use App\Http\Controllers\hr_management\StaffAttendance;
use App\Http\Controllers\users_management\ManageUsers;
use App\Http\Controllers\users_management\UserRole;
use App\Http\Controllers\settings\GeneralSettings;
use App\Http\Controllers\settings\MarketingSettings;
use App\Http\Controllers\settings\LeadSettings;
use App\Http\Controllers\settings\QuotationSettings;
use App\Http\Controllers\settings\InvoiceSettings;
use App\Http\Controllers\settings\ServiceSettings;
use App\Http\Controllers\settings\JournalSettings;
use App\Http\Controllers\settings\ExamSettings;
use App\Http\Controllers\settings\HRMSettings;
use App\Http\Controllers\settings\CounsellorSettings;
use App\Http\Controllers\settings\AccountsSettings;
use App\Http\Controllers\settings\BaseSettings;
use App\Http\Controllers\settings\CommonSettings;

// common setting
use App\Http\Controllers\settings\common_settings\Country;
use App\Http\Controllers\settings\common_settings\State;
use App\Http\Controllers\settings\common_settings\City;
use App\Http\Controllers\settings\common_settings\CurrencyFormat;
use App\Http\Controllers\settings\common_settings\TimeZone;

// lead setting
use App\Http\Controllers\settings\lead_settings\LeadSource;
use App\Http\Controllers\settings\lead_settings\LeadType;
use App\Http\Controllers\settings\lead_settings\LeadPotentialType;
use App\Http\Controllers\settings\lead_settings\LeadStatus;
use App\Http\Controllers\settings\lead_settings\LeadRequirementStatus;
use App\Http\Controllers\settings\lead_settings\DeadReason;
use App\Http\Controllers\settings\lead_settings\SpamCallReason;
use App\Http\Controllers\settings\lead_settings\InternalCallReason;
use App\Http\Controllers\settings\lead_settings\FollowupReason;

// Main Menu Starts 


// Manage Branch
  Route::match(['get', 'post'], '/branch', [ManageBranch::class, 'index'])->name('branch-management-manage-branch');
  Route::get('/branch/create', [ManageBranch::class, 'create_branch_franchise'])->name('branch-management-manage-branch');
  Route::get('/branch/update', [ManageBranch::class, 'update_branch_franchise'])->name('branch-management-manage-branch');
  Route::post('/branch_status/{id}', [ManageBranch::class, 'Status']);
  Route::delete('/branch_delete/{id}', [ManageBranch::class, 'Delete']);
  Route::get('/branch_view/{id}', [ManageBranch::class, 'View']);
  Route::get('/create_branch_franchise', [ManageBranch::class, 'create_branch_franchise'])->name('branch');
  Route::get('/update_branch_franchise/{id}', [ManageBranch::class, 'Edit']);
  Route::post('/add_branch_franchise', [ManageBranch::class, 'Add'])->name('add_branch_franchise');
  Route::post('/update_branch_franchise', [ManageBranch::class, 'Update'])->name('update_branch_franchise');
  Route::post('/assign_center_head', [ManageBranch::class, 'AssignCenterHead'])->name('assign_center_head');
  Route::post('/branch/Add_staff_branch', [ManageBranch::class, 'Add_staff_branch'])->name('Add_staff_branch');
  Route::get('/bran_drop_down', [ManageBranch::class, 'List'])->name('bran_drop_down');
  Route::get('/get_course_branch', [ManageBranch::class, 'get_course_by_type'])->name('get_course_branch');
  Route::get('/job_position_branch', [ManageBranch::class, 'Job_postion_to_Cug'])->name('job_position_branch');
  Route::get('/get_staff_data_based_on_role/{id}', [ManageBranch::class, 'Staff_based_on_role'])->name('get_staff_data_based_on_role');
  Route::post('/assign_cug_Detail', [ManageBranch::class, 'AssignCugDetails'])->name('assign_cug_Detail');
  Route::post('/edit_cug_to_staff', [ManageBranch::class, 'Update_staff_Cug_modal'])->name('edit_cug_to_staff');
  Route::get('/cre_dropdown_for_branch', [ManageBranch::class, 'Cre_Dropdown'])->name('cre_dropdown_for_branch');
  Route::get('/cug_edit_fetch', [ManageBranch::class, 'Cug_Edit_Fetch'])->name('cug_edit_fetch');
  Route::delete('/cug_delete', [ManageBranch::class, 'Cug_delete'])->name('cug_delete');
  Route::get('/check_unique_mobile_number', [ManageBranch::class, 'checkUniqueMobileNumber'])->name('check_unique_mobile_number');

  // lead Management
   // Raw Lead   
   Route::match(['get', 'post'], '/raw_lead', [ManageRawLead::class, 'index'])->name('lead-management-manage-lead');
   Route::get('/lead/export-excel', [ManageRawLead::class, 'exportExcel']);
   Route::get('/lead/sample-excel', [ManageRawLead::class, 'LeadExportExcel']);
   Route::post('/lead_import', [ManageRawLead::class, 'LeadImport'])->name('lead_import');
   Route::post('/submit_raw_spam_reason', [ManageRawLead::class, 'Rawspam'])->name('submit_raw_spam_reason');
   Route::post('/raw_drop', [ManageRawLead::class, 'Rawdrop'])->name('raw_drop');
   Route::post('/future_lead_status/{id}', [ManageRawLead::class, 'FutureLead']);
   Route::post('/check-mobile-exists', [ManageRawLead::class, 'checkMobileExists'])->name('checkMobileExists');
   Route::post('/convert_raw_to_lead/{id}', [ManageRawLead::class, 'ConvertRawtoLead']);


    // Main Menu lead
  Route::match(['get', 'post'],'/manage_lead', [ManageLead::class, 'index'])->name('lead-management-manage-lead');
  Route::get('/sales/raw_lead', [Lead::class, 'raw_lead'])->name('sales-manage-lead');
  Route::match(['get', 'post'], '/lead_bank_list', [Lead::class, 'Lead_bank_list'])->name('sales-manage-lead');
  Route::post('/bulk_bank_lead', [Lead::class, 'bulk_bank_lead_conversion'])->name('bulk_bank_lead');
  Route::post('/bank_lead', [Lead::class, 'bank_lead_conversion'])->name('bank_lead');
  Route::get('/lead_edit_bank_convert/{id}', [Lead::class, 'EditConvertBank']);
  Route::post('/convert_bank_to_lead', [Lead::class, 'ConvertBanktoLead'])->name('convert_bank_to_lead');

  // Hrm Staff
  Route::get('/staff_list_by_branch_id/{id}', [Staff::class, 'StaffListByBranch'])->name('staff_list_by_branch_id');
  Route::get('/staff_data_get/{id}', [Staff::class, 'staff_data_get']);


Route::get('/company', [ManageCompany::class, 'index'])->name('branch-management-manage-company');
Route::get('/entity', [ManageEntity::class, 'index'])->name('branch-management-manage-entity');

// Route::get('/manage_lead', [ManageLead::class, 'index'])->name('lead-management-manage-lead');
Route::get('/manage_lead/lead_worklist', [ManageLead::class, 'worklist_add'])->name('lead-management-manage-lead');
Route::get('/manage_lead/lead_worklist_complete', [ManageLead::class, 'worklist_add_complete'])->name('lead-management-manage-lead');
Route::get('/manage_lead/quotation_list', [ManageLead::class, 'quotation_list'])->name('lead-management-manage-lead');
Route::get('/manage_requirements', [ManageRequirements::class, 'index'])->name('lead-management-manage-requirments');
Route::get('/manage_proposal', [ManageProposal::class, 'index'])->name('lead-management-manage-proposal');
Route::get('/manage_proposal/proposal_add', [ManageProposal::class, 'manage_proposal_add'])->name('lead-management-manage-proposal');
Route::get('/manage_proposal/proposal_edit', [ManageProposal::class, 'manage_proposal_edit'])->name('lead-management-manage-proposal');
Route::get('/manage_proposal/proposal_view', [ManageProposal::class, 'manage_proposal_view'])->name('lead-management-manage-proposal');
Route::get('/manage_proposal/proposal_print', [ManageProposal::class, 'manage_proposal_print'])->name('lead-management-manage-proposal');
Route::get('/manage_invoice', [ManageInvoice::class, 'index'])->name('customer-management-manage-invoice');
Route::get('/manage_invoice/invoice_add', [ManageInvoice::class, 'manage_invoice_add'])->name('customer-management-manage-invoice');
Route::get('/manage_invoice/quote_to_invoice', [ManageInvoice::class, 'quote_to_invoice'])->name('customer-management-manage-invoice');
Route::get('/manage_invoice/balance_amount_invoice', [ManageInvoice::class, 'balance_amount_invoice'])->name('customer-management-manage-invoice');
Route::get('/manage_invoice/invoice_add_payment', [ManageInvoice::class, 'manage_invoice_payment_add'])->name('customer-management-manage-invoice');
Route::get('/manage_invoice/invoice_edit', [ManageInvoice::class, 'manage_invoice_edit'])->name('customer-management-manage-invoice');
Route::get('/manage_invoice/invoice_view', [ManageInvoice::class, 'manage_invoice_view'])->name('customer-management-manage-invoice');
Route::get('/manage_invoice/invoice_print', [ManageInvoice::class, 'manage_invoice_print'])->name('customer-management-manage-invoice');
Route::get('/manage_nda', [ManageNDA::class, 'index'])->name('customer-management-manage-nda');
Route::get('/manage_nda/nda_add', [ManageNDA::class, 'nda_add'])->name('customer-management-manage-nda');
Route::get('/manage_nda/nda_view', [ManageNDA::class, 'nda_view'])->name('customer-management-manage-nda');
Route::get('/manage_nda/nda_print', [ManageNDA::class, 'nda_print'])->name('customer-management-manage-nda');
Route::get('/manage_customer', [ManageCustomer::class, 'index'])->name('customer-management-manage-customer');
Route::get('/manage_customer/customer_add_service', [ManageCustomer::class, 'customer_add_service'])->name('customer-management-manage-customer');
Route::get('/manage_customer/customer_add', [ManageCustomer::class, 'customer_add'])->name('customer-management-manage-customer');
Route::get('/manage_customer/customer_view', [ManageCustomer::class, 'customer_view'])->name('customer-management-manage-customer');
Route::get('/manage_customer/customer_edit', [ManageCustomer::class, 'customer_edit'])->name('customer-management-manage-customer');
Route::get('/manage_customer/payment', [ManageCustomer::class, 'payment'])->name('customer-management-manage-customer');
Route::get('/manage_customer/customer_quotation', [ManageCustomer::class, 'customer_quotation'])->name('customer-management-manage-customer');
Route::get('/manage_customer/customer_invoice', [ManageCustomer::class, 'customer_invoice'])->name('customer-management-manage-customer');
Route::get('/manage_customer/payment', [ManageCustomer::class, 'payment'])->name('customer-management-manage-customer');
Route::get('/manage_customer/customer_invoice_add', [ManageCustomer::class, 'customer_invoice_add'])->name('customer-management-manage-customer');
Route::get('/hr_management/staff', [Staff::class, 'index'])->name('hr-management-staff');
Route::get('/hr_management/staff/staff_add', [Staff::class, 'staff_add'])->name('hr-management-staff');
Route::get('/hr_management/staff/staff_edit', [Staff::class, 'staff_edit'])->name('hr-management-staff');
Route::get('/hr_management/staff/staff_view', [Staff::class, 'staff_view'])->name('hr-management-staff');
Route::get('/hr_management/staff_attendance', [StaffAttendance::class, 'index'])->name('hr-management-staff-attendance');
Route::get('/hr_management/staff/staff_manage_batch', [Staff::class, 'staff_manage_batch'])->name('hr-management-staff');
Route::get('/hr_management/staff/staff_manage_batch/feedback', [Staff::class, 'staff_manage_batch_feedback'])->name('hr_management-staff-manage-batch-feedback');
Route::get('/users/manage_users', [ManageUsers::class, 'index'])->name('users-manage-users');
Route::get('/users/create_manage_users', [ManageUsers::class, 'users_add'])->name('users-manage-users');
Route::get('/users/update_manage_users', [ManageUsers::class, 'users_edit'])->name('users-manage-users');
Route::get('/users/view_manage_users', [ManageUsers::class, 'users_view'])->name('users-manage-users');
Route::get('/users/user_role', [UserRole::class, 'index'])->name('users-role');
// Main Menu End

// Settings Menu Starts
Route::get('/settings/general_settings', [GeneralSettings::class, 'index'])->name('settings-general-settings');
Route::get('/settings/base', [BaseSettings::class, 'index'])->name('settings-base-settings');
Route::get('/settings/common_settings', [CommonSettings::class, 'index'])->name('settings-common-ui');
Route::get('/settings/marketing', [MarketingSettings::class, 'index'])->name('settings-marketing-settings');
Route::get('/settings/lead', [LeadSettings::class, 'index'])->name('settings-lead-ui');
Route::get('/settings/quotation', [QuotationSettings::class, 'index'])->name('settings-quotation-settings');
Route::get('/settings/quotataion/quotation_template_add', [QuotationSettings::class, 'quotation_template_add'])->name('settings-quotation-settings');
Route::get('/settings/quotataion/quotation_template_edit', [QuotationSettings::class, 'quotation_template_edit'])->name('settings-quotation-settings');
Route::get('/settings/quotataion/quotation_template_view', [QuotationSettings::class, 'quotation_template_view'])->name('settings-quotation-settings');
Route::get('/settings/invoice', [InvoiceSettings::class, 'index'])->name('settings-invoice-settings');
Route::get('/settings/sales/lead_questions_add', [LeadSettings::class, 'lead_questions_add'])->name('settings-sales-lead-questions-add');
Route::get('/settings/sales/lead_questions_edit', [LeadSettings::class, 'lead_questions_edit'])->name('settings-sales-lead-questions-edit');
Route::get('/settings/customer_type_option/customer_type_option_add', [LeadSettings::class, 'customer_type_option_add'])->name('settings-sales');
Route::get('/settings/customer_type_option/customer_type_option_edit', [LeadSettings::class, 'customer_type_option_edit'])->name('settings-sales');
Route::get('/settings/payment_mode_option/payment_mode_option_add', [LeadSettings::class, 'payment_mode_option_add'])->name('settings-sales');
Route::get('/settings/payment_mode_option/payment_mode_option_edit', [LeadSettings::class, 'payment_mode_option_edit'])->name('settings-sales');
Route::get('/settings/journal', [JournalSettings::class, 'index'])->name('settings-journal-settings');
Route::get('/settings/services', [ServiceSettings::class, 'index'])->name('settings-service-settings');
Route::get('/settings/services/service_properties_add', [ServiceSettings::class, 'service_properties_add'])->name('settings-service-settings');
Route::get('/settings/services/service_properties_edit', [ServiceSettings::class, 'service_properties_edit'])->name('settings-service-settings');
Route::get('/settings/services/service_product_add', [ServiceSettings::class, 'service_product_add'])->name('settings-service-settings');
Route::get('/settings/services/service_product_edit', [ServiceSettings::class, 'service_product_edit'])->name('settings-service-settings');
Route::get('/settings/exam', [ExamSettings::class, 'index'])->name('settings-exam-settings');
Route::get('/settings/hrm', [HRMSettings::class, 'index'])->name('settings-hrm-settings');
Route::get('/settings/counsellor', [CounsellorSettings::class, 'index'])->name('settings-counsellor-settings');
Route::get('/settings/counsellor/category_analysis_questions_add', [CounsellorSettings::class, 'category_analysis_questions_add'])->name('settings-counsellor');
Route::get('/settings/counsellor/category_analysis_questions_edit', [CounsellorSettings::class, 'category_analysis_questions_edit'])->name('settings-counsellor');
Route::get('/settings/counsellor/course_analysis_questions_add', [CounsellorSettings::class, 'course_analysis_questions_add'])->name('settings-counsellor');
Route::get('/settings/counsellor/course_analysis_questions_edit', [CounsellorSettings::class, 'course_analysis_questions_edit'])->name('settings-counsellor');
Route::get('/settings/counsellor/feedback_analysis_questions_add', [CounsellorSettings::class, 'feedback_analysis_questions_add'])->name('settings-counsellor');
Route::get('/settings/counsellor/feedback_analysis_questions_edit', [CounsellorSettings::class, 'feedback_analysis_questions_edit'])->name('settings-counsellor');
Route::get('/settings/accounts', [AccountsSettings::class, 'index'])->name('settings-accounts-settings');




// generel setting
Route::get('/settings/general_settings', [GeneralSettings::class, 'index'])->name('settings-general_settings');
Route::post('/general_settings-update', [GeneralSettings::class, 'Update'])->name('general_settings_update');

// Country 
Route::get('/country', [Country::class, 'List'])->name('country');
// state
Route::get('/state', [State::class, 'List'])->name('state');
// city
Route::get('/city', [City::class, 'List'])->name('city');
// timezone
Route::get('/time_zone', [TimeZone::class, 'List'])->name('time_zone');


// Common settings
  // Country Setting
     Route::match(['get', 'post'], '/settings/common/country', [Country::class, 'index'])->name('settings-common-settings');
  Route::post('/add_country', [Country::class, 'Add'])->name('add_country');
  Route::get('/country_edit', [Country::class, 'Edit'])->name('country_edit');
  Route::post('/country_update', [Country::class, 'Update'])->name('country_update');
  Route::delete('/country_delete/{id}', [Country::class, 'Delete'])->name('country_delete');
  Route::post('/country_status_change/{id}', [Country::class, 'Status'])->name('country_status_change');

// state Setting
   Route::match(['get', 'post'], '/settings/common/state', [State::class, 'index'])->name('settings-common-settings');
Route::post('/add_state', [State::class, 'Add'])->name('add_state');
Route::get('/state_edit', [State::class, 'Edit'])->name('state_edit');
Route::post('/state_update', [State::class, 'Update'])->name('state_update');
Route::delete('/state_delete/{id}', [State::class, 'Delete'])->name('state_delete');
Route::post('/state_status_change/{id}', [State::class, 'Status'])->name('state_status_change');

// city Setting
   Route::match(['get', 'post'], '/settings/common/city', [City::class, 'index'])->name('settings-common-settings');
Route::post('/add_city', [City::class, 'Add'])->name('add_city');
Route::get('/city_edit', [City::class, 'Edit'])->name('city_edit');
Route::post('/city_update', [City::class, 'Update'])->name('city_update');
Route::delete('/city_delete/{id}', [City::class, 'Delete'])->name('city_delete');
Route::post('/city_status_change/{id}', [City::class, 'Status'])->name('city_status_change');


// currency_format Setting
   Route::match(['get', 'post'], '/settings/common/currency_format', [CurrencyFormat::class, 'index'])->name('settings-common-settings');
Route::get('/currency_format', [CurrencyFormat::class, 'List'])->name('currency_format');
Route::post('/add_currency_format', [CurrencyFormat::class, 'Add'])->name('add_currency_format');
Route::get('/currency_format_edit/{id}', [CurrencyFormat::class, 'Edit'])->name('currency_format_edit');
Route::post('/currency_format_update', [CurrencyFormat::class, 'Update'])->name('currency_format_update');
Route::delete('/currency_format_delete/{id}', [CurrencyFormat::class, 'Delete']);
Route::post('/currency_format_status/{id}', [CurrencyFormat::class, 'Status']);

// time_zone Setting
   Route::match(['get', 'post'], '/settings/common/time_zone', [TimeZone::class, 'index'])->name('settings-common-settings');
Route::post('/add_time_zone', [TimeZone::class, 'Add'])->name('add_time_zone');
Route::get('/time_zone_edit', [TimeZone::class, 'Edit'])->name('time_zone_edit');
Route::post('/time_zone_update', [TimeZone::class, 'Update'])->name('time_zone_update');
Route::delete('/time_zone_delete/{id}', [TimeZone::class, 'Delete'])->name('time_zone_delete');
Route::post('/time_zone_status_change/{id}', [TimeZone::class, 'Status'])->name('time_zone_status_change');


// Lead settings
// LeadSource
   Route::match(['get', 'post'], '/settings/lead/lead_source', [LeadSource::class, 'index'])->name('settings-lead-settings');
Route::get('lead_source', [LeadSource::class, 'List'])->name('lead_source');
Route::post('/add-lead-source', [LeadSource::class, 'Add'])->name('add_lead_source');
Route::get('/lead-source-edit/{id}', [LeadSource::class, 'Edit'])->name('lead_source_edit');
Route::post('/lead-source-update', [LeadSource::class, 'Update'])->name('lead_source_update');
Route::delete('/lead-source-delete/{id}', [LeadSource::class, 'Delete']);
Route::post('/lead-source-status/{id}', [LeadSource::class, 'Status']);

// LeadType
   Route::match(['get', 'post'], '/settings/lead/lead_type', [LeadType::class, 'index'])->name('settings-lead-settings');
Route::get('lead_type', [LeadType::class, 'List'])->name('lead_type');
Route::post('/add-lead-type', [LeadType::class, 'Add'])->name('add_lead_type');
Route::get('/lead-type-edit/{id}', [LeadType::class, 'Edit'])->name('lead_type_edit');
Route::post('/lead-type-update', [LeadType::class, 'Update'])->name('lead_type_update');
Route::delete('/lead-type-delete/{id}', [LeadType::class, 'Delete']);
Route::post('/lead-type-status/{id}', [LeadType::class, 'Status']);


// LeadPotential type
   Route::match(['get', 'post'], '/settings/lead/lead_potential_type', [LeadPotentialType::class, 'index'])->name('settings-lead-settings');
Route::post('/add-potential_type', [LeadPotentialType::class, 'Add'])->name('add_lead_potential_type');
Route::get('/lead-potential_type-edit/{id}', [LeadPotentialType::class, 'Edit'])->name('lead_potential_type_edit');
Route::post('/lead-potential_type-update', [LeadPotentialType::class, 'Update'])->name('lead_potential_type_update');
Route::delete('/lead-potential_type-delete/{id}', [LeadPotentialType::class, 'Delete']);
Route::post('/lead-potential_type-status/{id}', [LeadPotentialType::class, 'Status']);


// Lead status
   Route::match(['get', 'post'], '/settings/lead/lead_status', [LeadStatus::class, 'index'])->name('settings-lead-settings');
Route::get('/lead_status', [LeadStatus::class, 'List'])->name('lead_status');
Route::post('/add_lead_status', [LeadStatus::class, 'Add'])->name('add_lead_status');
Route::get('/lead_status_edit/{id}', [LeadStatus::class, 'Edit']);
Route::post('/lead_status_update', [LeadStatus::class, 'Update'])->name('lead_status_update');
Route::delete('/lead_status_delete/{id}', [LeadStatus::class, 'Delete']);
Route::post('/lead_status_status/{id}', [LeadStatus::class, 'Status']);
Route::post('/lead_status_lg_status/{id}', [LeadStatus::class, 'Legend_Status']);

// Lead requirement status
   Route::match(['get', 'post'], '/settings/lead/lead_requirement_status', [LeadRequirementStatus::class, 'index'])->name('settings-lead-settings');
Route::get('/lead_requirement_status', [LeadRequirementStatus::class, 'List'])->name('lead_requirement_status');
Route::post('/add_lead_requirement_status', [LeadRequirementStatus::class, 'Add'])->name('add_lead_requirement_status');
Route::get('/lead_requirement_status_edit/{id}', [LeadRequirementStatus::class, 'Edit']);
Route::post('/lead_requirement_status_update', [LeadRequirementStatus::class, 'Update'])->name('lead_requirement_status_update');
Route::delete('/lead_requirement_status_delete/{id}', [LeadRequirementStatus::class, 'Delete']);
Route::post('/lead_requirement_status_status/{id}', [LeadRequirementStatus::class, 'Status']);
Route::post('/lead_requirement_status_lg_status/{id}', [LeadRequirementStatus::class, 'Legend_Status']);

// followup Reason
   Route::match(['get', 'post'], '/settings/lead/followup_reason', [FollowupReason::class, 'index'])->name('settings-lead-settings');
Route::post('/followup_reason_add', [FollowupReason::class, 'Add'])->name('followup_reason_add');
Route::get('followup_reason_list', [FollowupReason::class, 'List'])->name('followup_reason_list');
Route::post('/followup_reason_status/{id}', [FollowupReason::class, 'Status']);
Route::delete('/followup_reason_delete/{id}', [FollowupReason::class, 'Delete']);
Route::post('/followup_reason_update', [FollowupReason::class, 'Update'])->name('followup_reason_update');  

// Spam Call Reason
   Route::match(['get', 'post'], '/settings/lead/spam_call_reason', [SpamCallReason::class, 'index'])->name('settings-lead-settings');
Route::post('/spam_call_reason_add', [SpamCallReason::class, 'Add'])->name('spam_call_reason_add');
Route::get('spam_call_reason_list', [SpamCallReason::class, 'List'])->name('spam_call_reason_list');
Route::post('/spam_call_reason_status/{id}', [SpamCallReason::class, 'Status']);
Route::delete('/spam_call_reason_delete/{id}', [SpamCallReason::class, 'Delete']);
Route::post('/spam_call_reason_update', [SpamCallReason::class, 'Update'])->name('spam_call_reason_update');

//Internal Call Reason
   Route::match(['get', 'post'], '/settings/lead/internal_call_reason', [InternalCallReason::class, 'index'])->name('settings-lead-settings');
Route::post('/internal_call_reason_add', [InternalCallReason::class, 'Add'])->name('internal_call_reason_add');
Route::get('internal_call_reason_list', [InternalCallReason::class, 'List'])->name('internal_call_reason_list');
Route::post('/internal_call_reason_status/{id}', [InternalCallReason::class, 'Status']);
Route::delete('/internal_call_reason_delete/{id}', [InternalCallReason::class, 'Delete']);
Route::post('/internal_call_reason_update', [InternalCallReason::class, 'Update'])->name('internal_call_reason_update');


// dead Reason
   Route::match(['get', 'post'], '/settings/lead/dead_reason', [DeadReason::class, 'index'])->name('settings-lead-settings');
Route::post('/dead_reason_add', [DeadReason::class, 'Add'])->name('dead_reason_add');
Route::get('dead_reason_list', [DeadReason::class, 'List'])->name('dead_reason_list');
Route::post('/dead_reason_status/{id}', [DeadReason::class, 'Status']);
Route::delete('/dead_reason_delete/{id}', [DeadReason::class, 'Delete']);
Route::post('/dead_reason_update', [DeadReason::class, 'Update'])->name('dead_reason_update');

// Settings Menu End





// Main Page Route
Route::get('/', [Login::class, 'index'])->name('login');
Route::get('/get_staff', [Login::class, 'get_staff'])->name('get-staff');
Route::get('/forgot_password', [Login::class, 'forgot_password'])->name('forgot-password');
Route::get('/change_password', [Login::class, 'new_password'])->name('new-password');
Route::get('/dashboards', [Login::class, 'dashboards'])->name('dashboards');
// locale

// icons
// Route::get('/icons/icons-mdi', [MdiIcons::class, 'index'])->name('icons-mdi');
