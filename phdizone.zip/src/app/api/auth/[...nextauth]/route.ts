import { handlers } from '@auth/authJs';

export const { GET, POST } = handlers;
