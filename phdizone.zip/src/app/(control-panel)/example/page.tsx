import Example from './Example';

export default Example;
