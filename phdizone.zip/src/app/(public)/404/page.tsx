'use client';

import Error404Page from './Error404Page';

function Page() {
	return <Error404Page />;
}

export default Page;
