'use client';

import Error401Page from './Error401Page';

function Page() {
	return <Error401Page />;
}

export default Page;
