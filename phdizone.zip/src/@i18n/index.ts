import i18 from './i18n';

export default i18;
