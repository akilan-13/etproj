const components: Record<string, React.FC<unknown>> = {};

export default components;
