/**
 * Form Editors
 */

'use strict';

(function () {
  // Quotation Notes
  // --------------------------------------------------------------------
  const CreatefullToolbar = [
    [
      {
        font: []
      },
      {
        size: []
      }
    ],
    ['bold', 'italic', 'underline', 'strike'],
    [
      {
        color: []
      },
      {
        background: []
      }
    ],
    [
      {
        script: 'super'
      },
      {
        script: 'sub'
      }
    ],
    [
      {
        header: '1'
      },
      {
        header: '2'
      },
      'blockquote',
      'code-block'
    ],
    [
      {
        list: 'ordered'
      },
      {
        list: 'bullet'
      },
      {
        indent: '-1'
      },
      {
        indent: '+1'
      }
    ],
    [{ direction: 'rtl' }],
    ['link', 'image', 'video', 'formula'],
    ['clean']
  ];
  const CreatefullEditor = new Quill('#create_quotation_notes', {
    bounds: '#create_quotation_notes',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: CreatefullToolbar
    },
    theme: 'snow'
  });

    // Quotation Notes
  // --------------------------------------------------------------------
 
  const CreatefullEditor_1 = new Quill('#create_quotation_terms_condition', {
    bounds: '#create_quotation_terms_condition',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: CreatefullToolbar
    },
    theme: 'snow'
  });

  const CreatefullEditor_2 = new Quill('#create_quotation_support_section', {
    bounds: '#create_quotation_support_section',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: CreatefullToolbar
    },
    theme: 'snow'
  });


  const Createslot1 = [
   
    ['bold', 'italic', 'underline'],
    [
      {
        color: []
      },
      {
        background: []
      }
    ],
    [
      {
        list: 'ordered'
      },
      {
        list: 'bullet'
      }
    ],
  ];
  const CreatefullEditor_3 = new Quill('#create_slot1', {
    bounds: '#create_slot1',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
  const CreatefullEditor_5 = new Quill('#create_slot2', {
    bounds: '#create_slot2',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
  const CreatefullEditor_8 = new Quill('#create_slot3', {
    bounds: '#create_slot3',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
  const CreatefullEditor_10 = new Quill('#create_slot4', {
    bounds: '#create_slot4',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
  const CreatefullEditor_4 = new Quill('#create_slot_note1', {
    bounds: '#create_slot_note1',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
  const CreatefullEditor_6 = new Quill('#create_slot_note2', {
    bounds: '#create_slot_note2',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
  const CreatefullEditor_7 = new Quill('#create_slot_note3', {
    bounds: '#create_slot_note3',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
  const CreatefullEditor_9 = new Quill('#create_slot_note4', {
    bounds: '#create_slot_note4',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: Createslot1
    },
    theme: 'snow'
  });
})();
