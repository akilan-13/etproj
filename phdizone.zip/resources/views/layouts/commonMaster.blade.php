<!DOCTYPE html>
@php
$menuFixed = ($configData['layout'] === 'vertical') ? ($menuFixed ?? '') : (($configData['layout'] === 'front') ? '' : $configData['headerType']);
$navbarType = ($configData['layout'] === 'vertical') ? $configData['navbarType']: (($configData['layout'] === 'front') ? 'layout-navbar-fixed': '');
$isFront = ($isFront ?? '') == true ? 'Front' : '';
$contentLayout = (isset($container) ? (($container === 'container-xxl') ? "layout-compact" : "layout-wide") : "");
@endphp

<html id="project_tag" lang="{{ session()->get('locale') ?? app()->getLocale() }}" class="{{ $configData['style'] }}-style {{($contentLayout ?? '')}} {{ ($navbarType ?? '') }} {{ ($menuFixed ?? '') }} {{ $menuCollapsed ?? '' }} {{ $menuFlipped ?? '' }} {{ $menuOffcanvas ?? '' }} {{ $footerFixed ?? '' }} {{ $customizerHidden ?? '' }}" dir="{{ $configData['textDirection'] }}" data-theme="{{ $configData['theme'] }}" data-assets-path="{{ asset('/assets') . '/' }}" data-base-url="{{url('/')}}" data-framework="laravel" data-template="{{ $configData['layout'] . '-menu-' . $configData['themeOpt'] . '-' . $configData['styleOpt'] }}">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title>PhDiZone | @yield('title')</title>
  <meta name="description" content="{{ config('variables.templateDescription') ? config('variables.templateDescription') : '' }}" />
  <meta name="keywords" content="{{ config('variables.templateKeyword') ? config('variables.templateKeyword') : '' }}">
  <!-- laravel CRUD token -->
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <!-- Canonical SEO -->
  <link rel="canonical" href="{{ config('variables.productPage') ? config('variables.productPage') : '' }}">
  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="{{ asset('assets/phdizone_images/phdizone_fav_icon.png') }}" />
  <link href="{{url ('assets/custom_file/swal2.css')}}" rel="stylesheet" type="text/css" />

  <!-- Include Styles -->
  <!-- $isFront is used to append the front layout styles only on the front layout otherwise the variable will be blank -->
  @include('layouts/sections/styles' . $isFront)

  <!-- Include Scripts for customizer, helper, analytics, config -->
  <!-- $isFront is used to append the front layout scriptsIncludes only on the front layout otherwise the variable will be blank -->
  @include('layouts/sections/scriptsIncludes' . $isFront)

</head>
<style>
  .txt_vertical {
    writing-mode: vertical-lr;
  }

  .overlay-wrapper {
    position: relative;
    overflow: hidden;
    display: block;
    text-align: center;
  }

  .overlay-layer {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .overlay-layer:hover {
    opacity: 1;
  }

  .overlay-layer i {
    color: rgb(37, 33, 33);
    font-size: 24px;
  }

  .download-image {
    /* background-image:url('{{ asset('/assets/eapl_images/def_pdf.png') }}'); */
    position: relative;
    background-size: cover;
    background-position: center;
  }

  .dataTables_scroll {
    position: relative;
    overflow: auto;
    /* max-height: 218px; */
    /*the maximum height you want to achieve*/
    width: 100%;
  }

  .dataTables_scroll thead {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    /* background-color: #ec9629 !important; */
    z-index: 2;
  }
  .scroll-container-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    max-width: 100%;
    overflow: hidden;
  }

  .scroll-container {
    display: flex;
    overflow-x: auto;
    scroll-behavior: smooth;
    padding: 10px 40px;
    gap: 10px;
    scrollbar-width: none;
  }

  .scroll-container::-webkit-scrollbar {
    display: none;
  }

  .item {
    flex: 0 0 auto;
    text-align: center;
    font-weight: bold;
    border-radius: 8px;
  }

  .scroll-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgb(122, 122, 122);
    border: none;
    padding: 17px 6px;
    cursor: pointer;
    z-index: 10;
    border-radius: 4px;
    display: none;
  }

  .scroll-btn.left {
    left: 0;
  }

  .scroll-btn.right {
    right: 0;
  }

</style>
<script src="{{url ('assets/custom_file/jquery-3.7.1.js')}}"></script>
<script src="{{url ('assets/custom_file/dataTables.js')}}"></script>
<script src="{{url ('assets/custom_file/dataTables.bootstrap5.js')}}"></script>
<!-- <script src="{{url ('assets/custom_file/fslightbox.bundle.js')}}"></script> -->


<body>


  <!-- Layout Content -->
  @yield('layoutContent')
  <!--/ Layout Content -->



  <!-- Include Scripts -->
  <!-- $isFront is used to append the front layout scripts only on the front layout otherwise the variable will be blank -->
  @include('layouts/sections/scripts' . $isFront)
  <!-- <script>
    const textarea = document.querySelector("txt_area");
    autosize(textarea);
  </script> -->
  <!-- Modal Dropdown box start -->
  <script>
    'use strict';
    $(function() {
      const select2 = $('.select3');
      if (select2.length) {
        select2.each(function() {
          var $this = $(this);
          select2Focus($this);
          $this.wrap('<div class="position-relative"></div>').select2({
            // placeholder: 'Select value',
            dropdownParent: $this.parent()
          });
        });
      }
    });
  </script>
  <!-- Modal Dropdown box end -->
  <!-- Modal Dropdown box(Multi Select) start -->
  <script>
    'use strict';
    $(function() {
      const select2 = $('.select4');
      if (select2.length) {
        select2.each(function() {
          var $this = $(this);
          select2Focus($this);
          $this.wrap('<div class="position-relative"></div>').select2({
            placeholder: 'Select',
            dropdownParent: $this.parent()
          });
        });
      }
    });
    
  </script>
  <!-- Modal Dropdown box(Multi Select) end -->
  <script>
    $('[data-bs-toggle="tooltip"]').on("mouseleave", function() {
      $(this).tooltip("hide");
    })
  </script>
  <script>
    const scrollContainer = document.getElementById('scrollContainer');
    const scrollLeftBtn = document.getElementById('scrollLeftBtn');
    const scrollRightBtn = document.getElementById('scrollRightBtn');

    function updateScrollButtons() {
      const scrollLeft = scrollContainer.scrollLeft;
      const scrollWidth = scrollContainer.scrollWidth;
      const clientWidth = scrollContainer.clientWidth;

      scrollLeftBtn.style.display = scrollLeft > 0 ? 'block' : 'none';
      scrollRightBtn.style.display = scrollLeft + clientWidth < scrollWidth ? 'block' : 'none';
    }

    scrollLeftBtn.addEventListener('click', () => {
      scrollContainer.scrollBy({
        left: -300,
        behavior: 'smooth'
      });
    });

    scrollRightBtn.addEventListener('click', () => {
      scrollContainer.scrollBy({
        left: 300,
        behavior: 'smooth'
      });
    });

    scrollContainer.addEventListener('scroll', updateScrollButtons);
    window.addEventListener('resize', updateScrollButtons);

    // Run on load
    updateScrollButtons();
  </script>
</body>

</html>