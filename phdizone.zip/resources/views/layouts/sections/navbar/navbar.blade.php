@php
$containerNav = $containerNav ?? 'container-fluid';
$navbarDetached = ($navbarDetached ?? '');
@endphp

<!-- Navbar -->
@if(isset($navbarDetached) && $navbarDetached == 'navbar-detached')
<nav class="layout-navbar {{$containerNav}} navbar navbar-expand-xl {{$navbarDetached}} align-items-center bg-navbar-theme" id="layout-navbar">
  @endif
  @if(isset($navbarDetached) && $navbarDetached == '')
  <nav class="layout-navbar navbar navbar-expand-xl align-items-center bg-navbar-theme" id="layout-navbar">
    <div class="{{$containerNav}}">
      @endif

      <!--  Brand demo (display only for navbar-full and hide on below xl) -->
      @if(isset($navbarFull))
      <div class="navbar-brand app-brand demo d-none d-xl-flex py-0 me-4">
        <a href="{{url('/')}}" class="app-brand-link gap-2">
          <span class="app-brand-logo demo">@include('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'])</span>
          <span class="app-brand-text demo menu-text fw-bold">{{config('variables.templateName')}}</span>
        </a>
        @if(isset($menuHorizontal))
        <a href="javascript:;" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
          <i class="mdi mdi-close align-middle"></i>
        </a>
        @endif
      </div>
      @endif

      <!-- ! Not required for layout-without-menu -->
      @if(!isset($navbarHideToggle))
      <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0{{ isset($menuHorizontal) ? ' d-xl-none ' : '' }} {{ isset($contentNavbar) ?' d-xl-none ' : '' }}">
        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
          <i class="mdi mdi-menu mdi-24px"></i>
        </a>
      </div>
      @endif

      <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

        @if(!isset($menuHorizontal))
        <!-- Search -->
        <!-- <div class="navbar-nav align-items-center">
          <div class="nav-item navbar-search-wrapper mb-0">
            <a class="nav-item nav-link search-toggler fw-normal px-0" href="javascript:;">
              <i class="mdi mdi-magnify mdi-24px scaleX-n1-rtl"></i>
              <span class="d-none d-md-inline-block text-muted">Search (Ctrl+/)</span>
            </a>
          </div>
        </div> -->
        <!-- /Search -->
        @endif

        <ul class="navbar-nav flex-row align-items-center ms-auto">
          @if(isset($menuHorizontal))
          <!-- Search -->
          <!-- <li class="nav-item navbar-search-wrapper me-1 me-xl-0">
            <a class="nav-link search-toggler fw-normal" href="javascript:;">
              <i class="mdi mdi-magnify mdi-24px scaleX-n1-rtl"></i>
            </a>
          </li> -->
          <!-- /Search -->
          @endif
          <!-- Language -->
          <!-- <li class="nav-item dropdown-language dropdown me-1 me-xl-0">
            <a class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" href="javascript:;" data-bs-toggle="dropdown">
              <i class='mdi mdi-translate mdi-24px'></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <a class="dropdown-item {{ app()->getLocale() === 'en' ? 'active' : '' }}" href="{{url('lang/en')}}" data-language="en" data-text-direction="ltr">
                  <span class="align-middle">English</span>
                </a>
              </li>
              <li>
                <a class="dropdown-item {{ app()->getLocale() === 'fr' ? 'active' : '' }}" href="{{url('lang/fr')}}" data-language="fr" data-text-direction="ltr">
                  <span class="align-middle">French</span>
                </a>
              </li>
              <li>
                <a class="dropdown-item {{ app()->getLocale() === 'ar' ? 'active' : '' }}" href="{{url('lang/ar')}}" data-language="ar" data-text-direction="rtl">
                  <span class="align-middle">Arabic</span>
                </a>
              </li>
              <li>
                <a class="dropdown-item {{ app()->getLocale() === 'de' ? 'active' : '' }}" href="{{url('lang/de')}}" data-language="de" data-text-direction="ltr">
                  <span class="align-middle">German</span>
                </a>
              </li>
            </ul>
          </li> -->
          <!--/ Language -->

          @if($configData['hasCustomizer'] == true)
          <!-- Style Switcher -->
          <!-- <li class="nav-item dropdown-style-switcher dropdown me-2 me-xl-0">
            <a class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" href="javascript:;" data-bs-toggle="dropdown">
              <i class='mdi mdi-24px'></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end dropdown-styles">
              <li>
                <a class="dropdown-item" href="javascript:;" data-theme="light">
                  <span class="align-middle"><i class='mdi mdi-weather-sunny me-2'></i>Light</span>
                </a>
              </li>
              <li>
                <a class="dropdown-item" href="javascript:;" data-theme="dark">
                  <span class="align-middle"><i class="mdi mdi-weather-night me-2"></i>Dark</span>
                </a>
              </li>
              <li>
                <a class="dropdown-item" href="javascript:;" data-theme="system">
                  <span class="align-middle"><i class="mdi mdi-monitor me-2"></i>System</span>
                </a>
              </li>
            </ul>
          </li> -->
          <!--/ Style Switcher -->
          @endif

          <!-- Notification -->
          <!-- <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
            <a class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" href="javascript:;" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
              <i class="mdi mdi-bell-outline mdi-24px"></i>
              <span class="position-absolute top-0 start-50 translate-middle-y badge badge-dot bg-danger mt-2 border"></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end py-0">
              <li class="dropdown-menu-header border-bottom">
                <div class="dropdown-header d-flex align-items-center py-3">
                  <h6 class="mb-0 me-auto">Notification</h6>
                  <span class="badge rounded-pill bg-label-primary">8 New</span>
                </div>
              </li>
              <li class="dropdown-notifications-list scrollable-container">
                <ul class="list-group list-group-flush">
                  <li class="list-group-item list-group-item-action dropdown-notifications-item">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <img src="{{ asset('assets/eapl_images/user_1.png') }}" alt class="w-px-40 h-auto rounded-circle">
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">Congratulation Lettie 🎉</h6>
                        <small class="text-truncate text-body">Won the monthly best seller gold badge</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">1h ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <span class="avatar-initial rounded-circle bg-label-danger">CF</span>
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">Charles Franklin</h6>
                        <small class="text-truncate text-body">Accepted your connection</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">12hr ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <img src="#" alt class="w-px-40 h-auto rounded-circle">
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">New Message ✉️</h6>
                        <small class="text-truncate text-body">You have new message from Natalie</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">1h ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <span class="avatar-initial rounded-circle bg-label-success"><i class="mdi mdi-cart-outline"></i></span>
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">Whoo! You have new order 🛒 </h6>
                        <small class="text-truncate text-body">ACME Inc. made new order $1,154</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">1 day ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <img src="#" alt class="w-px-40 h-auto rounded-circle">
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">Application has been approved 🚀 </h6>
                        <small class="text-truncate text-body">Your ABC project application has been approved.</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">2 days ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <span class="avatar-initial rounded-circle bg-label-success"><i class="mdi mdi-chart-pie-outline"></i></span>
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">Monthly report is generated</h6>
                        <small class="text-truncate text-body">July monthly financial report is generated </small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">3 days ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <img src="#" alt class="w-px-40 h-auto rounded-circle">
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">Send connection request</h6>
                        <small class="text-truncate text-body">Peter sent you connection request</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">4 days ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <img src="#" alt class="w-px-40 h-auto rounded-circle">
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1 text-truncate">New message from Jane</h6>
                        <small class="text-truncate text-body">Your have new message from Jane</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">5 days ago</small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                    <div class="d-flex gap-2">
                      <div class="flex-shrink-0">
                        <div class="avatar me-1">
                          <span class="avatar-initial rounded-circle bg-label-warning"><i class="mdi mdi-alert-circle-outline"></i></span>
                        </div>
                      </div>
                      <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                        <h6 class="mb-1">CPU is running high</h6>
                        <small class="text-truncate text-body">CPU Utilization Percent is currently at 88.63%,</small>
                      </div>
                      <div class="flex-shrink-0 dropdown-notifications-actions">
                        <small class="text-muted">5 days ago</small>
                      </div>
                    </div>
                  </li>
                </ul>
              </li>
              <li class="dropdown-menu-footer border-top p-2">
                <a href="javascript:;" class="btn btn-primary d-flex justify-content-center">
                  View all notifications
                </a>
              </li>
            </ul>
          </li> -->
          <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
            <a class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="offcanvas" data-bs-target="#notification_tab">
              <i class="mdi mdi-bell-outline mdi-24px"></i>
              <span class="position-absolute top-0 start-50 translate-middle-y badge badge-dot bg-danger mt-2 border"></span>
            </a>
          </li>
          <!--/ Notification -->

          <!-- User -->
          <li class="nav-item navbar-dropdown dropdown-user dropdown">
            <a class="nav-link dropdown-toggle hide-arrow" href="javascript:;" data-bs-toggle="dropdown">
              <div class="avatar avatar-online">
                <img src="{{ Auth::user() ? Auth::user()->profile_photo_url : asset('assets/phdizone_images/admin.png') }}" alt class="w-px-40 h-px-40 rounded-circle border border-gray-400">
              </div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <a class="dropdown-item" href="{{ Route::has('profile.show') ? route('profile.show') : url('pages/profile-user') }}">
                  <div class="d-flex">
                    <div class="flex-shrink-0 me-2">
                      <div class="avatar avatar-online">
                        <img src="{{ Auth::user() ? Auth::user()->profile_photo_url : asset('assets/phdizone_images/admin.png') }}" alt class="w-px-40 h-px-40 rounded-circle">
                      </div>
                    </div>
                    <div class="flex-grow-1">
                      <span class="fw-medium d-block">Muthumari A</span>
                      <small class="text-muted">Super Admin</small>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <div class="dropdown-divider"></div>
              </li>
              <li>
                <a class="dropdown-item" href="javascript:;">
                  <i class="mdi mdi-account-outline me-2"></i>
                  <span class="align-middle">My Profile</span>
                </a>
              </li>
              <li>
                <a class="dropdown-item" href="{{url('/')}}">
                  <i class='mdi mdi-logout me-2'></i>
                  <span class="align-middle">Logout</span>
                </a>
              </li>
            </ul>
          </li>
          <!--/ User -->
        </ul>
      </div>

      <!-- Search Small Screens -->
      <div class="navbar-search-wrapper search-input-wrapper {{ isset($menuHorizontal) ? $containerNav : '' }} d-none">
        <input type="text" class="form-control search-input {{ isset($menuHorizontal) ? '' : $containerNav }} border-0" placeholder="Search..." aria-label="Search...">
        <i class="mdi mdi-close search-toggler cursor-pointer"></i>
      </div>
      @if(!isset($navbarDetached))
    </div>
    @endif
  </nav>
  <!-- / Navbar -->

  <!--begin:: Notification Offcanvan-->
  <div class="offcanvas offcanvas-end" id="notification_tab" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="offcanvas-header border-bottom d-block bg-label-secondary">
      <div class="d-flex align-items-center justify-content-between mb-3">
        <div class="d-flex align-items-center gap-1">
          <h5 class="offcanvas-title text-dark fw-bold">Notifications</h5>
          <span class="badge rounded-pill bg-dark text-white">3 New</span>
        </div>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="d-flex align-items-center justify-content-between">
        <label>
          <span class="fs-6 fw-semibold text-black">Clear All</span>
        </label>
        <label>
          <span class="fs-6 fw-semibold text-black">Mark all as read</span>
        </label>
      </div>
    </div>
    <div class="offcanvas-body flex-grow-1">
      <ul class="list-group list-group-flush list-unstyled scrollable-container">
        <li class="list-group-item list-group-item-action bg-label-success rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-multiple-outline fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                <div class="text-secondary fs-8 fw-semibold">New Lead Created</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">Just Now</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
        <li class="list-group-item list-group-item-action rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-cash-outline fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Customer</a>
                <div class="text-secondary fw-semibold fs-8">New Payment Made</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">5 Mins ago</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
        <li class="list-group-item list-group-item-action rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-outline fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Customer</a>
                <div class="text-secondary fw-semibold fs-8">Lead Converted to Customer</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">10 Mins ago</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
        <li class="list-group-item list-group-item-action rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-book fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Course</a>
                <div class="text-secondary fw-semibold fs-8">New Course Created</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">1 Hr ago</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
      </ul>
    </div>
  </div>
  <!--end:: Notification Offcanvan-->