@extends('layouts/layoutMaster')
@section('style')
@section('title', 'General Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection


@section('content')


<!-- Users List Table -->
<div class="card">
  <div class="card-header border-bottom pb-1">
    <h5 class="card-title mb-1">General Settings</h5>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
        </li>
        <span class="text-black opacity-75 me-1 ms-1">
          <i class="mdi mdi-arrow-right-thin fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Settings</a>
        </li>
      </ol>
    </nav>
  </div>
  <div class="card-body">
    <form id="validationForm" class="needs-validation" novalidate method="POST"
      action="{{ route('general_settings_update') }}" enctype="multipart/form-data">
      @csrf
      <div class="row">
        <div class="col-lg-6">
          <div class="row">
            <label class="col-lg-6 text-black fs-6 fw-semibold">Logo<span class="text-danger">*</span></label>
            <div class="col-lg-6">
              <div class="align-items-sm-center gap-4">
                  @if($logoUrl)
                  <img src="{{ $logoUrl }}" alt="Logo"
                      class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                      id="uploadedlogo" />
                  @else
                  <img src="{{asset('assets/phdizone_images/phdizone_icon.png')}}" alt="user-avatar" class="w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                  @endif
                <div class="button-wrapper">
                  <div class="d-flex align-items-start mt-2 mb-2">
                    <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                      <i class="mdi mdi-tray-arrow-up"></i>
                      <input type="file" name="logo" id="upload" class="file-in" hidden accept="image/png, image/jpeg" />
                    </label>
                    <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                      <i class="mdi mdi-reload"></i>
                    </button>
                  </div>
                  <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="row">
            <label class="col-lg-6 text-black fs-6 fw-semibold">Fav Icon<span class="text-danger">*</span></label>
            <div class="col-lg-6">
              <div class="align-items-sm-center gap-4">
                @if($favUrl)
                  <img src="{{ $favUrl }}" alt="Favicon"
                    class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                    id="uploadedFavicon" />
                @else
                <img src="{{asset('assets/phdizone_images/phdizone_fav_icon.png')}}" alt="Fav Icon" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="uploadedFavicon" />
                @endif
                <div class="button-wrapper">
                  <div class="d-flex align-items-start mt-2 mb-2">
                    <label for="fav_upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Fav Icon">
                      <i class="mdi mdi-tray-arrow-up"></i>
                      <input type="file" name="fav_icon" id="fav_upload" class="fav_file-in" hidden accept="image/png, image/jpeg" />
                    </label>
                    <button type="button" class="btn btn-sm btn-outline-danger fav_file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Fav Icon">
                      <i class="mdi mdi-reload"></i>
                    </button>
                  </div>
                  <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row mt-2 mb-2">
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Title<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" value="{{ $title ?? '' }}" required />
          <div class="invalid-feedback">Please enter the Title.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Website (URL)<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Website (URL)" id="" name="url"  value="{{ $url ?? '' }}" required />
          <div class="invalid-feedback">Please enter the Website (URL).</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Email ID" value="{{ $email_id ?? '' }}" required  id="emailid" name="email_id" />
          <div class="invalid-feedback">Please enter the Email ID.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Phone No<span class="text-danger">*</span></label>
          <input type="text" class="form-control" value="{{ $phone_number ?? '' }}" required id="phoneno" name="phone_number" placeholder="Enter Phone No"  />
          <div class="invalid-feedback">Please enter the Phone No.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Mobile No<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Mobile No" id="mobileno" name="mobile_number" value="{{ $mobile_number ?? '' }}" required />
          <div class="invalid-feedback">Please enter the Mobile No.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Whatsapp No<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Whatsapp No" id="whatsappno" name="whatsapp_number" value="{{ $whatsapp_number ?? '' }}" required />
          <div class="invalid-feedback">Please enter the Whatsapp No.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Date Format<span class="text-danger">*</span></label>
          <select class="select3 form-select" name="date_format" id="date_format">
            <option value="">Select Date Format</option>
            <option value="d-m-Y" <?php if ($date_format=='d-m-Y' ) { echo 'selected' ; } else { echo '' ; }
                ?>>dd-mm-yyyy</option>

            <option value="Y-m-d" <?php if ($date_format=='Y-m-d' ) { echo 'selected' ; } else { echo '' ; }
                ?>>yyyy-mm-dd</option>

            <option value="Y/m/d" <?php if ($date_format=='Y/m/d' ) { echo 'selected' ; } else { echo '' ; }
                ?>>yyyy/mm/dd</option>

            <option value="d-M-Y" <?php if ($date_format=='d-M-Y' ) { echo 'selected' ; } else { echo '' ; }
                ?>>dd-mmm-yyyy</option>

            <option value="d/M/Y" <?php if ($date_format=='d/M/Y' ) { echo 'selected' ; } else { echo '' ; }
                ?>>dd/mmm/yyyy</option>
          </select>
          <div class="invalid-feedback">Please Select Date Format</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Registered Name<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="" name="registered_name" placeholder="Enter Registered Name" value="{{ $registered_name ?? '' }}" required />
          <div class="invalid-feedback">Please enter the Registered Name.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="" name="tax_no" placeholder="Enter Tax No"
                        value="{{ $tax_no ?? '' }}" required />
                    <div class="invalid-feedback">Please enter the Tax No.</div>
        </div>
        <div class="col-lg-4 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
          <select class="select3 form-select" id="countryId" name="country">
            <option value="">Select Country</option>
          </select>
          <div class="invalid-feedback">Please Select Country</div>
        </div>
        <div class="col-lg-4 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
          <select class="select3 form-select" id="stateId" name="state">
            <option value="">Select State</option>
          </select>
          <div class="invalid-feedback">Please Select State</div>
        </div>
        <div class="col-lg-4 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
          <select class="select3 form-select" id="cityId" name="city">
            <option value="">Select City</option>
          </select>
          <div class="invalid-feedback">Please Select City</div>
        </div>
        <div class="col-lg-4 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
          <textarea class="form-control h-auto"id="" name="address"
             placeholder="Enter Area /Street">{{ $address ?? '' }}</textarea>
             <div class="invalid-feedback">Please enter Area /Street.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="" name="pincode" placeholder="Enter Pincode"
                        value="{{ $pincode ?? '' }}" required />
                    <div class="invalid-feedback">Please enter the Pincode.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Lead Bank Count<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="" name="lead_bank_count" 
          oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
           placeholder="Enter Lead Bank Count" value="{{ $lead_bank_count ?? '' }}"  required />
           <div class="invalid-feedback">Lead Bank Count Required.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Payment Remainder Days<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="" name="pay_rem_day" placeholder="Enter Payment Remainder Days" value="{{ $payment_remainder ?? '' }}"
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                        required />
                    <div class="invalid-feedback">Payment Remainder Days Required.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Hot Lead Limit<span class="text-danger">*</span></label>
          <input type="text" class="form-control"  id="" name="hot_lead_limit" placeholder="Enter Hot Lead Limit" value="{{ $hot_lead_limit ?? '' }}"
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                        required />
                    <div class="invalid-feedback">Hot Lead Limit Required.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Hot Lead Hold Days<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="" name="hot_lead_days" placeholder="Enter Hot Lead Hold Days" value="{{ $hot_lead_days ?? '' }}"
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                        required />
                        <div class="invalid-feedback">Hot Lead Days Required.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Twitter<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Twitter" id="twitter" name="twitter"  value="{{ $twitter_link ?? '' }}" />
          <div class="invalid-feedback">Twitter is Required.</div>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Pinterest<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Pinterest" id="pinterest" name="pinterest" value="{{ $pinterest_link ?? '' }}" />
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">LinkedIn<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter LinkedIn" id="linkedin" name="linkedin" value="{{ $linkedin_link ?? '' }}" />
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Youtube<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="youtube" name="youtube" placeholder="Enter Youtube"
              value="{{ $youtube_link ?? '' }}" />
        </div>
      </div>
      <div class="d-flex justify-content-end align-items-center mt-4">
        <button type="reset" class="btn btn-secondary me-2">Cancel</button>
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
</style>
<script>
    const form = document.getElementById('validationForm');
const emailInput = document.getElementById('emailid');
const phoneInput = document.getElementById('phoneno');
const mobileInput = document.getElementById('mobileno');
const whatsappInput = document.getElementById('whatsappno');

emailInput.addEventListener('input', function(event) {
    if (!validateEmail(emailInput.value)) {
        displayError(emailInput, "Please enter a valid email address.");
    } else {
        clearError(emailInput);
    }
});

phoneInput.addEventListener('input', function(event) {
    if (!validatePhoneNumber(phoneInput.value)) {
        displayError(phoneInput, "Please enter a 10-digit phone number.");
    } else {
        clearError(phoneInput);
    }
});

form.addEventListener('submit', function(event) {
    event.preventDefault();

    if (!form.checkValidity() || !validateEmail(emailInput.value)) {
        displayError(emailInput, "Please enter a valid email address.");
        event.stopPropagation();
    } else if (!validatePhoneNumber(phoneInput.value)) {
        displayError(phoneInput, "Please enter a 10-digit phone number.");
        event.stopPropagation();
    } else {
        form.submit();
        toastr.success('General Setting updated successfully!');
    }

    form.classList.add('was-validated');
});

function validateEmail(email) {
    const emailRegex =
        /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return emailRegex.test(email);
}

function validatePhoneNumber(phoneNumber) {
    // Remove non-numeric characters from phone number
    const numericPhoneNumber = phoneNumber.replace(/\D/g, '');
    return numericPhoneNumber.length === 10; // Assuming you want exactly 10 digits
}

function displayError(input, message) {
    const feedbackElement = input.nextElementSibling;
    feedbackElement.innerText = message;
    input.classList.add('is-invalid');
}

function clearError(input) {
    const feedbackElement = input.nextElementSibling;
    feedbackElement.innerText = "";
    input.classList.remove('is-invalid');
}
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
    const logoFileInput = document.querySelector('.file-in');
    const logoResetButton = document.querySelector('.file-reset');
    const faviconFileInput = document.querySelector('.fav_file-in');
    const faviconResetButton = document.querySelector('.fav_file-reset');

    // Function to reset logo image and input
    logoResetButton.addEventListener('click', function() {
        const logoImage = document.getElementById('uploadedlogo');
        const resetLogoImage = "{{ $logoUrl }}"; // Replace with the initial logo path
        logoImage.src = resetLogoImage;
        logoFileInput.value = null;
    });

    // Function to reset favicon image and input
    faviconResetButton.addEventListener('click', function() {
        const faviconImage = document.getElementById('fav_uploadedlogo');
        const resetFaviconImage =
            "{{ asset('assets/eapl_images/ea_favicon.png') }}"; // Replace with the initial favicon path
        faviconImage.src = resetFaviconImage;
        faviconFileInput.value = null;
    });

    // Function to preview logo image
    logoFileInput.addEventListener('change', function() {
        const logoImage = document.getElementById('uploadedlogo');
        if (this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                logoImage.src = e.target.result;
            };
            reader.readAsDataURL(this.files[0]);
        }
    });

    // Function to preview favicon image
    faviconFileInput.addEventListener('change', function() {
        const faviconImage = document.getElementById('fav_uploadedlogo');
        if (this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                faviconImage.src = e.target.result;
            };
            reader.readAsDataURL(this.files[0]);
        }
    });
});
</script>
<script>
    $(document).ready(function() {
        $.ajax({
            url: "{{ route('time_zone') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    // Populate the select dropdown with fetched time zones
                    var selectDropdown = $('select[name="time_zone"]');
                    selectDropdown.empty();
                    selectDropdown.append($('<option value="">Select Time Zone</option>'));
                    response.data.forEach(function(t) {
                        var optionText = t.country + " (UTC " + t.utc_offset + ")";
                        var optionElement = $('<option></option>').attr('value', t.sno).text(optionText);
                        selectDropdown.append(optionElement);
                    });

                    // Set the selected option based on the passed time_zone value
                    var selectedTimeZone = {{ $time_zone }};
                    if (selectedTimeZone) {
                        selectDropdown.val(selectedTimeZone);
                    }
                }
            },
            error: function(error) {
                console.error('Error fetching time zones:', error);
            }
        });
    });

    $(document).ready(function() {
        $.ajax({
            url: "{{ route('currency_format') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    // Populate the select dropdown with fetched time zones
                    var selectDropdown = $('select[name="currency_format"]');
                    selectDropdown.empty();
                    selectDropdown.append($('<option value="">Select Currency Format</option>'));
                    response.data.forEach(function(t) {
                        var optionText = t.currency_code + " - " + t.currency_symbol;
                        var optionElement = $('<option></option>').attr('value', t.sno).text(optionText);
                        selectDropdown.append(optionElement);
                    });

                    // Set the selected option based on the passed time_zone value
                    var selectedCurrency = {{ $currency_format }};
                    if (selectedCurrency) {
                        selectDropdown.val(selectedCurrency);
                    }
                }
            },
            error: function(error) {
                console.error('Error fetching time zones:', error);
            }
        });
    });
</script>
<script>
    $(document).ready(function() {
        var selectedCountryId = "{{ $country }}";
        var selectedStateId = "{{ $state }}";
        var selectedCityId = "{{ $city }}";

        // Fetch and populate countries
        $.ajax({
            url: "{{ route('country') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdown = $('select[name="country"]');
                    countryDropdown.empty();
                    countryDropdown.append('<option value="">Select Country</option>');
                    response.data.forEach(function(country) {
                        countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                    });
                    countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });

        // Event listener for country change
        $('select[name="country"]').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('select[name="state"]');
            var cityDropdown = $('select[name="city"]');

            stateDropdown.empty().append('<option value="">Select State</option>');
            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('state') }}",
                    type: "GET",
                    data: { country_id: countryId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                            });
                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // Event listener for state change
        $('select[name="state"]').on('change', function() {
            var stateId = $(this).val();
            var countryId = $('select[name="country"]').val();
            var cityDropdown = $('select[name="city"]');

            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId && stateId) {
                // Fetch and populate cities based on selected state and country
                $.ajax({
                    url: "{{ route('city') }}",
                    type: "GET",
                    data: { country_id: countryId, state_id: stateId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(city) {
                                cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                            });
                            cityDropdown.val(selectedCityId); // Set the selected city
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });
    });

</script>

@endsection