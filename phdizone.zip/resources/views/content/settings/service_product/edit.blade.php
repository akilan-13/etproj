@extends('layouts/layoutMaster')

@section('title', 'Update Service Product')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection


@section('content')
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Service Product</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Settings</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Services</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Service Properties</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
                <select id="ser_cat" class="select3 form-select">
                    <option value="">Select Service Category</option>
                    <option value="1">Reasearch Services</option>
                    <option value="2" selected>PHD Services</option>
                    <option value="3">Writing Services</option>
                    <option value="4">Development Services</option>
                    <option value="5">Analysis Services</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
                <select id="ser_sub_cat" class="select3 form-select">
                    <option value="">Select Service Sub Category</option>
                    <option value="1">Research Paper Writing Service </option>
                    <option value="2">Book Writing Service</option>
                    <option value="3">Scopus Indexed Journal </option>
                    <option value="4" selected>Thesis Writing Services</option>
                    <option value="5">SPSS Analysis</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3 d-flex align-items-center">
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input" type="checkbox" name="service_check" id="service_check" onclick="service_product_func_add();" checked />
                    <label class="text-dark mb-1 fs-6 fw-semibold" checked>Add Product</label>
                </div>
            </div>
        </div>
        <div class="row mt-4" id="service_properties">
            <div class="form-repeater_service_question">
                <div data-repeater-list="group-a_service_question">
                    <div data-repeater-item>
                        <div class="row">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Property Label" value="Pages" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Input Type<span class="text-danger">*</span></label>
                                        <select id="question_cat" name="question_cat" class="select3 form-select" onchange="Question_func();">
                                            <option>Select Question Type</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box" selected>List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service">
                                                            <div data-repeater-list="group-a_service">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_radio_button" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_radio">
                                                            <div data-repeater-list="group-a_service_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_list_box">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_list_box_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">100 Pages</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 2
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">200 Pages</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 3
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">300 Pages</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Mandatory</label>
                                            <input class="form-check-input" type="checkbox" name="service_check" id="service_check" checked />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <!-- <div class="row">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Property Label" value="Language" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Input Type<span class="text-danger">*</span></label>
                                        <select id="question_cat_id" name="question_cat_id" class="select3 form-select" onchange="Question_func();">
                                            <option>Select Question Type</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box" selected>List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service">
                                                            <div data-repeater-list="group-a_service">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_radio_button" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_radio">
                                                            <div data-repeater-list="group-a_service_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_list_box">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_list_box_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Python</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 2
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Java</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 3
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">VLSI</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 4
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Embedded</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Mandatory</label>
                                            <input class="form-check-input" type="checkbox" name="service_check" id="service_check" checked />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div> -->
                        <!-- <div class="row">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Property Label" value="Domain" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Input Type<span class="text-danger">*</span></label>
                                        <select id="domain" name="domain" class="select3 form-select" onchange="Question_func();">
                                            <option>Select Question Type</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box" selected>List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service">
                                                            <div data-repeater-list="group-a_service">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_radio_button" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_radio">
                                                            <div data-repeater-list="group-a_service_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_list_box">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_list_box_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Data Mining</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 2
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Image Processing</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 3
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Cloud Computing</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 4
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Cybersecurity</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Mandatory</label>
                                            <input class="form-check-input" type="checkbox" name="service_check" id="service_check" checked />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Property Label" value="Database" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Input Type<span class="text-danger">*</span></label>
                                        <select id="database" name="database" class="select3 form-select" onchange="Question_func();">
                                            <option>Select Question Type</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button" selected>Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service">
                                                            <div data-repeater-list="group-a_service">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_radio_button">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_radio">
                                                            <div data-repeater-list="group-a_service_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Yes</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">No</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_list_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_acrd_list_box_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Data Mining</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 2
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Image Processing</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 3
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Cloud Computing</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 4
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Cybersecurity</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Mandatory</label>
                                            <input class="form-check-input" type="checkbox" name="service_check" id="service_check" checked />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div> -->
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-check form-check-inline mb-1">
                                            <input class="form-check-input cred_check" type="checkbox" id="depends_id" name="depends_id" onclick="depends_func();" checked />
                                            <label class="text-dark fs-6 fw-semibold">Depends<span class="text-danger" id="depends_danger">*</span></label>
                                        </div>
                                        <div id="depends_tbox">
                                            <select id="" class="select3 form-select">
                                                <option value="">Select Label</option>
                                                <option value="100_page" selected>100 Pages</option>
                                                <option value="200_page">200 Pages</option>
                                                <option value="300_page">300 Pages</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Property Label" value="Amount" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="question_opt_amt" name="question_opt_amt" class="select3 form-select" onchange="Question_opt_func();">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt">
                                                            <div data-repeater-list="group-a_service">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_radio_button" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt_radio">
                                                            <div data-repeater-list="group-a_service_opt_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_list_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd_list_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del_list" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-check form-check-inline mb-1">
                                            <input class="form-check-input cred_check" type="checkbox" id="depends_id" name="depends_id" onclick="depends_func();" checked />
                                            <label class="text-dark fs-6 fw-semibold">Depends<span class="text-danger" id="depends_danger">*</span></label>
                                        </div>
                                        <div id="depends_tbox">
                                            <select id="" class="select3 form-select">
                                                <option value="">Select Label</option>
                                                <option value="100_page" selected>100 Pages</option>
                                                <option value="200_page">200 Pages</option>
                                                <option value="300_page">300 Pages</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Property Label" value="Working Days" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="question_opt" name="question_opt" class="select3 form-select" onchange="Question_opt_func();">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt">
                                                            <div data-repeater-list="group-a_service">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_radio_button" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt_radio">
                                                            <div data-repeater-list="group-a_service_opt_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_list_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd_list_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del_list" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-check form-check-inline mb-1">
                                            <input class="form-check-input cred_check" type="checkbox" id="depends_id" name="depends_id" onclick="depends_func();" checked />
                                            <label class="text-dark fs-6 fw-semibold">Depends<span class="text-danger" id="depends_danger">*</span></label>
                                        </div>
                                        <div id="depends_tbox">
                                            <select id="" class="select3 form-select">
                                                <option value="">Select Label</option>
                                                <option value="100_page" selected>100 Pages</option>
                                                <option value="200_page">200 Pages</option>
                                                <option value="300_page">300 Pages</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Property Label" value="Working Hours" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="question_opt_hrs" name="question_opt_hrs" class="select3 form-select" onchange="Question_opt_func();">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt">
                                                            <div data-repeater-list="group-a_service">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_radio_button" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt_radio">
                                                            <div data-repeater-list="group-a_service_opt_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="service_opt_list_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="service_opt_acrd_list_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="service_opt_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_opt_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_service_opt_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_opt_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_opt_butt_del_list" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary service_opt_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4" style="display:none;" id="list_properties">
                <div class="form-repeater_service_opt_question">
                    <div data-repeater-list="group-a_service_opt_question">
                        <div data-repeater-item>
                            <div class="row">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Property Label<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="" placeholder="Enter Property Label" />
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Input Type<span class="text-danger">*</span></label>
                                            <select id="question_cat1" name="question_cat1" class="select3 form-select" onchange="Question_func();">
                                                <option>Select Question Type</option>
                                                <option value="text_field">Text Field</option>
                                                <option value="check_box">Check Box</option>
                                                <option value="radio_button">Radio Button</option>
                                                <option value="list_box">List Box</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-4 mb-3" id="service_check_box" style="display: none !important;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                            <div class="accordion" id="service_acrd">
                                                <div class="accordion-item mb-2">
                                                    <h2 class="accordion-header" id="service_acrd">
                                                        <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                        </button>
                                                    </h2>
                                                    <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd">
                                                        <div class="accordion-body">
                                                            <div class="form-repeater_service">
                                                                <div data-repeater-list="group-a_service">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                    <span class="text-danger">*</span>
                                                                                    <input class="form-check-input" type="checkbox" name="option_check" id="option_check" onclick="option_func();" />
                                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Depends</label>
                                                                                </label>
                                                                                <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="mb-1 mt-1">
                                                                <button class="btn btn-primary service_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add">
                                                                    <i class="mdi mdi-plus me-1"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 mb-3" id="service_radio_button" style="display: none !important;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                            <div class="accordion" id="service_acrd_radio">
                                                <div class="accordion-item mb-2">
                                                    <h2 class="accordion-header" id="service_acrd_radio">
                                                        <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                        </button>
                                                    </h2>
                                                    <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_radio">
                                                        <div class="accordion-body">
                                                            <div class="form-repeater_service_radio">
                                                                <div data-repeater-list="group-a_service_radio">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_radio" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="mb-1 mt-1">
                                                                <button class="btn btn-primary service_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_radio">
                                                                    <i class="mdi mdi-plus me-1"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 mb-3" id="service_list_box" style="display: none !important;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                            <div class="accordion" id="service_acrd_list_box_box">
                                                <div class="accordion-item mb-2">
                                                    <h2 class="accordion-header" id="service_acrd_list_box">
                                                        <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                        </button>
                                                    </h2>
                                                    <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#service_acrd_list_box">
                                                        <div class="accordion-body">
                                                            <div class="form-repeater_service_list">
                                                                <div data-repeater-list="group-a_led_list">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_list" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="mb-1 mt-1">
                                                                <button class="btn btn-primary service_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_list">
                                                                    <i class="mdi mdi-plus me-1"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 mb-3 align-items-center">
                                            <div class="form-check form-check-inline mt-4">
                                                <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Mandatory</label>
                                                <input class="form-check-input" type="checkbox" name="service_check" id="service_check" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1 px-1 py-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-1 mt-1">
                    <button class="btn btn-primary service_opt_butt_add_Question" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_opt_butt_add_Question">
                        <i class="mdi mdi-plus me-1"></i>
                    </button>
                </div>
            </div>
            <div class="mb-1 mt-1">
                <button class="btn btn-primary service_butt_add_Question" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_Question">
                    <i class="mdi mdi-plus me-1"></i>
                </button>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
            <a href="{{url('/settings/counsellor')}}" class="btn btn-secondary me-3">Cancel</a>
            <a href="{{url('/settings/counsellor')}}" class="btn btn-primary">Create Service Properties</a>
        </div>
    </div>
</div>

<script>
    function depends_func() {
        var depends_id = document.getElementById("depends_id");
        var depends_danger = document.getElementById("depends_danger");
        var depends_tbox = document.getElementById("depends_tbox");

        if (depends_id.checked) {
            // depends.style.display = "block";
            depends_danger.style.display = "inline";
            depends_tbox.style.display = "block";
        } else {
            depends_danger.style.display = "none";
            depends_tbox.style.display = "none";
        }
    }
</script>

<script>
    function service_product_func_add() {
        var service_check = document.getElementById("service_check");
        var service_properties = document.getElementById("service_properties");

        if (service_check.checked) {
            service_properties.style.display = "block";
        } else {
            service_properties.style.display = "none";
        }
    }
</script>

<script>
    function Question_func() {
        var question_cat = document.getElementById("question_cat").value;
        var service_check_box = document.getElementById("service_check_box");
        var service_radio_button = document.getElementById("service_radio_button");
        var service_list_box = document.getElementById("service_list_box");

        if (question_cat == "check_box") {
            service_check_box.style.display = "block";
            service_radio_button.style.display = "none";
            service_list_box.style.display = "none";
        } else if (question_cat == "radio_button") {
            service_check_box.style.display = "none";
            service_radio_button.style.display = "block";
            service_list_box.style.display = "none";
        } else if (question_cat == "list_box") {
            service_check_box.style.display = "none";
            service_radio_button.style.display = "none";
            service_list_box.style.display = "block";
        } else {
            service_check_box.style.display = "none";
            service_radio_button.style.display = "none";
            service_list_box.style.display = "none";
        }
    }
</script>
<script>
    $('.service_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_service').length);
        let $clone = $('.form-repeater_service').first().clone().hide();
        $clone.insertBefore('.form-repeater_service:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service .service_butt_del', e => {
        var bt = parseFloat($('.service_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_butt_add_radio').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_radio').length);
        let $clone = $('.form-repeater_service_radio').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_radio:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_radio').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_radio').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_radio .service_butt_del_radio', e => {
        var bt = parseFloat($('.service_butt_del_radio').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_radio').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_radio').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_butt_add_list').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_list').length);
        let $clone = $('.form-repeater_service_list').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_list:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_list').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_list').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_list .service_butt_del_list', e => {
        var bt = parseFloat($('.service_butt_del_list').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_list').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_list').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_question').length);
        let $clone = $('.form-repeater_service_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_question:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_question .service_butt_del_question', e => {
        var bt = parseFloat($('.service_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>
@endsection