@extends('layouts/layoutMaster')

@section('title', 'Accounts Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection


@section('content')
<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_ledger" aria-controls="tab_ledger" aria-selected="true">Ledger</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_sub_ledger" aria-controls="tab_sub_ledger" aria-selected="false">Sub Ledger</button>
        </li>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
          <div class="tab-pane fade show active" id="tab_ledger" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_ledger">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Ledger
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Ledger</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Expense</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Income</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_sub_ledger" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_sub_ledger">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Sub Ledger
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-125px">Ledger</th>
                      <th class="min-w-150px">Sub Ledger</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Expense</td>
                      <td>
                        <label>Rent Expense</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Expense</td>
                      <td>
                        <label>Salary Expense</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Income</td>
                      <td>
                        <label>Cost of goods sold Income</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Income</td>
                      <td>
                        <label>By Subscriptions Income</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_sub_ledger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!--begin::Modal - Add Ledger-->
<div class="modal fade" id="kt_modal_add_ledger" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Ledger</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ledger Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Ledger Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Ledger</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Ledger-->
<!--begin::Modal - Edit Ledger-->
<div class="modal fade" id="kt_modal_edit_ledger" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Ledger</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ledger Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Ledger Name" value="Expense" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Ledger</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Ledger-->
<!--begin::Modal - Delete Ledger-->
<div class="modal fade" id="kt_modal_delete_ledger" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Ledger ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Ledger-->




<!--begin::Modal - Add Sub Ledger-->
<div class="modal fade" id="kt_modal_add_sub_ledger" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Sub Ledger</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ledger<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Ledger</option>
              <option value="1">Expense</option>
              <option value="2">Income</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Sub Ledger Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Sub Ledger Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Sub Ledger</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Sub Ledger-->
<!--begin::Modal - Edit Sub Ledger-->
<div class="modal fade" id="kt_modal_edit_sub_ledger" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Sub Ledger</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ledger<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Ledger</option>
              <option value="1" selected>Expense</option>
              <option value="2">Income</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Sub Ledger Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Sub Ledger Name" value="Rent Expense" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Sub Ledger</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Sub Ledger-->
<!--begin::Modal - Delete Sub Ledger-->
<div class="modal fade" id="kt_modal_delete_sub_ledger" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Sub Ledger ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Sub Ledger-->


<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
@endsection