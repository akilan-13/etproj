@extends('layouts/layoutMaster')

@section('title', 'Update Payment Mode Option')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection


@section('content')
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Payment Mode Option</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Settings</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Sales</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Payment Mode Option</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
                <select id="" class="select3 form-select">
                    <option value="">Select Payment Mode</option>
                    <option value="1">Cash</option>
                    <option value="2" selected>Cheque</option>
                    <option value="3">Cashfree</option>
                    <option value="4">Razorpay</option>
                    <option value="5">PayUMoney</option>
                    <option value="6">NetBanking</option>
                    <option value="7">Google Pay</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="form-repeater_payment_mode_option_questions_edit">
                <div data-repeater-list="group-a_payment_mode_option_question_edit">
                    <div data-repeater-item>
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" value="Bank Name" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="payment_mode_option_label_value_edit" name="payment_mode_option_label_value_edit" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="multiple_images">Multiple Images</option>
                                            <option value="date_field">Date Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 payment_mode_option_butt_del_question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="payment_mode_option_butt_del_question_edit">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" value="Account No" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="payment_mode_option_label_value_edit" name="payment_mode_option_label_value_edit" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="multiple_images">Multiple Images</option>
                                            <option value="date_field">Date Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 payment_mode_option_butt_del_question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="payment_mode_option_butt_del_question_edit">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" value="Amount" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="payment_mode_option_label_value_edit" name="payment_mode_option_label_value_edit" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="multiple_images">Multiple Images</option>
                                            <option value="date_field">Date Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 payment_mode_option_butt_del_question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="payment_mode_option_butt_del_question_edit">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" value="Cheque No" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="payment_mode_option_label_value_edit" name="payment_mode_option_label_value_edit" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="multiple_images">Multiple Images</option>
                                            <option value="date_field">Date Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 payment_mode_option_butt_del_question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="payment_mode_option_butt_del_question_edit">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" value="Cheque Expiery Date" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="payment_mode_option_label_value_edit" name="payment_mode_option_label_value_edit" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="multiple_images">Multiple Images</option>
                                            <option value="date_field" selected>Date Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 payment_mode_option_butt_del_question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="payment_mode_option_butt_del_question_edit">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" value="Cheque Entry Date" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="payment_mode_option_label_value_edit" name="payment_mode_option_label_value_edit" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="multiple_images">Multiple Images</option>
                                            <option value="date_field" selected>Date Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 payment_mode_option_butt_del_question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="payment_mode_option_butt_del_question_edit">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" value="Holder Name" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="payment_mode_option_label_value_edit" name="payment_mode_option_label_value_edit" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field" selected>Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="multiple_images">Multiple Images</option>
                                            <option value="date_field">Date Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" checked />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 payment_mode_option_butt_del_question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="payment_mode_option_butt_del_question_edit">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                    </div>
                </div>
            </div>
            <div class="mb-1 mt-1">
                <button class="btn btn-primary payment_mode_option_butt_add_Question_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="payment_mode_option_butt_add_Question_edit">
                    <i class="mdi mdi-plus me-1"></i>
                </button>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <a href="{{url('/settings/sales')}}" class="btn btn-secondary me-3">Cancel</a>
                <a href="{{url('/settings/sales')}}" class="btn btn-primary">Update Payment Mode Option</a>
            </div>
        </div>
    </div>
</div>


@endsection