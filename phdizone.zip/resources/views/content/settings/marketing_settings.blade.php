@extends('layouts/layoutMaster')

@section('title', 'Marketing Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection

@section('content')
<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_marketing_category" aria-controls="tab_marketing_category" aria-selected="true">Category</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_marketing_type" aria-controls="tab_marketing_type" aria-selected="false">Type</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_marketing_zone" aria-controls="tab_marketing_zone" aria-selected="false">Zone</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_marketing_vendor" aria-controls="tab_marketing_vendor" aria-selected="false">Vendor</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_marketing_compaign_checklist" aria-controls="tab_marketing_compaign_checklist" aria-selected="false">Campaign Checklist</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_time_campaign_status" aria-controls="tab_time_campaign_status" aria-selected="false">Campaign Status</button>
        </li>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
          <div class="tab-pane fade show active" id="tab_marketing_category" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_marketing_category">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Category
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Category</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Physical Marketing
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Digital Marketing
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_marketing_type" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_marketing_tpe">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Type
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Type</th>
                      <th class="min-w-100px">Category</th>
                      <th class="min-w-100px">options</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-gray-600 fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Poster
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      <td>Physical Marketing</td>
                      <td>
                        <label class="align-items-center text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Vendor, Zone, Count">Vendor, Zone, Count</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>FM
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      <td>Physical Marketing</td>
                      <td>
                        <label class="align-items-center text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Vendor, Zone, Count">Vendor, Zone, Count</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_marketing_zone" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_marketing_zone">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Zone
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Branch</th>
                      <th class="min-w-100px">Zone</th>
                      <th class="min-w-100px">Area</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Madurai - Anna Nagar</td>
                      <td>Zone East
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td><label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Andarkottaram, Angadimangalam, Arumbanur, Ayilangudi, Chinnamangalam, Elangiyendal, Idayapatti, Ilamanur, Isalani, Kalimangalam, Kallandhiri">Andarkottaram, Angadimangalam, Arumbanur, Ayilangudi, Chinnamangalam, Elangiyendal, Idayapatti, Ilamanur, Isalani, Kalimangalam, Kallandhiri</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_zone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Chennai - CIT Nagar</td>
                      <td>Zone West
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td><label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Andarkottaram, Angadimangalam, Arumbanur, Ayilangudi, Chinnamangalam, Elangiyendal, Idayapatti, Ilamanur, Isalani, Kalimangalam, Kallandhiri">Andarkottaram, Angadimangalam, Arumbanur, Ayilangudi, Chinnamangalam, Elangiyendal, Idayapatti, Ilamanur, Isalani, Kalimangalam, Kallandhiri</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_zone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_marketing_vendor" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_marketing_vendor">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Vendor
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Vendor</th>
                      <th class="min-w-100px">Contact Person</th>
                      <th class="min-w-150px">Location</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>PHD Center</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td><label>Manoj Kumar</label>
                        <div class="d-block">
                          <label class="badge bg-info text-white fw-semibold fs-8 text-dark">9876543210</label>
                        </div>
                      </td>
                      <td><label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Bharathiyar Street Avaniyapuram madurai-12">Bharathiyar Street Avaniyapuram madurai-12</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_vendor" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_vendor" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>PHD Services</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td><label>Madhan Kumar</label>
                        <div class="d-block">
                          <label class="badge bg-info text-white fw-semibold fs-8 text-dark">9876543210</label>
                        </div>
                      </td>
                      <td><label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Bharathiyar Street Avaniyapuram madurai-12">Bharathiyar Street Avaniyapuram madurai-12</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_vendor" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_marketing_vendor" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_marketing_compaign_checklist" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_campaign_checklist">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Campaign Checklist
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-30px">S.No</th>
                      <th class="min-w-150px">Category</th>
                      <th class="min-w-100px">Type</th>
                      <th class="min-w-100px">Checklist</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Physical Marketing
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Poster
                      </td>
                      <td><label class="text-truncate max-w-120px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Poster Desiging, Poster Printing">Poster Desiging, Poster Printing</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_campaign_checklist" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_campaign_checklist" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Digital Marketing
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Bit Notice
                      </td>
                      <td><label class="text-truncate max-w-120px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Poster Desiging, Poster Printing">Poster Desiging, Poster Printing</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_marketing_campaign_checklist" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_campaign_checklist" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_time_campaign_status" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_campaign_sts">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Campaign Status
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Campaign Status</th>
                      <th class="min-w-100px">Background Color</th>
                      <th class="min-w-100px">Text Color</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Scheduled
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#fdb528</td>
                      <td>#ffffff</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_compaign_status" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_compaign_sts" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Completed
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#fdb528</td>
                      <td>#ffffff</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_compaign_status" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_compaign_sts" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<!--begin::Modal - Add Category-->
<div class="modal fade" id="kt_modal_add_marketing_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Category</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Category" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Category</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Add Category-->
<!--begin::Modal - Edit  Category-->
<div class="modal fade" id="kt_modal_edit_marketing_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Category</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Category" value="Physical Marketing" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Category</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Category-->
<!--begin::Modal - Delete Category-->
<div class="modal fade" id="kt_modal_delete_marketing_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Category ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Country-->




<!--begin::Modal - Add Marketing Type-->
<div class="modal fade" id="kt_modal_add_marketing_tpe" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select category</option>
              <option value="1">Physical Marketing</option>
              <option value="2">Digital marketing</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Type" />
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Vendor</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Zone</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Count</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Payment</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Schedule</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">GST</label>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
          <div class="col-lg-12 mb-3">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Add to Lead Source</label>
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Marketing Type-->
<!--begin::Modal - Edit Marketing Type-->
<div class="modal fade" id="kt_modal_edit_marketing_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update State</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select category</option>
              <option value="1" selected>Physical Marketing</option>
              <option value="2">Digital marketing</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Type" value="poster" />
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" checked>
              <label class="text-dark fs-6 fw-semibold">Vendor</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" checked>
              <label class="text-dark fs-6 fw-semibold">Zone</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" checked>
              <label class="text-dark fs-6 fw-semibold">Count</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Payment</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Schedule</label>
            </div>
          </div>
          <div class="col-lg-4 mb-2 d-flex align-items-center">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">GST</label>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
          <div class="col-lg-12 mb-3">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox">
              <label class="text-dark fs-6 fw-semibold">Add to Lead Source</label>
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update State</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Marketing Type-->
<!--begin::Modal - Delete Marketing Type-->
<div class="modal fade" id="kt_modal_delete_marketing_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Type ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div>

    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Marketing Type-->




<!--begin::Modal - Add Zone-->
<div class="modal fade" id="kt_modal_add_marketing_zone" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Zone</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Branch</option>
              <option value="1">Madurai - Anna Nagar</option>
              <option value="2">Chennai - CIT Nagar</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Zone Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Zone Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Area Name</label>
            <textarea class="form-control" rows="2" id="" placeholder="Enter Area Name"></textarea>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Zone</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Zone-->
<!--begin::Modal - Edit Zone-->
<div class="modal fade" id="kt_modal_edit_marketing_zone" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Zone</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Branch</option>
              <option value="1" selected>Madurai - Anna Nagar</option>
              <option value="2">Chennai - CIT Nagar</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Zone Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Zone Name" value="Zone East" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Area Name</label>
            <textarea class="form-control" rows="2" id="" placeholder="Enter Area Name">Andarkottaram, Angadimangalam, Arumbanur, Ayilangudi, Chinnamangalam, Elangiyendal, Idayapatti, Ilamanur, Isalani, Kalimangalam, Kallandhiri	</textarea>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Zone</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Zone-->
<!--begin::Modal - Delete Zone-->
<div class="modal fade" id="kt_modal_delete_marketing_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Zone ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Zone-->




<!--begin::Modal - Add marketing Vendor-->
<div class="modal fade" id="kt_modal_add_marketing_vendor" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Vendor</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Vendor Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Vendor Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Contact Person Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Mobile No<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Contact Person Mobile No" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Address<span class="text-danger">*</span></label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Address"></textarea>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Vendor</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add marketing Vendor-->
<!--begin::Modal - Edit marketing Vendor-->
<div class="modal fade" id="kt_modal_edit_marketing_vendor" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Vendor</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Vendor Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Vendor Name" value="PHD Center" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Contact Person Name" value="Manoj Kumar
" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Mobile No<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Contact Person Mobile No" value="9876543210" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Address<span class="text-danger">*</span></label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Address">Bharathiyar Street Avaniyapuram madurai-12	</textarea>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Vendor</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit marketing Vendor-->
<!--begin::Modal - Delete marketing Vendor-->
<div class="modal fade" id="kt_modal_delete_marketing_vendor" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Vendor ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete marketing Vendor-->





<!--begin::Modal - Add Campaign Status-->
<div class="modal fade" id="kt_modal_add_campaign_sts" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Campaign Status</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Campaign Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Campaign Status" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Text Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Campaign Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Campaign Status-->
<!--begin::Modal - Edit Campaign Status-->
<div class="modal fade" id="kt_modal_edit_compaign_status" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Campaign Status</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Campaign Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Campaign Status" value="scheduled" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" value="#fdb528" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Text Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" value="#ffffff" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Campaign Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Campaign Status-->
<!--begin::Modal - Delete Campaign Status-->
<div class="modal fade" id="kt_modal_delete_compaign_sts" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Campaign Status ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Campaign Status-->

<!--begin::Modal - Add Campaign Checklist-->
<div class="modal fade" id="kt_modal_add_campaign_checklist" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Campaign Checklist</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select category</option>
              <option value="1">Physical Marketing</option>
              <option value="2">Digital marketing</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Type</option>
              <option value="1">Poster</option>
              <option value="2">Bit Notice</option>
            </select>
          </div>
          <div class="col-lg-12">
            <div class="scroll-y max-h-200px pe-3">
              <div class="row mt-2">
                <div class="form-repeater_marketing_campaign_checklist">
                  <div data-repeater-list="group-a_service_question_service">
                    <div data-repeater-item>
                      <div class="row">
                        <div class="col-lg-10 mb-1">
                          <div class="row">
                            <div class="col-lg-12">
                              <input type="text" class="form-control" id="" placeholder="Enter Work Check List" />
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-2 mb-1">
                          <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 marketing_del_campaign_checklist" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="marketing_del_campaign_checklist" style="display: none !important;">
                            <i class="mdi mdi-delete fs-4"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="mb-1 mt-1">
                  <button class="btn btn-primary marketing_add_campaign_checklist" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="marketing_add_campaign_checklist">
                    <i class="mdi mdi-plus me-1"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Campaign Checklist</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Campaign Checklist-->
<!--begin::Modal - Edit Campaign Checklist-->
<div class="modal fade" id="kt_modal_edit_marketing_campaign_checklist" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Campaign Checklist</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select category</option>
              <option value="1" selected>Physical Marketing</option>
              <option value="2">Digital marketing</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Type</option>
              <option value="1" selected>Poster</option>
              <option value="2">Bit Notice</option>
            </select>
          </div>
          <div class="col-lg-12">
            <div class="scroll-y max-h-200px pe-3">
              <div class="row mt-2">
                <div class="form-repeater_marketing_campaign_checklist_edit">
                  <div data-repeater-list="group-a_service_question_service">
                    <div data-repeater-item>
                      <div class="row">
                        <div class="col-lg-10 mb-1">
                          <div class="row">
                            <div class="col-lg-12">
                              <input type="text" class="form-control" id="" placeholder="Enter Work Check List" value="Poster Desiging" />
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-2 mb-1">
                          <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 marketing_del_campaign_checklist_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="marketing_del_campaign_checklist_edit">
                            <i class="mdi mdi-delete fs-4"></i>
                          </a>
                        </div>
                        <div class="col-lg-10 mb-1">
                          <div class="row">
                            <div class="col-lg-12">
                              <input type="text" class="form-control" id="" placeholder="Enter Work Check List" value="printer Desiging" />
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-2 mb-1">
                          <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 marketing_del_campaign_checklist_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="marketing_del_campaign_checklist_edit">
                            <i class="mdi mdi-delete fs-4"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="mb-1 mt-1">
                  <button class="btn btn-primary marketing_add_campaign_checklist_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="marketing_add_campaign_checklist_edit">
                    <i class="mdi mdi-plus me-1"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Campaign Checklist</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Campaign Checklist-->
<!--begin::Modal - Delete Campaign Checklist-->
<div class="modal fade" id="kt_modal_delete_campaign_checklist" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Campaign Check List ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div>

    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Campaign Checklist-->



<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  $('#facilites_chk_all').change(function() {
    $('.fac_ver_chk').prop('checked', this.checked);
  });

  $('.fac_ver_chk').change(function() {
    if ($('.fac_ver_chk:checked').length == $('.fac_ver_chk').length) {
      $('#facilites_chk_all').prop('checked', true);
    } else {
      $('#facilites_chk_all').prop('checked', false);
    }

  });
</script>
<script>
  $('#facilites_chk_all_up').change(function() {
    $('.fac_ver_chk_up').prop('checked', this.checked);
  });

  $('.fac_ver_chk_up').change(function() {
    if ($('.fac_ver_chk_up:checked').length == $('.fac_ver_chk_up').length) {
      $('#facilites_chk_all_up').prop('checked', true);
    } else {
      $('#facilites_chk_all_up').prop('checked', false);
    }

  });
</script>
<script>
  $('.marketing_add_campaign_checklist').on('click', e => {
    var bt = parseFloat($('.form-repeater_marketing_campaign_checklist').length);
    let $clone = $('.form-repeater_marketing_campaign_checklist').first().clone().hide();
    $clone.insertBefore('.form-repeater_marketing_campaign_checklist:first').slideDown();
    if (bt == 1) {
      $('.marketing_del_campaign_checklist').attr('style', 'display: block !important');
    } else {
      $('.marketing_del_campaign_checklist').attr('style', 'display: block !important');
    }
  });

  $(document).on('click', '.form-repeater_marketing_campaign_checklist .marketing_del_campaign_checklist', e => {
    var bt = parseFloat($('.marketing_del_campaign_checklist').length);
    // alert(bt);
    $(e.target).closest('.form-repeater_marketing_campaign_checklist').slideUp(400, function() {
      $(this).remove()
    });
    if (bt == 2) {
      $('.marketing_del_campaign_checklist').attr('style', 'display: none !important');
    } else {}
  });
</script>

<script>
  $('.marketing_add_campaign_checklist_edit').on('click', e => {
    var bt = parseFloat($('.form-repeater_marketing_campaign_checklist_edit').length);
    let $clone = $('.form-repeater_marketing_campaign_checklist_edit').first().clone().hide();
    $clone.insertBefore('.form-repeater_marketing_campaign_checklist_edit:first').slideDown();
    if (bt == 1) {
      $('.marketing_del_campaign_checklist_edit').attr('style', 'display: block !important');
    } else {
      $('.marketing_del_campaign_checklist_edit').attr('style', 'display: block !important');
    }
  });

  $(document).on('click', '.form-repeater_marketing_campaign_checklist_edit .marketing_del_campaign_checklist_edit', e => {
    var bt = parseFloat($('.marketing_del_campaign_checklist_edit').length);
    // alert(bt);
    $(e.target).closest('.form-repeater_marketing_campaign_checklist_edit').slideUp(400, function() {
      $(this).remove()
    });
    if (bt == 2) {
      $('.marketing_del_campaign_checklist_edit').attr('style', 'display: none !important');
    } else {}
  });
</script>
@endsection