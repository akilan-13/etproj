@extends('layouts/layoutMaster')

@section('title', 'Update Course Analysis Questions')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection


@section('content')
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Course Analysis Questions</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Settings</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Counseller</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Cousrse Analysis Questions</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="form-repeater_course_question">
                <div data-repeater-list="group-a_led_question">
                    <div data-repeater-item>
                        <div class="row">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Question<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Question" value="Are You Interested In" />
                                    </div>
                                    <div class="col-lg-3 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Question Type<span class="text-danger">*</span></label>
                                        <select id="question_course" name="question_course" class="select3 form-select" onchange="Question_func();">
                                            <option>Select Question Type</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button" selected>Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-5 mb-3" id="course_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="lead_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="lead_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_course">
                                                            <div data-repeater-list="group-a_led">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary course_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="course_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 mb-3" id="course_radio_button">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                        <div class="accordion" id="lead_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="lead_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_course_radio">
                                                            <div data-repeater-list="group-a_led_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Technical</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del_radio">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 2
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1">Non-Technical</textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del_radio">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary course_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="course_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 mb-3" id="course_list_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                        <div class="accordion" id="lead_acrd_list_box_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="lead_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_list_box">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_course_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                <span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                        </div>
                                                                        <!-- <div class="col-lg-4">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Score
                                                                                <span class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control" id="" placeholder="Score" />
                                                                        </div> -->
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del_list" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary course_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="course_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 course_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="course_butt_del_question" style="display: none !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <a href="{{url('/settings/counsellor')}}" class="btn btn-secondary me-3">Cancel</a>
                <a href="{{url('/settings/counsellor')}}" class="btn btn-primary">Update Course Analysis Questions</a>
            </div>
        </div>
    </div>
</div>


<script>
    function Question_func() {
        var question_course = document.getElementById("question_course").value;
        var course_check_box = document.getElementById("course_check_box");
        var course_radio_button = document.getElementById("course_radio_button");
        var course_list_box = document.getElementById("course_list_box");

        if (question_course == "check_box") {
            course_check_box.style.display = "block";
            course_radio_button.style.display = "none";
            course_list_box.style.display = "none";
        } else if (question_course == "radio_button") {
            course_check_box.style.display = "none";
            course_radio_button.style.display = "block";
            course_list_box.style.display = "none";
        } else if (question_course == "list_box") {
            course_check_box.style.display = "none";
            course_radio_button.style.display = "none";
            course_list_box.style.display = "block";
        } else {
            course_check_box.style.display = "none";
            course_radio_button.style.display = "none";
            course_list_box.style.display = "none";
        }
    }
</script>
<script>
    $('.course_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_course').length);
        let $clone = $('.form-repeater_course').first().clone().hide();
        $clone.insertBefore('.form-repeater_course:first').slideDown();
        if (bt == 1) {
            $('.lead_butt_del').attr('style', 'display: block !important');
        } else {
            $('.lead_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course .lead_butt_del', e => {
        var bt = parseFloat($('.lead_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.lead_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.course_butt_add_radio').on('click', e => {
        var bt = parseFloat($('.form-repeater_course_radio').length);
        let $clone = $('.form-repeater_course_radio').first().clone().hide();
        $clone.insertBefore('.form-repeater_course_radio:first').slideDown();
        if (bt == 1) {
            $('.lead_butt_del_radio').attr('style', 'display: block !important');
        } else {
            $('.lead_butt_del_radio').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course_radio .lead_butt_del_radio', e => {
        var bt = parseFloat($('.lead_butt_del_radio').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course_radio').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.lead_butt_del_radio').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.course_butt_add_list').on('click', e => {
        var bt = parseFloat($('.form-repeater_course_list').length);
        let $clone = $('.form-repeater_course_list').first().clone().hide();
        $clone.insertBefore('.form-repeater_course_list:first').slideDown();
        if (bt == 1) {
            $('.lead_butt_del_list').attr('style', 'display: block !important');
        } else {
            $('.lead_butt_del_list').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course_list .lead_butt_del_list', e => {
        var bt = parseFloat($('.lead_butt_del_list').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course_list').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.lead_butt_del_list').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.course_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_course_question').length);
        let $clone = $('.form-repeater_course_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_course_question:first').slideDown();
        if (bt == 1) {
            $('.course_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.course_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course_question .course_butt_del_question', e => {
        var bt = parseFloat($('.course_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.course_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>
@endsection