@extends('layouts/layoutMaster')

@section('title', 'Lead Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('content')

<style>
  .scroll-container-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    max-width: 100%;
    overflow: hidden;
  }

  .scroll-container {
    display: flex;
    overflow-x: auto;
    scroll-behavior: smooth;
    padding: 10px 40px;
    gap: 10px;
    scrollbar-width: none;
  }

  .scroll-container::-webkit-scrollbar {
    display: none;
  }

  .item {
    flex: 0 0 auto;
    text-align: center;
    font-weight: bold;
    border-radius: 8px;
  }

  .scroll-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: #099DDA;
    border: none;
    padding: 10px 10px;
    cursor: pointer;
    z-index: 10;
    border-radius: 4px;
    display: none;
  }

  .scroll-btn.left {
    left: 0;
  }

  .scroll-btn.right {
    right: 0;
  }
</style>

<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills flex-nowrap" style="background-color: #dfdfdf;" role="tablist">
        <div class="scroll-container-wrapper">
          <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
          <div class="scroll-container" id="scrollContainer">
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/lead_source') }}" class="nav-link text-capitalize "  aria-selected="false">Lead Source</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/lead_type') }}" class="nav-link text-capitalize"  aria-selected="false">Lead Type</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/lead_potential_type') }}" class="nav-link text-capitalize" aria-selected="false">Lead Potential Type</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/lead_status') }}" class="nav-link text-capitalize active"  aria-selected="false">Lead Status</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/lead_requirement_status') }}" class="nav-link text-capitalize"  aria-selected="false">Lead Requirement Status</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/university') }}" class="nav-link text-capitalize"  aria-selected="false">University</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/followup_reason') }}" class="nav-link text-capitalize"  aria-selected="false">FolllowUp Reason</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/spam_call_reason') }}" class="nav-link text-capitalize"  aria-selected="false">Spam Reason</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/internal_call_reason') }}" class="nav-link text-capitalize"  aria-selected="false">Internal Call Reason</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a type="button" href="{{ url('/settings/lead/dead_reason') }}" class="nav-link text-capitalize"  aria-selected="false">Dead Reason</a>
              </li>
            </div>
          </div>
          <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
        </div>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
      
     
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead_status">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Lead Status
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-150px">Lead Status</th>
                      <th class="min-w-150px">Background Color</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>
                        <label>Active</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#7239EA</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_status">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_status">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                          </a>
                        </span>
                      </td>
                    </tr>
                   
                  </tbody>
                </table>
              </div>
            </div>
         
        
        </div>
      </div>
    </div>
  </div>
</div>





<!--begin::Modal - Add Lead Source-->
<div class="modal fade" id="kt_modal_add_lead_source" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Source</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Source" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Source</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Source-->

<!--begin::Modal - Edit Lead Source-->
<div class="modal fade" id="kt_modal_edit_lead_source" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Source</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Source" value="Email" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Source</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Source-->

<!--begin::Modal - Delete Lead Source-->
<div class="modal fade" id="kt_modal_delete_lead_source" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Source ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Email</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Source-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->


<!--begin::Modal - Add Lead Type-->
<div class="modal fade" id="kt_modal_add_lead_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Type" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Type-->

<!--begin::Modal - Edit Lead Type-->
<div class="modal fade" id="kt_modal_edit_lead_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Type" value="Employee" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Type-->

<!--begin::Modal - Delete Lead Type-->
<div class="modal fade" id="kt_modal_delete_lead_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Type ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Employee</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Type-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Lead Potential Type-->
<div class="modal fade" id="kt_modal_add_lead_potential_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Potential Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Potential Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Potential Type" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black fs-6 mb-1 fw-semibold">Lead Potential Image<span class="text-danger">*</span></label>
            <div class="mb-0">
              <img src="{{asset('assets/phdizone_images/def_img.png')}}" alt="user-avatar" class="w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="uploadedlogo" />
              <div class="button-wrapper">
                <div class="d-flex align-items-start mt-2 mb-2">
                  <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                    <i class="mdi mdi-tray-arrow-up"></i>
                    <input type="file" id="upload" class="file-in" hidden accept="image/png, image/jpeg" />
                  </label>
                  <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                    <i class="mdi mdi-reload"></i>
                  </button>
                </div>
                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
              </div>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Potential Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Potential Type-->

<!--begin::Modal - Edit Lead Potential Type-->
<div class="modal fade" id="kt_modal_edit_lead_potential_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Potential Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Potential Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Potential Type" value="Premium Potential" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black fs-6 mb-1 fw-semibold">Lead Potential Image<span class="text-danger">*</span></label>
            <div class="mb-0">
              <img src="{{asset('assets/phdizone_images/potential/premium.png')}}" alt="user-avatar" class="w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="uploadedlogo_edit" />
              <div class="button-wrapper">
                <div class="d-flex align-items-start mt-2 mb-2">
                  <label class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                    <i class="mdi mdi-tray-arrow-up"></i>
                    <input type="file" id="upload_edit" class="file-in_edit" hidden accept="image/png, image/jpeg" />
                  </label>
                  <button type="button" class="btn btn-sm btn-outline-danger file-reset_edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                    <i class="mdi mdi-reload"></i>
                  </button>
                </div>
                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
              </div>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Potential Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Potential Type-->

<!--begin::Modal - Delete Lead Potential Type-->
<div class="modal fade" id="kt_modal_delete_lead_potential_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Potential Type ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Premium Potential</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Potential Type-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Lead Status-->
<div class="modal fade" id="kt_modal_add_lead_status" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Status</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Status" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" placeholder="Enter Background Color" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Status-->

<!--begin::Modal - Edit Lead Status-->
<div class="modal fade" id="kt_modal_edit_lead_status" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Status</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Status" value="Active" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" placeholder="Enter Background Color" value="#7239EA" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Status-->

<!--begin::Modal - Delete Lead Status-->
<div class="modal fade" id="kt_modal_delete_lead_status" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Status ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Active</label>
          <span class="ms-2 me-2">-</span>
          <label> #7239EA</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Status-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Lead Requirment Status-->
<div class="modal fade" id="kt_modal_add_req_lead_status" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Requirement Status</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Requirement Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Status" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" placeholder="Enter Background Color" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Requirement Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Requirment Status-->

<!--begin::Modal - Edit Lead Requirment Status-->
<div class="modal fade" id="kt_modal_edit_lead_req_status" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Requirments Status</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Lead Requirments Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Lead Requirments Status" value="Requirement Approved" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" placeholder="Enter Background Color" value="#fdb528" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Requirments Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Requirment Status-->

<!--begin::Modal - Delete Lead Requirments Status-->
<div class="modal fade" id="kt_modal_delete_lead_req_status" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Requirments Status ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Requirement Approved</label>
          <span class="ms-2 me-2">-</span>
          <label>#fdb528</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Status-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add University-->
<div class="modal fade" id="kt_modal_add_university" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create University</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">University Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter University Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create University</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add University-->

<!--begin::Modal - Edit University-->
<div class="modal fade" id="kt_modal_edit_university" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Update University</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">University Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter University Name" value="Madurai Kamarajar University" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update University</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit University-->

<!--begin::Modal - Delete University-->
<div class="modal fade" id="kt_modal_delete_university" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete University ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Madurai Kamarajar University</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete university-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->


<!-- Logo File Upload Start -->
<script>
  let logofile = document.getElementById('uploadedlogo');
  const fileInput = document.querySelector('.file-in'),
    resetFileInput = document.querySelector('.file-reset');

  if (logofile) {
    const resetImage = logofile.src;
    fileInput.onchange = () => {
      if (fileInput.files[0]) {
        logofile.src = window.URL.createObjectURL(fileInput.files[0]);
      }
    };
    resetFileInput.onclick = () => {
      fileInput.value = '';
      logofile.src = resetImage;
    };
  }
</script>

<script>
  let logofile_edit = document.getElementById('uploadedlogo_edit');
  const fileInput_edit = document.querySelector('.file-in_edit'),
    resetFileInput_edit = document.querySelector('.file-reset_edit');

  if (logofile_edit) {
    const resetImage_edit = logofile_edit.src;
    fileInput_edit.onchange = () => {
      if (fileInput_edit.files[0]) {
        logofile_edit.src = window.URL.createObjectURL(fileInput_edit.files[0]);
      }
    };
    resetFileInput_edit.onclick = () => {
      fileInput_edit.value = '';
      logofile_edit.src = resetImage_edit;
    };
  }
</script>
<!-- Logo File Upload End -->
<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
    const scrollContainer = document.getElementById('scrollContainer');
    const scrollLeftBtn = document.getElementById('scrollLeftBtn');
    const scrollRightBtn = document.getElementById('scrollRightBtn');

    function updateScrollButtons() {
        const scrollLeft = scrollContainer.scrollLeft;
        const scrollWidth = scrollContainer.scrollWidth;
        const clientWidth = scrollContainer.clientWidth;

        scrollLeftBtn.style.display = scrollLeft > 0 ? 'block' : 'none';
        scrollRightBtn.style.display = scrollLeft + clientWidth < scrollWidth ? 'block' : 'none';
    }

    scrollLeftBtn.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: -300,
            behavior: 'smooth'
        });
    });

    scrollRightBtn.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: 300,
            behavior: 'smooth'
        });
    });

    scrollContainer.addEventListener('scroll', updateScrollButtons);
    window.addEventListener('resize', updateScrollButtons);

    // Run on load
    updateScrollButtons();
</script>
@endsection