@extends('layouts/layoutMaster')

@section('title', 'HRM Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_knowledge_tag" aria-controls="tab_knowledge_tag" aria-selected="true">Knowledge Tag</button>
        </li>
        <!-- <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_knowledge_tag" aria-controls="tab_knowledge_tag" aria-selected="false">Knowledge Tag</button>
        </li> -->
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#credential" aria-controls="credential" aria-selected="false">Credentials Book</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#job_role" aria-controls="job_role" aria-selected="false">Job Role</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#attachment" aria-controls="attachment" aria-selected="false">Attachment</button>
        </li>
        <!-- <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#job_role" aria-controls="job_role" aria-selected="false">Job Position</button>
        </li> -->
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_emp_grade" aria-controls="tab_emp_grade" aria-selected="false">Grade</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_emp_level" aria-controls="tab_emp_level" aria-selected="false">Level</button>
        </li>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
          <div class="tab-pane fade show active" id="tab_knowledge_tag" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_knowledge_tag">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Knowledge Tag
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-100px">S.No</th>
                      <th class="min-w-200px">Knowledge Tag</th>
                      <th class="min-w-100px">Knowledge Level</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Data Science - Machine Learning
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Data Science - Machine Learning"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Intermediate</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Advanced Java
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Advanced Java"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Expert</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Full Stack - PHP
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Full Stack - PHP"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Expert</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_knowledge_tag" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_knowledge_tag">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Knowledge Tag
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-100px">S.No</th>
                      <th class="min-w-200px">Knowledge Tag</th>
                      <th class="min-w-100px">Knowledge Level</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Data Science - Machine Learning
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Data Science - Machine Learning"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Intermediate</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Advanced Java
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Advanced Java"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Expert</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Full Stack - PHP
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Full Stack - PHP"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Expert</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_knowledge_tag" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="credential" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_credential">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Credentials
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-250px">Credential</th>
                      <th class="min-w-100px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Skype
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_credential" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_passbook" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Firewall
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_credential" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_passbook" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Spark
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_credential" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_passbook" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="job_role" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_job_role">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Job Role
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Job Role</th>
                      <th class="min-w-150px">Background Color</th>
                      <th class="min-w-100px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Developer
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#fdb528</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Content Writer
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#fdb528</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Sales
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#fdb528</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="job_role" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_job_role">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Job Position
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-250px">Job Position</th>
                      <th class="min-w-100px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>CEO & Founders
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Managing Director
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Vice President
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Adviser
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>Management Head
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>6</td>
                      <td>Business Head
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>7</td>
                      <td>Business Manager
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>8</td>
                      <td>Business Co-Ordinator
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>9</td>
                      <td>Team Manager
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>10</td>
                      <td>CRE
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>11</td>
                      <td>Project Co-Ordinator
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>12</td>
                      <td>Team Leader
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>13</td>
                      <td>Senior Executive
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>14</td>
                      <td>Executive & Trainers
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>15</td>
                      <td>Supporters
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- <div class="tab-pane fade" id="credential_type" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_credential_book">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Credential Book
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">ID</th>
                      <th class="min-w-80px">Credential</th>
                      <th class="min-w-80px">Book</th>
                      <th class="min-w-100px">Credentials</th>
                      <th class="min-w-100px">URL</th>
                      <th class="min-w-100px">Description</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>PT-0003/24</td>
                      <td>PC</td>
                      <td>Firewall</td>
                      <td>
                        <label>pcadmin@123</label>
                        <div class="d-block text-danger fs-8">admin123</div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="https://192.168.3.1/sonicui/7/login/#">https://192.168.3.1/sonicui/7/login/#</label>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">-</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_credential_book" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_credential_book" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>PT-0002/24</td>
                      <td>PC</td>
                      <td>
                        <label>pcspark@123</label>
                        <div class="d-block text-danger fs-8">spark123</div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">-</label>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">-</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_credential_book" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_credential_book" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>PT-0001/24</td>
                      <td>PC</td>
                      <td>Skype</td>
                      <td>
                        <label>pcSkype@123</label>
                        <div class="d-block text-danger fs-8">Skype123</div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">-</label>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">-</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_credential_book" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_credential_book" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div> -->
          <div class="tab-pane fade" id="attachment" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_attachment">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Attachment
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Attachment Type</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Aadhar</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Government-issued ID for Indian residents."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Driving </label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label>Pan Card</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>
                        <label>Voter ID</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_attachment" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_emp_grade" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_emp_grade">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Grade
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Grade</th>
                      <th class="min-w-150px">Position</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>G1</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>CEO & Founders</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>G2</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Managing Directors</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label>G3</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Vice President</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>
                        <label>G4</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Advisor</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>
                        <label>G5</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Management Head</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>6</td>
                      <td>
                        <label>G6</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Business Head</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>7</td>
                      <td>
                        <label>G7</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Business Manager</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>8</td>
                      <td>
                        <label>G8</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Business Coordinator</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>9</td>
                      <td>
                        <label>G9</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Team Manager</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>10</td>
                      <td>
                        <label>G10</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>CRE</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>11</td>
                      <td>
                        <label>G11</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Project Coordinator</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>12</td>
                      <td>
                        <label>G12</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Team Leader</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>13</td>
                      <td>
                        <label>G13</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Senior Executive</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>14</td>
                      <td>
                        <label>G14</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Executive & Trainer</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>15</td>
                      <td>
                        <label>G15</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Supporters</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_grade" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_emp_level" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_emp_level">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Level
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Level</th>
                      <th class="min-w-100px">Position</th>
                      <th class="min-w-80px">Per Hour Cost</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>L1</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>CEO & Founders</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">15,000.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>L2</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Managing Directors</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">13,000.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label>L3</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Vice President</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">9,500.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>
                        <label>L4</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Advisor</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">7,500.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>
                        <label>L5</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Management Head</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">5,500.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>6</td>
                      <td>
                        <label>L6</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Business Head</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">4,500.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>7</td>
                      <td>
                        <label>L7</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Business Manager</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">3,700.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>8</td>
                      <td>
                        <label>L8</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Business Coordinator</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">3,000.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>9</td>
                      <td>
                        <label>L9</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Team Manager</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">2,500.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>10</td>
                      <td>
                        <label>L10</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>CRE</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">1,900.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>11</td>
                      <td>
                        <label>L11</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Project Coordinator</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">1,700.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>12</td>
                      <td>
                        <label>L12</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Team Leader</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">1,500.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>13</td>
                      <td>
                        <label>L13</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Senior Executive</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">1,200.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>14</td>
                      <td>
                        <label>L14</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Executive & Trainer</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">975.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>15</td>
                      <td>
                        <label>L15</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Supporters</td>
                      <td align="right">
                        <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></label>
                        <label class="fs-6">750.00</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_emp_level" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!--begin::Modal - Add Job Time-->
<div class="modal fade" id="kt_modal_add_job_time" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Job Time</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Time Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Job Time Name" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Starting Time<span class="text-danger">*</span></label>
            <input type="text" class="form-control " placeholder="HH:MM" id="job_st_tm" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ending Time<span class="text-danger">*</span></label>
            <input type="text" class="form-control " placeholder="HH:MM" id="job_ed_tm" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Job Time</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Job Time-->
<!--begin::Modal - Edit Job Time-->
<div class="modal fade" id="kt_modal_edit_job_time" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Job Time</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Time Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Job Time Name" value="Morning Shift-1" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Starting Time<span class="text-danger">*</span></label>
            <input type="text" class="form-control " placeholder="HH:MM" id="job_st_tm_up" value="11:30" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ending Time<span class="text-danger">*</span></label>
            <input type="text" class="form-control " placeholder="HH:MM" id="job_ed_tm_up" value="13:00" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Job Time</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Job Time-->
<!--begin::Modal - Delete Job Time-->
<div class="modal fade" id="kt_modal_delete_job_time" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Job Time ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Job Time-->




<!--begin::Modal - Add Knowledge Tag-->
<div class="modal fade" id="kt_modal_add_knowledge_tag" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Knowledge Tag</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Knowledge Tag Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Knowledge Tag Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Knowledge Level<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option>Select Knowledge Level</option>
              <option value="1">Beginner</option>
              <option value="2">Intermediate</option>
              <option value="3">Expert</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Knowledge Tag</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Knowledge Tag-->
<!--begin::Modal - Edit Knowledge Tag-->
<div class="modal fade" id="kt_modal_edit_knowledge_tag" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Knowledge Tag</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Knowledge Tag Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Knowledge Tag Name" value="Data Science - Machine Learning" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Knowledge Level<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option>Select Knowledge Level</option>
              <option value="1">Beginner</option>
              <option value="2" selected>Intermediate</option>
              <option value="3">Expert</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Knowledge Tag</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Knowledge Tag-->
<!--begin::Modal - Delete Knowledge Tag-->
<div class="modal fade" id="kt_modal_delete_knowledge_tag" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Knowledge Tag ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Knowledge Tag-->


<!--begin::Modal - Add Passbook-->
<div class="modal fade" id="kt_modal_add_credential" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Credentials</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Credential Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Credential Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Credential</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Passbook-->
<!--begin::Modal - Edit Passbook-->
<div class="modal fade" id="kt_modal_edit_credential" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Credentials</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Credential Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Credential Name" value="PC" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Credential</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Passbook-->
<!--begin::Modal - Delete Passbook-->
<div class="modal fade" id="kt_modal_delete_passbook" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Credential ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Passbook-->


<!--begin::Modal - Add Job Role-->
<div class="modal fade" id="kt_modal_add_job_role" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Job Role</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Role Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Job Role Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Job Role</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Job Role-->
<!--begin::Modal - Edit Job Role-->
<div class="modal fade" id="kt_modal_edit_job_role" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Job Role</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Role Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Credential Name" value="PC" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" value="#fdb528" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Job Role</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Job Role-->
<!--begin::Modal - Delete Job Role-->
<div class="modal fade" id="kt_modal_delete_job_role" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Job Role ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Job Role-->

<!--begin::Modal - Add Passbook Type-->
<div class="modal fade" id="kt_modal_add_credential_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Credential Book</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Credential<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option>Select Credential</option>
              <option value="1">PC</option>
              <option value="2">CRE</option>
              <option value="3">Sales</option>
            </select>
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Credential Book<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Credential Book" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter User Name" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter User Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
            <input type="text" class="form-control" id="" placeholder="Enter URL" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Credential Book</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Passbook Type-->
<!--begin::Modal - Edit Passbook Type-->
<div class="modal fade" id="kt_modal_edit_credential_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Credential Book</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Credential<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option>Select Credential</option>
              <option value="1" selected>PC</option>
              <option value="2">CRE</option>
              <option value="3">Sales</option>
            </select>
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Credential Book<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Credential Book" value="Firewall" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter User Name" value="pcadmin@123" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter User Name" value="admin123" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
            <input type="text" class="form-control" id="" placeholder="Enter URL" value="https://192.168.3.1/sonicui/7/login/#" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Passbook Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Passbook Type-->
<!--begin::Modal - Delete Passbook Type-->
<div class="modal fade" id="kt_modal_delete_credential_book" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Credential Book ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Passbook Type-->

<!--begin::Modal - Add Payment Mode-->
<div class="modal fade" id="kt_modal_add_attachment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Attachment</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Attachment<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter attachachment Type" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Attachment</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Payment Mode-->
<!--begin::Modal - Edit Payment Mode-->
<div class="modal fade" id="kt_modal_edit_attachment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Attachment</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Attachment<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Attachment" value="Aadhar" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">Government-issued ID for Indian residents.</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Attachment</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Payment Mode-->
<!--begin::Modal - Delete Payment Mode-->
<div class="modal fade" id="kt_modal_delete_attachment" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Attachment ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Source-->

<!--begin::Modal - Add Job Role-->
<div class="modal fade" id="kt_modal_add_job_role" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Job Position</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Job Position" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Job Position</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Passbook-->
<!--begin::Modal - Edit Passbook-->
<div class="modal fade" id="kt_modal_edit_job_role" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Job Position</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Job Position" value="PC" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Job Position</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Passbook-->
<!--begin::Modal - Delete Passbook-->
<div class="modal fade" id="kt_modal_delete_job_role" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Job Position ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Passbook-->



<!--begin::Modal - Add Employee Grade-->
<div class="modal fade" id="kt_modal_add_emp_grade" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Grade</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Grade Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Grade Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select" multiple>
              <option value="">Select Job Position</option>
              <option value="1">CEO & Founders</option>
              <option value="2">Managing Directors</option>
              <option value="3">Vice President</option>
              <option value="4">Advisor</option>
              <option value="5">Management Head</option>
              <option value="6">Business Head</option>
              <option value="7">Business Manager</option>
              <option value="8">Business Coordinator</option>
              <option value="9">Team Manager</option>
              <option value="10">CRE</option>
              <option value="11">Project Coordinator</option>
              <option value="12">Team Leader</option>
              <option value="13">Senior Executive</option>
              <option value="14">Executive & Trainer</option>
              <option value="15">Supporters</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Grade</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Employee Grade-->
<!--begin::Modal - Edit Employee Grade-->
<div class="modal fade" id="kt_modal_edit_emp_grade" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Grade</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Grade Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Grade Name" value="G1" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select" multiple>
              <option value="">Select Job Position</option>
              <option value="1" selected>CEO & Founders</option>
              <option value="2">Managing Directors</option>
              <option value="3">Vice President</option>
              <option value="4">Advisor</option>
              <option value="5">Management Head</option>
              <option value="6">Business Head</option>
              <option value="7">Business Manager</option>
              <option value="8">Business Coordinator</option>
              <option value="9">Team Manager</option>
              <option value="10">CRE</option>
              <option value="11">Project Coordinator</option>
              <option value="12">Team Leader</option>
              <option value="13">Senior Executive</option>
              <option value="14">Executive & Trainer</option>
              <option value="15">Supporters</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Grade</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Employee Grade-->
<!--begin::Modal - Delete Employee Grade-->
<div class="modal fade" id="kt_modal_delete_emp_grade" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Grade ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Employee Grade-->




<!--begin::Modal - Add Employee Level-->
<div class="modal fade" id="kt_modal_add_emp_level" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Level</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Level Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Level Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Per Hour Cost<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Per Hour Cost" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select" multiple>
              <option value="">Select Job Position</option>
              <option value="1">CEO & Founders</option>
              <option value="2">Managing Directors</option>
              <option value="3">Vice President</option>
              <option value="4">Advisor</option>
              <option value="5">Management Head</option>
              <option value="6">Business Head</option>
              <option value="7">Business Manager</option>
              <option value="8">Business Coordinator</option>
              <option value="9">Team Manager</option>
              <option value="10">CRE</option>
              <option value="11">Project Coordinator</option>
              <option value="12">Team Leader</option>
              <option value="13">Senior Executive</option>
              <option value="14">Executive & Trainer</option>
              <option value="15">Supporters</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Level</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Employee Level-->
<!--begin::Modal - Edit Employee Level-->
<div class="modal fade" id="kt_modal_edit_emp_level" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Level</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Level Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Level Name" value="L1" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Per Hour Cost<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Per Hour Cost" value="15,000" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select" multiple>
              <option value="">Select Job Position</option>
              <option value="1" selected>CEO & Founders</option>
              <option value="2">Managing Directors</option>
              <option value="3">Vice President</option>
              <option value="4">Advisor</option>
              <option value="5">Management Head</option>
              <option value="6">Business Head</option>
              <option value="7">Business Manager</option>
              <option value="8">Business Coordinator</option>
              <option value="9">Team Manager</option>
              <option value="10">CRE</option>
              <option value="11">Project Coordinator</option>
              <option value="12">Team Leader</option>
              <option value="13">Senior Executive</option>
              <option value="14">Executive & Trainer</option>
              <option value="15">Supporters</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Level</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Employee Level-->
<!--begin::Modal - Delete Employee Level-->
<div class="modal fade" id="kt_modal_delete_emp_level" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Level ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Employee Level-->


<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
@endsection