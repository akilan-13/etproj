@extends('layouts/layoutMaster')

@section('title', 'Counsellor Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite([
'resources/assets/js/sliders.js',
'resources/assets/js/forms_date_time_pickers.js'
])
@endsection

@section('content')
<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#offerzone" aria-controls="offerzone" aria-selected="true">Offerzone</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_category_analysis_questions" aria-controls="tab_category_analysis_questions" aria-selected="false">Category Analysis Question</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_course_analysis_questions" aria-controls="tab_course_analysis_questions" aria-selected="false">Course Analysis Question</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_feedback_analysis_questions" aria-controls="tab_feedback_analysis_questions" aria-selected="false">Feedback Analysis Question</button>
        </li>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
          <div class="tab-pane fade show active" id="offerzone" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_offerzone">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Offerzone
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Coupon</th>
                      <th class="min-w-100px">Validity</th>
                      <th class="min-w-100px">Offer Type</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <div class="d-flex  px-1">
                          <div class="symbol symbol-35px me-2">
                            <div class="d-flex align-items-center">
                              <div class="flex-shrink-0 me-2 text-center">
                                <img src="{{asset('assets/phdizone_images/currency_format/usd_dollar.png')}}" alt="USD Dollar Image" class="w-35px h-35px">
                              </div>
                            </div>
                          </div>
                          <div class="mb-0 align-items-center">
                            <label>
                              <span class="fs-7 me-2">Course Based Offer</span>
                            </label>
                            <div><label class="badge bg-info text-white rounded fw-bold fs-8" title="">CODE-001</label></div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div>
                          <label class="badge bg-success text-black fw-bold fs-8">
                            <span class="me-2">11-JUN-2024</span>
                            <span>12:00 AM</span>
                          </label>
                          <!-- <label class="badge bg-warning fs-8 text-black fw-bold">
                            <span>12:00</span>
                            <span>AM</span>
                          </label> -->
                        </div>
                        <div class="mt-1">
                          <label class="badge bg-danger fs-8">
                            <span class="me-2">19-JUN-2024</span>
                            <span>12:00 AM</span>
                          </label>
                          <!-- <label class="badge bg-warning fs-8 text-black fw-bold">
                            <span>12:00</span>
                            <span>AM</span>
                          </label> -->
                        </div>
                      </td>
                      <td>
                        <label>One + One</label>
                        <div><label class="text-white text-primary fw-bold fs-8 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Python for Data Science">Python for Data Science</label></div>
                      </td>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_offerzone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="modal" data-bs-target="#kt_modal_view_offerzone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_offerzone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <!-- <tr>
                      <td>2</td>
                      <td>
                        <div class="d-flex align-items-center">
                          <div class="flex-shrink-0 me-2 text-center">
                            <img src="{{asset('assets/phdizone_images/currency_format/usd_dollar.png')}}" alt="USD Dollar Image" class="w-35px h-35px">
                          </div>
                        </div>
                      </td>
                      <td>
                        <label>Course Based Offer</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="The United States dollar"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                        <div><label class="badge bg-info text-white rounded fw-bold fs-8" title="">CODE-001</label></div>
                      </td>
                      <td>
                        <label class="badge bg-dark fs-8">
                          <span>11-JUN-2024</span>
                        </label>
                        <label class="badge bg-warning fs-8 text-black fw-bold">
                          <span>12</span>
                          <span>AM</span>
                        </label>
                      </td>
                      <td>
                        <label>One + One</label>
                        <div><label class="badge bg-success text-white rounded fw-bold fs-8" title="">1000</label></div>
                      </td>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_currency_format" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_currency_format" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr> -->
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="offerzone_type" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_offerzone_type">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Offerzone Categories
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Offerzone Categories</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Common Offer</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">

                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_offerzone_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_offerzone_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Course Based Offer</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_offerzone_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_offerzone_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_category_analysis_questions" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/counsellor/category_analysis_questions_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Category Analysis Questions
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Question</th>
                      <th class="min-w-100px">Question Type</th>
                      <th class="min-w-100px">Question Option</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Are You Intererted in">Are You Intererted in</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Technical, Non Technical">Technical, Non Technical</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/category_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_category_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Are You Studied any Programming Language">Are You Studied any Programming Language</label>
                      </td>
                      <td>List Box</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yes, No">Yes, No</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/category_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_category_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Interested to take call or not?">Customer Interested to take call or not?</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yes, No">Yes, No
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/category_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_category_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_course_analysis_questions" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/counsellor/course_analysis_questions_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Course Analysis Questions
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Question</th>
                      <th class="min-w-100px">Question Type</th>
                      <th class="min-w-100px">Question Option</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Are You Intererted in">Are You Intererted in</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Technical, Non Technical">Technical, Non Technical</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/course_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_course_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Are You Studied any Programming Language">Are You Studied any Programming Language</label>
                      </td>
                      <td>List Box</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yes, No">Yes, No</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/course_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_course_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Interested to take call or not?">Customer Interested to take call or not?</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yes, No">Yes, No
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/course_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_course_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_feedback_analysis_questions" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/counsellor/feedback_analysis_questions_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Feedback Analysis Questions
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Question</th>
                      <th class="min-w-100px">Question Type</th>
                      <th class="min-w-100px">Question Option</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Are You Intererted in">Are You Intererted in</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Technical, Non Technical">Technical, Non Technical</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/feedback_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_feedback_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Are You Studied any Programming Language">Are You Studied any Programming Language</label>
                      </td>
                      <td>List Box</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yes, No">Yes, No</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/feedback_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_feedback_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Interested to take call or not?">Customer Interested to take call or not?</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yes, No">Yes, No
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/counsellor/feedback_analysis_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_feedback_analysis_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--begin::Modal - Add offerzone-->
<div class="modal fade" id="kt_modal_add_offerzone" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Offerzone</h3>
        </div>

        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold d-block">Offerzone Category<span class="text-danger">*</span></label>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="common_offer" checked value="option1" onchange="common_func();" />
              <label class="form-check-label" for="common_offer">Common Offer</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="course_offer" value="option2" onchange="course_func();" />
              <label class="form-check-label" for="course_offer">Course Based Offer</label>
            </div>
          </div>
        </div>

        <div class="row" id="common_offer_info">
          <!-- Basic -->
          <div class="row">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offerzone Name" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Code<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Coupon Code" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="offer_start" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="offer_end" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Type<span class="text-danger">*</span></label>
              <select id="offer_type" name="offer_type" class="select3 form-select" onchange="offertype_func();">
                <option value="">Select Offerzone Type</option>
                <option value="amt_based">Amount Based</option>
                <option value="per_based">Percentage Based</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3" id="off_amt" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Amount" />
            </div>
            <div class="col-lg-4 mb-3" id="off_per" name="off_per" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer %<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Percentage" />
            </div>
          </div>
          <div class="row"><a href="{{url('/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
              <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span></a>
            <div class="col-lg-4 mb-3">
              <div class="row">
                <label class="text-dark fs-6 fw-semibold">Image<span class="text-danger">*</span></label>
                <div class="col-lg-6">
                  <div class="align-items-sm-center gap-4">
                    <img src="{{asset('assets/phdizone_images/def_img.png')}}" alt="user-avatar" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="currency_foramt" />
                    <div class="button-wrapper">
                      <div class="d-flex align-items-start mt-2 mb-2">
                        <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Coupon Image">
                          <i class="mdi mdi-tray-arrow-up"></i>
                          <input type="file" id="upload" class="upload-in" hidden accept="image/png" />
                        </label>
                        <button type="button" class="btn btn-sm btn-outline-danger currency_reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Coupon Image">
                          <i class="mdi mdi-reload"></i>
                        </button>
                      </div>
                      <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="3" id="" placeholder="Enter Description"></textarea>
            </div>
            <div class="col-lg-4 mb-3">
              <div class="form-check form-check-inline">
                <input class="form-check-input facility_verify_up" type="checkbox" id="facilites_chk_all_up" />
                <label class="text-dark mb-1 fs-5 fw-semibold">Display Counseller App Dashboard</label>
              </div>
            </div>
          </div>

        </div>
        <div class="row" id="course_offer_info" style="display: none !important;">
          <!-- Basic -->
          <div class="row">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offerzone Name" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course Category<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Course Category</option>
                <option value="1">Business Management</option>
                <option value="2">Network Management</option>
                <option value="3">Programming Training</option>
                <option value="4">Data Analyst</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course Sub Category<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Course Sub Category</option>
                <option value="1">Application Development</option>
                <option value="2">Expert</option>
                <option value="3">Web Development</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course Type<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Course Type</option>
                <option value="1">Tesbo</option>
                <option value="2">Slash</option>
                <option value="3">Classic</option>
                <option value="4">Professional</option>
                <option value="5">Crash</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="course">Select Course</option>
                <option value="python">Python For Data Science</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer Type<span class="text-danger">*</span></label>
              <select id="offer_type_course" name="offer_type_course" class="select3 form-select" onchange="courseoffertype_func();">
                <option value="">Select Offer Type</option>
                <option value="one">One + One</option>
                <option value="amount">Amount Based</option>
                <option value="percentage">Percentage Based</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3" id="one_info" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Related Courses<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select" multiple>
                <option value="course">Select Course</option>
                <option value="python">Python For Data Science</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3" id="off_amt_info" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Amount" />
            </div>
            <div class="col-lg-4 mb-3" id="off_per_info" name="off_per" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer %<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Percentage" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Code<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Coupon Code" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="courseoffer_start" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="courseoffer_end" />
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 mb-3">
              <div class="row">
                <label class="text-dark fs-6 fw-semibold">Image<span class="text-danger">*</span></label>
                <div class="col-lg-6">
                  <div class="align-items-sm-center gap-4">
                    <img src="{{asset('assets/phdizone_images/def_img.png')}}" alt="Coupon Code" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="fav_uploadedlogo" />
                    <div class="button-wrapper">
                      <div class="d-flex align-items-start mt-2 mb-2">
                        <label for="fav_upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Coupon Image">
                          <i class="mdi mdi-tray-arrow-up"></i>
                          <input type="file" id="fav_upload" class="fav_file-in" hidden accept="image/png, image/jpeg" />
                        </label>
                        <button type="button" class="btn btn-sm btn-outline-danger fav_file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Coupon Image">
                          <i class="mdi mdi-reload"></i>
                        </button>
                      </div>
                      <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="3" id="" placeholder="Enter Description"></textarea>
            </div>
            <div class="col-lg-4 mb-3">
              <div class="form-check form-check-inline">
                <input class="form-check-input facility_verify_up" type="checkbox" id="facilites_chk_all_up" />
                <label class="text-dark mb-1 fs-6 fw-semibold">Display Counsellor App Dashboard</label>
              </div>
            </div>
          </div>

        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Offerzone</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--End Offerzone---->
<!--begin::Modal - Edit offerzone-->
<div class="modal fade" id="kt_modal_edit_offerzone" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Offerzone</h3>
        </div>

        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold d-block">Offerzone Category<span class="text-danger">*</span></label>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="common_offer" value="option1" onchange="common_func();" />
              <label class="form-check-label" for="common_offer">Common Offer</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="course_offer" checked value="option2" onchange="course_func();" />
              <label class="form-check-label" for="course_offer">Course Based Offer</label>
            </div>
          </div>
        </div>

        <div class="row" id="common_offer_info" style="display: none !important;">
          <!-- Basic -->
          <div class="row">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offerzone Name" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Code<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Coupon Code" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="offer_start" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="offer_end" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Type<span class="text-danger">*</span></label>
              <select id="offer_type_edit" name="offer_type_edit" class="select3 form-select" onclick="offertype_func();">
                <option value="">Select Offerzone Type</option>
                <option value="amt_based">Amount Based</option>
                <option value="per_based">Percentage Based</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3" id="off_amt" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Amount" />
            </div>
            <div class="col-lg-4 mb-3" id="off_per" name="off_per" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer %<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Percentage" />
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 mb-3">
              <div class="row">
                <label class="text-dark fs-6 fw-semibold">Image<span class="text-danger">*</span></label>
                <div class="col-lg-6">
                  <div class="align-items-sm-center gap-4">
                    <img src="{{asset('assets/phdizone_images/def_img.png')}}" alt="user-avatar" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="currency_foramt" />
                    <div class="button-wrapper">
                      <div class="d-flex align-items-start mt-2 mb-2">
                        <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Coupon Image">
                          <i class="mdi mdi-tray-arrow-up"></i>
                          <input type="file" id="upload" class="upload-in" hidden accept="image/png" />
                        </label>
                        <button type="button" class="btn btn-sm btn-outline-danger currency_reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Coupon Image">
                          <i class="mdi mdi-reload"></i>
                        </button>
                      </div>
                      <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="3" id="" placeholder="Enter Description"></textarea>
            </div>
            <div class="col-lg-4 mb-3">
              <div class="form-check form-check-inline">
                <input class="form-check-input facility_verify_up" type="checkbox" id="facilites_chk_all_up" />
                <label class="text-dark mb-1 fs-5 fw-semibold">Display Counseller App Dashboard</label>
              </div>
            </div>
          </div>

        </div>
        <div class="row" id="course_offer_info">
          <!-- Basic -->
          <div class="row">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offerzone Name" value="Offer1" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course Category<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Course Category</option>
                <option value="1">Business Management</option>
                <option value="2">Network Management</option>
                <option value="3">Programming Training</option>
                <option value="4" selected>Data Analyst</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course Sub Category<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Course Sub Category</option>
                <option value="1">Application Development</option>
                <option value="2">Expert</option>
                <option value="3" selected>Web Development</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course Type<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Course Type</option>
                <option value="1">Tesbo</option>
                <option value="2">Slash</option>
                <option value="3">Classic</option>
                <option value="4" selected>Professional</option>
                <option value="5">Crash</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Course<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="course">Select Course</option>
                <option value="python" selected>Python For Data Science</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer Type<span class="text-danger">*</span></label>
              <select id="offer_type_course_edit" name="offer_type_course_edit" class="select3 form-select" onchange="courseoffertype_func();">
                <option value="">Select Offer Type</option>
                <option value="one" selected>One + One</option>
                <option value="amount">Amount Based</option>
                <option value="percentage">Percentage Based</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3" id="one_info">
              <label class="text-dark mb-1 fs-6 fw-semibold">Related Courses<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select" multiple>
                <option value="course">Select Course</option>
                <option value="python">Python For Data Science</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3" id="off_amt_info" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Amount" />
            </div>
            <div class="col-lg-4 mb-3" id="off_per_info" name="off_per" style="display: none !important;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Offer %<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Offer Percentage" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Code<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Coupon Code" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="courseoffer_start_edit" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="courseoffer_end_edit" />
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 mb-3">
              <div class="row">
                <label class="text-dark fs-6 fw-semibold">Image<span class="text-danger">*</span></label>
                <div class="col-lg-6">
                  <div class="align-items-sm-center gap-4">
                    <img src="{{asset('assets/phdizone_images/def_img.png')}}" alt="Coupon Code" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="coupon_code" />
                    <div class="button-wrapper">
                      <div class="d-flex align-items-start mt-2 mb-2">
                        <label for="fav_upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Coupon Image">
                          <i class="mdi mdi-tray-arrow-up"></i>
                          <input type="file" id="coupon_upload" class="upload-in-crs" hidden accept="image/png, image/jpeg" />
                        </label>
                        <button type="button" class="btn btn-sm btn-outline-danger coupon_reset_crs" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Coupon Image">
                          <i class="mdi mdi-reload"></i>
                        </button>
                      </div>
                      <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="3" id="" placeholder="Enter Description"></textarea>
            </div>
            <div class="col-lg-4 mb-3">
              <div class="form-check form-check-inline">
                <input class="form-check-input facility_verify_up" type="checkbox" id="facilites_chk_all_up" />
                <label class="text-dark mb-1 fs-6 fw-semibold">Display Counsellor App Dashboard</label>
              </div>
            </div>
          </div>

        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Offerzone</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--End Offerzone---->
<!--begin::Modal - View offerzone-->
<div class="modal fade" id="kt_modal_view_offerzone" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">View Offerzone
            <!-- <label class="me-4 badge bg-warning text-black rounded fw-bold fs-4">Email</label> -->
          </h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mt-2">
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Coupon Image</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">
                <div class="row">
                  <div class="align-items-sm-center gap-4">
                    <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                  </div>
                </div>
              </label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Offerzone Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Course based offer</label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Offer Name</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Python Offer</label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Course Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Data Analyst</label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Course Sub Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Web Application</label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Course Type</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 fs-6 fw-bold">
                <span class="badge bg-danger">Professional</span></label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Offer Type</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">One + One</label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Offered Courses</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold text-truncate max-w-250px" title="Python for Data Science">Python for Data Science</label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Coupon Code</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 fs-6 fw-bold">
                <span class="badge bg-info">CODE-001</span></label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">Starting Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">11-JUN-2024 12:00 AM</label>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-black fs-7 fw-semibold">End Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">19-JUN-2024 12:00 AM</label>
            </div>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View offerzone-->
<!--begin::Modal - Delete offerzone type-->
<div class="modal fade" id="kt_modal_delete_offerzone" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Offerzone ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete offerzone type-->



<!--begin::Modal - Add offerzone type-->
<div class="modal fade" id="kt_modal_add_offerzone_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Offerzone Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Offerzone Type" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Offerzone Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add offerzone type-->
<!--begin::Modal - Edit offerzone type-->
<div class="modal fade" id="kt_modal_edit_offerzone_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Offerzone Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Offerzone Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Offerzone" value="Common Offer" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Offerzone Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit offerzone type-->
<!--begin::Modal - Delete offerzone type-->
<div class="modal fade" id="kt_modal_delete_offerzone_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Offerzone Type ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete offerzone type-->




<!--begin::Modal - Delete Category Analysis Question-->
<div class="modal fade" id="kt_modal_delete_category_analysis_question" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Category Analysis Question ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Category Analysis Question-->





<!--begin::Modal - Delete Course Analysis Question-->
<div class="modal fade" id="kt_modal_delete_course_analysis_question" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Course Analysis Question ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Course Analysis Question-->





<!--begin::Modal - Delete feedback Analysis Question-->
<div class="modal fade" id="kt_modal_delete_feedback_analysis_question" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Feedback Analysis Question ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete feedback Analysis Question-->



<script>
  function common_func() {
    var common_offer = document.getElementById("common_offer");
    var course_offer = document.getElementById("course_offer");
    var common_offer_info = document.getElementById("common_offer_info");
    var course_offer_info = document.getElementById("course_offer_info");
    if (common_offer.checked) {
      common_offer_info.style.display = "block";
      course_offer_info.style.display = "none";
    } else if (course_offer.checked) {
      course_offer_info.style.display = "block";
      common_offer_info.style.display = "none";
    } else {

    }
  }
</script>

<script>
  function course_func() {
    var common_offer = document.getElementById("common_offer");
    var course_offer = document.getElementById("course_offer");
    var common_offer_info = document.getElementById("common_offer_info");
    var course_offer_info = document.getElementById("course_offer_info");
    if (course_offer.checked) {
      common_offer_info.style.display = "none";
      course_offer_info.style.display = "block";
    } else if (common_offer.checked) {
      course_offer_info.style.display = "block";
      common_offer_info.style.display = "none";
    } else {

    }
  }
</script>

<script>
  function offertype_func() {
    var offer_type = document.getElementById("offer_type").value;
    var off_amt = document.getElementById("off_amt");
    var off_per = document.getElementById("off_per");
    if (offer_type == "amt_based") {
      off_amt.style.display = "block";
      off_per.style.display = "none";
    } else if (offer_type == "per_based") {
      off_amt.style.display = "none";
      off_per.style.display = "block";
    } else {

    }
  }
</script>

<script>
  function courseoffertype_func() {
    var offer_type_course = document.getElementById("offer_type_course").value;
    var one_info = document.getElementById("one_info");
    var off_amt_info = document.getElementById("off_amt_info");
    var off_per_info = document.getElementById("off_per_info");
    if (offer_type_course == "one") {
      one_info.style.display = "block";
      off_amt_info.style.display = "none";
      off_per_info.style.display = "none";
    } else if (offer_type_course == "amount") {
      one_info.style.display = "none";
      off_amt_info.style.display = "block";
      off_per_info.style.display = "none";
    } else if (offer_type_course == "percentage") {
      one_info.style.display = "none";
      off_per_info.style.display = "block";
      off_amt_info.style.display = "none";
    } else {

    }
  }
</script>

<script>
  function offerzone_func() {
    var offerzone_field = document.getElementById("offerzone_field").value;
    var common_offer_info = document.getElementById("common_offer_info");
    var course_offer_info = document.getElementById("course_offer_info");
    if (offerzone_field == "common_offer") {
      common_offer_info.style.display = "block";
      course_offer_info.style.display = "none";
    } else if (offerzone_field == "course_offer") {
      course_offer_info.style.display = "block";
      common_offer_info.style.display = "none";
    } else {
      common_offer_info.style.display = "none";
    }
  }
</script>
<script>
  let logofile = document.getElementById('currency_foramt');
  const fileInput = document.querySelector('.upload-in'),
    resetFileInput = document.querySelector('.currency_reset');

  if (logofile) {
    const resetImage = logofile.src;
    fileInput.onchange = () => {
      if (fileInput.files[0]) {
        logofile.src = window.URL.createObjectURL(fileInput.files[0]);
      }
    };
    resetFileInput.onclick = () => {
      fileInput.value = '';
      logofile.src = resetImage;
    };
  }
</script>
<script>
  let logofile_crs = document.getElementById('coupon_code');
  const fileInputcrs = document.querySelector('.upload-in-crs'),
    resetFileInputcrs = document.querySelector('.coupon_reset_crs');

  if (logofile_crs) {
    const resetImagecrs = logofile_crs.src;
    fileInputcrs.onchange = () => {
      if (fileInputcrs.files[0]) {
        logofile_crs.src = window.URL.createObjectURL(fileInputcrs.files[0]);
      }
    };
    resetFileInputcrs.onclick = () => {
      fileInputcrs.value = '';
      logofile_crs.src = resetImagecrs;
    };
  }
</script>
<script>
  let faviconfile = document.getElementById('fav_uploadedlogo');
  const fav_fileInput = document.querySelector('.fav_file-in'),
    fav_resetFileInput = document.querySelector('.fav_file-reset');

  if (faviconfile) {
    const fav_resetImage = faviconfile.src;
    fav_fileInput.onchange = () => {
      if (fav_fileInput.files[0]) {
        faviconfile.src = window.URL.createObjectURL(fav_fileInput.files[0]);
      }
    };
    fav_resetFileInput.onclick = () => {
      fav_fileInput.value = '';
      faviconfile.src = fav_resetImage;
    };
  }
</script>

<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
@endsection