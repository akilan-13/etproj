@extends('layouts/layoutMaster')

@section('title', 'Create Customer Type Option')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection


@section('content')
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Customer Type Option</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Settings</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Sales</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Customer Type Option</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Customer Type<span class="text-danger">*</span></label>
                <select id="" class="select3 form-select">
                    <option value="">Select Customer Type</option>
                    <option value="1">Student</option>
                    <option value="2">Employee</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="form-repeater_customer_type_option_questions">
                <div data-repeater-list="group-a_customer_type_option_question">
                    <div data-repeater-item>
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="customer_type_option_label_value" name="customer_type_option_label_value" class="select3 form-select" onchange="customer_type_option_label_func();">
                                            <option>Select Label Value</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3 mt-3" id="customer_type_option_check_box" style="display: none !important;">
                                        <div class="accordion" id="customer_type_option_acrd_chk_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="customer_type_option_acrd_chk_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#customer_type_option_accordion_chk_box" aria-expanded="false" aria-controls="customer_type_option_accordion_chk_box" role="tabpanel">Check Box
                                                    </button>
                                                </h2>
                                                <div id="customer_type_option_accordion_chk_box" class="accordion-collapse collapse" data-bs-parent="#customer_type_option_acrd_chk_box">
                                                    <div class="accordion-body px-2">
                                                        <div class="scroll-y max-h-200px px-3">
                                                            <div class="form-repeater_customer_type_option_chk_box">
                                                                <div data-repeater-list="group-a_customer_type_option_chk_box">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 customer_type_option_butt_del_chk_box" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_chk_box" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary customer_type_option_butt_add_chk_box" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="customer_type_option_butt_add_chk_box">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 mt-3" id="customer_type_option_radio_button" style="display: none !important;">
                                        <div class="accordion" id="customer_type_option_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="customer_type_option_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#customer_type_option_accordion_radio" aria-expanded="false" aria-controls="customer_type_option_accordion_radio" role="tabpanel">Radio Button</button>
                                                </h2>
                                                <div id="customer_type_option_accordion_radio" class="accordion-collapse collapse" data-bs-parent="#customer_type_option_acrd_radio">
                                                    <div class="accordion-body px-2">
                                                        <div class="scroll-y max-h-200px px-3">
                                                            <div class="form-repeater_customer_type_option_radio">
                                                                <div data-repeater-list="group-a_customer_type_option_radio">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 customer_type_option_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_radio" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary customer_type_option_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="customer_type_option_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 mt-3" id="customer_type_option_list_box" style="display: none !important;">
                                        <div class="accordion" id="customer_type_option_acrd_list_box">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="customer_type_option_acrd_list_box">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#customer_type_option_accordion_list_box" aria-expanded="false" aria-controls="customer_type_option_accordion_list_box" role="tabpanel">List Box</button>
                                                </h2>
                                                <div id="customer_type_option_accordion_list_box" class="accordion-collapse collapse" data-bs-parent="#customer_type_option_acrd_list_box">
                                                    <div class="accordion-body px-2">
                                                        <div class="scroll-y max-h-200px px-3">
                                                            <div class="form-repeater_customer_type_option_list_box">
                                                                <div data-repeater-list="group-a_customer_type_option_list_box">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 customer_type_option_butt_del_list_box" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_list_box" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary customer_type_option_butt_add_list_box" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="customer_type_option_butt_add_list_box">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 customer_type_option_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_question" style="display: none !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                        <hr class="bg-light m-1">
                        <div class="row my-2">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-check form-check-inline mb-1">
                                            <input class="form-check-input cred_check" type="checkbox" id="depends_id" name="depends_id" onclick="depends_func();" />
                                            <label class="text-dark fs-6 fw-semibold">Depends<span class="text-danger" id="depends_danger" style="display: none !important;">*</span></label>
                                        </div>
                                        <div id="depends_tbox" style="display: none !important;">
                                            <select id="" class="select3 form-select">
                                                <option value="">Select Label</option>
                                                <option value="1">School</option>
                                                <option value="1">College</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Label Name" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Label Value<span class="text-danger">*</span></label>
                                        <select id="customer_type_option_label_value_1" name="customer_type_option_label_value_1" class="select3 form-select">
                                            <option>Select Label Value</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="text_area">Text Area</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3 mt-3" id="customer_type_option_check_box_1" style="display: none !important;">
                                        <div class="accordion" id="customer_type_option_acrd_chk_box_1">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="customer_type_option_acrd_chk_box_1">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#customer_type_option_accordion_chk_box_1" aria-expanded="false" aria-controls="customer_type_option_accordion_chk_box_1" role="tabpanel">Check Box
                                                    </button>
                                                </h2>
                                                <div id="customer_type_option_accordion_chk_box_1" class="accordion-collapse collapse" data-bs-parent="#customer_type_option_acrd_chk_box_1">
                                                    <div class="accordion-body px-2">
                                                        <div class="scroll-y max-h-200px px-3">
                                                            <div class="form-repeater_customer_type_option_chk_box_1">
                                                                <div data-repeater-list="group-a_customer_type_option_chk_box_1">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 customer_type_option_butt_del_chk_box_1" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_chk_box_1" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary customer_type_option_butt_add_chk_box_1" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="customer_type_option_butt_add_chk_box_1">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 mt-3" id="customer_type_option_radio_button_1" style="display: none !important;">
                                        <div class="accordion" id="customer_type_option_acrd_radio_1">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="customer_type_option_acrd_radio_1">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#customer_type_option_accordion_radio_1" aria-expanded="false" aria-controls="customer_type_option_accordion_radio_1" role="tabpanel">Radio Button</button>
                                                </h2>
                                                <div id="customer_type_option_accordion_radio_1" class="accordion-collapse collapse" data-bs-parent="#customer_type_option_acrd_radio_1">
                                                    <div class="accordion-body px-2">
                                                        <div class="scroll-y max-h-200px px-3">
                                                            <div class="form-repeater_customer_type_option_radio_1">
                                                                <div data-repeater-list="group-a_customer_type_option_radio_1">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 customer_type_option_butt_del_radio_1" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_radio_1" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary customer_type_option_butt_add_radio_1" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="customer_type_option_butt_add_radio_1">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3 mt-3" id="customer_type_option_list_box_1" style="display: none !important;">
                                        <div class="accordion" id="customer_type_option_acrd_list_box_1">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="customer_type_option_acrd_list_box_1">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#customer_type_option_accordion_list_box_1" aria-expanded="false" aria-controls="customer_type_option_accordion_list_box_1" role="tabpanel">List Box</button>
                                                </h2>
                                                <div id="customer_type_option_accordion_list_box_1" class="accordion-collapse collapse" data-bs-parent="#customer_type_option_acrd_list_box_1">
                                                    <div class="accordion-body px-2">
                                                        <div class="scroll-y max-h-200px px-3">
                                                            <div class="form-repeater_customer_type_option_list_box_1">
                                                                <div data-repeater-list="group-a_customer_type_option_list_box_1">
                                                                    <div data-repeater-item>
                                                                        <div class="row">
                                                                            <div class="col-lg-10">
                                                                                <label class="text-dark mb-1 fs-6 fw-semibold">Option 1
                                                                                    <span class="text-danger">*</span></label>
                                                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Option 1"></textarea>
                                                                            </div>
                                                                            <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 customer_type_option_butt_del_list_box_1" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_list_box_1" style="display: none !important;">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary customer_type_option_butt_add_list_box_1" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="customer_type_option_butt_add_list_box_1">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-3 d-flex align-items-center">
                                        <div class="form-check form-check-inline mt-4">
                                            <input class="form-check-input cred_check" type="checkbox" />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 customer_type_option_butt_del_question_1" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="customer_type_option_butt_del_question_1" style="display: none !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div> -->
                        </div>
                        <hr class="bg-light m-1">
                    </div>
                </div>
            </div>
            <div class="mb-1 mt-1">
                <button class="btn btn-primary customer_type_option_butt_add_Question" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="customer_type_option_butt_add_Question">
                    <i class="mdi mdi-plus me-1"></i>
                </button>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <a href="{{url('/settings/sales')}}" class="btn btn-secondary me-3">Cancel</a>
                <a href="{{url('/settings/sales')}}" class="btn btn-primary">Create Customer Type Option</a>
            </div>
        </div>
    </div>
</div>


<!-- Label Value Function Start -->
<script>
    function customer_type_option_label_func() {
        var customer_type_option_label_value = document.getElementById("customer_type_option_label_value").value;
        var customer_type_option_check_box = document.getElementById("customer_type_option_check_box");
        var customer_type_option_radio_button = document.getElementById("customer_type_option_radio_button");
        var customer_type_option_list_box = document.getElementById("customer_type_option_list_box");

        if (customer_type_option_label_value == "check_box") {
            customer_type_option_check_box.style.display = "block";
            customer_type_option_radio_button.style.display = "none";
            customer_type_option_list_box.style.display = "none";
        } else if (customer_type_option_label_value == "radio_button") {
            customer_type_option_check_box.style.display = "none";
            customer_type_option_radio_button.style.display = "block";
            customer_type_option_list_box.style.display = "none";
        } else if (customer_type_option_label_value == "list_box") {
            customer_type_option_check_box.style.display = "none";
            customer_type_option_radio_button.style.display = "none";
            customer_type_option_list_box.style.display = "block";
        } else {
            customer_type_option_check_box.style.display = "none";
            customer_type_option_radio_button.style.display = "none";
            customer_type_option_list_box.style.display = "none";
        }
    }
</script>
<!-- Label Value Function End -->
<!-- label value ( Check Box ) drop down box Start -->
<script>
    $('.customer_type_option_butt_add_chk_box').on('click', e => {
        var bt = parseFloat($('.form-repeater_customer_type_option_chk_box').length);
        let $clone = $('.form-repeater_customer_type_option_chk_box').first().clone().hide();
        $clone.insertBefore('.form-repeater_customer_type_option_chk_box:first').slideDown();
        if (bt == 1) {
            $('.customer_type_option_butt_del_chk_box').attr('style', 'display: block !important');
        } else {
            $('.customer_type_option_butt_del_chk_box').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_customer_type_option_chk_box .customer_type_option_butt_del_chk_box', e => {
        var bt = parseFloat($('.customer_type_option_butt_del_chk_box').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_customer_type_option_chk_box').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.customer_type_option_butt_del_chk_box').attr('style', 'display: none !important');
        } else {}
    });
</script>
<!-- label value ( Check Box ) drop down box end -->
<!-- label value ( Radio Button ) drop down box Start -->
<script>
    $('.customer_type_option_butt_add_radio').on('click', e => {
        var bt = parseFloat($('.form-repeater_customer_type_option_radio').length);
        let $clone = $('.form-repeater_customer_type_option_radio').first().clone().hide();
        $clone.insertBefore('.form-repeater_customer_type_option_radio:first').slideDown();
        if (bt == 1) {
            $('.customer_type_option_butt_del_radio').attr('style', 'display: block !important');
        } else {
            $('.customer_type_option_butt_del_radio').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_customer_type_option_radio .customer_type_option_butt_del_radio', e => {
        var bt = parseFloat($('.customer_type_option_butt_del_radio').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_customer_type_option_radio').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.customer_type_option_butt_del_radio').attr('style', 'display: none !important');
        } else {}
    });
</script>
<!-- label value ( Radio Button ) drop down box End -->
<!-- label value ( List Box ) drop down box Start -->
<script>
    $('.customer_type_option_butt_add_list_box').on('click', e => {
        var bt = parseFloat($('.form-repeater_customer_type_option_list_box').length);
        let $clone = $('.form-repeater_customer_type_option_list_box').first().clone().hide();
        $clone.insertBefore('.form-repeater_customer_type_option_list_box:first').slideDown();
        if (bt == 1) {
            $('.customer_type_option_butt_del_list_box').attr('style', 'display: block !important');
        } else {
            $('.customer_type_option_butt_del_list_box').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_customer_type_option_list_box .customer_type_option_butt_del_list_box', e => {
        var bt = parseFloat($('.customer_type_option_butt_del_list_box').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_customer_type_option_list_box').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.customer_type_option_butt_del_list_box').attr('style', 'display: none !important');
        } else {}
    });
</script>
<!-- label value ( List Box ) drop down box End -->
<!-- Overall label value Add More Start -->
<script>
    $('.customer_type_option_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_customer_type_option_questions').length);
        let $clone = $('.form-repeater_customer_type_option_questions').first().clone().hide();
        $clone.insertBefore('.form-repeater_customer_type_option_questions:first').slideDown();
        if (bt == 1) {
            $('.customer_type_option_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.customer_type_option_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_customer_type_option_questions .customer_type_option_butt_del_question', e => {
        var bt = parseFloat($('.customer_type_option_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_customer_type_option_questions').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.customer_type_option_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>
<!-- Overall label value Add More End -->
<!-- Depends Function Start -->
<script>
    function depends_func() {
        var depends_id = document.getElementById("depends_id");
        var depends_danger = document.getElementById("depends_danger");
        var depends_tbox = document.getElementById("depends_tbox");

        if (depends_id.checked) {
            // depends.style.display = "block";
            depends_danger.style.display = "inline";
            depends_tbox.style.display = "block";
        } else {
            depends_danger.style.display = "none";
            depends_tbox.style.display = "none";
        }
    }
</script>
<!-- Depends Function End -->
@endsection