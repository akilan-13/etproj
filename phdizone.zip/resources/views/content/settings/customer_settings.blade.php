@extends('layouts/layoutMaster')

@section('title', 'Customer Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss',
'resources/assets/vendor/libs/jstree/jstree.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/jstree/jstree.js'
])
@endsection

@section('page-script')
@vite([
'resources/assets/js/sliders.js'
])
@endsection

@section('content')
<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_lead_university" aria-controls="tab_lead_university" aria-selected="true">University Name</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_payment_mode" aria-controls="tab_payment_mode" aria-selected="false">Payment Mode</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_payment_mode_option" aria-controls="tab_payment_mode_option" aria-selected="false">Payment Mode Option</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_customer_type" aria-controls="tab_customer_type" aria-selected="false">Customer Type</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_customer_type_option" aria-controls="tab_customer_type_option" aria-selected="false">Customer Type Option</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_progress_bar" aria-controls="tab_progress_bar" aria-selected="false">Progress Level</button>
        </li>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
          <div class="tab-pane fade" id="tab_lead_source" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead_source">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Lead Source
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Lead Source</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Email</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="A lead source represents the channel or pathway through which potential customers first encounter your business."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Website</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="A lead source represents the channel or pathway through which potential customers first encounter your business."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label>Facebook</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="A lead source represents the channel or pathway through which potential customers first encounter your business."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>
                        <label>Justdial</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="A lead source represents the channel or pathway through which potential customers first encounter your business."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_source" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_lead_type" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead_type">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Lead Type
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Lead Type</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Employee</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">

                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Student</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leading as a student in an academy course involves setting an example, fostering participation, and supporting peers to enhance the learning experience for all"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_lead_potential_type" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead_potential_type">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Lead Potential Type
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Lead Potential Type</th>
                      <th class="min-w-50px">Score</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Good</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>7 - 10</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Some Potential</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>5 - 7</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label>Moderate</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>3 - 5</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>
                        <label>Very Worst</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>0 - 3</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_potential_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_lead_questions" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/sales/lead_questions_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Lead Questions
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Question</th>
                      <th class="min-w-100px">Question Type</th>
                      <th class="min-w-100px">Question Option</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer is interested to Assign Project or Not ?">Customer is interested to join course or not ?</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Interested , Not Interested">Interested, Not Interested</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/sales/lead_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer is a">Customer is a</label>
                      </td>
                      <td>List Box</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="School Student, College Student, Employee, House Wife">School Student, School Student, College Student</label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/sales/lead_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Interested to take call or not?">Customer Interested to take call or not?</label>
                      </td>
                      <td>Radio Button</td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yes, No">Yes, No
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/sales/lead_questions_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_question" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_lead_status" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead_status">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Lead Status
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Lead Status</th>
                      <th class="min-w-150px">Background Color</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Active</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#fdb528</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_status" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_status" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Drop</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leading as a student in an academy course involves setting an example, fostering participation, and supporting peers to enhance the learning experience for all"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#fdb528</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_status" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead_status" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane show active" id="tab_lead_university" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_university">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add University Name
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">University Name</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Madurai Kamarajar University</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_university" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_university" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Dindugal Anna University</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_university" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_university" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_payment_mode" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_payment_mode">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Payment Mode
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Payment Mode</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Cash</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Cash payment mode involves the exchange of physical currency notes and coins as a means of settling transactions."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Cheque</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Cheque payment mode involves the issuance of a written order directing a bank to pay a specified sum to the designated recipient."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label>Cashfree</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>
                        <label>Razorpay</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>
                        <label>PayUMoney</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>6</td>
                      <td>
                        <label>NetBanking</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>7</td>
                      <td>
                        <label>Google Pay</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_payment_mode_option" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/payment_mode_option/payment_mode_option_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Payment Mode Option
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-25px">S.No</th>
                      <th class="min-w-100px">Payment Mode</th>
                      <th class="min-w-100px">Label / Value</th>
                      <th class="min-w-100px">Option</th>
                      <th class="min-w-80px">Depends</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Cheque">Cheque</label>
                      </td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Bank Name">Bank Name</label>
                        <div class="d-flex align-items-center">
                          <div class="text-info fs-8" title="Batch">List Box</div>
                          <div>
                            <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover"><i class="ms-1 mdi mdi-information text-black"></i></a>
                            <div class="dropdown-menu pt-4 pb-2 px-6 text-black scroll-y max-h-250px" style="width: 330px;">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Bank Name<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Account No<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Amount<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Cheque No<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Cheque Entry Date<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Date Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Cheque Expiery Date<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Date Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Holder Name<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="-">-</label>
                      </td>
                      <td>-
                        <!-- <label class="badge bg-info fs-8">No</label> -->
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_payment_mode_option" title="View">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="{{url('/settings/payment_mode_option/payment_mode_option_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode_option" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Cash">Cash</label>
                      </td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">Amount</label>
                        <div class="d-flex align-items-center">
                          <div class="text-info fs-8" title="Batch">Text Field</div>
                          <div>
                            <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover"><i class="ms-1 mdi mdi-information text-black"></i></a>
                            <div class="dropdown-menu pt-4 pb-2 px-6 text-black scroll-y max-h-250px" style="width: 330px;">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Amount<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Created Date<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Date Field</label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="-">-</label>
                      </td>
                      <td>-
                        <!-- <label class="badge bg-info fs-8">No</label> -->
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_payment_mode_option" title="View">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="{{url('/settings/payment_mode_option/payment_mode_option_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode_option" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Google Pay">Google Pay</label>
                      </td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">Amount</label>
                        <div class="d-flex align-items-center">
                          <div class="text-info fs-8" title="Batch">Text Field</div>
                          <div>
                            <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover"><i class="ms-1 mdi mdi-information text-black"></i></a>
                            <div class="dropdown-menu pt-4 pb-2 px-6 text-black scroll-y max-h-250px" style="width: 330px;">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Amount<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Created Date<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Date Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Mobile No<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Transaction ID<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">UPI ID<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Text Field</label>
                              </div>
                              <hr class="bg-gray-400 m-1">
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Label</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fw-bold fs-7">Attachments<span class="text-danger ms-1">*</span></label>
                              </div>
                              <div class="row mb-2">
                                <label class="col-3 text-black fs-7 fw-semibold">Value</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <label class="col-8 text-black fs-7 fw-bold">Multiple Images</label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="-">-</label>
                      </td>
                      <td>-
                        <!-- <label class="badge bg-info fs-8">No</label> -->
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_payment_mode_option" title="View">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="{{url('/settings/payment_mode_option/payment_mode_option_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_payment_mode_option" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_customer_type" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_customer_type">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Customer Type
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Customer Type</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label>Employee</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_customer_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>Student</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_customer_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer_type" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_customer_type_option" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/customer_type_option/customer_type_option_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Customer Type Option
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-25px">S.No</th>
                      <th class="min-w-100px">Customer Type</th>
                      <th class="min-w-100px">Label / Value</th>
                      <th class="min-w-100px">Option</th>
                      <th class="min-w-80px">Depends</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-100px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Student</td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Educational Level">Educational Level</label>
                        <div class="d-block text-primary fs-8">List Box</div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="School, College">School, College</label>
                      </td>

                      <td>
                        <label class="badge bg-info fs-8">Yes
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_cus_type_option" title="View">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="{{url('/settings/customer_type_option/customer_type_option_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer_type_option" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Employee</td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Work Place Name">Work Place Name</label>
                        <div class="d-block text-primary fs-8">Text Field</div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="-">-</label>
                      </td>
                      <td>-</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_cus_type_option" title="View">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="{{url('/settings/customer_type_option/customer_type_option_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer_type_option" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Employee</td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Years of Experience">Years of Experience</label>
                        <div class="d-block text-primary fs-8">Text Field</div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="-">-</label>
                      </td>

                      <td>-
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_cus_type_option" title="View">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="{{url('/settings/customer_type_option/customer_type_option_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer_type_option" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Employee</td>
                      <td>
                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Position">Position</label>
                        <div class="d-block text-primary fs-8">Text Field</div>
                      </td>
                      <td>
                        <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="-">-</label>
                      </td>
                      <td>-
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_cus_type_option" title="View">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="{{url('/settings/customer_type_option/customer_type_option_edit')}}" class="btn btn-icon btn-sm me-2" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer_type_option" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_progress_bar" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_progress_bar">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Progress Level
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Progress Level %</th>
                      <th class="min-w-80px">Background Color</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td><label>
                          <span>0</span>
                          <span class="me-1 ms-1">-</span>
                          <span>25</span>
                        </label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#ff0000</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label>
                          <span>25</span>
                          <span class="me-1 ms-1">-</span>
                          <span>50</span>
                        </label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#ffa500</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td><label>
                          <span>50</span>
                          <span class="me-1 ms-1">-</span>
                          <span>75</span>
                        </label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#ec9629</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td><label>
                          <span>75</span>
                          <span class="me-1 ms-1">-</span>
                          <span>100</span>
                        </label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>#008000</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_progress_bar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--begin::Modal - Add Lead Source-->
<div class="modal fade" id="kt_modal_add_lead_source" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Source</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Source" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Source</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Source-->
<!--begin::Modal - Edit Lead Source-->
<div class="modal fade" id="kt_modal_edit_lead_source" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Source</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Source" value="Email" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Source</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Source-->
<!--begin::Modal - Delete Lead Source-->
<div class="modal fade" id="kt_modal_delete_lead_source" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Source ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Source-->




<!--begin::Modal - Add Lead Type-->
<div class="modal fade" id="kt_modal_add_lead_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Type" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Type-->
<!--begin::Modal - Edit Lead Type-->
<div class="modal fade" id="kt_modal_edit_lead_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Type" value="Employee" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Type-->
<!--begin::Modal - Delete Lead Type-->
<div class="modal fade" id="kt_modal_delete_lead_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Type ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Type-->




<!--begin::Modal - Add Lead Potential Type-->
<div class="modal fade" id="kt_modal_add_lead_potential_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Potential Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Potential Score<span class="text-danger">*</span></label>
            <div class="noUi-primary mb-7" id="lead_potential_type_add"></div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Potential Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Potential Type" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Emoji<span class="text-danger">*</span></label>
            <div class="scroll-y max-h-200px">
              <div class="d-flex flex-wrap gap-3 py-4 px-4">
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('box_smile');">
                  <i class="mdi mdi-sticker-emoji fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_1" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_smile');">
                  <i class="mdi mdi-emoticon-lol-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_2" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_sad');">
                  <i class="mdi mdi-emoticon-frown-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_3" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_angry');">
                  <i class="mdi mdi-emoticon-confused-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_4" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_cry');">
                  <i class="mdi mdi-emoticon-cry-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_5" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_feel');">
                  <i class="mdi mdi-emoticon-sad-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_6" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_sick');">
                  <i class="mdi mdi-emoticon-sick-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_7" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_no_eye');">
                  <i class="mdi mdi-emoticon-dead-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_8" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_kiss');">
                  <i class="mdi mdi-emoticon-kiss-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_9" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_one_eye');">
                  <i class="mdi mdi-emoticon-wink-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_10" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_very_angry');">
                  <i class="mdi mdi-emoticon-angry-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_11" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_devil');">
                  <i class="mdi mdi-emoticon-devil-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_12" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_happy');">
                  <i class="mdi mdi-emoticon-happy-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_13" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_all_close');">
                  <i class="mdi mdi-emoticon-tongue-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_14" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_eye_up');">
                  <i class="mdi mdi-emoticon-excited-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_15" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_cooler');">
                  <i class="mdi mdi-emoticon-cool-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_16" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_very_happy');">
                  <i class="mdi mdi-emoticon-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_17" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
                <a href="javascript:;" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2" onclick="emoji_func('cir_boy');">
                  <i class="mdi mdi-face-man-shimmer-outline fs-2"></i>
                  <label class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1" id="emj_18" style="display: none;">
                    <span class="mdi mdi-check fs-6 fw-bold"></span>
                  </label>
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Potential Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Potential Type-->
<!--begin::Modal - Edit Lead Potential Type-->
<div class="modal fade" id="kt_modal_edit_lead_potential_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Potential Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Potential Score<span class="text-danger">*</span></label>
            <div class="noUi-primary mb-7" id="lead_potential_type_edit"></div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Potential Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Potential Type" value="Good" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Potential Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Potential Type-->
<!--begin::Modal - Delete Lead Potential Type-->
<div class="modal fade" id="kt_modal_delete_lead_potential_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Potential Type ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Potential Type-->




<!--begin::Modal - Delete Lead Question-->
<div class="modal fade" id="kt_modal_delete_lead_question" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
        delete Lead Question ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Question-->



<!--begin::Modal - Add Lead Status-->
<div class="modal fade" id="kt_modal_add_lead_status" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Lead Status</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Status" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Lead Status-->
<!--begin::Modal - Edit Lead Status-->
<div class="modal fade" id="kt_modal_edit_lead_status" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Lead Status</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Status<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Lead Status" value="Active" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" value="#fdb528" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead Status</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Lead Status-->
<!--begin::Modal - Delete Lead Status-->
<div class="modal fade" id="kt_modal_delete_lead_status" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Lead Status ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead Status-->

<!--begin::Modal - Add University-->
<div class="modal fade" id="kt_modal_add_university" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create University</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">University<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter University Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create University</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add University-->
<!--begin::Modal - Edit University-->
<div class="modal fade" id="kt_modal_edit_university" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update University</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">University<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter University" value="Madurai Kamarajar University" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update University</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit University-->
<!--begin::Modal - Delete University-->
<div class="modal fade" id="kt_modal_delete_university" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete University ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete university-->



<!--begin::Modal - Add Payment Mode-->
<div class="modal fade" id="kt_modal_add_payment_mode" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Payment Mode</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Payment Mode" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Payment Mode</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Payment Mode-->
<!--begin::Modal - Edit Payment Mode-->
<div class="modal fade" id="kt_modal_edit_payment_mode" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Payment Mode</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Payment Mode" value="Cash" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Payment Mode</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Payment Mode-->
<!--begin::Modal - Delete Payment Mode-->
<div class="modal fade" id="kt_modal_delete_payment_mode" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Payment Mode ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Payment Mode-->




<!--begin::Modal - View Payment Mode option-->
<div class="modal fade" id="kt_modal_view_payment_mode_option" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">View Payment Mode Option</h3>
        </div>
        <div class="row mb-4">
          <div class="col-lg-12">
            <div id="payment_mode_option_view">
              <!--List box icon <i class="mdi mdi-format-list-bulleted-triangle"></i> -->
              <!--check box icon <i class="mdi mdi-checkbox-marked-outline"></i> -->
              <!--Radio Button icon <i class="mdi mdi-radiobox-marked"></i> -->
              <!--TextArea icon <i class="mdi mdi-form-textarea"></i> -->
              <!--Date icon <i class="mdi mdi-calendar-range"></i> -->
              <!--Multi Image icon <i class="mdi mdi-image-outline"></i> -->
              <ul>
                <li class="jstree-open" data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                  <span class="fw-bold fs-5" title="Payment Mode Option">Cheque</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                  <ul data-jstree='{"icon" : "mdi mdi-folder-network-outline"}'>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Bank Name</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Account No</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Amount</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Cheque No</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-calendar-range"}'>
                      <span class="fw-semibold fs-7" title="Date Field">Cheque Entry Date</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-calendar-range"}'>
                      <span class="fw-semibold fs-7" title="Date Field">Cheque Expiery Date</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Holder Name</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View Payment Mode option-->
<!--begin::Modal - Delete Payment Mode option-->
<div class="modal fade" id="kt_modal_delete_payment_mode_option" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Payment Mode Option ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Payment Mode option-->





<!--begin::Modal - Add Customer Type-->
<div class="modal fade" id="kt_modal_add_customer_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Customer Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Customer Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Customer Type" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Customer Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Customer Type-->
<!--begin::Modal - Edit Customer Type-->
<div class="modal fade" id="kt_modal_edit_customer_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Customer Type</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Customer Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Customer Type" value="Employee" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Customer Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Customer Type-->
<!--begin::Modal - Delete Customer Type-->
<div class="modal fade" id="kt_modal_delete_customer_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Customer Type ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Customer Type-->




<!--begin::Modal - View Customer type option-->
<div class="modal fade" id="kt_modal_view_cus_type_option" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">View Customer Type Option
            <!-- <label class="me-4 badge bg-warning text-black rounded fw-bold fs-4">Email</label> -->
          </h3>
        </div>
        <div class="row mb-4">
          <div class="col-lg-12">
            <div id="custom_type_option_view">
              <!--check box icon <i class="mdi mdi-checkbox-marked-outline"></i> -->
              <!--Radio Button icon <i class="mdi mdi-radiobox-marked"></i> -->
              <!--TextArea icon <i class="mdi mdi-form-textarea"></i> -->
              <ul>
                <li class="jstree-open" data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                  <span class="fw-bold fs-5" title="Customer Type Option">Student</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                  <ul>
                    <li class="jstree-open" data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                      <span class="fw-bold fs-6" title="List Box">Educational Level</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                      <ul data-jstree='{"icon" : "mdi mdi-folder-network-outline"}'>
                        <li class="jstree-open" data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                          <span class="fw-bold fs-6" title="List Box">School</span>
                          <ul data-jstree='{"icon" : "mdi mdi-folder-network-outline"}'>
                            <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                              <span class="fw-semibold fs-7" title="Text Field">School Name</span>
                            </li>
                            <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                              <span class="fw-semibold fs-7" title="Text Field">Studing Class</span>
                            </li>
                          </ul>
                        </li>
                      </ul>
                      <ul data-jstree='{"icon" : "mdi mdi-folder-network-outline"}'>
                        <li class="jstree-open" data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                          <span class="fw-bold fs-6" title="List Box">College</span>
                          <ul data-jstree='{"icon" : "mdi mdi-folder-network-outline"}'>
                            <li data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                              <span class="fw-bold fs-6" title="List Box">Qualification Type</span>
                            </li>
                            <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                              <span class="fw-bold fs-6" title="Text Field">Qualification Name</span>
                            </li>
                            <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                              <span class="fw-bold fs-6" title="Text Field">University Name</span>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li class="jstree-open" data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                  <span class="fw-bold fs-5" title="Customer Type Option">Employee</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                  <ul data-jstree='{"icon" : "mdi mdi-folder-network-outline"}'>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Work Place Name</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Position</span>
                    </li>
                    <li data-jstree='{"icon" : "mdi mdi-text-recognition"}'>
                      <span class="fw-semibold fs-7" title="Text Field">Years of Experience</span>
                    </li>
                  </ul>
                </li>
                <li data-jstree='{"icon" : "mdi mdi-format-list-bulleted-triangle"}'>
                  <span class="fw-bold fs-5" title="Customer Type Option">Others</span><span class="text-danger fs-4 fw-bold ms-1">*</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View Customer type option-->
<!--begin::Modal - Delete Customer type option-->
<div class="modal fade" id="kt_modal_delete_customer_type_option" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Customer Type Option ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Customer type option-->




<!--begin::Modal - Add progress bar Level-->
<div class="modal fade" id="kt_modal_add_progress_bar" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Progress Level</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Progress Start (%)<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Progress Level" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Progress End (%)<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Progress Level" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Progress Level</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add progress bar Level -->
<!--begin::Modal - Edit progress bar Level-->
<div class="modal fade" id="kt_modal_edit_progress_bar" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Progress Level</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Progress Start (%)<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Progress Level" value="0" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Progress End (%)<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Progress Level" value="25" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Background Color<span class="text-danger">*</span></label>
            <input type="color" class="form-control" id="" placeholder="Enter Background Color" value="#ff0000" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Progress Level</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit progress bar Level -->
<!--begin::Modal - Delete progress bar-->
<div class="modal fade" id="kt_modal_delete_progress_bar" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Progress Level ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete progress bar--->

<script>
  'use strict';
  // Customer Type Option Treeview
  $(function() {
    var theme = $('html').hasClass('light-style') ? 'default' : 'default-dark',
      basicTree = $('#custom_type_option_view');

    // Basic
    // --------------------------------------------------------------------
    if (basicTree.length) {
      basicTree.jstree({
        core: {
          themes: {
            name: theme
          }
        }
      });
    }
  });

  // Payment Mode Option Treeview
  $(function() {
    var payment_mode_opt_theme = $('html').hasClass('light-style') ? 'default' : 'default-dark',
      payment_mode_option_basicTree = $('#payment_mode_option_view');

    // Basic
    // --------------------------------------------------------------------
    if (payment_mode_option_basicTree.length) {
      payment_mode_option_basicTree.jstree({
        core: {
          themes: {
            name: payment_mode_opt_theme
          }
        }
      });
    }
  });
</script>

<script>
  $('.cus_edu_info').on('click', e => {
    var bt = parseFloat($('.form-repeater_cus_edu').length);
    let $clone = $('.form-repeater_cus_edu').first().clone().hide();
    $clone.insertBefore('.form-repeater_cus_edu:first').slideDown();
    if (bt == 1) {
      $('.cus_edu_del').attr('style', 'display: block !important');
    } else {
      $('.cus_edu_del').attr('style', 'display: block !important');
    }
  });

  $(document).on('click', '.form-repeater_cus_edu .cus_edu_del', e => {
    var bt = parseFloat($('.cus_edu_del').length);
    // alert(bt);
    $(e.target).closest('.form-repeater_cus_edu').slideUp(400, function() {
      $(this).remove()
    });
    if (bt == 2) {
      $('.cus_edu_del').attr('style', 'display: none !important');
    } else {}
  });
</script>
<script>
  function fields_func() {
    var fields_id = document.getElementById("fields_id");
    var cus_edu = document.getElementById("cus_edu");

    if (fields_id.checked) {
      cus_edu.style.display = "block";

    } else {
      cus_edu.style.display = "none";

    }
  }
</script>
<script>
  function emoji_func(val) {
    if (val == "box_smile") {
      document.getElementById("emj_1").style.display = "block";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_smile") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "block";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_sad") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "block";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_angry") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "block";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_cry") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "block";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_feel") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "block";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_sick") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "block";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_no_eye") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "block";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_kiss") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "block";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_one_eye") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "block";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_very_angry") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "block";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_devil") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "block";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_happy") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "block";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_all_close") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "block";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_eye_up") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "block";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_cooler") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "block";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_very_happy") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "block";
      document.getElementById("emj_18").style.display = "none";

    } else if (val == "cir_boy") {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "block";

    } else {
      document.getElementById("emj_1").style.display = "none";
      document.getElementById("emj_2").style.display = "none";
      document.getElementById("emj_3").style.display = "none";
      document.getElementById("emj_4").style.display = "none";
      document.getElementById("emj_5").style.display = "none";
      document.getElementById("emj_6").style.display = "none";
      document.getElementById("emj_7").style.display = "none";
      document.getElementById("emj_8").style.display = "none";
      document.getElementById("emj_9").style.display = "none";
      document.getElementById("emj_10").style.display = "none";
      document.getElementById("emj_11").style.display = "none";
      document.getElementById("emj_12").style.display = "none";
      document.getElementById("emj_13").style.display = "none";
      document.getElementById("emj_14").style.display = "none";
      document.getElementById("emj_15").style.display = "none";
      document.getElementById("emj_16").style.display = "none";
      document.getElementById("emj_17").style.display = "none";
      document.getElementById("emj_18").style.display = "none";
    }
  }
</script>
<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
@endsection