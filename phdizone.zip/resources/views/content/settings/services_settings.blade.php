@extends('layouts/layoutMaster')

@section('title', 'Services Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/tagify/tagify.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/tagify/tagify.js'
])
@endsection

@section('page-script')
@vite('resources/assets/js/forms_tagify.js')
@endsection
@section('content')

@section('content')
<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_service_category" aria-controls="tab_service_category" aria-selected="true">Service Category</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_service_name" aria-controls="tab_service_name" aria-selected="false">Service Name</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_add_package" aria-controls="tab_add_package" aria-selected="false">Package</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_add_on_service_category" aria-controls="tab_add_on_service_category" aria-selected="false">Add-On-Services</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_add_on_properties" aria-controls="tab_add_on_properties" aria-selected="false">Add Properties</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_add_duration" aria-controls="tab_add_duration" aria-selected="false">Duration</button>
        </li>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
          <div class="tab-pane fade show active" id="tab_service_category" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_service_category">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Service Category
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Service Category</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Reasearch Services
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>PHD Services
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Writing Services
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Development Services
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>Analysis Services
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_service_name" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_service_name">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Service Name
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Service Name</th>
                      <th class="min-w-100px">Service Category</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-gray-600 fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Research Paper Writing Service
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Research services</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_course_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Book Writing Service
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>PHD Service</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_course_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Scopus Indexed Journal
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Writing Service</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_course_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Python Development
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Development Service</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_course_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>SPSS Analysis
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>Analysis Service</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_course_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_service_subcategory" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_on_service_category" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_on_service_category">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Add-On-Services
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-20px">S.No</th>
                      <th class="min-w-150px">Add-On-Services</th>
                      <th class="min-w-150px">Services</th>
                      <th class="min-w-50px">F / P</th>
                      <th class="min-w-50px">Cost</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Literature Writing
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Development Services</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">Python Services</label>
                        </div>
                      </td>
                      <td><label class="badge bg-success text-black fw-bold">Paid</label></td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Duration">1 Hour</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Cost">
                            <span class="mdi mdi-currency-rupee fs-8"></span>
                            <span>750</span>
                          </label>
                        </div>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_add_on_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_on_services" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Plagiarism Checking
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Research services</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">Research Paper Writing Service</label>
                        </div>
                      </td>
                      <td><label class="badge bg-info text-white">Free</label></td>
                      <td>-
                        <!-- <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Duration">1 Hour</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Cost">
                            <span class="mdi mdi-currency-rupee fs-8"></span>
                            <span>750</span>
                          </label>
                        </div> -->
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_add_on_service_category" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_on_services" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_package" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/quotataion/quotation_template_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Package
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-100px">Package Name</th>
                      <th class="min-w-100px">Service</th>
                      <th class="min-w-100px">Price</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Package Name">Paper Writing</label>
                      </td>
                      <td>
                        <label>Writing Service</label>
                        <div class="d-block">
                          <label class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">Thesis Writing</label>
                        </div>
                      </td>
                      <td>
                        <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">
                          <span class="mdi mdi-currency-rupee fs-7"></span>
                          <span>50,000</span>
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/quotataion/quotation_template_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_view_service_package" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_package" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Package Name">Scopue Q1/Q2 Research Paper</label>
                      </td>
                      <td>
                        <label>Writing Service</label>
                        <div class="d-block">
                          <label class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">Essay Writing</label>
                        </div>
                      </td>
                      <td>
                        <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">
                          <span class="mdi mdi-currency-rupee fs-7"></span>
                          <span>60,000</span>
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/quotataion/quotation_template_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_view_service_package" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_package" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Package Name">Coding Development</label>
                      </td>
                      <td>
                        <label>Development Service</label>
                        <div class="d-block">
                          <label class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">Python Development</label>
                        </div>
                      </td>
                      <td>
                        <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">
                          <span class="mdi mdi-currency-rupee fs-7"></span>
                          <span>40,000</span>
                        </label>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/quotataion/quotation_template_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_view_service_package" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_package" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_on_properties" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/services/service_properties_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Add-Properties
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Service</th>
                      <th class="min-w-100px">Add Properties</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Development Services</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">Python Services</label>
                        </div>
                      </td>
                      <td><label class="badge bg-info text-white">Yes</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/services/service_properties_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="modal" data-bs-target="#kt_modal_view_offerzone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_properties" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Research services</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">Research Paper Writing Service</label>
                        </div>
                      </td>
                      <td><label class="badge bg-info text-white">Yes</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/services/service_properties_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="modal" data-bs-target="#kt_modal_view_offerzone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_properties" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Analysis Service</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">SPSS Analysis</label>
                        </div>
                      </td>
                      <td><label class="badge bg-warning text-black fw-bold">No</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/services/service_properties_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <!-- <a href="#" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="modal" data-bs-target="#kt_modal_view_offerzone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a> -->
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_properties" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_product" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="{{url('/settings/services/service_product_add')}}" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Product
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-150px">Service</th>
                      <th class="min-w-100px">Add Product</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-80px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">PHD Services</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">Thesis Writing</label>
                        </div>
                      </td>
                      <td><label class="badge bg-info text-white">Yes</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/services/service_product_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="modal" data-bs-target="#kt_modal_view_service_product" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_product" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Research services</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">Research Paper Writing Service</label>
                        </div>
                      </td>
                      <td><label class="badge bg-info text-white">Yes</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/services/service_product_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="modal" data-bs-target="#kt_modal_view_service_product" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_product" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Analysis Service</label>
                        <div class="d-block">
                          <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Sub Category">SPSS Analysis</label>
                        </div>
                      </td>
                      <td><label class="badge bg-warning text-black fw-bold">No</label></td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="{{url('/settings/services/service_product_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <!-- <a href="#" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="modal" data-bs-target="#kt_modal_view_offerzone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                          </a> -->
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_add_product" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_programming_language" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_programming_language">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Programming Language
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Programming Language</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Python
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Java
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Matlab
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>VLSI
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>Embedded
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_programming_language" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_domain" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_domain">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Domain
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-25px">S.No</th>
                      <th class="min-w-100px">Programming Language</th>
                      <th class="min-w-150px">Domain</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-gray-600 fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>Python</td>
                      <td>Cloud Computing
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Java</td>
                      <td>Big Data
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Matlab</td>
                      <td>Image Processing
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>VLSI</td>
                      <td>Data Mining
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>Embedded</td>
                      <td>Hadoop
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_domain" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_data_base" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_database">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Database
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Data Base</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>MySQL
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Oracle
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>PostgreSQL
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Microsoft SQL Server
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>MongoDB
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_database" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="tab_add_duration" role="tabpanel">
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_duration">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Duration
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-50px">S.No</th>
                      <th class="min-w-300px">Duration</th>
                      <th class="min-w-50px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                    <tr>
                      <td>1</td>
                      <td>15 - 20 Days
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_duration" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_duration" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>10 - 15 Days
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_duration" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_duration" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>20 - 25 Days
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_duration" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_duration" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!--begin::Modal - Add Service Category-->
<div class="modal fade" id="kt_modal_add_service_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Service Category</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Service Category" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Service Category</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Service Category-->
<!--begin::Modal - Edit Service Category-->
<div class="modal fade" id="kt_modal_edit_service_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Service Category</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Service Category" value="Research Services" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Service Category</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Service Category-->
<!--begin::Modal - Delete Service Category-->
<div class="modal fade" id="kt_modal_delete_service_category" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Service Category ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Service Category-->



<!--begin::Modal - Add Service Name-->
<div class="modal fade" id="kt_modal_add_service_name" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Service Name</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Service Category</option>
              <option value="1">Reasearch Services</option>
              <option value="2">PHD Services</option>
              <option value="3">Writing Services</option>
              <option value="4">Development Services</option>
              <option value="5">Analysis Services</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Service Name Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="">Create Service Name</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Service Sub Category-->
<!--begin::Modal - Edit Service Sub Category-->
<div class="modal fade" id="kt_modal_edit_course_subcategory" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Service Sub Category</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Service Category</option>
              <option value="1" selected>Reasearch Services</option>
              <option value="2">PHD Services</option>
              <option value="3">Writing Services</option>
              <option value="4">Development Services</option>
              <option value="5">Analysis Services</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Service Sub Category Name" value="Research Paper Writing Service " />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="">Update Service Sub Category</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Course Sub Category-->
<!--begin::Modal - Delete Course Sub Category-->
<div class="modal fade" id="kt_modal_delete_service_subcategory" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Service Sub Category ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Course Sub Category-->


<!--begin::Modal - Add On Service Category-->
<div class="modal fade" id="kt_modal_add_on_service_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Add On Services</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <select id="ser_cat" class="select3 form-select">
              <option value="">Select Service Category</option>
              <option value="1">Reasearch Services</option>
              <option value="2">PHD Services</option>
              <option value="3">Writing Services</option>
              <option value="4">Development Services</option>
              <option value="5">Analysis Services</option>
            </select>
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Name<span class="text-danger">*</span></label>
            <select id="ser_sub_cat" class="select3 form-select">
              <option value="">Select Service Name</option>
              <option value="1">Research Paper Writing Service </option>
              <option value="2">Book Writing Service</option>
              <option value="3">Scopus Indexed Journal </option>
              <option value="4">Python Development </option>
              <option value="5">SPSS Analysis</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Add On Services<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Add On Services" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold d-block">Free / Cost<span class="text-danger">*</span></label>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="free" value="option1" onclick="free_cost()" />
              <label class="form-check-label" for="inlineRadio1">Free</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="cost" value="option2" onclick="free_cost()" />
              <label class="form-check-label" for="inlineRadio2">Cost</label>
            </div>
          </div>
          <div style="display:none;" id="cost_info">
            <div class="col-lg-12 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
              <select id="cost_dur" name="cost_dur" class="select3 form-select">
                <option value="">Select Duration</option>
                <option value="">1 Hour</option>
                <option value="">2 Hours</option>
                <option value="">4 Hours</option>
                <option value="">1 Day</option>
              </select>
            </div>
            <div class="col-lg-12 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Costing<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Costing" />
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Add On Services</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Add On Services-->
<!--begin::Modal - Edit Add On Services-->
<div class="modal fade" id="kt_modal_edit_add_on_service_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Add On Services</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <select id="ser_cat_edit" class="select3 form-select">
              <option value="">Select Service Category</option>
              <option value="1">Reasearch Services</option>
              <option value="2">PHD Services</option>
              <option value="3">Writing Services</option>
              <option value="4" selected>Development Services</option>
              <option value="5">Analysis Services</option>
            </select>
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
            <select id="ser_sub_cat_edit" class="select3 form-select">
              <option value="">Select Service Sub Category</option>
              <option value="1">Research Paper Writing Service </option>
              <option value="2">Book Writing Service</option>
              <option value="3">Scopus Indexed Journal </option>
              <option value="4" selected>Python Development </option>
              <option value="5">SPSS Analysis</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Add On Services<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Add On Services" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold d-block">Free / Cost<span class="text-danger">*</span></label>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="free_add_on" value="option1" onclick="edit_free_cost()" />
              <label class="form-check-label" for="inlineRadio1">Free</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="cost_add_on" value="option2" onclick="edit_free_cost()" />
              <label class="form-check-label" for="inlineRadio2">Cost</label>
            </div>
          </div>
          <div style="display:none;" id="edit_cost_info">
            <div class="col-lg-12 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
              <select id="edit_cost_dur" name="edit_cost_dur" class="select3 form-select">
                <option value="">Select Duration</option>
                <option value="">1 Hour</option>
                <option value="">2 Hours</option>
                <option value="">4 Hours</option>
                <option value="">1 Day</option>
              </select>
            </div>
            <div class="col-lg-12 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Costing<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Costing" />
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Add On Services</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Add On Services-->
<!--begin::Modal - Delete Add On Services-->
<div class="modal fade" id="kt_modal_delete_add_on_services" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Add On Services ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Add On Services-->


<!--begin::Modal - Add Package-->
<div class="modal fade" id="kt_modal_add_package" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Package</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <select id="ser_cat_package" class="select3 form-select">
              <option value="">Select Service Category</option>
              <option value="1">Reasearch Services</option>
              <option value="2">PHD Services</option>
              <option value="3">Writing Services</option>
              <option value="4">Development Services</option>
              <option value="5">Analysis Services</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Package Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Package Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Amount" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Add On Services</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Add Package-->


<!--begin::Modal - Edit Package-->
<div class="modal fade" id="kt_modal_edit_package" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Package</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
            <select id="ser_cat_edit_package" class="select3 form-select">
              <option value="">Select Service Category</option>
              <option value="1">Reasearch Services</option>
              <option value="2">PHD Services</option>
              <option value="3" selected>Writing Services</option>
              <option value="4">Development Services</option>
              <option value="5">Analysis Services</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Package Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Package Name" value="Page - 100" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Amount" value="50,000" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Packages</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Package-->

<!--begin::Modal - View Service Package-->
<div class="modal fade" id="kt_modal_view_service_package" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">View Service Package
          </h3>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Writing Service</label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Service Name</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Thesis Writing</label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Package Name</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Paper Writing</label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Price</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 fw-bold">
                <label class="badge bg-info fs-8">
                  <span class="mdi mdi-currency-rupee fs-8"></span>
                  <span>50,000.00</span></label>
              </label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">No Of Pages</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">100
              </label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Chapter</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">10
              </label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Working Hours</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">10 Hours
              </label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Working Days</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">10 Hours
              </label>
            </div>
            <div class="row mt-2">
              <label class="col-4 text-black fs-7 fw-semibold">Description</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">-</label>
            </div>
          </div>
        </div>
        <!--end::Modal body-->
      </div>
      <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
  </div>
  <!--end::Modal - View Service Management-->
</div>
<!--End::Modal - View Service Package-->

<!--begin::Modal - Delete Package-->
<div class="modal fade" id="kt_modal_delete_package" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Package ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Package-->

<!--begin::Modal - Delete Add Properties-->
<div class="modal fade" id="kt_modal_delete_add_properties" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Service Add Properties ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Add Properties-->

<!--begin::Modal - Delete Add Product-->
<div class="modal fade" id="kt_modal_delete_add_product" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Service Add Product ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Add Product-->

<!--begin::Modal - Add Programming language-->
<div class="modal fade" id="kt_modal_add_programming_language" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Programming Language</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Programming Language<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Programming Language" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Programming Language</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Programming language-->
<!--begin::Modal - Edit Programming language-->
<div class="modal fade" id="kt_modal_edit_programming_language" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Programming Language</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Programming Language<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Programming Language" value="Python" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Programming Language</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Programming language-->
<!--begin::Modal - Delete Programming language-->
<div class="modal fade" id="kt_modal_delete_programming_language" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Programming Language ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Programming Language-->


<!--begin::Modal - Add domain-->
<div class="modal fade" id="kt_modal_add_domain" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Domain</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Programming Language<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Programming Language</option>
              <option value="1">Python</option>
              <option value="2">Java</option>
              <option value="3">Matlab</option>
              <option value="4">VLSI</option>
              <option value="5">Embedded</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Domain<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Domain Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="">Create Domain</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Domain-->
<!--begin::Modal - Edit Domain-->
<div class="modal fade" id="kt_modal_edit_domain" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Domain</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Programming Language<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
              <option value="">Select Programming Language</option>
              <option value="1" selected>Python</option>
              <option value="2">Java</option>
              <option value="3">Matlab</option>
              <option value="4">VLSI</option>
              <option value="5">Embedded</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Domain<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Domain Name" value="Cloud Computing" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="">Update Domain</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Domain-->
<!--begin::Modal - Delete Domain-->
<div class="modal fade" id="kt_modal_delete_domain" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Domain ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Domain-->

<!--begin::Modal - Add Database-->
<div class="modal fade" id="kt_modal_add_database" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Database Name</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Database Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Database Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Database</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Database-->
<!--begin::Modal - Edit Database-->
<div class="modal fade" id="kt_modal_edit_database" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Database</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Database<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Database" value="MySQL" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Database</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Database-->
<!--begin::Modal - Delete Database-->
<div class="modal fade" id="kt_modal_delete_database" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Database ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Database-->

<!--begin::Modal - Add Duration-->
<div class="modal fade" id="kt_modal_add_duration" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Duration</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Duration" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Duration</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Duration-->
<!--begin::Modal - Edit Duration-->
<div class="modal fade" id="kt_modal_edit_duration" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Duration</h3>
        </div>
        <div class="row">
          <!-- Basic -->
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Duration" value="5 - 10 Days" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Duration</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Duration-->
<!--begin::Modal - Delete Duration-->
<div class="modal fade" id="kt_modal_delete_duration" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Duration ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Duration-->

<!--begin::Modal - Add Course Type-->
<div class="modal fade" id="kt_modal_add_course_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Course Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Course Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Course Type Name" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Days<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Days" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
            <div class="d-flex align-items-center">
              <input type="text" class="form-control me-2" id="" placeholder="Enter Duration" />
              <label class="text-dark mb-1 fs-6 fw-semibold">Hours</label>
            </div>
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Fees Collection End Days<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Fees Collt. End Days" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Fees Schedule Count<span class="text-danger">*</span>
              <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Without Minimum Collection Amount Count">
                <i class="mdi mdi-information text-dark"></i>
              </a>
            </label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Fees Schedule Count" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="2" id="" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="" data-bs-dismiss="modal">Create Course Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Course Type-->
<!--begin::Modal - Edit Course Type-->
<div class="modal fade" id="kt_modal_edit_course_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Course Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Course Type<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Course Type Name" value="Tesbo" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Days<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Days" value="60" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
            <div class="d-flex align-items-center">
              <input type="text" class="form-control me-2" id="" placeholder="Enter Duration" value="90" />
              <label class="text-dark mb-1 fs-6 fw-semibold">Hours</label>
            </div>
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Fees Collection End Days<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Fees Collt. End Days" value="40" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Fees Schedule Count<span class="text-danger">*</span>
              <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Without Minimum Collection Amount Count">
                <i class="mdi mdi-information text-dark"></i>
              </a>
            </label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Fees Schedule Count" value="2" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="2" id="" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="" data-bs-dismiss="modal">Update Course Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Course Type-->
<!--begin::Modal - Delete Course Type-->
<div class="modal fade" id="kt_modal_delete_course_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Course Type ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Course Type-->


<!--begin::Modal - Add Course Action-->
<div class="modal fade" id="kt_modal_add_course_action" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Course Action</h3>
        </div>
        <div class="row">
          <div class="col-lg-8">
            <div class="row">
              <div class="col-lg-12 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Course Action<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="" placeholder="Enter Course Action Name" />
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Course Action Type<span class="text-danger">*</span></label>
                <select id="ca_type" name="ca_type" class="select3 form-select" onchange="course_action_type_func();">
                  <option value="">Select Course Action Type</option>
                  <option value="manual_title">Manual Title</option>
                  <option value="link_base">Linkbase(URL)</option>
                  <option value="manual_content">Manual Content</option>
                  <option value="file_base">File Base</option>
                </select>
              </div>
              <div class="col-lg-12 mb-3" id="man_title_type" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Manual Title</label>
                <input type="text" class="form-control me-2" id="" placeholder="Enter Text" value="Title 1" disabled />
              </div>
              <div class="col-lg-12 mb-3" id="link_base_type" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Linkbase(URL)</label>
                <input type="text" class="form-control me-2" id="" placeholder="Enter Text" value="https://elysiumacademy.org/" disabled />
              </div>
              <div class="col-lg-12 mb-3" id="man_content_type" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Manual Content</label>
                <textarea class="form-control" rows="2" id="" placeholder="Enter Text" disabled>Content 1</textarea>
              </div>
              <div class="col-lg-12 mb-3" id="file_upload_type" style="display: none;">
                <label class="text-dark fs-6 fw-semibold">File Base</label>
                <div class="align-items-sm-center gap-4">
                  <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="Attachment" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="" />
                </div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control" rows="2" id="" placeholder="Enter Description"></textarea>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
              <div class="col-lg-12 mb-3">
                <label class="text-dark fs-6 fw-semibold">Icon<span class="text-danger">*</span></label>
                <div class="align-items-sm-center gap-4">
                  <div class="rounded border border-gray-600 border-solid w-px-120 h-px-120">
                    <img src="{{asset('assets/phdizone_images/def_img.png')}}" alt="Attachment" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="course_action" />
                  </div>
                  <div class="button-wrapper">
                    <div class="d-flex align-items-start mt-2 mb-2">
                      <label class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload File">
                        <i class="mdi mdi-tray-arrow-up"></i>
                        <input type="file" id="" class="course_action_cls" hidden accept="image/png, image/jpeg" />
                      </label>
                      <button type="button" class="btn btn-sm btn-outline-danger course_action-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                        <i class="mdi mdi-reload"></i>
                      </button>
                    </div>
                    <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="" data-bs-dismiss="modal">Create Course Action</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Course Action-->
<!--begin::Modal - Edit Course Action-->
<div class="modal fade" id="kt_modal_edit_course_action" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Course Action</h3>
        </div>
        <div class="row">
          <div class="col-lg-8">
            <div class="row">
              <div class="col-lg-12 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Course Action<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="" placeholder="Enter Course Action Name" value="Exam" />
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Course Action Type<span class="text-danger">*</span></label>
                <select id="ca_type_edit" name="ca_type_edit" class="select3 form-select">
                  <option value="">Select Course Action Type</option>
                  <option value="manual_title">Manual Title</option>
                  <option value="link_base" selected>Linkbase(URL)</option>
                  <option value="manual_content">Manual Content</option>
                  <option value="file_base">File Base</option>
                </select>
              </div>
              <div class="col-lg-12 mb-3" id="man_title_type" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Manual Title</label>
                <input type="text" class="form-control me-2" id="" placeholder="Enter Text" value="Title 1" disabled />
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Linkbase(URL)</label>
                <input type="text" class="form-control me-2" id="" placeholder="Enter Text" value="https://elysiumacademy.org/" disabled />
              </div>
              <div class="col-lg-12 mb-3" id="man_content_type" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Manual Content</label>
                <textarea class="form-control" rows="2" id="" placeholder="Enter Text" disabled>Content 1</textarea>
              </div>
              <div class="col-lg-12 mb-3" id="file_upload_type" style="display: none;">
                <label class="text-dark fs-6 fw-semibold">File Base</label>
                <div class="align-items-sm-center gap-4">
                  <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="Attachment" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="attach_upload" />
                </div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control" rows="2" id="" placeholder="Enter Description"></textarea>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
              <div class="col-lg-12 mb-3">
                <label class="text-dark fs-6 fw-semibold">Icon<span class="text-danger">*</span></label>
                <div class="align-items-sm-center gap-4">
                  <div class="rounded border border-gray-600 border-solid w-px-120 h-px-120">
                    <img src="{{asset('assets/phdizone_images/icon/exam_icon.svg')}}" alt="Attachment" class="ms-2 d-block w-px-100 h-px-100" id="course_action_edit" />
                  </div>
                  <div class="button-wrapper">
                    <div class="d-flex align-items-start mt-2 mb-2">
                      <label class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload File">
                        <i class="mdi mdi-tray-arrow-up"></i>
                        <input type="file" id="" class="course_action_edit_cls" hidden accept="image/png, image/jpeg" />
                      </label>
                      <button type="button" class="btn btn-sm btn-outline-danger course_action_edit-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                        <i class="mdi mdi-reload"></i>
                      </button>
                    </div>
                    <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="" data-bs-dismiss="modal">Update Course Action</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Course Action-->
<!--begin::Modal - Delete Course Action-->
<div class="modal fade" id="kt_modal_delete_course_action" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Course Action ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Course Action-->



<!--begin::Modal - Add Course Action Type-->
<div class="modal fade" id="kt_modal_add_course_action_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Course Action Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Course Action Type Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Course Action Type Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <select id="ca_category" name="ca_category" class="select3 form-select" onchange="category_func();">
              <option value="">Select Category</option>
              <option value="text_field">Text Field</option>
              <option value="text_area">Text Area</option>
              <option value="file_upload">File Upload</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3" id="cate_text_field" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category(Text Field)<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Text" />
          </div>
          <div class="col-lg-12 mb-3" id="cate_text_area" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category(Text Area)<span class="text-danger">*</span></label>
            <textarea class="form-control" rows="2" id="" placeholder="Enter Text"></textarea>
          </div>
          <div class="col-lg-12 mb-3" id="cate_file_upload" style="display: none;">
            <label class="text-dark fs-6 fw-semibold">Category(File Upload)<span class="text-danger">*</span></label>
            <div class="align-items-sm-center gap-4">
              <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="Attachment" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="course_action_type" />
              <div class="button-wrapper">
                <div class="d-flex align-items-start mt-2 mb-2">
                  <label for="fav_upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload File">
                    <i class="mdi mdi-tray-arrow-up"></i>
                    <!-- <input type="file" id="fav_upload" class="course_action_type_cls" hidden accept="application/pdf" /> -->
                    <input type="file" id="fav_upload" class="course_action_type_cls" hidden accept="application/pdf,.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" />
                  </label>
                  <button type="button" class="btn btn-sm btn-outline-danger course_action_type-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                    <i class="mdi mdi-reload"></i>
                  </button>
                </div>
                <div class="small">Allowed All files. Max size of 800K</div>
              </div>
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="" data-bs-dismiss="modal">Create Course Action Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Course Action Type-->
<!--begin::Modal - Edit Course Action Type-->
<div class="modal fade" id="kt_modal_edit_course_action_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Course Action Type</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Course Action Type Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Course Action Type Name" value="Linkbase(URL)" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
            <select id="ca_category_edit" name="ca_category_edit" class="select3 form-select">
              <option value="">Select Category</option>
              <option value="text_field" selected>Text Field</option>
              <option value="text_area">Text Area</option>
              <option value="file_upload">File Upload</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category(Text Field)<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Text" value="https://elysiumacademy.org/" />
          </div>
          <div class="col-lg-12 mb-3" id="cate_text_area" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">Category(Text Area)<span class="text-danger">*</span></label>
            <textarea class="form-control" rows="2" id="" placeholder="Enter Text"></textarea>
          </div>
          <div class="col-lg-12 mb-3" id="cate_file_upload" style="display: none;">
            <label class="text-dark fs-6 fw-semibold">Category(File Upload)<span class="text-danger">*</span></label>
            <div class="align-items-sm-center gap-4">
              <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="Attachment" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="course_action_type_edit" />
              <div class="button-wrapper">
                <div class="d-flex align-items-start mt-2 mb-2">
                  <label class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload File">
                    <i class="mdi mdi-tray-arrow-up"></i>
                    <!-- <input type="file" id="fav_upload" class="course_action_type_edit_cls" hidden accept="application/pdf" /> -->
                    <input type="file" id="fav_upload" class="course_action_type_edit_cls" hidden accept="application/pdf,.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" />
                  </label>
                  <button type="button" class="btn btn-sm btn-outline-danger course_action_type_edit-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                    <i class="mdi mdi-reload"></i>
                  </button>
                </div>
                <div class="small">Allowed All files. Max size of 800K</div>
              </div>
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" id="" name="">Cancel</button>
          <button type="submit" class="btn btn-primary" id="" name="" data-bs-dismiss="modal">Update Course Action Type</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Course Action Type-->
<!--begin::Modal - Delete Course Action Type-->
<div class="modal fade" id="kt_modal_delete_course_action_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Course Action Type ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Course Action Type-->

<!--begin::Modal - View Service Properties-->
<div class="modal fade" id="kt_modal_view_offerzone" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">View Service Properties
          </h3>
        </div>
        <div class="row">
          <div class="col-lg-6">
            <div class="row">
              <label class="col-4 text-black fs-7 fw-semibold">Service Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Development Service</label>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="row">
              <label class="col-4 text-black fs-7 fw-semibold">Service Sub Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Python Development</label>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 mt-2">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 view_properties">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-150px">Parent Field</th>
                  <th class="min-w-150px">Label</th>
                  <th class="min-w-150px">Type</th>
                  <th class="min-w-150px">Input</th>
                  <th class="min-w-50px">Required</th>
                  <th class="min-w-50px">Depend</th>
                  <th class="min-w-100px">Field</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                <tr>
                  <td>-</td>
                  <td><label>Title</label></td>
                  <td><label>Text Field</label></td>
                  <td>-
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td>

                  </td>
                </tr>
                <tr>
                  <td>-</td>
                  <td>Language</td>
                  <td>List Box</td>
                  <td><label>
                      <span>Python</span>
                      <span>Java</span>
                      <span> PHP</span>
                      <span>VLSI</span>
                      <span>Embedded</span></label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td>

                  </td>
                </tr>
                <tr>
                  <td>-</td>
                  <td>Domain</td>
                  <td>List Box</td>
                  <td><label>
                      <span>Data Mining</span>
                      <span>Image Processing</span>
                      <span>Cloud Computing</span>
                      <span>Big Data</span>
                    </label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td>

                  </td>
                </tr>
                <tr>
                  <td>-</td>
                  <td>Database</td>
                  <td>Radio Btn</td>
                  <td><label>
                      <span class="text-danger">Yes</span>
                      <span>No</span></label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-success text-black fs-8 fw-bold">Yes</label>
                  </td>
                  <td><label>Yes</label>
                  </td>
                </tr>
                <tr>
                  <td>Yes</td>
                  <td>Database Name</td>
                  <td>List Box</td>
                  <td><label>
                      <span>MySQL</span>
                      <span>Oracle</span></label>
                  </td>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td>
                  </td>
                </tr>
                <tr>
                  <td>-</td>
                  <td>Description</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-alpha-x-circle text-danger fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View Service Properties-->

<!--begin::Modal - View Service Product-->
<div class="modal fade" id="kt_modal_view_service_product" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">View Service Product
          </h3>
        </div>
        <div class="row">
          <div class="col-lg-6">
            <div class="row">
              <label class="col-4 text-black fs-7 fw-semibold">Service Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">PHD Service</label>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="row">
              <label class="col-4 text-black fs-7 fw-semibold">Service Sub Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-7 text-black fs-6 fw-bold">Thesis Writing</label>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 mt-2">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 view_properties">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-150px">Parent Field</th>
                  <th class="min-w-150px">Label</th>
                  <th class="min-w-150px">Type</th>
                  <th class="min-w-150px">Input</th>
                  <th class="min-w-50px">Required</th>
                  <th class="min-w-50px">Depend</th>
                  <th class="min-w-100px">Field</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                <tr>
                  <td>-</td>
                  <td><label>Page</label></td>
                  <td><label>List Box</label></td>
                  <td>
                    <div>
                      <label>100 Pages <span>,</span></label>
                      <label>200 Pages <span>,</span></label>
                      <label>300 Pages </label>
                    </div>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-success text-black fs-8 fw-bold">Yes</label>
                  </td>
                  <td>

                  </td>
                </tr>
                <tr>
                  <td>100 Page</td>
                  <td>Amount</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td><label>Yes</label>
                </tr>
                <tr>
                  <td>100 Page</td>
                  <td>working Days</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td><label>Yes</label>
                </tr>
                <tr>
                  <td>100 Page</td>
                  <td>working Hours</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td><label>Yes</label>
                </tr>
                <tr>
                  <td>200 Page</td>
                  <td>Amount</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td><label>Yes</label>
                </tr>
                <tr>
                  <td>200 Page</td>
                  <td>working Days</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td><label>Yes</label>
                </tr>
                <tr>
                  <td>200 Page</td>
                  <td>working Hours</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-check-circle text-info fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td><label>Yes</label>
                </tr>
                <tr>
                  <td>-</td>
                  <td>Description</td>
                  <td>Text Field</td>
                  <td><label>-</label>
                  </td>
                  <td class="text-center"><label>
                      <span class="mdi mdi-alpha-x-circle text-danger fs-4"></span>
                    </label></td>
                  <td>
                    <label class="badge bg-warning text-black fs-8 fw-bold">No</label>
                  </td>
                  <td>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View Service Product-->

<script>
  function edit_free_cost() {
    var cost_add_on = document.getElementById("cost_add_on");
    var free_add_on = document.getElementById("free_add_on");
    if (cost_add_on.checked) {
      edit_cost_info.style.display = "block";
    } else if (free_add_on.checked) {
      edit_cost_info.style.display = "none";
    } else {

    }
  }
</script>

<script>
  function free_cost() {
    var cost = document.getElementById("cost");
    var free = document.getElementById("free");
    if (cost.checked) {
      cost_info.style.display = "block";
    } else if (free.checked) {
      cost_info.style.display = "none";
    } else {

    }
  }
</script>

<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  function course_action_type_func() {
    var ca_type = document.getElementById("ca_type").value;
    var man_title_type = document.getElementById("man_title_type");
    var link_base_type = document.getElementById("link_base_type");
    var man_content_type = document.getElementById("man_content_type");
    var file_upload_type = document.getElementById("file_upload_type");

    if (ca_type == "manual_title") {
      man_title_type.style.display = "block";
      link_base_type.style.display = "none";
      man_content_type.style.display = "none";
      file_upload_type.style.display = "none";
    } else if (ca_type == "link_base") {
      man_title_type.style.display = "none";
      link_base_type.style.display = "block";
      man_content_type.style.display = "none";
      file_upload_type.style.display = "none";
    } else if (ca_type == "manual_content") {
      man_title_type.style.display = "none";
      link_base_type.style.display = "none";
      man_content_type.style.display = "block";
      file_upload_type.style.display = "none";
    } else if (ca_type == "file_base") {
      man_title_type.style.display = "none";
      link_base_type.style.display = "none";
      man_content_type.style.display = "none";
      file_upload_type.style.display = "block";
    } else {
      man_title_type.style.display = "none";
      link_base_type.style.display = "none";
      man_content_type.style.display = "none";
      file_upload_type.style.display = "none";
    }
  }
</script>
<!-- Icon Upload Start : ADD-->
<script>
  let course_action = document.getElementById('course_action');
  const course_action_fileInput = document.querySelector('.course_action_cls'),
    course_action_resetFileInput = document.querySelector('.course_action-reset');

  if (course_action) {
    const course_action_resetImage = course_action.src;
    course_action_fileInput.onchange = () => {
      if (course_action_fileInput.files[0]) {
        course_action.src = window.URL.createObjectURL(course_action_fileInput.files[0]);
      }
    };
    course_action_resetFileInput.onclick = () => {
      course_action_fileInput.value = '';
      course_action.src = course_action_resetImage;
    };
  }
</script>
<!-- Icon Upload End : ADD-->
<!-- Icon Upload Start : Edit-->
<script>
  let course_action_edit = document.getElementById('course_action_edit');
  const course_action_edit_fileInput = document.querySelector('.course_action_edit_cls'),
    course_action_edit_resetFileInput = document.querySelector('.course_action_edit-reset');

  if (course_action_edit) {
    const course_action_edit_resetImage = course_action_edit.src;
    course_action_edit_fileInput.onchange = () => {
      if (course_action_edit_fileInput.files[0]) {
        course_action_edit.src = window.URL.createObjectURL(course_action_edit_fileInput.files[0]);
      }
    };
    course_action_edit_resetFileInput.onclick = () => {
      course_action_edit_fileInput.value = '';
      course_action_edit.src = course_action_edit_resetImage;
    };
  }
</script>
<!-- Icon Upload End : Edit-->
<script>
  function category_func() {
    var ca_category = document.getElementById("ca_category").value;
    var cate_text_field = document.getElementById("cate_text_field");
    var cate_text_area = document.getElementById("cate_text_area");
    var cate_file_upload = document.getElementById("cate_file_upload");

    if (ca_category == "text_field") {
      cate_text_field.style.display = "block";
      cate_text_area.style.display = "none";
      cate_file_upload.style.display = "none";
    } else if (ca_category == "text_area") {
      cate_text_field.style.display = "none";
      cate_text_area.style.display = "block";
      cate_file_upload.style.display = "none";
    } else if (ca_category == "file_upload") {
      cate_text_field.style.display = "none";
      cate_text_area.style.display = "none";
      cate_file_upload.style.display = "block";
    } else {
      cate_text_field.style.display = "none";
      cate_text_area.style.display = "none";
      cate_file_upload.style.display = "none";
    }
  }
</script>
<!-- Attachment File Upload Start : ADD -->
<script>
  let course_action_type = document.getElementById('course_action_type');
  const course_action_type_fileInput = document.querySelector('.course_action_type_cls'),
    course_action_type_resetFileInput = document.querySelector('.course_action_type-reset');

  if (course_action_type) {
    const fav_resetImage = course_action_type.src;
    course_action_type_fileInput.onchange = () => {
      if (course_action_type_fileInput.files[0]) {
        course_action_type.src = window.URL.createObjectURL(course_action_type_fileInput.files[0]);
      }
    };
    course_action_type_resetFileInput.onclick = () => {
      course_action_type_fileInput.value = '';
      course_action_type.src = fav_resetImage;
    };
  }
</script>
<!-- Attachment File Upload End : ADD-->
<!-- Attachment File Upload Start : Edit -->
<script>
  let course_action_type_edit = document.getElementById('course_action_type_edit');
  const course_action_type_edit_fileInput = document.querySelector('.course_action_type_edit_cls'),
    course_action_type_edit_resetFileInput = document.querySelector('.course_action_type_edit-reset');

  if (course_action_type_edit) {
    const fav_resetImage = course_action_type_edit.src;
    course_action_type_edit_fileInput.onchange = () => {
      if (course_action_type_edit_fileInput.files[0]) {
        course_action_type_edit.src = window.URL.createObjectURL(course_action_type_edit_fileInput.files[0]);
      }
    };
    course_action_type_edit_resetFileInput.onclick = () => {
      course_action_type_edit_fileInput.value = '';
      course_action_type_edit.src = fav_resetImage;
    };
  }
</script>
<!-- Attachment File Upload End : Edit-->


<!-- Feedabck Icon Upload Start : ADD-->
<script>
  let stu_feedback_sts = document.getElementById('stu_feedback_sts');
  const stu_feedback_sts_up = document.querySelector('.stu_feedback_sts_up'),
    stu_feedback_sts_resetFileInput = document.querySelector('.stu_feedback_sts-reset');

  if (stu_feedback_sts) {
    const stu_feedback_sts_resetImage = stu_feedback_sts.src;
    stu_feedback_sts_up.onchange = () => {
      if (stu_feedback_sts_up.files[0]) {
        stu_feedback_sts.src = window.URL.createObjectURL(stu_feedback_sts_up.files[0]);
      }
    };
    stu_feedback_sts_resetFileInput.onclick = () => {
      stu_feedback_sts_up.value = '';
      stu_feedback_sts.src = stu_feedback_sts_resetImage;
    };
  }
</script>
<!-- Feedabck Icon Upload End : ADD-->
<!-- Feedabck Icon Upload Start : ADD-->
<script>
  let stu_feedback_sts_edit = document.getElementById('stu_feedback_sts_edit');
  const stu_feedback_sts_up_edit = document.querySelector('.stu_feedback_sts_up_edit'),
    stu_feedback_sts_resetFileInput_edit = document.querySelector('.stu_feedback_sts-reset_edit');

  if (stu_feedback_sts_edit) {
    const stu_feedback_sts_resetImage_edit = stu_feedback_sts_edit.src;
    stu_feedback_sts_up_edit.onchange = () => {
      if (stu_feedback_sts_up_edit.files[0]) {
        stu_feedback_sts_edit.src = window.URL.createObjectURL(stu_feedback_sts_up_edit.files[0]);
      }
    };
    stu_feedback_sts_resetFileInput_edit.onclick = () => {
      stu_feedback_sts_up_edit.value = '';
      stu_feedback_sts_edit.src = stu_feedback_sts_resetImage_edit;
    };
  }
</script>
<!-- Feedabck Icon Upload End : ADD-->
@endsection