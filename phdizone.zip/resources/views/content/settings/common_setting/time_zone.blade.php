@extends('layouts/layoutMaster')

@section('title', 'Common Settings')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection


@section('content')

<style>
  .scroll-container-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    max-width: 100%;
    overflow: hidden;
  }

  .scroll-container {
    display: flex;
    overflow-x: auto;
    scroll-behavior: smooth;
    padding: 10px 40px;
    gap: 10px;
    scrollbar-width: none;
  }

  .scroll-container::-webkit-scrollbar {
    display: none;
  }

  .item {
    flex: 0 0 auto;
    text-align: center;
    font-weight: bold;
    border-radius: 8px;
  }

  .scroll-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: #099DDA;
    border: none;
    padding: 10px 10px;
    cursor: pointer;
    z-index: 10;
    border-radius: 4px;
    display: none;
  }

  .scroll-btn.left {
    left: 0;
  }

  .scroll-btn.right {
    right: 0;
  }
</style>
<!-- Users List Table -->
<div class="row">
  <div class="col-xl-12">
    <div class="nav-align-top mb-2">
      <ul class="nav nav-pills flex-nowrap" style="background-color: #dfdfdf;" role="tablist">
        <div class="scroll-container-wrapper">
          <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
          <div class="scroll-container" id="scrollContainer">
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a href="{{ url('/settings/common/country') }}" type="button" class="nav-link text-capitalize "  aria-selected="false">Country</a>
                
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a href="{{ url('/settings/common/state') }}" type="button" class="nav-link text-capitalize"  aria-selected="false">State</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a href="{{ url('/settings/common/city') }}" type="button" class="nav-link text-capitalize"  aria-selected="false">City</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a href="{{ url('/settings/common/currency_format') }}" type="button" class="nav-link text-capitalize"  aria-selected="false">Currency Format</a>
              </li>
            </div>
            <div class="item">
              <li class="nav-item rounded" style="border: 1px solid #099dda;">
                <a href="{{ url('/settings/common/time_zone') }}" type="button" class="nav-link text-capitalize active" aria-selected="false">Time Zone Format</a>
              </li>
            </div>
          </div>
          <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
        </div>
      </ul>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="tab-content p-0">
         
          
            <div class="d-flex justify-content-end align-items-center mb-2">
              <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_time_zone_format">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Time Zone Format
              </a>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-150px">Time Zone</th>
                      <th class="min-w-50px">UTC Offset</th>
                      <th class="min-w-100px">Country</th>
                      <th class="min-w-80px">Status</th>
                      <th class="min-w-50px">Action</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">
                
                    <tr>
                      <td>
                        <label>Asia/Kolkata</label>
                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                      </td>
                      <td><label class="fs-6">UTC +05:30</label></td>
                      <td>India</td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox" class="switch-input" checked />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>
                        <span class="text-end">
                          <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_time_zone_format" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                          </a>
                          <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_time_zone_format" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                          </a>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          
        </div>
      </div>
    </div>
  </div>
</div>




<!--begin::Modal - Add Country-->
<div class="modal fade" id="kt_modal_add_country" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create Country</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Country Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country Code<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Country Code" />
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Country</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Country-->

<!--begin::Modal - Edit Country-->
<div class="modal fade" id="kt_modal_edit_country" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Update Country</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Country Name" value="Belize" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country Code<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Country Code" value="BZ" />
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Country</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Country-->

<!--begin::Modal - Delete Country-->
<div class="modal fade" id="kt_modal_delete_country" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Country ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Belize</label>
          <span class="ms-2 me-2">-</span>
          <label>BZ</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Country-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add State-->
<div class="modal fade" id="kt_modal_add_state" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create State</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">Belize</option>
              <option value="2">Brazil</option>
              <option value="3">Cambodia</option>
              <option value="4">Canada</option>
              <option value="5">India</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter State" />
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create State</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add State-->

<!--begin::Modal - Edit State-->
<div class="modal fade" id="kt_modal_edit_state" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update State</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">Belize</option>
              <option value="2">Brazil</option>
              <option value="3">Cambodia</option>
              <option value="4">Canada</option>
              <option value="5" selected>India</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter State" value="Tamil Nadu" />
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update State</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit State-->

<!--begin::Modal - Delete State-->
<div class="modal fade" id="kt_modal_delete_state" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete State ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>TamilNadu</label>
          <span class="ms-2 me-2">-</span>
          <label>India</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div>

    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete State-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add City-->
<div class="modal fade" id="kt_modal_add_city" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create City</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">Belize</option>
              <option value="2">Brazil</option>
              <option value="3">Cambodia</option>
              <option value="4">Canada</option>
              <option value="5">India</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select State</option>
              <option value="1">TamilNadu</option>
              <option value="2">Maharashtra</option>
              <option value="3">Punjab</option>
              <option value="4">Karnataka</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">City Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter City Name" />
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create City</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add City-->

<!--begin::Modal - Edit City-->
<div class="modal fade" id="kt_modal_edit_city" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update City</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">Belize</option>
              <option value="2">Brazil</option>
              <option value="3">Cambodia</option>
              <option value="4">Canada</option>
              <option value="5" selected>India</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select State</option>
              <option value="1" selected>TamilNadu</option>
              <option value="2">Maharashtra</option>
              <option value="3">Punjab</option>
              <option value="4">Karnataka</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">City Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter City Name" value="Chennai" />
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update City</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit City-->

<!--begin::Modal - Delete City-->
<div class="modal fade" id="kt_modal_delete_city" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete City ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Chennai</label>
          <span class="ms-2 me-2">-</span>
          <label>TamilNadu</label>
          <span class="ms-2 me-2">-</span>
          <label>India</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete City-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Currency Format-->
<div class="modal fade" id="kt_modal_add_currency_format" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Currency Format</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">Zimbabwe</option>
              <option value="2">Zambia</option>
              <option value="3">India</option>
              <option value="4">Vietnam</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Currency Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Currency Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Currency Symbol(In Hex Code)<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Currency Symbol(In Hex Code)" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Currency Format</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Currency Format-->

<!--begin::Modal - Edit Currency Format-->
<div class="modal fade" id="kt_modal_edit_currency_format" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Currency Format</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1" selected>Zimbabwe</option>
              <option value="2">Zambia</option>
              <option value="3">India</option>
              <option value="4">Vietnam</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Currency Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Currency Name" value="Zimbabwean Dollar" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Currency Symbol(In Hex Code)<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Currency Symbol(In Hex Code)" value="&#x24;" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Currency Format</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Currency Format-->

<!--begin::Modal - Delete Currency Format-->
<div class="modal fade" id="kt_modal_delete_currency_format" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Currency Format ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Zimbabwean Dollar ($)</label>
          <span class="ms-2 me-2">-</span>
          <label>Zimbabwe</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Currency Format-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Time Zone Format-->
<div class="modal fade" id="kt_modal_add_time_zone_format" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Time Zone Format</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">Zimbabwe</option>
              <option value="2">Zambia</option>
              <option value="3">India</option>
              <option value="4">Vietnam</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Time Zone Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Time Zone Name" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">UTC Offset<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter UTC Offset" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Time Zone Format</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Time Zone Format-->

<!--begin::Modal - Edit Time Zone Format-->
<div class="modal fade" id="kt_modal_edit_time_zone_format" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Time Zone Format</h3>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">Zimbabwe</option>
              <option value="2">Zambia</option>
              <option value="3" selected>India</option>
              <option value="4">Vietnam</option>
            </select>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Time Zone Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Time Zone Name" value="Asia/Kolkata" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">UTC Offset<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter UTC Offset" value="UTC +05:30" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1" placeholder="Enter Description">-</textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Time Zone Format</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Time Zone Format-->

<!--begin::Modal - Delete Time Zone Format-->
<div class="modal fade" id="kt_modal_delete_time_zone_format" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Time Zone Format ?
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
          <label>Asia/Kolkata (UTC +05:30)</label>
          <span class="ms-2 me-2">-</span>
          <label>India</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Time Zone Format-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->



<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  $('#facilites_chk_all').change(function() {
    $('.fac_ver_chk').prop('checked', this.checked);
  });

  $('.fac_ver_chk').change(function() {
    if ($('.fac_ver_chk:checked').length == $('.fac_ver_chk').length) {
      $('#facilites_chk_all').prop('checked', true);
    } else {
      $('#facilites_chk_all').prop('checked', false);
    }

  });
</script>
<script>
  $('#facilites_chk_all_up').change(function() {
    $('.fac_ver_chk_up').prop('checked', this.checked);
  });

  $('.fac_ver_chk_up').change(function() {
    if ($('.fac_ver_chk_up:checked').length == $('.fac_ver_chk_up').length) {
      $('#facilites_chk_all_up').prop('checked', true);
    } else {
      $('#facilites_chk_all_up').prop('checked', false);
    }

  });
</script>
<script>
    const scrollContainer = document.getElementById('scrollContainer');
    const scrollLeftBtn = document.getElementById('scrollLeftBtn');
    const scrollRightBtn = document.getElementById('scrollRightBtn');

    function updateScrollButtons() {
        const scrollLeft = scrollContainer.scrollLeft;
        const scrollWidth = scrollContainer.scrollWidth;
        const clientWidth = scrollContainer.clientWidth;

        scrollLeftBtn.style.display = scrollLeft > 0 ? 'block' : 'none';
        scrollRightBtn.style.display = scrollLeft + clientWidth < scrollWidth ? 'block' : 'none';
    }

    scrollLeftBtn.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: -300,
            behavior: 'smooth'
        });
    });

    scrollRightBtn.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: 300,
            behavior: 'smooth'
        });
    });

    scrollContainer.addEventListener('scroll', updateScrollButtons);
    window.addEventListener('resize', updateScrollButtons);

    // Run on load
    updateScrollButtons();
</script>
@endsection