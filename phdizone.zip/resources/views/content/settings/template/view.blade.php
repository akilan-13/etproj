@extends('layouts/layoutMaster')

@section('title', 'View Template')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection
@section('content')
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">View Template</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Settings</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Quotation</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">View Template</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">
                                <i class="mdi mdi-desktop-classic fs-3 text-black"></i>
                            </label>
                            <label class="fs-5 align-items-center text-black fw-bold">
                                <span>Development Service</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Template Name">
                                <i class="mdi mdi-file-alert-outline fs-3 text-black"></i>
                            </label>
                            <label class="fs-5 align-items-center text-black fw-bold">
                                <span>Template 1</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="row">
                    <div class="col-lg-6 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Slot">
                                <i class="mdi mdi-cash-sync fs-3 text-black"></i>
                            </label>
                            <label class="fs-5 align-items-center text-black fw-bold">
                                <span>Dual</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Template">
                                <i class="mdi mdi-folder-plus-outline fs-3 text-black"></i>
                            </label>
                            <label class="fs-6 align-items-center text-black fw-bold">
                                <span class="badge bg-info text-white fw-bold">yes</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-80px">Slot </th>
                            <th class="min-w-150px">Deliverables </th>
                            <th class="min-w-150px">Note </th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        <tr>
                            <td>
                                <div>
                                    <label class="fs-6">
                                        <span class="text-info d-block">Slot I</span>
                                        <span class="fs-7">To Start The Work</span>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <label class="fs-7">
                                        <ul>
                                            <li><span>Technical Discussion</span></li>
                                            <li><span>Flow of the Work (Novelty and Dataset)</span></li>
                                        </ul>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <label class="fs-7">
                                        <span class="d-block">Once you acknowledge the flow only, we will move on
                                            otherwise,updated flow will be shared</span>
                                    </label>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>
                                    <label class="fs-6">
                                        <span class="text-info d-block">Slot II</span>
                                        <span class="fs-7">(After taking the Demo)(Before taking the Delivery of Coding)</span>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <label class="fs-7">
                                        <ul>
                                            <li><span>Source Code</span></li>
                                            <li><span>Pseudo Code</span></li>
                                            <li><span>Demo through Running video</span></li>
                                            <li><span>Results As per client specification-As per the Description</span></li>
                                            <li><span>Software Installation</span></li>
                                        </ul>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <label class="fs-7">
                                        <ul>
                                            <li><span>Each and every step will be acknowledged by you</span></li>
                                            <li><span>Every Section and Module of the Coding part will be clearly explained in the Google meet.Entire Technical Knowledge will be given to you,until the client understands the concept</span></li>
                                            <li><span>As per the acknowledged description.We will be work on it</span></li>
                                        </ul>
                                    </label>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<script>
    function template_func_edit() {
        var service_check = document.getElementById("service_check");
        var template_properties_edit = document.getElementById("template_properties_edit");

        if (service_check.checked) {
            template_properties_edit.style.display = "block";
        } else {
            template_properties_edit.style.display = "none";
        }
    }
</script>

<script>
    $('.template_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_quotation_template_edit').length);
        let $clone = $('.form-repeater_quotation_template_edit').first().clone().hide();
        $clone.insertBefore('.form-repeater_quotation_template_edit:first').slideDown();
        if (bt == 1) {
            $('.template_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.template_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_quotation_template_edit .template_butt_del_question', e => {
        var bt = parseFloat($('.template_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_quotation_template_edit').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.template_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>

@endsection