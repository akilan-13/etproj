@extends('layouts/layoutMaster')

@section('title', 'Base Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection


@section('content')
<style>
    .scroll-container-wrapper {
        position: relative;
        display: flex;
        align-items: center;
        max-width: 100%;
        overflow: hidden;
    }

    .scroll-container {
        display: flex;
        overflow-x: auto;
        scroll-behavior: smooth;
        padding: 10px 40px;
        gap: 10px;
        scrollbar-width: none;
    }

    .scroll-container::-webkit-scrollbar {
        display: none;
    }

    .item {
        flex: 0 0 auto;
        text-align: center;
        font-weight: bold;
        border-radius: 8px;
    }

    .scroll-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: #099DDA;
        border: none;
        padding: 10px 10px;
        cursor: pointer;
        z-index: 10;
        border-radius: 4px;
        display: none;
    }

    .scroll-btn.left {
        left: 0;
    }

    .scroll-btn.right {
        right: 0;
    }

    .select2-results__group {
        color: #F0913D !important;
    }
</style>
<!-- Users List Table -->
<div class="row">
    <div class="col-xl-12">
        <div class="nav-align-top mb-2">
            <ul class="nav nav-pills flex-nowrap" style="background-color: #dfdfdf;" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                    <div class="scroll-container" id="scrollContainer">
                        <div class="item">
                            <li class="nav-item rounded" style="border: 1px solid #099dda;">
                                <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_company_type" aria-controls="tab_company_type" aria-selected="false">Company Type</button>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded" style="border: 1px solid #099dda;">
                                <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_brand" aria-controls="tab_brand" aria-selected="false">Brand</button>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded" style="border: 1px solid #099dda;">
                                <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_department" aria-controls="tab_department" aria-selected="false">Department</button>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded" style="border: 1px solid #099dda;">
                                <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_division" aria-controls="tab_division" aria-selected="false">Division</button>
                            </li>
                        </div>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="tab-content p-0">
                    <!--begin:: Company Type tab-->
                    <div class="tab-pane fade show active" id="tab_company_type" role="tabpanel">
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_company_type">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Company Type
                            </a>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-150px">Company Type</th>
                                            <th class="min-w-150px">Slug</th>
                                            <th class="min-w-80px">Status</th>
                                            <th class="min-w-50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-semibold fs-7">
                                        <tr>
                                            <td>
                                                <label>Private Limited Company</label>
                                                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="A privately held business entity with limited liability. Shares are not publicly traded and are held by a small group."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                            </td>
                                            <td>
                                                <label>Pvt Ltd</label>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_company_type">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_company_type">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>Public Limited Company</label>
                                                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="A company listed on the stock exchange with shares available to the general public. It must comply with strict regulatory requirements."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                            </td>
                                            <td>
                                                <label>PLC</label>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_company_type">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_company_type">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>Limited Liability Partnership</label>
                                                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="A hybrid structure offering limited liability to partners. It combines flexibility of a partnership with benefits of a corporation."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                            </td>
                                            <td>
                                                <label>LLP</label>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_company_type">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_company_type">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--end:: Company Type tab-->
                    <!--begin:: Brand tab-->
                    <div class="tab-pane fade" id="tab_brand" role="tabpanel">
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_brand">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Brand
                            </a>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-300px">Brand</th>
                                            <th class="min-w-80px">Status</th>
                                            <th class="min-w-50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-semibold fs-7">
                                        <tr>
                                            <td>
                                                <label>Brand 1</label>
                                                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_brand">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_brand">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>Brand 2</label>
                                                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_brand">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_brand">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--end:: Brand tab-->
                    <!--begin:: Department tab-->
                    <div class="tab-pane fade" id="tab_department" role="tabpanel">
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_department">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Department
                            </a>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-150px">Department</th>
                                            <th class="min-w-150px">Entity</th>
                                            <th class="min-w-150px">Branch / Franchise</th>
                                            <th class="min-w-80px">Status</th>
                                            <th class="min-w-100px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-semibold fs-7">
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sales">Sales</div>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                            </td>
                                            <td>
                                                <div>Elysium Technologies Pvt Ltd</div>
                                            </td>
                                            <td>
                                                <div class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PhDiZone">PhDiZone</div>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Production">Production</div>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                            </td>
                                            <td>
                                                <div>Elysium Technologies Pvt Ltd</div>
                                            </td>
                                            <td>
                                                <div class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PhDiZone">PhDiZone</div>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Support">Support</div>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                            </td>
                                            <td>
                                                <div>Elysium Technologies Pvt Ltd</div>
                                            </td>
                                            <td>
                                                <div class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PhDiZone">PhDiZone</div>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Management">Management</div>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                            </td>
                                            <td>
                                                <div>Elysium Technologies Pvt Ltd</div>
                                            </td>
                                            <td>
                                                <div class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PhDiZone">PhDiZone</div>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_department">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--end:: Department tab-->
                    <!--begin:: Division tab-->
                    <div class="tab-pane fade" id="tab_division" role="tabpanel">
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_division">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Division
                            </a>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-150px">Division</th>
                                            <th class="min-w-150px">Entity</th>
                                            <th class="min-w-150px">Branch / Franchise</th>
                                            <th class="min-w-150px">Department</th>
                                            <th class="min-w-80px">Status</th>
                                            <th class="min-w-100px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-semibold fs-7">
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pre Sale">Pre Sale</div>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                            </td>
                                            <td>
                                                <div>Elysium Technologies Pvt Ltd</div>
                                            </td>
                                            <td>
                                                <div class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PhDiZone">PhDiZone</div>
                                            </td>
                                            <td>Sales</td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input" checked />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td>
                                                <span class="text-end">
                                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_division">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                    </a>
                                                    <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_division">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--end:: Division tab-->
                </div>
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Add Company Type-->
<div class="modal fade" id="kt_modal_add_company_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Create Company Type</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Type Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Company Type Name" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Slug Name <span class="text-danger">(to be displayed entire application)</span><span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Slug Name" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Company Type</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Company Type-->

<!--begin::Modal - Edit Company Type-->
<div class="modal fade" id="kt_modal_edit_company_type" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Company Type
                    </h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Type Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Company Type Name" value="Private Limited Company" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Slug Name <span class="text-danger">(to be displayed entire application)</span><span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Slug Name" value="Pvt Ltd" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description">A privately held business entity with limited liability. Shares are not publicly traded and are held by a small group.</textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Company Type</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Company Type-->

<!--begin::Modal - Delete Company Type-->
<div class="modal fade" id="kt_modal_delete_company_type" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Company Type?
                <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                    <label>Private Limited Company</label>
                    <span class="ms-2 me-2">-</span>
                    <label>Pvt Ltd</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Company Type-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Brand-->
<div class="modal fade" id="kt_modal_add_brand" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Brand</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Brand Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Brand Name" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Brand</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Brand-->

<!--begin::Modal - Edit Brand-->
<div class="modal fade" id="kt_modal_edit_brand" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Brand</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Brand Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Brand Name" value="Brand 1" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Brand</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Brand-->

<!--begin::Modal - Delete Brand-->
<div class="modal fade" id="kt_modal_delete_brand" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Brand?</div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Brand-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Department-->
<div class="modal fade" id="kt_modal_add_department" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Department</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Entity</option>
                            <option value="1">Phdizone</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Branch / Franchise</option>
                            <optgroup label="Branch">
                                <option value="1">Phdizone Madurai Branch</option>
                            </optgroup>
                            <optgroup label="Franchise">
                                <option value="1">Phdizone Virudhunagar</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Department Name" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Department</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Department-->

<!--begin::Modal - Edit Department-->
<div class="modal fade" id="kt_modal_edit_department" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Department</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Entity</option>
                            <option value="1" selected>Phdizone</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Branch / Franchise</option>
                            <optgroup label="Branch">
                                <option value="1" selected>Phdizone Madurai Branch</option>
                            </optgroup>
                            <optgroup label="Franchise">
                                <option value="1">Phdizone Virudhunagar</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Department Name" value="Sales" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Department</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Department-->

<!--begin::Modal - Delete Department-->
<div class="modal fade" id="kt_modal_delete_department" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Department ?
                <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                    <label>Sales</label>
                    <label class="ms-1 me-1">-</label>
                    <label>Phdizone Madurai Branch</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Department-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!--begin::Modal - Add Division-->
<div class="modal fade" id="kt_modal_add_division" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Division</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Entity</option>
                            <option value="1">Phdizone</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Branch / Franchise</option>
                            <optgroup label="Branch">
                                <option value="1">Phdizone Madurai Branch</option>
                            </optgroup>
                            <optgroup label="Franchise">
                                <option value="1">Phdizone Virudhunagar</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Department</option>
                            <option value="1">Sales</option>
                            <option value="2">Production</option>
                            <option value="3">Support</option>
                            <option value="4">Management</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Division Name" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Division</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Division-->

<!--begin::Modal - Edit Division-->
<div class="modal fade" id="kt_modal_edit_division" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Division</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Entity</option>
                            <option value="1" selected>Phdizone</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Branch / Franchise</option>
                            <optgroup label="Branch">
                                <option value="1" selected>Phdizone Madurai Branch</option>
                            </optgroup>
                            <optgroup label="Franchise">
                                <option value="1">Phdizone Virudhunagar</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Department</option>
                            <option value="1" selected>Sales</option>
                            <option value="2">Production</option>
                            <option value="3">Support</option>
                            <option value="4">Management</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Division Name" value="Pre Sale" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" placeholder="Enter Description">-</textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Division</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Division-->

<!--begin::Modal - Delete Division-->
<div class="modal fade" id="kt_modal_delete_division" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Division ?
                <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                    <label>Pre Sale</label>
                    <label class="ms-1 me-1">-</label>
                    <label>Sales</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Division-->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
    $(".course_view_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive scroll-y max-h-200px'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    const select = document.getElementById('course-type-add');
    select.addEventListener('change', function() {
        const options = select.options;
        const allOption = options[options.length - 1];

        if (allOption.selected) {
            for (let i = 0; i < options.length - 1; i++) {
                options[i].disabled = true;
            }
        } else {
            for (let i = 0; i < options.length -
                1; i++) {
                options[i].disabled = false;
            }
        }
    });
</script>

<script>
    const select_update = document.getElementById('course-type-update');
    select_update.addEventListener('change', function() {
        const options = select_update.options;
        const allOption = options[options.length - 1];

        if (allOption.selected) {
            for (let i = 0; i < options.length - 1; i++) {
                options[i].disabled = true;
            }
        } else {
            for (let i = 0; i < options.length -
                1; i++) {
                options[i].disabled = false;
            }
        }
    });
</script>


<script>
    $('.ip_config_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_ip_config').length);
        let $clone = $('.form-repeater_ip_config').first().clone().hide();
        $clone.insertBefore('.form-repeater_ip_config:first').slideDown();
        if (bt == 1) {
            $('.ip_config_butt_del').attr('style', 'display: block !important');
        } else {
            $('.ip_config_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_ip_config .ip_config_butt_del', e => {
        var bt = parseFloat($('.ip_config_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_ip_config').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.ip_config_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    const scrollContainer = document.getElementById('scrollContainer');
    const scrollLeftBtn = document.getElementById('scrollLeftBtn');
    const scrollRightBtn = document.getElementById('scrollRightBtn');

    function updateScrollButtons() {
        const scrollLeft = scrollContainer.scrollLeft;
        const scrollWidth = scrollContainer.scrollWidth;
        const clientWidth = scrollContainer.clientWidth;

        scrollLeftBtn.style.display = scrollLeft > 0 ? 'block' : 'none';
        scrollRightBtn.style.display = scrollLeft + clientWidth < scrollWidth ? 'block' : 'none';
    }

    scrollLeftBtn.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: -300,
            behavior: 'smooth'
        });
    });

    scrollRightBtn.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: 300,
            behavior: 'smooth'
        });
    });

    scrollContainer.addEventListener('scroll', updateScrollButtons);
    window.addEventListener('resize', updateScrollButtons);

    // Run on load
    updateScrollButtons();
</script>
@endsection