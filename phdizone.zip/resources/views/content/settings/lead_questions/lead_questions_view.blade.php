@extends('layouts/layoutMaster')

@section('title', 'Create Lead Questions')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js'
])
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Lead Questions</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Settings</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Lead Questions</a>
                </li>
            </ol>
        </nav>
    </div>
    <!-- <div class="card-body">
        <div class="row">
            <div class="col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Question 1<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="" placeholder="Enter Question 1" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Question Type<span class="text-danger">*</span></label>
                <select id="question_lead" name="question_lead" class="select3 form-select" onchange="Question_func();">
                    <option>Select Question Type</option>
                    <option value="text_field">Text Field</option>
                    <option value="check_box">Check Box</option>
                    <option value="radio_button">Radio Button</option>
                    <option value="list_box">List Box</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3" id="lead_check_box" style="display: none !important;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Check Box Question Option<span
                        class="text-danger">*</span></label>
                <div class="accordion" id="lead_acrd">
                    <div class="accordion-item mb-2">
                        <h2 class="accordion-header" id="lead_acrd">
                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse"
                                data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion"
                                role="tabpanel">Question Option
                            </button>
                        </h2>
                        <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd">
                            <div class="accordion-body">
                                <div class="form-repeater_lead">
                                    <div data-repeater-list="group-a_led">
                                        <div data-repeater-item>
                                            <div class="row">
                                                <div class="col-lg-10">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Topic
                                                        Name<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="top_name"
                                                        placeholder="Enter Topic Name"></textarea>
                                                </div>
                                                <div class="col-lg-2 mb-1 px-1 py-1">
                                                    <a href="javascript:;"
                                                        class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                                        id="lead_butt_del" style="display: none !important;">
                                                        <i class="mdi mdi-delete fs-4"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-1 mt-1">
                                    <button class="btn btn-primary lead_butt_add" data-bs-toggle="tooltip"
                                        data-bs-placement="top" title="Add" data-repeater-create id="lead_butt_add">
                                        <i class="mdi mdi-plus me-1"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-3" id="lead_radio_button" style="display: none !important;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button Question Option<span
                        class="text-danger">*</span></label>
                <div class="accordion" id="lead_acrd_radio">
                    <div class="accordion-item mb-2">
                        <h2 class="accordion-header" id="lead_acrd_radio">
                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse"
                                data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion"
                                role="tabpanel">Question Option
                            </button>
                        </h2>
                        <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_radio">
                            <div class="accordion-body">
                                <div class="form-repeater_lead_radio">
                                    <div data-repeater-list="group-a_led_radio">
                                        <div data-repeater-item>
                                            <div class="row">
                                                <div class="col-lg-10">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Topic
                                                        Name<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="top_name"
                                                        placeholder="Enter Topic Name"></textarea>
                                                </div>
                                                <div class="col-lg-2 mb-1 px-1 py-1">
                                                    <a href="javascript:;"
                                                        class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_radio"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                                        id="lead_butt_del_radio" style="display: none !important;">
                                                        <i class="mdi mdi-delete fs-4"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-1 mt-1">
                                    <button class="btn btn-primary lead_butt_add_radio" data-bs-toggle="tooltip"
                                        data-bs-placement="top" title="Add" data-repeater-create
                                        id="lead_butt_add_radio">
                                        <i class="mdi mdi-plus me-1"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-3" id="lead_list_box" style="display: none !important;">
                <label class="text-dark mb-1 fs-6 fw-semibold">List Box Question Option<span
                        class="text-danger">*</span></label>
                <div class="accordion" id="lead_acrd_radio">
                    <div class="accordion-item mb-2">
                        <h2 class="accordion-header" id="lead_acrd_radio">
                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse"
                                data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion"
                                role="tabpanel">Question Option
                            </button>
                        </h2>
                        <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_list">
                            <div class="accordion-body">
                                <div class="form-repeater_lead_list">
                                    <div data-repeater-list="group-a_led_list">
                                        <div data-repeater-item>
                                            <div class="row">
                                                <div class="col-lg-10">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Topic
                                                        Name<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="top_name"
                                                        placeholder="Enter Topic Name"></textarea>
                                                </div>
                                                <div class="col-lg-2 mb-1 px-1 py-1">
                                                    <a href="javascript:;"
                                                        class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_list"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                                        id="lead_butt_del_list" style="display: none !important;">
                                                        <i class="mdi mdi-delete fs-4"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-1 mt-1">
                                    <button class="btn btn-primary lead_butt_add_list" data-bs-toggle="tooltip"
                                        data-bs-placement="top" title="Add" data-repeater-create
                                        id="lead_butt_add_list">
                                        <i class="mdi mdi-plus me-1"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
            <a href="#" class="btn btn-secondary me-3">Cancel</a>
            <a href="#" class="btn btn-primary">Create Lead Questions</a>
        </div>
    </div> -->
    <div class="card-body">
        <div class="row">
            <div class="form-repeater_lead_question">
                <div data-repeater-list="group-a_led_question">
                    <div data-repeater-item>
                        <div class="row">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Question<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Question" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Question Type<span class="text-danger">*</span></label>
                                        <select id="question_lead" name="question_lead" class="select3 form-select" onchange="Question_func();">
                                            <option>Select Question Type</option>
                                            <option value="text_field">Text Field</option>
                                            <option value="check_box">Check Box</option>
                                            <option value="radio_button">Radio Button</option>
                                            <option value="list_box">List Box</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="lead_check_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Check Box Question Option<span class="text-danger">*</span></label>
                                        <div class="accordion" id="lead_acrd">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="lead_acrd">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_lead">
                                                            <div data-repeater-list="group-a_led">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Topic
                                                                                Name<span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Topic Name"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary lead_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="lead_butt_add">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="lead_radio_button" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button Question Option<span class="text-danger">*</span></label>
                                        <div class="accordion" id="lead_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="lead_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_radio">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_lead_radio">
                                                            <div data-repeater-list="group-a_led_radio">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Topic
                                                                                Name<span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Topic Name"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del_radio" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary lead_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="lead_butt_add_radio">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="lead_list_box" style="display: none !important;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">List Box Question Option<span class="text-danger">*</span></label>
                                        <div class="accordion" id="lead_acrd_radio">
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="lead_acrd_radio">
                                                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                    </button>
                                                </h2>
                                                <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_list">
                                                    <div class="accordion-body">
                                                        <div class="form-repeater_lead_list">
                                                            <div data-repeater-list="group-a_led_list">
                                                                <div data-repeater-item>
                                                                    <div class="row">
                                                                        <div class="col-lg-10">
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Topic
                                                                                Name<span class="text-danger">*</span></label>
                                                                            <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Topic Name"></textarea>
                                                                        </div>
                                                                        <div class="col-lg-2 mb-1 px-1 py-1">
                                                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del_list" style="display: none !important;">
                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1 mt-1">
                                                            <button class="btn btn-primary lead_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="lead_butt_add_list">
                                                                <i class="mdi mdi-plus me-1"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-1 px-1 py-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 lead_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="lead_butt_del_question" style="display: none !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-1 mt-1">
                <button class="btn btn-primary lead_butt_add_Question" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="lead_butt_add_Question">
                    <i class="mdi mdi-plus me-1"></i>
                </button>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <a href="#" class="btn btn-secondary me-3">Cancel</a>
                <a href="#" class="btn btn-primary">Create Lead Questions</a>
            </div>
        </div>
    </div>
    <script>
        function Question_func() {
            var question_lead = document.getElementById("question_lead").value;
            var lead_check_box = document.getElementById("lead_check_box");
            var lead_radio_button = document.getElementById("lead_radio_button");
            var lead_list_box = document.getElementById("lead_list_box");

            if (question_lead == "check_box") {
                lead_check_box.style.display = "block";
                lead_radio_button.style.display = "none";
                lead_list_box.style.display = "none";
            } else if (question_lead == "radio_button") {
                lead_check_box.style.display = "none";
                lead_radio_button.style.display = "block";
                lead_list_box.style.display = "none";
            } else if (question_lead == "list_box") {
                lead_check_box.style.display = "none";
                lead_radio_button.style.display = "none";
                lead_list_box.style.display = "block";
            } else {
                lead_check_box.style.display = "none";
                lead_radio_button.style.display = "none";
                lead_list_box.style.display = "none";
            }
        }
    </script>
    <script>
        $('.lead_butt_add').on('click', e => {
            var bt = parseFloat($('.form-repeater_lead').length);
            let $clone = $('.form-repeater_lead').first().clone().hide();
            $clone.insertBefore('.form-repeater_lead:first').slideDown();
            if (bt == 1) {
                $('.lead_butt_del').attr('style', 'display: block !important');
            } else {
                $('.lead_butt_del').attr('style', 'display: block !important');
            }
        });

        $(document).on('click', '.form-repeater_lead .lead_butt_del', e => {
            var bt = parseFloat($('.lead_butt_del').length);
            // alert(bt);
            $(e.target).closest('.form-repeater_lead').slideUp(400, function() {
                $(this).remove()
            });
            if (bt == 2) {
                $('.lead_butt_del').attr('style', 'display: none !important');
            } else {}
        });
    </script>

    <script>
        $('.lead_butt_add_radio').on('click', e => {
            var bt = parseFloat($('.form-repeater_lead_radio').length);
            let $clone = $('.form-repeater_lead_radio').first().clone().hide();
            $clone.insertBefore('.form-repeater_lead_radio:first').slideDown();
            if (bt == 1) {
                $('.lead_butt_del_radio').attr('style', 'display: block !important');
            } else {
                $('.lead_butt_del_radio').attr('style', 'display: block !important');
            }
        });

        $(document).on('click', '.form-repeater_lead_radio .lead_butt_del_radio', e => {
            var bt = parseFloat($('.lead_butt_del_radio').length);
            // alert(bt);
            $(e.target).closest('.form-repeater_lead_radio').slideUp(400, function() {
                $(this).remove()
            });
            if (bt == 2) {
                $('.lead_butt_del_radio').attr('style', 'display: none !important');
            } else {}
        });
    </script>

    <script>
        $('.lead_butt_add_list').on('click', e => {
            var bt = parseFloat($('.form-repeater_lead_list').length);
            let $clone = $('.form-repeater_lead_list').first().clone().hide();
            $clone.insertBefore('.form-repeater_lead_list:first').slideDown();
            if (bt == 1) {
                $('.lead_butt_del_list').attr('style', 'display: block !important');
            } else {
                $('.lead_butt_del_list').attr('style', 'display: block !important');
            }
        });

        $(document).on('click', '.form-repeater_lead_list .lead_butt_del_list', e => {
            var bt = parseFloat($('.lead_butt_del_list').length);
            // alert(bt);
            $(e.target).closest('.form-repeater_lead_list').slideUp(400, function() {
                $(this).remove()
            });
            if (bt == 2) {
                $('.lead_butt_del_list').attr('style', 'display: none !important');
            } else {}
        });
    </script>
    <script>
        $('.lead_butt_add_Question').on('click', e => {
            var bt = parseFloat($('.form-repeater_lead_question').length);
            let $clone = $('.form-repeater_lead_question').first().clone().hide();
            $clone.insertBefore('.form-repeater_lead_question:first').slideDown();
            if (bt == 1) {
                $('.lead_butt_del_question').attr('style', 'display: block !important');
            } else {
                $('.lead_butt_del_question').attr('style', 'display: block !important');
            }
        });

        $(document).on('click', '.form-repeater_lead_question .lead_butt_del_question', e => {
            var bt = parseFloat($('.lead_butt_del_question').length);
            // alert(bt);
            $(e.target).closest('.form-repeater_lead_question').slideUp(400, function() {
                $(this).remove()
            });
            if (bt == 2) {
                $('.lead_butt_del_question').attr('style', 'display: none !important');
            } else {}
        });
    </script>
    @endsection