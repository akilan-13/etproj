@extends('layouts/layoutMaster')

@section('title', 'View Invoice')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('content')

<style>
    .list_page thead th,
    .list_page tbody td {
        border: 1px solid black !important;
        padding: 8px !important;
    }

    @media (min-width: 992px) {
        .text-lg-end {
            text-align: end !important;
        }
    }
</style>
<div class="card card-action">
    <div class="card-header border-bottom flex-wrap pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">View Invoice</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Customer Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Manage Invoice</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element flex-shrink-1 flex-wrap">
            <div class="d-flex align-items-center justify-content-center gap-4 flex-wrap">
                <div class="border border-gray-600 rounded px-2 py-1 text-center mb-0">
                    <div class="text-black fw-semibold fs-6">Total Amount</div>
                    <div class="d-block">
                        <div class="badge bg-warning rounded fw-semibold fs-6 text-black">&#8377; 1,21,068</div>
                    </div>
                </div>
                <div class="border border-gray-600 rounded px-2 py-1 text-center mb-0">
                    <div class="text-black fw-semibold fs-6">Paid Amount</div>
                    <div class="d-block">
                        <div class="badge bg-success rounded fw-semibold fs-6 text-black">&#8377; 1,00,000</div>
                    </div>
                </div>
                <div class="border border-gray-600 rounded px-2 py-1 text-center mb-0">
                    <div class="text-black fw-semibold fs-6">Balance Amount</div>
                    <div class="d-block">
                        <div class="badge bg-danger rounded fw-semibold fs-6 text-white">&#8377; 21,068</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Company</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">PhDiZone</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Branch</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Madurai - Anna Nagar</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">presale@phdizone.com</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Phone No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">9944049888</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">#229, Ist & IInd Floor, A Block, Elysium Campus, Church Rd, Anna Nagar,
                        Madurai, Tamilnadu, India.</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sale Agent</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Ananya D</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Invoice Due Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-danger fs-6 fw-semibold">11-Apr-2025</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">priya@gmail.com</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Phone No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Currency</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-info fs-6 fw-semibold">INR</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Payment Slot</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-danger fs-6 fw-semibold text-black" style="background-color: #39f5dd !important;">03</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Invoice No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-warning rounded text-black fs-6 fw-semibold">INV-005003/04/2025</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">1, Bharathiyar Street, Avaniyapuram, Madurai, Tamilnadu, India.</label>
                </div>
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-lg-12">
                <div class="nav-align-top mb-2">
                    <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item border border-gray-400 rounded me-2">
                            <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_invoice" aria-controls="tab_invoice" aria-selected="false">Invoice</button>
                        </li>
                        <li class="nav-item border border-gray-400 rounded me-2">
                            <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_invoice_1" aria-controls="tab_invoice_1" aria-selected="false">INV-005003/04/2025-01</button>
                        </li>
                        <li class="nav-item border border-gray-400 rounded me-2">
                            <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_invoice_2" aria-controls="tab_invoice_2" aria-selected="false">INV-005003/04/2025-02</button>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="border border-gray-800 rounded pb-2">
                    <div class="tab-content p-0">
                        <div class="tab-pane fade show active" id="tab_invoice" role="tabpanel">
                            <div class="px-4 pb-4">
                                <div class="row mb-3 mt-2">
                                    <div class="col-lg-6">
                                        <div class="fs-2 text-lg-end text-center text-black mt-3 mb-1 fw-bold">Service Details</div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="d-flex align-items-center justify-content-end gap-2">
                                            <div class="cursor-pointer me-2">
                                                <a href="{{url('/manage_invoice/invoice_print')}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                    <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                                </a>
                                            </div>
                                            <div class="mb-0">
                                                <div class="d-block text-end mt-3 mb-1">
                                                    <label class="text-black fw-semibold fs-6">Invoice Date &nbsp; - &nbsp;</label>
                                                    <label class="text-black fw-semibold fs-6">06-Apr-2025</label>
                                                </div>
                                                <div class="d-block text-end mb-1">
                                                    <label class="text-black fw-semibold fs-6">Invoice Due Date &nbsp; - &nbsp;</label>
                                                    <label class="text-black fw-semibold fs-6">
                                                        <span class="badge bg-danger fw-semibold fs-7">11-Apr-2025</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 mb-2">
                                        <table class="table align-top gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-50px text-center">S.No</th>
                                                    <th class="min-w-300px text-center">Work </th>
                                                    <th class="min-w-150px text-center">Qty </th>
                                                    <th class="min-w-150px text-center">Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600">
                                                <tr>
                                                    <td align="center">1</td>
                                                    <td>
                                                        <div>
                                                            <div class="text-black fw-semibold fs-6 mb-1">Scopue Q1 / Q2 Research Paper ( Rs.50,000 )</div>
                                                            <div class="text-dark fw-semibold fs-7">Writing Services - Thesis Writing</div>
                                                            <div class="border-bottom my-2 border-gray-400 border-1 border-dashed"></div>
                                                            <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                            <div class="text-black fw-semibold fs-7 my-2">Free Services</div>
                                                            <div class="d-block text-black">Grammer Checking</div>
                                                            <div class="d-block text-black">Proof Reading</div>
                                                            <div class="border-bottom my-2 border-gray-400 border-1 border-dashed"></div>
                                                            <div class="text-black fw-semibold fs-7 my-2">Paid Services</div>
                                                            <div class="d-block text-black">Literature Writing ( Rs.1,000 )</div>
                                                            <div class="d-block text-black">Plagiarism Checking ( Rs.1,000 )</div>
                                                            <div class="border-bottom my-2 border-gray-400 border-1 border-dashed"></div>
                                                            <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                            <div class="d-block">1. Technical discussion</div>
                                                            <div class="d-block">2. Flow of the work ( Novelty and Data Set )</div>
                                                            <div class="d-block">3. Source Code</div>
                                                            <div class="d-block">4. Pseudo Code</div>
                                                            <div class="d-block">5. Demo through Running video</div>
                                                            <div class="d-block">6. Results As per client specification-As per the Description</div>
                                                            <div class="d-block">7. Software Installation</div>
                                                        </div>
                                                    </td>
                                                    <td align="center">
                                                        <label class="fs-6 fw-bold">1</label>
                                                    </td>
                                                    <td align="right">
                                                        <label class="fs-6 text-black fw-semibold">&#8377; 52,000</label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="center">2</td>
                                                    <td>
                                                        <div>
                                                            <div class="text-black fw-semibold fs-6 mb-1">Computer Science- BlockChain technology-ML/DL ( Rs.60,000 )</div>
                                                            <div class="text-dark fw-semibold fs-7">Development Service - Python Development</div>
                                                            <div class="border-bottom my-2 border-gray-400 border-1 border-dashed"></div>
                                                            <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                            <div class="text-black fw-semibold fs-7 my-2">Free Services</div>
                                                            <div class="d-block text-black">Grammer Checking</div>
                                                            <div class="d-block text-black">Proof Reading</div>
                                                            <div class="border-bottom my-2 border-gray-400 border-1 border-dashed"></div>
                                                            <div class="text-black fw-semibold fs-7 my-2">Paid Services</div>
                                                            <div class="d-block text-black">Literature Writing ( Rs.1,000 )</div>
                                                            <div class="d-block text-black">Plagiarism Checking ( Rs.1,000 )</div>
                                                            <div class="border-bottom my-2 border-gray-400 border-1 border-dashed"></div>
                                                            <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                            <div class="d-block">1. Technical discussion</div>
                                                            <div class="d-block">2. Flow of the work ( Novelty and Data Set )</div>
                                                            <div class="d-block">3. Source Code</div>
                                                            <div class="d-block">4. Pseudo Code</div>
                                                            <div class="d-block">5. Demo through Running video</div>
                                                            <div class="d-block">6. Results As per client specification-As per the Description</div>
                                                            <div class="d-block">7. Software Installation</div>
                                                        </div>
                                                    </td>
                                                    <td align="center">
                                                        <label class="fs-6 fw-bold">1</label>
                                                    </td>
                                                    <td align="right">
                                                        <label class="fs-6 text-black fw-semibold">&#8377; 62,000</label>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <label class="fw-bold text-black fs-5 me-13">Sub Total</label>
                                    <div class="fw-bold text-black fs-2">
                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-black"></i></span>
                                        <span class="fs-3">1,14,000</span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <label class="fw-bold fs-5 me-13">Discount ( 10% )</label>
                                    <div class="fw-bold fs-2">
                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                        <span class="fs-3">11,400</span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <label class="fw-bold text-black fs-5 me-13">Total Amount</label>
                                    <div class="fw-bold text-black fs-2">
                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-black"></i></span>
                                        <span class="fs-3">1,02,600</span>
                                    </div>
                                    <!-- <div class="border-bottom mt-1 mb-1 border-gray-400 border-1 w-100 border-dashed float-end"></div><br> -->
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <div class="me-13">
                                        <label class="fw-bold fs-5">GST ( 18% )</label>
                                        <div class="d-block text-center fw-bold fs-8">[Exclusive]</div>
                                    </div>
                                    <div class="fw-bold fs-2">
                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                        <span class="fs-3">18,468</span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <label class="fw-bold text-black fs-2 me-13">Grand Total</label>
                                    <div class="fw-bold text-black fs-2">
                                        <label><i class="mdi mdi-currency-rupee fs-4 fw-bold text-black"></i></label>
                                        <label class="fs-2">1,21,068</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab_invoice_1" role="tabpanel">
                            <div class="px-4 pb-4">
                                <div class="d-flex align-items-center justify-content-between border-bottom mb-3 mt-2">
                                    <div class="text-black fw-semibold fs-4 mb-3 mt-2">Transaction Details</div>
                                    <div class="d-flex align-items-center justify-content-end gap-2">
                                        <div class="cursor-pointer me-2">
                                            <a href="{{url('/manage_invoice/invoice_print')}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                            </a>
                                        </div>
                                        <div class="mb-0">
                                            <div class="d-block text-end mb-3 mt-2">
                                                <label class="text-black fw-semibold fs-6">Invoice Date &nbsp; - &nbsp;</label>
                                                <label class="text-black fw-semibold fs-6">06-Apr-2025</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Payment Type</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">Bank</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Bank</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">TMB</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Account No</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">20272560000045</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Branch</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">Anna Nagar</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">IFSC Code</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">HDFC0002027</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 text-center">
                                        <div class="text-black fw-semibold fs-4">Paid Amount</div>
                                        <div class="d-block">
                                            <div class="badge bg-success rounded fw-semibold fs-3 text-black">&#8377; 50,000</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 text-center">
                                        <div class="text-black fw-semibold fs-4">Balance Amount</div>
                                        <div class="d-block">
                                            <div class="badge bg-danger rounded fw-semibold fs-3 text-white">&#8377; 71,068</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab_invoice_2" role="tabpanel">
                            <div class="px-4 pb-4">
                                <div class="d-flex align-items-center justify-content-between border-bottom mb-3 mt-2">
                                    <div class="text-black fw-semibold fs-4 mb-3 mt-2">Transaction Details</div>
                                    <div class="d-flex align-items-center justify-content-end gap-2">
                                        <div class="cursor-pointer me-2">
                                            <a href="{{url('/manage_invoice/invoice_print')}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                            </a>
                                        </div>
                                        <div class="mb-0">
                                            <div class="d-block text-end mb-3 mt-2">
                                                <label class="text-black fw-semibold fs-6">Invoice Date &nbsp; - &nbsp;</label>
                                                <label class="text-black fw-semibold fs-6">09-Apr-2025</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Payment Type</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">Bank</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Bank</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">TMB</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Account No</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">20272560000045</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">Branch</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">Anna Nagar</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-3 text-dark fs-6 fw-semibold">IFSC Code</label>
                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                            <label class="col-8 text-black fs-6 fw-semibold">HDFC0002027</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 text-center">
                                        <div class="text-black fw-semibold fs-4">Paid Amount</div>
                                        <div class="d-block">
                                            <div class="badge bg-success rounded fw-semibold fs-3 text-black">&#8377; 50,000</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 text-center">
                                        <div class="text-black fw-semibold fs-4">Balance Amount</div>
                                        <div class="d-block">
                                            <div class="badge bg-danger rounded fw-semibold fs-3 text-white">&#8377; 21,068</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +

            "<'table-responsive'tr>"

        // "<'row'" +
        // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>"


    });
</script>


@endsection