@extends('layouts/layoutMaster')

@section('title', 'Create Invoice')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection
@section('content')

<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 8px !important;
    }
</style>

<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Invoice</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Customer Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Invoice</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-1">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">priya@gmail.com</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Phone No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Currency</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-info fs-6 fw-semibold">INR</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">1, Bharathiyar Street, Avaniyapuram, Madurai, Tamilnadu, India.</label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Payment Slot</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-danger fs-6 fw-semibold text-black" style="background-color: #39f5dd !important;">03</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Work</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya Work Details</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Branch</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Madurai - Anna Nagar</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sale Agent</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Ananya D</label>
                </div>
            </div>
        </div>
        <div class="fs-2 text-center text-black mt-3 mb-3 fw-bold">Service Details</div>
        <div class="row">
            <div class="col-lg-12 mb-2">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-50px">S.No</th>
                            <th class="min-w-150px">Services</th>
                            <th class="min-w-50px">Qty</th>
                            <th class="min-w-100px">Service Amt</th>
                            <th class="min-w-100px">Add-On Service Amt</th>
                            <th class="min-w-100px">Total Amount</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        <tr>
                            <td>1</td>
                            <td>
                                <div>
                                    <label class="fs-7">Scopue Q1 / Q2 Research Paper</label>
                                    <div class="d-block">
                                        <span class="text-dark fw-semibold fs-8">Writing Services - Thesis Writing</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7">01</label>
                            </td>
                            <td align="right">
                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 50,000</label>
                            </td>
                            <td align="right">
                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 2,000</label>
                            </td>
                            <td align="right">
                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 52,000</label>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>
                                <div>
                                    <label class="fs-7">Computer Science- BlockChain technology-ML/DL</label>
                                    <div class="d-block">
                                        <span class="text-dark fw-semibold fs-8">Development Service - Python Development</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7">01</label>
                            </td>
                            <td align="right">
                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 60,000</label>
                            </td>
                            <td align="right">
                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 2,000</label>
                            </td>
                            <td align="right">
                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 62,000</label>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <label class="fw-bold text-black fs-5 me-13">Sub Total</label>
            <div class="fw-bold text-black fs-2">
                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-black"></i></span>
                <span class="fs-3">1,14,000</span>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <label class="fw-bold fs-5 me-13">Discount ( 10% )</label>
            <div class="fw-bold fs-2">
                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                <span class="fs-3">11,400</span>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <label class="fw-bold text-black fs-5 me-13">Total Amount</label>
            <div class="fw-bold text-black fs-2">
                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-black"></i></span>
                <span class="fs-3">1,02,600</span>
            </div>
            <!-- <div class="border-bottom mt-1 mb-1 border-gray-400 border-1 w-100 border-dashed float-end"></div><br> -->
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <div class="me-13">
                <label class="fw-bold fs-5">GST ( 18% )</label>
                <div class="d-block text-center fw-bold fs-8">[Exclusive]</div>
            </div>
            <div class="fw-bold fs-2">
                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                <span class="fs-3">18,468</span>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <label class="fw-bold text-black fs-2 me-13">Grand Total</label>
            <div class="fw-bold text-black fs-2">
                <label><i class="mdi mdi-currency-rupee fs-4 fw-bold text-black"></i></label>
                <label class="fs-2">1,21,068</label>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Invoice Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="quotation_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Due Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="quotation_validity" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                </div>
            </div>
            <div class="col-lg-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
                <select id="payment" name="payment" class="select3 form-select" onchange="payment_func();">
                    <option value="">Select Payment Mode</option>
                    <option value="cash">Cash</option>
                    <option value="check">Cheque</option>
                    <option value="paypal">PayPal</option>
                    <option value="gpay">GPay</option>
                    <option value="bank">Bank</option>
                </select>
            </div>
        </div>
        <div id="cash_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Cash Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Cash Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="check_det" style="display: none !important;">
            <div class="row mt-4">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                    <select id="" class="select3 form-select">
                        <option value="">Select Bank</option>
                        <option value="">TMB</option>
                        <option value="">Indian</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Cheque No<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Cheque No" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="gpay_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="paypal_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="bank_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                    <select id="" class="select3 form-select">
                        <option value="">Select Bank</option>
                        <option value="">TMB</option>
                        <option value="">Indian</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Account Number<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Account Number" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Branch Name" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter IFSC Code" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
            <a href="/manage_invoice" class="btn btn-secondary me-2">Cancel</a>
            <a href="/manage_invoice" class="btn btn-primary">Create Invoice</a>
        </div>
    </div>
</div>

<!--Quotation Payment Accordion Start-->
<script>
    $('.course_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_course_question').length);
        let $clone = $('.form-repeater_course_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_course_question:first').slideDown();
        if (bt == 1) {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course_question .cat_butt_del_question', e => {
        var bt = parseFloat($('.cat_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.cat_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    let logofile = document.getElementById('uploadedsignature');
    const fileInput = document.querySelector('.file-in'),
        resetFileInput = document.querySelector('.file-reset');

    if (logofile) {
        const resetImage = logofile.src;
        fileInput.onchange = () => {
            if (fileInput.files[0]) {
                logofile.src = window.URL.createObjectURL(fileInput.files[0]);
            }
        };
        resetFileInput.onclick = () => {
            fileInput.value = '';
            logofile.src = resetImage;
        };
    }
</script>

<script>
    function add_on_func() {
        var add_on = document.getElementById("add_on");
        var view_add_on = document.getElementById("view_add_on");

        if (add_on.checked) {
            view_add_on.style.display = "block";
        } else {
            view_add_on.style.display = "none";
        }
    }
</script>
<script>
    function package_on_func() {
        var package_on = document.getElementById("package_on");
        var view_package = document.getElementById("view_package");
        var view_service_on = document.getElementById("view_service_on");
        if (package_on.checked) {
            view_package.style.display = "block";
            view_service_on.style.display = "none";
        } else {
            view_package.style.display = "none";
        }
    }
</script>
<script>
    function service_on_func() {
        var service_on = document.getElementById("service_on");
        var view_service_on = document.getElementById("view_service_on");
        var view_package = document.getElementById("view_package");
        var amount_view = document.getElementById("amount_view");
        var chapter_view = document.getElementById("chapter_view");
        var wrk_hrs_view = document.getElementById("wrk_hrs_view");
        var wrk_days_view = document.getElementById("wrk_days_view");
        var description_view = document.getElementById("description_view");
        var amount_view_2 = document.getElementById("amount_view_2");
        var no_of_pages_view_2 = document.getElementById("no_of_pages_view_2");
        var wrk_hrs_view_2 = document.getElementById("wrk_hrs_view_2");
        var description_view_2 = document.getElementById("description_view_2");
        if (service_on.checked) {
            view_service_on.style.display = "block";
            view_package.style.display = "none";
            amount_view_2.style.display = "none";
            no_of_pages_view_2.style.display = "none";
            chapter_view_2.style.display = "none";
            wrk_hrs_view_2.style.display = "none";
            amount_view.style.display = "none";
            no_of_pages_view.style.display = "none";
            chapter_view.style.display = "none";
            wrk_hrs_view.style.display = "none";
            description_view.style.display = "none";
            description_view_2.style.display = "none";
            wrk_days_view.style.display = "none";
        } else {
            view_service_on.style.display = "none";
        }
    }
</script>
<script>
    function package_name_func() {
        var package_name = document.getElementById("package_name").value;
        var amount_view = document.getElementById("amount_view");
        var chapter_view = document.getElementById("chapter_view");
        var wrk_hrs_view = document.getElementById("wrk_hrs_view");
        var wrk_days_view = document.getElementById("wrk_days_view");
        var description_view = document.getElementById("description_view");
        var amount_view_2 = document.getElementById("amount_view_2");
        var no_of_pages_view_2 = document.getElementById("no_of_pages_view_2");
        var wrk_hrs_view_2 = document.getElementById("wrk_hrs_view_2");

        if (package_name == "paper_write_1") {
            amount_view.style.display = "block";
            no_of_pages_view.style.display = "block";
            chapter_view.style.display = "block";
            wrk_hrs_view.style.display = "block";
            wrk_days_view.style.display = "block";
            description_view.style.display = "block";
            amount_view_2.style.display = "none";
            no_of_pages_view_2.style.display = "none";
            chapter_view_2.style.display = "none";
            wrk_hrs_view_2.style.display = "none";
            description_view_2.style.display = "none";
        } else if (package_name == "paper_write_2") {
            amount_view_2.style.display = "block";
            no_of_pages_view_2.style.display = "block";
            chapter_view_2.style.display = "block";
            wrk_hrs_view_2.style.display = "block";
            amount_view.style.display = "none";
            no_of_pages_view.style.display = "none";
            chapter_view.style.display = "none";
            wrk_hrs_view.style.display = "none";
            description_view.style.display = "none";
            description_view_2.style.display = "block";
        } else {
            amount_view.style.display = "none";
            no_of_pages_view.style.display = "none";
            chapter_view.style.display = "none";
            wrk_hrs_view.style.display = "none";
            amount_view_2.style.display = "none";
            no_of_pages_view_2.style.display = "none";
            chapter_view_2.style.display = "none";
            wrk_hrs_view_2.style.display = "none";
            description_view.style.display = "none";
        }
    }
</script>
<script>
    function page_count_func() {
        var total_pages = document.getElementById("total_pages").value;
        var pages_view = document.getElementById("pages_view");
        var two_pages_view = document.getElementById("two_pages_view");
        var one_pages = document.getElementById("one_pages");
        if (total_pages == "one_pages") {
            pages_view.style.display = "block";
            two_pages_view.style.display = "none";
        } else if (total_pages == "two_pages") {
            pages_view.style.display = "none";
            two_pages_view.style.display = "block";
        } else {
            pages_view.style.display = "none";
        }
    }
</script>

<script>
    function service_properties_func() {
        var service_prod_add = document.getElementById("service_prod_add");
        var service_product_view = document.getElementById("service_product_view");

        if (service_prod_add.checked) {
            service_product_view.style.display = "block";
        } else {
            service_product_view.style.display = "none";
        }
    }
</script>

<script>
    $('#add_on_chk_all').change(function() {
        $('.add_on_ver_chk').prop('checked', this.checked);
    });

    $('.add_on_ver_chk').change(function() {
        if ($('.add_on_ver_chk:checked').length == $('.add_on_ver_chk').length) {
            $('#add_on_chk_all').prop('checked', true);
        } else {
            $('#add_on_chk_all').prop('checked', false);
        }

    });
</script>

<script>
    $('#add_on_chk_all_paid').change(function() {
        $('.add_on_ver_chk_paid').prop('checked', this.checked);
    });

    $('.add_on_ver_chk_paid').change(function() {
        if ($('.add_on_ver_chk_paid:checked').length == $('.add_on_ver_chk_paid').length) {
            $('#add_on_chk_all_paid').prop('checked', true);
        } else {
            $('#add_on_chk_all_paid').prop('checked', false);
        }

    });
</script>
<script>
    $('.service_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_add').length);
        let $clone = $('.form-repeater_service_add').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_add:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_add .service_butt_del', e => {
        var bt = parseFloat($('.service_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_add').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    function template_slot_func() {
        var template_slot = document.getElementById("template_slot").value;
        var template_1 = document.getElementById("template_1");
        var template_2 = document.getElementById("template_2");

        if (template_slot == "template_1") {
            view_single_template_slot.style.display = "block";
            view_double_template_slot.style.display = "none";
        } else if (template_slot == "template_2") {
            view_double_template_slot.style.display = "block";
            view_single_template_slot.style.display = "none";
        } else {

        }
    }
</script>

<script>
    function payment_func() {
        var payment = document.getElementById("payment").value;
        var cash_det = document.getElementById("cash_det");
        var check_det = document.getElementById("check_det");
        var gpay_det = document.getElementById("gpay_det");
        var paypal_det = document.getElementById("paypal_det");
        var bank_det = document.getElementById("bank_det");
        if (payment == "cash") {
            cash_det.style.display = "block";
            check_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "check") {
            check_det.style.display = "block";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "gpay") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "block";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "paypal") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "none";
            paypal_det.style.display = "block";
        } else if (payment == "bank") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "block";
            paypal_det.style.display = "none";
        } else {
            cash_det.style.display = "none";
            check_det.style.display = "none";
        }
    }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection