@extends('layouts/layoutMaster')

@section('title', 'Create Invoice')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection
@section('content')

<style>
    .list_page thead th,
    .list_page tbody td {
        border: 1px solid black !important;
        padding: 8px !important;
    }
</style>

<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Invoice</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Lead Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Invoice</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-1">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">priya@gmail.com</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Phone No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Currency</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-info fs-6 fw-semibold">INR</label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">1, Bharathiyar Street, Avaniyapuram, Madurai, Tamilnadu, India.</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Branch</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Madurai - Anna Nagar</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sale Agent</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Ananya D</label>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Work Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control me-2" placeholder="Enter Work Name" />
            </div>
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                <select id="payment_slot" class="select3 form-select" data-style="btn-default" data-live-search="true">
                    <option value="">Select Payment Slot</option>
                    <option value="1">Single Slot</option>
                    <option value="2">Dual Slot</option>
                </select>
            </div>
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Invoice Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="quotation_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Due Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="quotation_validity" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="divider divider-primary mb-2">
                            <div class="divider-text fs-3 text-black fw-semibold">Service Details</div>
                        </div>
                    </div>
                    <div class="col-lg-12 mt-2">
                        <div class="form-repeater_service_add">
                            <div data-repeater-list="group-a_service_question">
                                <div data-repeater-item>
                                    <div class="row">
                                        <div class="col-lg-11">
                                            <div class="row mb-4">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
                                                    <select class="select3 form-select">
                                                        <option value="">Select Service Category</option>
                                                        <option value="1">Writing Services</option>
                                                        <option value="2">Research Services</option>
                                                        <option value="3">Development Services</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Services<span class="text-danger">*</span></label>
                                                    <select class="select3 form-select">
                                                        <option value="">Select Services</option>
                                                        <option value="1">Essay Writing</option>
                                                        <option value="2">Book Writing</option>
                                                        <option value="3">Thesis Writing</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Service Title<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control me-2" placeholder="Enter Service Title" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="list-group list-group-horizontal-md text-md-center">
                                                        <a class="list-group-item list-group-item-action fw-semibold active" id="service_only_item" data-bs-toggle="list" href="#service_only" style="border-bottom-left-radius: 0px !important;">Service Only</a>
                                                        <a class="list-group-item list-group-item-action fw-semibold" id="serv_packages_item" data-bs-toggle="list" href="#serv_packages">Packages</a>
                                                        <a class="list-group-item list-group-item-action fw-semibold" id="serv_customize_item" data-bs-toggle="list" href="#serv_customize" style="border-bottom-right-radius: 0px !important;">Customize</a>
                                                    </div>
                                                    <div class="tab-content px-3 py-4" style="border-top-left-radius: 0px !important;border-top-right-radius: 0px !important;border:1px solid #5c5c5c !important;border-top-style:hidden !important;">
                                                        <div class="tab-pane fade show active" id="service_only">
                                                            <div class="row">
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Quantity<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control text-center" placeholder="Enter Quantity" />
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control" placeholder="Enter Amount" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="serv_packages">
                                                            <div class="row">
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Packages<span class="text-danger">*</span></label>
                                                                    <select id="pkgs" class="select3 form-select text-black" onchange="package_func();">
                                                                        <option value="">Select Package</option>
                                                                        <option value="write_1">Paper Writing - 1</option>
                                                                        <option value="write_2">Paper Writing - 2</option>
                                                                    </select>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">No of Pages<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control" id="pkg_no_of_page" placeholder="Enter No of Pages" />
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Chapter<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control" id="pkg_chapt" placeholder="Enter Chapter" />
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Working Hours<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control" id="pkg_work_hrs" placeholder="Enter Working Hours" />
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Working Days<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control" id="pkg_work_dys" placeholder="Enter Working Days" />
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                                                    <textarea class="form-control" rows="1" id="pkg_descp" placeholder="Enter Description"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control" id="pkg_amt" placeholder="Enter Amount" />
                                                                </div>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-end gap-3">
                                                                <div class="mb-3">
                                                                    <label class="text-dark mb-1 fs-5 fw-semibold">Quantity<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control text-center w-100px fs-4 px-1 py-0" placeholder="Qty" />
                                                                </div>
                                                                <div class="text-center min-w-150px mb-3">
                                                                    <label class="text-dark mb-1 fs-4 fw-semibold">Amount</label>
                                                                    <div class="d-block mb-0">
                                                                        <label class="text-black fs-4 fw-semibold">&#8377; 0</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="serv_customize">
                                                            <div class="row">
                                                                <div class="col-lg-12 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Service Details<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="2" placeholder="Enter Service Details"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-end gap-3">
                                                                <div class="mb-3">
                                                                    <label class="text-dark mb-1 fs-5 fw-semibold">Quantity<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control text-center w-100px fs-4 py-1" placeholder="Qty" />
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label class="text-dark mb-1 fs-5 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <input type="text" class="form-control min-w-150px fs-4 py-1" placeholder="Enter Amount" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex align-items-center mt-4 mb-1">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input w-25px h-25px" type="checkbox" id="add_on" name="add_on" onclick="add_on_func();" />
                                                    <label class="text-black mb-1 fs-5 fw-semibold">Add On Services</label>
                                                </div>
                                            </div>
                                            <div class="mb-4" id="view_add_on" style="display:none;">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="border border-gray-700 rounded py-2">
                                                            <div class="d-flex align-items-center justify-content-between border-bottom">
                                                                <div class="mb-0 ps-3 py-2">
                                                                    <label class="text-black fw-semibold fs-6">Free Services &nbsp;-&nbsp;</label>
                                                                    <label class="badge bg-secondary rounded fs-6">
                                                                        <span>02</span>
                                                                        <span>/</span>
                                                                        <span>08</span>
                                                                    </label>
                                                                </div>
                                                                <div class="form-check form-check-inline mt-1 mb-0 pe-3 py-2">
                                                                    <input class="form-check-input" type="checkbox" id="add_on_chk_all" />
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                                </div>
                                                            </div>
                                                            <div class="scroll-y max-h-150px px-3 py-2">
                                                                <div class="row">
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" checked />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" checked />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-2">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="border border-gray-700 rounded py-2">
                                                            <div class="d-flex align-items-center justify-content-between border-bottom">
                                                                <div class="mb-0 ps-3 py-2">
                                                                    <label class="text-black fw-semibold fs-6">Paid Services &nbsp;-&nbsp;</label>
                                                                    <label class="badge bg-warning text-black rounded fs-6">
                                                                        <span>03</span>
                                                                        <span>/</span>
                                                                        <span>08</span>
                                                                    </label>
                                                                </div>
                                                                <div class="form-check form-check-inline mt-1 mb-0 pe-3 py-2">
                                                                    <input class="form-check-input" type="checkbox" id="add_on_chk_all_paid" />
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                                </div>
                                                            </div>
                                                            <div class="scroll-y max-h-150px px-3 py-2">
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input  add_on_ver_chk_paid" type="checkbox" checked />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Literature Writing</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1000</label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk_paid" type="checkbox" checked />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk_paid" type="checkbox" checked />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk_paid" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1000</label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input  add_on_ver_chk_paid" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">2 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1500</label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk_paid" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">2 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1500</label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk_paid" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">2 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1050</label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-2">
                                                                    <div class="col-lg-7">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input add_on_ver_chk_paid" type="checkbox" />
                                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-12 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="5" placeholder="Enter Deliverables"></textarea>
                                                </div>
                                                <!-- <div class="col-lg-12 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                    <div id="create_slot3" class="scroll-y max-h-100px">
                                                        <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                        </div>
                                                    </div>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="col-lg-1 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <hr class="bg-gray-400">
                                </div>
                            </div>
                        </div>
                        <div class="mb-1 mt-1">
                            <button class="btn btn-primary service_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add">
                                <i class="mdi mdi-plus me-1"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <label class="fw-bold fs-5 me-13">Sub Total</label>
            <div class="fw-bold fs-2">
                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                <span class="fs-3">0</span>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <div class="fw-bold fs-5 me-13">
                <label class="text-dark mb-1 fs-5 fw-semibold">Discount %</label>
                <input type="text" class="form-control fs-7 fw-semibold w-100px px-2 py-1 text-center" placeholder="Discount %" value="0" />
            </div>
            <div class="fw-bold fs-2">
                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                <span class="fs-3">0</span>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <div class="fw-bold fs-5 me-12">
                <div class="text-dark mb-1 fs-5 fw-semibold">
                    <label>GST(%)<span class="text-danger">*</span></label>
                    <div class="d-block fw-bold fs-8">[Exclusive]</div>
                </div>
                <div class="w-100px fs-7 fw-semibold mb-0">
                    <select class="select3 form-select fw-semibold">
                        <option value="1" selected>18%</option>
                        <option value="2">20%</option>
                    </select>
                </div>
            </div>
            <div class="fw-bold fs-2">
                <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                <label class="fs-3">0</label>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
            <label class="fw-bold fs-3 me-13">Grand Total</label>
            <div class="fw-bold fs-2">
                <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                <label class="fs-2">0</label>
            </div>
        </div>
        <h5 class="card-title mb-2 fw-bold">Payment Details</h5>
        <div class="row mt-4">
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
                <select id="payment" name="payment" class="select3 form-select" onchange="payment_func();">
                    <option value="">Select Payment Mode</option>
                    <option value="cash">Cash</option>
                    <option value="check">Cheque</option>
                    <option value="paypal">PayPal</option>
                    <option value="gpay">GPay</option>
                    <option value="bank">Bank</option>
                </select>
            </div>
        </div>
        <div id="cash_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Cash Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Cash Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="check_det" style="display: none !important;">
            <div class="row mt-4">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                    <select id="" class="select3 form-select">
                        <option value="">Select Bank</option>
                        <option value="">TMB</option>
                        <option value="">Indian</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Cheque No<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Cheque No" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="gpay_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="paypal_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div id="bank_det" style="display: none !important;">
            <div class="row mt-2">
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                    <select id="" class="select3 form-select">
                        <option value="">Select Bank</option>
                        <option value="">TMB</option>
                        <option value="">Indian</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Account Number<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Account Number" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter Branch Name" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="" placeholder="Enter IFSC Code" />
                </div>
                <div class="col-lg-3 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
            <a href="/manage_invoice" class="btn btn-secondary me-2">Cancel</a>
            <a href="/manage_invoice" class="btn btn-primary">Create Invoice</a>
        </div>
    </div>
</div>

<!--Quotation Payment Accordion Start-->
<script>
    $('.course_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_course_question').length);
        let $clone = $('.form-repeater_course_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_course_question:first').slideDown();
        if (bt == 1) {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course_question .cat_butt_del_question', e => {
        var bt = parseFloat($('.cat_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.cat_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    function add_on_func() {
        var add_on = document.getElementById("add_on");
        var view_add_on = document.getElementById("view_add_on");

        if (add_on.checked) {
            view_add_on.style.display = "block";
        } else {
            view_add_on.style.display = "none";
        }
    }
</script>
<script>
    function package_func() {
        var pkgs = document.getElementById("pkgs").value;
        var amount_view = document.getElementById("amount_view");
        var chapter_view = document.getElementById("chapter_view");
        var wrk_hrs_view = document.getElementById("wrk_hrs_view");
        var wrk_days_view = document.getElementById("wrk_days_view");
        var description_view = document.getElementById("description_view");
        var amount_view_2 = document.getElementById("amount_view_2");
        var no_of_pages_view_2 = document.getElementById("no_of_pages_view_2");
        var wrk_hrs_view_2 = document.getElementById("wrk_hrs_view_2");

        if (pkgs == "write_1") {
            document.getElementById("pkg_no_of_page").value = "100";
            document.getElementById("pkg_chapt").value = "10";
            document.getElementById("pkg_work_hrs").value = "30 Hours";
            document.getElementById("pkg_work_dys").value = "4 Days";
            document.getElementById("pkg_descp").value = "-";
            document.getElementById("pkg_amt").value = "70,000";
        } else if (pkgs == "write_2") {
            document.getElementById("pkg_no_of_page").value = "200";
            document.getElementById("pkg_chapt").value = "15";
            document.getElementById("pkg_work_hrs").value = "50 Hours";
            document.getElementById("pkg_work_dys").value = "6 Days";
            document.getElementById("pkg_descp").value = "-";
            document.getElementById("pkg_amt").value = "90,000";
        } else {
            document.getElementById("pkg_no_of_page").value = "";
            document.getElementById("pkg_chapt").value = "";
            document.getElementById("pkg_work_hrs").value = "";
            document.getElementById("pkg_work_dys").value = "";
            document.getElementById("pkg_descp").value = "";
            document.getElementById("pkg_amt").value = "";
        }
    }
</script>

<script>
    $('#add_on_chk_all').change(function() {
        $('.add_on_ver_chk').prop('checked', this.checked);
    });

    $('.add_on_ver_chk').change(function() {
        if ($('.add_on_ver_chk:checked').length == $('.add_on_ver_chk').length) {
            $('#add_on_chk_all').prop('checked', true);
        } else {
            $('#add_on_chk_all').prop('checked', false);
        }

    });
</script>

<script>
    $('#add_on_chk_all_paid').change(function() {
        $('.add_on_ver_chk_paid').prop('checked', this.checked);
    });

    $('.add_on_ver_chk_paid').change(function() {
        if ($('.add_on_ver_chk_paid:checked').length == $('.add_on_ver_chk_paid').length) {
            $('#add_on_chk_all_paid').prop('checked', true);
        } else {
            $('#add_on_chk_all_paid').prop('checked', false);
        }

    });
</script>
<script>
    $('.service_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_add').length);
        let $clone = $('.form-repeater_service_add').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_add:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_add .service_butt_del', e => {
        var bt = parseFloat($('.service_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_add').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    function payment_func() {
        var payment = document.getElementById("payment").value;
        var cash_det = document.getElementById("cash_det");
        var check_det = document.getElementById("check_det");
        var gpay_det = document.getElementById("gpay_det");
        var paypal_det = document.getElementById("paypal_det");
        var bank_det = document.getElementById("bank_det");
        if (payment == "cash") {
            cash_det.style.display = "block";
            check_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "check") {
            check_det.style.display = "block";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "gpay") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "block";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "paypal") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "none";
            paypal_det.style.display = "block";
        } else if (payment == "bank") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "block";
            paypal_det.style.display = "none";
        } else {
            cash_det.style.display = "none";
            check_det.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +

            "<'table-responsive'tr>"

        // "<'row'" +
        // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>"


    });
</script>
@endsection