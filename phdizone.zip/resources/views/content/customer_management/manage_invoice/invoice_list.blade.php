@extends('layouts/layoutMaster')

@section('title', 'Manage Invoice')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',

])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 8px !important;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Invoice</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 py-0">
        <div class="row mt-6">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <div class="row">
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Invoice No</th>
                                        <th class="min-w-80px">Date</th>
                                        <th class="min-w-100px">Customer</th>
                                        <th class="min-w-50px text-center">Invoice</th>
                                        <th class="min-w-50px text-center">Slot</th>
                                        <th class="min-w-80px">Amount</th>
                                        <th class="min-w-80px">Balance Amt</th>
                                        <th class="min-w-80px text-center">NDA</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice No">INV-005003/04/2025</label>
                                                <div class="d-block">
                                                    <span class="badge bg-info text-white fw-semibold">Partially Paid</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice  Date">06-Apr-2025</label>
                                            <div class="d-block">
                                                <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">11-Apr-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7">Priya</label>
                                            <div class="d-block">
                                                <label class="text-dark fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">priya@gmail.com</label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-warning text-black fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice Count">02</label>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-warning text-black fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Slot Count" style="background-color: #39f5dd !important;">03</label>
                                        </td>
                                        <td align="right">
                                            <label class="badge bg-secondary fs-7 text-white rounded fw-semibold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Actual Amount">&#8377; 1,21,068</label>
                                            <div class="d-block">
                                                <label class="badge bg-success fs-7 text-black rounded fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">&#8377; 1,00,000</label>
                                            </div>
                                        </td>
                                        <td align="right">
                                            <label class="badge bg-danger fs-7 text-white rounded fw-semibold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">&#8377; 21,068</label>
                                        </td>
                                        <td class="text-center">-</td>
                                        <td>
                                            <span class="text-end">
                                                <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_customer_nda">
                                                        <span><i class="mdi mdi-file-document-edit-outline fs-3 text-black me-1"></i>NDA</span>
                                                    </a>
                                                    <a href="{{url('/manage_invoice/invoice_view')}}" target="_blank" class="dropdown-item">
                                                        <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                    </a>
                                                    <a href="{{url('/manage_invoice/invoice_print')}}" target="_blank" class="dropdown-item">
                                                        <span><i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Print</span>
                                                    </a>
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice No">INV-005002/03/2025</label>
                                                <div class="d-block">
                                                    <span class="badge bg-info text-white fw-semibold">Partially Paid</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice  Date">04-Mar-2025</label>
                                            <div class="d-block">
                                                <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">09-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7">Kavi Priya</label>
                                            <div class="d-block">
                                                <label class="text-dark fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">kavipriya@gmail.com</label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-warning text-black fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice Count">01</label>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-warning text-black fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Slot Count" style="background-color: #39f5dd !important;">02</label>
                                        </td>
                                        <td align="right">
                                            <label class="badge bg-secondary fs-7 text-white rounded fw-semibold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Actual Amount">&#8377; 59,000</label>
                                            <div class="d-block">
                                                <label class="badge bg-success fs-7 text-black rounded fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">&#8377; 25,000</label>
                                            </div>
                                        </td>
                                        <td align="right">
                                            <label class="badge bg-danger fs-7 text-white rounded fw-semibold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">&#8377; 34,000</label>
                                        </td>
                                        <td class="text-center">
                                            <label class="d-block text-danger fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA Status">NDA Signed</label>
                                            <div class="d-block">
                                                <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA ID">GC/IZONE/2024/02346/03615</label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="{{url('/manage_invoice/invoice_view')}}" target="_blank" class="dropdown-item">
                                                        <span><i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                    </a>
                                                    <a href="{{url('/manage_invoice/invoice_print')}}" target="_blank" class="dropdown-item">
                                                        <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Print</span>
                                                    </a>
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice No">INV-005001/03/2025</label>
                                                <div class="d-block">
                                                    <span class="badge bg-success text-black fw-semibold">Paid</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice  Date">02-Mar-2025</label>
                                            <div class="d-block">
                                                <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">07-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7">Dharshini</label>
                                            <div class="d-block">
                                                <label class="text-dark fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">dharshini@gmail.com</label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-warning text-black fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice Count">01</label>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-warning text-black fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Slot Count" style="background-color: #39f5dd !important;">01</label>
                                        </td>
                                        <td align="right">
                                            <label class="badge bg-secondary fs-7 text-white rounded fw-semibold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Actual Amount">&#8377; 59,000</label>
                                            <div class="d-block">
                                                <label class="badge bg-success fs-7 text-black rounded fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">&#8377; 59,000</label>
                                            </div>
                                        </td>
                                        <td align="right">
                                            <label class="badge bg-danger fs-7 text-white rounded fw-semibold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">&#8377; 0</label>
                                        </td>
                                        <td class="text-center">
                                            <label class="d-block text-danger fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA Status">NDA Signed</label>
                                            <div class="d-block">
                                                <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA ID">GC/IZONE/2024/02346/03614</label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="{{url('/manage_invoice/invoice_view')}}" target="_blank" class="dropdown-item">
                                                        <span><i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                    </a>
                                                    <a href="{{url('/manage_invoice/invoice_print')}}" target="_blank" class="dropdown-item">
                                                        <span><i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Print</span>
                                                    </a>
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Customer NDA-->
<div class="modal fade" id="kt_modal_customer_nda" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Convert NDA?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya</label>
                    <span class="ms-2 me-2">-</span>
                    <label>INV-005003/04/2025</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <a href="/manage_nda/nda_add" class="btn btn-primary me-3">
                    Yes
                </a>
                <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Customer NDA-->


<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection