@extends('layouts/layoutMaster')

@section('title', 'Create Invoice')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')


<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Invoice</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Customer Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Invoice</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Invoice No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Invoice No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Invoice Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Due Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_validity" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Invoice Status<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Invoice Status</option>
                            <option value="1">Partially Paid</option>
                            <option value="2">Paid</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Sales<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Sales Person</option>
                            <option value="1">Sabana Barveen</option>
                            <option value="2">Mithra</option>
                            <option value="2">Salini </option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Email ID" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Phone No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Phone No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Country</option>
                            <option value="1">Afghanistan</option>
                            <option value="2">Bolivia</option>
                            <option value="3">Canada</option>
                            <option value="4">India</option>
                            <option value="5">Japan</option>
                            <option value="6">Kuwait</option>
                            <option value="7">Libya</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select State</option>
                            <option value="1">Andhra Pradesh</option>
                            <option value="2">Goa</option>
                            <option value="3">Karnataka</option>
                            <option value="4">Kerala</option>
                            <option value="5">Tamil Nadu</option>
                            <option value="6">Telangana</option>
                            <option value="7">Uttarakhand</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select City</option>
                            <option value="1">Chennai</option>
                            <option value="2">Vellore</option>
                            <option value="3">Salem</option>
                            <option value="4">Tirunelveli</option>
                            <option value="5">Madurai</option>
                            <option value="6">Dindigul</option>
                            <option value="7">Sivakasi</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Area / Street" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Door No / Flat No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Door No / Flat No" />
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-12">
                            <h4 class="card-title mb-1 fw-bold">Service Details</h4>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
                            <select id="ser_cat" class="select3 form-select">
                                <option value="">Select Service Category</option>
                                <option value="1">Reasearch Services</option>
                                <option value="2">PHD Services</option>
                                <option value="3">Writing Services</option>
                                <option value="4" selected>Development Services</option>
                                <option value="5">Analysis Services</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
                            <select id="ser_sub_cat" class="select3 form-select">
                                <option value="">Select Service Sub Category</option>
                                <option value="1">Research Paper Writing Service </option>
                                <option value="2">Book Writing Service</option>
                                <option value="3">Scopus Indexed Journal </option>
                                <option value="4" selected>Python Development </option>
                                <option value="5">SPSS Analysis</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
                            <select id="duration" class="select3 form-select" data-style="btn-default" data-live-search="true">
                                <option value="">Select Duration</option>
                                <option value="1">3 - 5 Days</option>
                                <option value="2">5 - 7 Days</option>
                                <option value="3">7 - 9 Days</option>
                                <option value="4">10 - 15 Days</option>
                                <option value="5" selected>15 - 20 Days</option>
                                <option value="6">20 - 25 Days</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description<span class="text-danger">*</span><span class="mdi mdi-information-slab-circle" data-bs-toggle="tooltip" data-bs-placement="right" title="Enter Project Title and Information"></span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter Description" value="Implementation Alone Domain : Computer Science-
                            BlockChain technology-ML/DL Topic : Need to be specified
                            Tool : Python" />
                        </div>
                        <div class="col-lg-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                            <select id="currency_format" class="select3 form-select" data-style="btn-default" data-live-search="true">
                                <option value="">Select Currency Format</option>
                                <option value="1">USD</option>
                                <option value="2">EUR</option>
                                <option value="3">GBP</option>
                                <option value="4">AUD</option>
                                <option value="5">INR</option>
                                <option value="6">KWD</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 d-flex align-items-center">
                            <div class="form-check form-check-inline mt-4">
                                <input class="form-check-input" type="checkbox" type="checkbox" id="add_on" name="add_on" onclick="add_on_func();" />
                                <label class="text-black mb-1 fs-5 fw-semibold">Add On Services</label>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4" id="view_add_on" name="view_add_on">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-xl-6 mb-2">
                                    <div class="card">
                                        <a class="card-body max-h-500px scroll-y">
                                            <div class="row">
                                                <div class="col-12 text-end">
                                                    <label class="badge bg-info rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Free</label>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="checkbox" id="edit_add_on_chk_all" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" checked />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" checked />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="card">
                                        <a class="card-body max-h-500px scroll-y">
                                            <div class="row">
                                                <div class="col-12 text-end">
                                                    <label class="badge bg-success text-black fw-bold rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Paid</label>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input" type="checkbox" id="edit_add_on_chk_all_paid" />
                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input  edit_add_on_ver_chk_paid" type="checkbox" />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input edit_add_on_ver_chk_paid" type="checkbox" />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input edit_add_on_ver_chk_paid" type="checkbox" checked />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input edit_add_on_ver_chk_paid" type="checkbox" checked />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <h4 class="card-title mb-1 fw-bold">Payment Details</h4>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Enter Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter Amount" readonly value="68,500" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Add-On-Service Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Add-On-Service Amount" readonly value="1500" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Sub Total Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Sub Total Amount" readonly value="70,000" />
                        </div>
                        <div class="col-lg-2 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Enter GST(%)<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter GST" value="12" />
                        </div>
                        <div class="col-lg-2 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">GST Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter GST" value="10,000" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Total Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Total Amount" value="80,000" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                            <select id="payment_slot" name="payment_slot" class="select3 form-select" onchange="payment_slot_func();">
                                <option value="">Select Payment Slot</option>
                                <option value="single">Single</option>
                                <option value="dual" selected>Dual</option>
                                <option value="triple">Trible</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-12 mb-4">
                        <div class="card-action">
                            <div class="card-header bg-gray-300">
                                <div class="card-action-title">
                                    <div class="row w-100">
                                        <label class="col-lg-12 text-black fs-6 fw-bold">Work Details</label>
                                    </div>
                                </div>
                                <div class="card-action-element">
                                    <ul class="list-inline mb-0">
                                        <li class="list-inline-item">
                                            <a href="javascript:;" class="quotation_payment_acrd"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="collapse quotation_payment_acrd_body border">
                            <div class="card-body">
                                <div class="row">
                                    <div class="row mt-2" style="display:none;" id="view_single_payment_slot">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I"></textarea>
                                                </div>

                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-2" id="view_double_payment_slot">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I">To start the work</textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables">1.Technical discussion  2.Flow of the work (Novelty and Data Set)
                                                </textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note">1.Once you acknowledge the flow only, we will move on
                                                otherwise,updated flow will be shared.</textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot II<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I">(After taking the Demo)(Before taking the Delivery of Code)</textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables">1.Source Code 2.Pseudo Code 3.Demo through Running video 4.Results As per client specification-As per the Description 5.Software Installation
                                                </textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note">1.Each and every step will be acknowledged by you 2.Every Section and Module of the Coding part will be clearly explained in the Google meet.Entire Technical Knowledge will be given to you,until the client understands the concept 3.As per the acknowledged description.We will be work on it.
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-2" style="display:none;" id="view_triple_payment_slot">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot II<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot II"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot III<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot III"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- <div class="row mt-4">
                    <div class="col-lg-12">
                        <h4 class="card-title mb-1 fw-bold">Payment Type</h4>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
                        <select id="payment" name="payment" class="select3 form-select" onchange="payment_func();">
                            <option value="">Select Payment Mode</option>
                            <option value="cash">Cash</option>
                            <option value="check">Cheque</option>
                            <option value="paypal">PayPal</option>
                            <option value="gpay">GPay</option>
                            <option value="bank">Bank</option>
                        </select>
                    </div>
                </div>
                <div id="cash_det" style="display: none !important;">
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Cash Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Cash Amount" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                </div>
                <div id="check_det" style="display: none !important;">
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select">
                                <option value="">Select Bank</option>
                                <option value="">TMB</option>
                                <option value="">Indian</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Cheque No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Cheque No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                </div>
                <div id="gpay_det" style="display: none !important;">
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                </div>
                <div id="paypal_det" style="display: none !important;">
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                </div>
                <div id="bank_det" style="display: none !important;">
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select">
                                <option value="">Select Bank</option>
                                <option value="">TMB</option>
                                <option value="">Indian</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Account Number<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Account Number" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Branch Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter IFSC Code" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                </div> -->
                <div class="row">
                    <div class="form-repeater_course_question">
                        <div data-repeater-list="group-a_led_question">
                            <div data-repeater-item>
                                <div class="row">
                                    <div class="col-lg-11">
                                        <div class="row mt-4">
                                            <div class="col-lg-4">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
                                                <select id="payment" name="payment" class="select3 form-select" onchange="payment_func();">
                                                    <option value="">Select Payment Mode</option>
                                                    <option value="cash">Cash</option>
                                                    <option value="check">Cheque</option>
                                                    <option value="paypal">PayPal</option>
                                                    <option value="gpay">GPay</option>
                                                    <option value="bank">Bank</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div id="cash_det" style="display: none !important;">
                                            <div class="row mt-4">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Cash Amount<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Cash Amount" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="check_det" style="display: none !important;">
                                            <div class="row mt-4">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                                    <select id="" class="select3 form-select">
                                                        <option value="">Select Bank</option>
                                                        <option value="">TMB</option>
                                                        <option value="">Indian</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Cheque No<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Cheque No" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="gpay_det" style="display: none !important;">
                                            <div class="row mt-4">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="paypal_det" style="display: none !important;">
                                            <div class="row mt-4">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="bank_det" style="display: none !important;">
                                            <div class="row mt-4">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                                    <select id="" class="select3 form-select">
                                                        <option value="">Select Bank</option>
                                                        <option value="">TMB</option>
                                                        <option value="">Indian</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Account Number<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Account Number" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter Branch Name" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control" id="" placeholder="Enter IFSC Code" />
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <div class="row">
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Question<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" id="" placeholder="Enter Question" />
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Question Type<span class="text-danger">*</span></label>
                                                <select id="question_course" name="question_course" class="select3 form-select" onchange="Question_func();">
                                                    <option>Select Question Type</option>
                                                    <option value="text_field">Text Field</option>
                                                    <option value="check_box">Check Box</option>
                                                    <option value="radio_button">Radio Button</option>
                                                    <option value="list_box">List Box</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-5 mb-3" id="course_check_box" style="display: none !important;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Check Box<span class="text-danger">*</span></label>
                                                <div class="accordion" id="lead_acrd">
                                                    <div class="accordion-item mb-2">
                                                        <h2 class="accordion-header" id="lead_acrd">
                                                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                            </button>
                                                        </h2>
                                                        <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd">
                                                            <div class="accordion-body">
                                                                <div class="form-repeater_cat">
                                                                    <div data-repeater-list="group-a_led">
                                                                        <div data-repeater-item>
                                                                            <div class="row">
                                                                                <div class="col-lg-10">
                                                                                    <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                        <span class="text-danger">*</span></label>
                                                                                    <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                                </div>
                                                                                <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 course_butt_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="course_butt_del" style="display: none !important;">
                                                                                        <i class="mdi mdi-delete fs-4"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="mb-1 mt-1">
                                                                    <button class="btn btn-primary course_butt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="course_butt_add">
                                                                        <i class="mdi mdi-plus me-1"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-5 mb-3" id="course_radio_button" style="display: none !important;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Radio Button<span class="text-danger">*</span></label>
                                                <div class="accordion" id="lead_acrd_radio">
                                                    <div class="accordion-item mb-2">
                                                        <h2 class="accordion-header" id="lead_acrd_radio">
                                                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                            </button>
                                                        </h2>
                                                        <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_radio">
                                                            <div class="accordion-body">
                                                                <div class="form-repeater_cat_radio">
                                                                    <div data-repeater-list="group-a_led_radio">
                                                                        <div data-repeater-item>
                                                                            <div class="row">
                                                                                <div class="col-lg-10">
                                                                                    <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                        <span class="text-danger">*</span></label>
                                                                                    <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                                </div>
                                                                                <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 course_butt_del_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="course_butt_del_radio" style="display: none !important;">
                                                                                        <i class="mdi mdi-delete fs-4"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="mb-1 mt-1">
                                                                    <button class="btn btn-primary course_butt_add_radio" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="course_butt_add_radio">
                                                                        <i class="mdi mdi-plus me-1"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-5 mb-3" id="course_list_box" style="display: none !important;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">List Box<span class="text-danger">*</span></label>
                                                <div class="accordion" id="lead_acrd_list_box_box">
                                                    <div class="accordion-item mb-2">
                                                        <h2 class="accordion-header" id="lead_acrd_list_box">
                                                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#lead_accordion" aria-expanded="false" aria-controls="lead_accordion" role="tabpanel">Question Option
                                                            </button>
                                                        </h2>
                                                        <div id="lead_accordion" class="accordion-collapse collapse" data-bs-parent="#lead_acrd_list_box">
                                                            <div class="accordion-body">
                                                                <div class="form-repeater_cat_list">
                                                                    <div data-repeater-list="group-a_led_list">
                                                                        <div data-repeater-item>
                                                                            <div class="row">
                                                                                <div class="col-lg-10">
                                                                                    <label class="text-dark mb-1 fs-6 fw-semibold" for="top_name">Option 1
                                                                                        <span class="text-danger">*</span></label>
                                                                                    <textarea class="form-control" rows="1" id="top_name" placeholder="Enter Option 1"></textarea>
                                                                                </div>

                                                                                <div class="col-lg-2 mb-1 px-1 py-1">
                                                                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 course_butt_del_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="course_butt_del_list" style="display: none !important;">
                                                                                        <i class="mdi mdi-delete fs-4"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="mb-1 mt-1">
                                                                    <button class="btn btn-primary course_butt_add_list" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="course_butt_add_list">
                                                                        <i class="mdi mdi-plus me-1"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                    <div class="col-lg-1 mb-1 px-1 py-1">
                                        <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 cat_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="cat_butt_del_question" style="display: none !important;">
                                            <i class="mdi mdi-delete fs-4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-1 mt-1">
                        <button class="btn btn-primary course_butt_add_Question" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="course_butt_add_Question">
                            <i class="mdi mdi-plus me-1"></i>
                        </button>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-4">
                        <div class="row">
                            <label class="text-dark fs-6 fw-semibold mb-2">Authorised Signature<span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <div class="align-items-sm-center gap-4">
                                    <img src="{{asset('assets/phdizone_images/phdizone_icon.png')}}" alt="user-avatar" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="uploadedsignature" />
                                    <div class="button-wrapper">
                                        <div class="d-flex align-items-start mt-2 mb-2">
                                            <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Signature">
                                                <i class="mdi mdi-tray-arrow-up"></i>
                                                <input type="file" id="upload" class="file-in" hidden accept="image/png, image/jpeg" />
                                            </label>
                                            <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                                                <i class="mdi mdi-reload"></i>
                                            </button>
                                        </div>
                                        <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-outline-secondary me-2">Cancel</button>
            <a href="/invoice/manage_invoice" class="btn btn-primary me-3">
                Create
            </a>
        </div>
    </div>
</div>

<!--Quotation Payment Accordion Start-->
<script>
    'use strict';

    (function() {
        const quotation_payment_acrd = [].slice.call(document.querySelectorAll('.quotation_payment_acrd'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (quotation_payment_acrd) {
            quotation_payment_acrd.map(function(quotation_payment_acrd_Element) {
                quotation_payment_acrd_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(quotation_payment_acrd_Element.closest('.card').querySelector('.collapse.quotation_payment_acrd_body'));
                    // Toggle collapsed class in `.card-header` element
                    quotation_payment_acrd_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(quotation_payment_acrd_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Quotation Payment Accordion End-->
<script>
    $('#add_on_chk_all_paid').change(function() {
        $('.add_on_ver_chk_paid').prop('checked', this.checked);
    });

    $('.add_on_ver_chk_paid').change(function() {
        if ($('.add_on_ver_chk_paid:checked').length == $('.add_on_ver_chk_paid').length) {
            $('#add_on_chk_all_paid').prop('checked', true);
        } else {
            $('#add_on_chk_all_paid').prop('checked', false);
        }

    });
</script>
<script>
    function add_on_func() {
        var add_on = document.getElementById("add_on");
        var view_add_on = document.getElementById("view_add_on");

        if (add_on.checked) {
            view_add_on.style.display = "block";
        } else {
            view_add_on.style.display = "none";
        }
    }
</script>

<script>
    $('#add_on_chk_all').change(function() {
        $('.add_on_ver_chk').prop('checked', this.checked);
    });

    $('.add_on_ver_chk').change(function() {
        if ($('.add_on_ver_chk:checked').length == $('.add_on_ver_chk').length) {
            $('#add_on_chk_all').prop('checked', true);
        } else {
            $('#add_on_chk_all').prop('checked', false);
        }

    });
</script>
<script>
    $('.quotation_info_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_quotation_info').length);
        let $clone = $('.form-repeater_quotation_info').first().clone().hide();
        $clone.insertBefore('.form-repeater_quotation_info:first').slideDown();
        if (bt == 1) {
            $('.quotation_del').attr('style', 'display: block !important');
        } else {
            $('.quotation_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_quotation_info .quotation_del', e => {
        var bt = parseFloat($('.quotation_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_quotation_info').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.quotation_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<!--end::Modal - Customer Payment-->
<script>
    function payment_func() {
        var payment = document.getElementById("payment").value;
        var cash_det = document.getElementById("cash_det");
        var check_det = document.getElementById("check_det");
        var gpay_det = document.getElementById("gpay_det");
        var paypal_det = document.getElementById("paypal_det");
        var bank_det = document.getElementById("bank_det");
        if (payment == "cash") {
            cash_det.style.display = "block";
            check_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "check") {
            check_det.style.display = "block";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "gpay") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "block";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "paypal") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "none";
            paypal_det.style.display = "block";
        } else if (payment == "bank") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "block";
            paypal_det.style.display = "none";
        } else {
            cash_det.style.display = "none";
            check_det.style.display = "none";
        }
    }
</script>

<script>
    function payment_slot_func() {
        var payment_slot = document.getElementById("payment_slot").value;
        var single = document.getElementById("single");
        var dual = document.getElementById("dual");
        var triple = document.getElementById("triple");

        if (payment_slot == "single") {
            view_single_payment_slot.style.display = "block";
            view_double_payment_slot.style.display = "none";
            view_triple_payment_slot.style.display = "none";
        } else if (payment_slot == "dual") {
            view_double_payment_slot.style.display = "block";
            view_single_payment_slot.style.display = "none";
            view_triple_payment_slot.style.display = "none";
        } else if (payment_slot == "triple") {
            view_triple_payment_slot.style.display = "block";
            view_single_payment_slot.style.display = "none";
            view_double_payment_slot.style.display = "none";
        } else {

        }
    }
</script>
<script>
    function Question_func() {
        var question_course = document.getElementById("question_course").value;
        var course_check_box = document.getElementById("course_check_box");
        var course_radio_button = document.getElementById("course_radio_button");
        var course_list_box = document.getElementById("course_list_box");

        if (question_course == "check_box") {
            course_check_box.style.display = "block";
            course_radio_button.style.display = "none";
            course_list_box.style.display = "none";
        } else if (question_course == "radio_button") {
            course_check_box.style.display = "none";
            course_radio_button.style.display = "block";
            course_list_box.style.display = "none";
        } else if (question_course == "list_box") {
            course_check_box.style.display = "none";
            course_radio_button.style.display = "none";
            course_list_box.style.display = "block";
        } else {
            course_check_box.style.display = "none";
            course_radio_button.style.display = "none";
            course_list_box.style.display = "none";
        }
    }
</script>
<script>
    $('.course_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_cat').length);
        let $clone = $('.form-repeater_cat').first().clone().hide();
        $clone.insertBefore('.form-repeater_cat:first').slideDown();
        if (bt == 1) {
            $('.course_butt_del').attr('style', 'display: block !important');
        } else {
            $('.course_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_cat .course_butt_del', e => {
        var bt = parseFloat($('.course_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_cat').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.course_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.course_butt_add_radio').on('click', e => {
        var bt = parseFloat($('.form-repeater_cat_radio').length);
        let $clone = $('.form-repeater_cat_radio').first().clone().hide();
        $clone.insertBefore('.form-repeater_cat_radio:first').slideDown();
        if (bt == 1) {
            $('.course_butt_del_radio').attr('style', 'display: block !important');
        } else {
            $('.course_butt_del_radio').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_cat_radio .course_butt_del_radio', e => {
        var bt = parseFloat($('.course_butt_del_radio').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_cat_radio').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.course_butt_del_radio').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.course_butt_add_list').on('click', e => {
        var bt = parseFloat($('.form-repeater_cat_list').length);
        let $clone = $('.form-repeater_cat_list').first().clone().hide();
        $clone.insertBefore('.form-repeater_cat_list:first').slideDown();
        if (bt == 1) {
            $('.course_butt_del_list').attr('style', 'display: block !important');
        } else {
            $('.course_butt_del_list').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_cat_list .course_butt_del_list', e => {
        var bt = parseFloat($('.course_butt_del_list').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_cat_list').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.course_butt_del_list').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.course_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_course_question').length);
        let $clone = $('.form-repeater_course_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_course_question:first').slideDown();
        if (bt == 1) {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course_question .cat_butt_del_question', e => {
        var bt = parseFloat($('.cat_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.cat_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>

@endsection