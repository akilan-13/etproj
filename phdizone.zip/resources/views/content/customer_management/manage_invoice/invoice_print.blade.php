@extends('layouts/blankLayout')

@section('title', 'Print Invoice')
@section('content')


<style>
    @media print {
        /* .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            padding: 10px;
            z-index: 1000;

        }

        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: white;
            color: black;
            text-align: right;
            page-break-before: always;
            counter-increment: page;
        } */

        body {
            background-color: white !important;
            margin: 0px !important;
            padding: 0px !important;
            page-break-before: auto;
            /* padding-top: 220px; */
            /* counter-reset: page; */
        }

        .print-container::before {
            content: "";
            display: block;
            height: 150px;
        }

        .start_cont {
            background: none !important;
            /* padding-top: 180px; */
            /* counter-reset: page; */
        }

        .page-break {
            page-break-before: auto !important;
        }

        /* .page-break-after {
            padding-top: 220px;
        } */

        /* .blank_row {
            page-break-inside: avoid;
            page-break-after: auto;
            line-height: 270px;
        } */

        table {
            width: 100%;
            border-collapse: collapse;
            /* overflow-x: visible !important; */
        }

        th,
        tr,
        td {
            border: 1px solid #ddd;
            padding: 5px;
            break-inside: avoid !important;
        }
    }


    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }
</style>

<center>
    <div style="width: 210mm !important;height: 297mm !important;">
        <div class="header">
            <div style="font-size:30px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:30px;">Invoice</div>
            <div style='display:flex;align-items:start !important;margin-left:10px;margin-right:10px;padding-top:10px;'>
                <div style="width:100% !important;margin-left: 10px !important;margin-right: 10px !important;">
                    <table style='width:100% !important;'>
                        <thead>
                            <tr>
                                <th rowspan="2" style="width: 25% !important;">
                                    <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" style="height: 80px;width: 180px;">
                                </th>
                                <th style="text-align: center; width: 50% !important;" colspan="2">
                                    <label style="font-size:16px;font-weight:700;color:black;"># INV-005003/04/2025-02</label>
                                </th>
                                <th style="text-align: center; width: 25% !important;">
                                    <label style="font-size:15px;font-weight:700;color:black;">
                                        <span>Partially Paid</span>
                                        <span>-</span>
                                        <span style="color:green;">Pay Invoice</span>
                                    </label>
                                </th>
                            </tr>
                            <tr>
                                <th style="text-align: center !important;width: 20% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Invoice Date</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:black;">06-Apr-2025</label>
                                    </div>
                                </th>
                                <th style="text-align: center !important;width: 20% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Due Date</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:red;">11-Apr-2025</label>
                                    </div>
                                </th>
                                <th style="text-align: center !important;width: 60% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Sale Agent</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:black;">Ananya D</label>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <div class="start_cont" style='text-align:left;display:flex; margin-top:10px;margin-left:20px;margin-right:20px;'>
            <div style="width: 50%; border: 1px solid #ccc; border-radius: 4px; padding: 20px;margin-right:30px;background-color:#e0f3f9;">
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Invoice By</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:600;color:black;">PhDiZone</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Church Road , Annanagar</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Madurai, Tamilnadu, India</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">presale@phdizone.com</label>
                </div>
                <div style="margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%;">
                        9944049888</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">GST Number</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">33AACCE2334E1ZA</label>
                </div>
            </div>
            <div style="width: 50%; border: 1px solid #ccc; border-radius: 4px; padding: 20px;background-color:#e0f3f9;">
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Invoice To</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Priya</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">1, Bharathiyar Street, Avaniyapuram</label>
                </div>
                <div style=" margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Madurai ,Tamilnadu, India</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">priya@gmail.com</label>
                </div>
                <div style="margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">
                        9876543210</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Currency Format</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">INR</label>
                </div>
            </div>
        </div>
        <div style="font-size:20px; font-weight:bold;color:black;margin-top:20px;text-align:left;margin-left:20px;margin-right:20px;">
            <label>Service Details</label>
        </div>
        <div style="margin-left:20px;margin-right:20px;margin-top:10px;">
            <table style="width:100%;border-collapse:collapse;border: 1px solid #ddd;padding:30px;">
                <thead style="font-weight:bold; font-size:16px;background-color:#1397c7;color:white;vertical-align:top !important;">
                    <tr>
                        <th style="width:5%;">S.No</th>
                        <th style="width:60%">Work</th>
                        <th style="width:5%">Qty</th>
                        <th style="width:15%">Rate</th>
                        <th style="width:15%">Amount</th>
                    </tr>
                </thead>
                <tbody style="vertical-align:top !important;">
                    <tr style="color:black">
                        <td style="text-align:center;">
                            <div>1</div>
                        </td>
                        <td>
                            <div>
                                <label>
                                    <div style="font-weight:bold">Writing Services</div>
                                    <div style="font-weight:600">Thesis Writing</div>
                                    <div style="font-weight:500">Scopue Q1/Q2 Research Paper
                                        <label>(Rs.50,000)</label>
                                    </div>
                                    <label style="font-weight:bold;margin-top:10px;">Add On Services</label>
                                    <div>
                                        <div>Literature Writing
                                            <label>(Rs.1,000)</label>
                                        </div>
                                        <div>Plagiarism Checking
                                            <label>(Rs.1,000)</label>
                                        </div>
                                        <div>Grammer Checking
                                            <label></label>
                                        </div>
                                        <div>Proof Reading
                                            <label></label>
                                        </div>
                                    </div>
                                    <div style="font-weight:bold;margin-top:10px;">Deliverables</div>
                                    <div style="display:block;">
                                        <span style="display:block;"></span>
                                        <span>
                                            1.Technical discussion<br>
                                            2.Flow of the work (Novelty and Data Set)<br>
                                            3.Source Code<br>
                                            4.Pseudo Code<br>
                                            5.Demo through Running video<br>
                                            6.Results As per client specification-As per the Description<br>
                                            7.Software Installation<br>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </td>
                        <td style="text-align:center;">
                            <div>1</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 52,000</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 52,000</div>
                        </td>
                    </tr>
                    <tr style="color:black;">
                        <td style="text-align:center;">
                            <div>2</div>
                        </td>
                        <td>
                            <div>
                                <label>
                                    <div style="font-weight:bold">Development Services</div>
                                    <div style="font-weight:600">Python Development</div>
                                    <div style="font-weight:500">Computer Science-
                                        BlockChain technology-ML/DL
                                        <label>(Rs.60,000)</label>
                                    </div>
                                    <label style="font-weight:bold;margin-top:10px;">Add On Services</label>
                                    <div>
                                        <div>Literature Writing
                                            <label>(Rs.1,000)</label>
                                        </div>
                                        <div>Plagiarism Checking
                                            <label>(Rs.1,000)</label>
                                        </div>
                                        <div>Grammer Checking
                                            <label></label>
                                        </div>
                                        <div>Proof Reading
                                            <label></label>
                                        </div>
                                    </div>
                                    <div style="font-weight:bold;margin-top:10px;">Deliverables</div>
                                    <div style="display:block;">
                                        <span style="display:block;"></span>
                                        <span>
                                            1.Technical discussion<br>
                                            2.Flow of the work (Novelty and Data Set)<br>
                                            3.Source Code<br>
                                            4.Pseudo Code<br>
                                            5.Demo through Running video<br>
                                            6.Results As per client specification-As per the Description<br>
                                            7.Software Installation<br>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </td>
                        <td style="text-align:center;">
                            <div>1</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 62,000</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 62,000</div>
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <thead>
                        <tr>
                            <th colspan="4" style="font-size:16px;color:black;text-align:end;font-weight:600;">Sub Total</th>
                            <th style="font-size:16px;color:black;text-align:end;font-weight:600;">&#8377; 1,14,000</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">Discount (10%)</th>
                            <th style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">&#8377; 11,400</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">GST (18%)</th>
                            <th style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">&#8377; 18,468</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:19px;color:black;text-align:end;font-weight:600;">Grand Total</th>
                            <th style="font-size:19px;color:black;text-align:end;font-weight:600;">&#8377; 1,21,068</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:17px;color:black;text-align:end;font-weight:600;">Total Paid</th>
                            <th style="font-size:17px;color:black;text-align:end;font-weight:600;">&#8377; 1,00,000</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:17px;color:#db4444;text-align:end;font-weight:600;">Amount Due</th>
                            <th style="font-size:17px;color:#db4444;text-align:end;font-weight:600;">&#8377; 21,068</th>
                        </tr>
                        <tr>
                            <th colspan="5" style="font-size:14px;color:#2c2c2c;text-align:start;font-weight:600;">
                                <label>Amount In Words &nbsp;:&nbsp;</label>
                                <label style="color:black">One Lakh Twenty One Thousand Sixty Eight Only</label>
                            </th>
                        </tr>
                    </thead>
                </tfoot>
            </table>
        </div>
        <div class="page-break-after" style="page-break-inside: avoid !important;">
            <div style="font-size:16px; font-weight:bold;color:black;margin-top:20px;text-align:left;margin-left:20px;margin-right:20px;">
                Transactions Details :
            </div>
            <div style="margin-left:20px;margin-right:20px;margin-top:10px;">
                <table style="width:100%;border-collapse:collapse;border: 1px solid #ddd;padding:10px;">
                    <thead style="font-weight:bold; font-size:14px;color:black;">
                        <tr>
                            <th style="width:25%;text-align:center;">Payment ID</th>
                            <th style="width:25%;text-align:center;">Payment Mode</th>
                            <th style="width:25%;text-align:center;">Date</th>
                            <th style="width:25%;text-align:center;">Amount</th>
                        </tr>
                    </thead>
                    <tr style="color:black;font-weight:600 !important;">
                        <td>
                            <div style="text-align:center;">5923</div>
                        </td>
                        <td>
                            <div style="text-align:center;">Cash</div>
                        </td>
                        <td>
                            <div style="text-align:center;">06-Apr-2025</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 50,000</div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="page-break" style="page-break-inside: avoid !important;">
            <div style="font-size:16px; font-weight:bold;color:black;margin-top:15px;text-align:left;margin-left:20px;margin-right:20px;">Offline Payment :
            </div>
            <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:40px;margin-right:20px;">
                <div style="font-size:14px; font-weight:600;color:black;margin-bottom:5px;">ELYSIUM TECHNOLOGIES PRIVATE LIMITED</div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">Bank</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 83% !important;font-weight:600;color:black;">TMB</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">Account No</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 83% !important;font-weight:600;color:black;">2027256000004</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">Branch</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 83% !important;font-weight:600;color:black;">Anna Nagar, Madurai, Tamilnadu, India</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">IFSC Code</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 83% !important;font-weight:600;color:black;">HDFC0002027</div>
                </div>
            </div>
        </div>
        <div class="page-break" style="width:100%;page-break-inside: avoid !important;">
            <div style="font-size:16px;font-weight:bold;color:black;margin-top:10px;text-align:left !important;margin-left:20px;margin-right:20px;">Note:
            </div>
            <div>
                <label style="font-size:14px;color:black;margin-top:5px;text-align:left;margin-left:20px;margin-right:20px;font-weight:500;">&emsp;&nbsp;This is computer generated invoice, signature not required. 100 % payment against delivery Cheques subject to realization Jurisdiction at Madurai</label>
            </div>
            <div style="font-size:16px; font-weight:bold;color:black;margin-top:10px;text-align:left !important;margin-left:20px;margin-right:20px;">Terms & Conditions:
            </div>
            <div style="font-size:14px; font-weight:500;color:black;margin-top:5px;text-align:left !important;margin-left:20px;margin-right:20px;">
                <ul>
                    <li>The payment is not refundable, Once registered</li>
                    <li>Only the registered candidates can communicate with the staff. Others should not be involved in the work</li>
                    <li>In case of modification, the request mail or report should be submitted on or before 15 days from delivery.</li>
                    <li>The requirements should be submitted as a document. Verbal conversation is not allowed for modification</li>
                    <li>Your work is a more confidential one. It won't be shared or discussed anybody else.</li>
                </ul>
            </div>
            <div style="margin-left:20px;margin-right:20px;margin-top:5px;float: right !important;">
                <img src="{{asset('assets/phdizone_images/signature.png')}}" alt="user-avatar" id="uploadedlogo" />
                <div style="display:block !important;font-size:16px;font-weight:600;color:black;margin-top:5px;margin-left:20px;margin-right:20px;">Authorized Signature</div>
            </div>
        </div>
    </div>
</center>
@endsection