@extends('layouts/blankLayout')

@section('title', 'View NDA')
@section('content')

<style>
    @page {
        size: A4;
        background: white !important;
    }

    @media print {
        .noprint {
            display: none;
        }

        #agr_butt {
            display: none !important;
        }

        .sign_box {
            border: 0px !important;
        }

        .sig_txt,
        button {
            display: none !important;
        }

        body {
            background: white !important;
        }

        .page-break {
            page-break-before: auto;
        }
    }

    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
        /* color: black; */
    }

    body {
        font-family: Arial, sans-serif;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
        background-color: #f0f0f0;
    }

    .signature-pad {
        background-color: #fff;
        margin: 50px;
        /* border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); */
        padding: 20px;
        text-align: center;
    }

    .signature-pad_1 {
        background-color: #fff;
        margin: 50px;
        /* border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); */
        padding: 20px;
        text-align: center;
    }

    #signatureCanvas {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    #signatureCanvas_1 {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    #signatureCanvas_2 {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    #signatureCanvas_all {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    .signature-pad-footer {
        margin-top: 10px;
    }

    button {
        padding: 5px 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        cursor: pointer;
        font-size: 16px;
    }

    button:hover {
        background-color: #0056b3;
    }

    button:active {
        background-color: #0056b3;
    }
</style>

<page size="A4">
    <center>
        <div style="width: 210mm !important;background-color:#ffffff !important;">
            <div class="header">
                <div style="font-size:18px; font-weight:bold;color:red;text-align:center;margin-left:30px;padding-top:30px;font-family:monospace;">
                    Privileged & Confidential
                </div>
            </div>
            <div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:10px;">
                    <label>6th April - 2025</label>
                </div>
                <div style="border-top:dashed 1px black;margin-top:60px;margin-right:160px;margin-left:160px;"></div>
                <div style="font-size:18px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:25px;"></div>
                <label style="font-weight:bold;color:black;">DELIVERY PARTNER AGREEMENT</label>
                <div style="border-top:dashed 1px black;margin-top:25px;margin-right:160px;margin-left:160px;"></div>
                <div style="font-size:15px; font-weight:400;color:black;text-align:center;margin-left:30px;padding-top:80px;">
                    <label>By and Amongst</label>
                </div>
                <div style="font-size:28px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:50px;">
                    <label>PhDiZone</label>
                </div>
                <div style="font-size:22px; font-weight:500;color:black;text-align:center;margin-left:30px;padding-top:10px;">
                    <label>[A part of Elysium Technologies Private Limited]</label>
                </div>
                <div style="font-size:20px; font-weight:500;color:black;text-align:center;margin-left:30px;padding-top:80px;">
                    <label>AND</label>
                </div>
                <div>
                    <label style="font-size:16px; font-weight:500;color:black;text-align:center;margin-left:30px;padding-top:80px;">Name</label>
                    <label>:</label>
                    <label style="font-size:24px; font-weight:bold;color:black;text-align:center;padding-top:80px;">Ms.Priya</label>
                </div>
                <div style="padding-top:12px;">
                    <label style="font-size:16px; font-weight:500;color:black;text-align:center;margin-left:30px;">Mail</label>
                    <label>:</label>
                    <label style="font-size:16px; font-weight:bold;color:black;text-align:center;">
                        <a href="mailto:priya@gmail.com">priya@gmail.com</a></label>
                </div>
                <div style="padding-top:12px;">
                    <label style="font-size:16px; font-weight:500;color:black;text-align:center;margin-left:30px;">NDA ID</label>
                    <label>:</label>
                    <label style="font-size:16px; font-weight:bold;color:black;text-align:center;">GC/IZONE/2024/02346/03616</label>
                </div>
                <div style="margin-top:100px;border:solid black;border-width:0.5px;margin-right:120px;margin-left:120px;"></div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;">
                <div style="padding-top:100px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<span>PhDiZone, a part of Elysium Technologies private Limited</span> company incorporated under the laws of Indian government, having its registered office at <span>No. 230, Church road, Anna nagar, Madurai – 625020, Tamil Nadu, India</span> (Here in after called the “iZone”) and which term shall unless excluded by or repugnant to the context mean and includes its heirs, successors, administrators, etc. acting through its authorized signatory <span>Mrs. Muthumari A</span> of the FIRST PART;</p>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:center;margin-left:30px;">
                    <label>AND</label>
                </div>
                <div style="margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<span>Ms.Priya </span>an individual/partnership under the laws of Indian government, having its registered office/residence at <span>1, Bharathiyar Street, Avaniyapuram, Madurai, Tamilnadu, India.</span> (Here in after called the “iClient”) and which term shall unless excluded by or repugnant to the context mean and include its heirs, successors, administrators etc. acting through as authorized signatory, <span>Ms.Priya</span> duly authorized as the SECOND PART</p>
                </div>
                <div style="font-size:18px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>WHEREAS</label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <ul>
                        <li>iClient is engaged in getting service from iZone for their research assistance</li>
                        <li>iZone carries on the business of providing the Services and has necessary manpower,
                            resources, and expertise to provide the Services; and</li>
                    </ul>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>NOW THEREFORE THIS AGREEMENT WITNESSETH as follows:</label>
                </div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>1.<span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">PURPOSE</span></label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <label>&emsp;&emsp;&emsp;&emsp;
                        Purpose of this Agreement is to set forth the terms and conditions under
                        which the “iZone”and“iClient” mentioned in Annexure A.
                    </label>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>2.<span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">SCOPE</span></label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <label>&emsp;&emsp;&emsp;&emsp;
                        This agreement applies to the Services mentioned in Annexure A.
                    </label>
                </div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>3.<span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">TERMS OF AGREEMENT</span></label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <label>&emsp;&emsp;&emsp;&emsp;
                        This agreement applies to the Services mentioned in Annexure A.
                    </label>
                </div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>a.<span style="padding-left:10px;">Confidentiality:</span></label>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;Confidential information provided under the Service Agreement must be treated as
                        confidential by the “iClient” and “iZone”
                        Parties shall treat any data and information, whether written, oral or visual, disclosed to it
                        or which comes into its possession or knowledge in connection with this Agreement as
                        confidential and shall not disclose the same to any others - except as may be required by
                        law or as may be required to be disclosed on a "Need-to-Know" basis for implementing
                        this Agreement.</p>
                </div>
                <div style="display:flex;align-items:center !important;justify-content:end !important;margin-right:100px;margin-top:25px;margin-bottom:25px;">
                    <img src="{{asset('assets/phdizone_images/priya_sign.png')}}" style="height: 50px;width: 125px;">
                </div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;">
                <div style="padding-top:100px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;If Parties has access to the other Party’s confidential information, the party who has been
                        given access to the confidential information will not disclose it to a third party without
                        the prior written consent of the other Party, unless:</p>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <ul>
                        <li>The disclosure of the confidential information is required by law or by the Service
                            Agreement; or</li>
                        <li>The disclosure is reasonably required by any person performing their obligations under
                            the Service Agreement; or</li>
                        <li>The disclosure is to a party's own professional advisers or its insurer; or</li>
                        <li>If the disclosure of the information is requested by the Auditor-General, the
                            Ombudsman, or the Minister responsible for the portfolio under which the service
                            operate.</li>
                    </ul>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">Subject to the above, each party to the Service Agreement will ensure that any third party
                        to which it discloses confidential information is made aware of the confidential nature of
                        that information.</p>
                </div>
                <div style="padding-top:5px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">iZone will use information regarding this Agreement only in the performance of this
                        Agreement the same applies to clients as well.</p>
                </div>
                <div style="padding-top:5px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">All written and oral information and material disclosed or provided by the “iClient” to
                        the “iZone” under this Agreement are Confidential Information regardless of whether it
                        was provided before or after the date of this Agreement or how it was provided to the
                        Company.</p>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>b.<span style="padding-left:10px;">Confidentiality:</span></label>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<b>Relationship & Non-Exclusivity: </b>Nothing contained in this Agreement is
                        intended to create, nor shall it be construed to create, a relationship between the Parties
                        other than that of two independent Parties contracting with each other solely for the
                        purpose of effectuating the provision of this Agreement.</p>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<b>Term and Termination: </b>This Agreement shall commence on the Effective Date
                        and shall continue in force for a period of <b><span>(120 days) </span>(As per estimate and invoice)</b>
                        unless terminated in accordance with the terms of this Agreement. Any renewal or
                        extension shall be subject to the written agreement of both Parties.</p>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>c.<span style="padding-left:10px;">General:</span></label>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>i.</span>Entire Agreement: </b>Nothing contained in this Agreement is
                        intended to create, nor shall it be construed to create, a relationship between the Parties
                        other than that of two independent Parties contracting with each other solely for the
                        purpose of effectuating the provision of this Agreement.</p>
                    <!-- <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>ii.</span>Amendments: </b>This agreement is effective as of the date of signature by all authorized
                    representatives indicated below and shall last until terminated in accordance with the
                    specific Party requirements described herein. The Agreement may be amended by
                    mutual agreement of the Parties. Either Party may terminate this agreement upon thirty
                    (30) days written notice to the other Party in accordance with the above terms, after first
                    pursuing a good faith effort to resolve any issues prompting termination.</p> -->
                </div>
                <div style="display:flex;align-items:center !important;justify-content:end !important;margin-right:100px;margin-top:25px;margin-bottom:25px;">
                    <img src="{{asset('assets/phdizone_images/priya_sign.png')}}" style="height: 50px;width: 125px;">
                </div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;">
                <div style="padding-top:100px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>ii.</span>Amendments: </b>This agreement is effective as of the date of signature by all authorized
                        representatives indicated below and shall last until terminated in accordance with the
                        specific Party requirements described herein. The Agreement may be amended by
                        mutual agreement of the Parties. Either Party may terminate this agreement upon thirty
                        (30) days written notice to the other Party in accordance with the above terms, after first
                        pursuing a good faith effort to resolve any issues prompting termination.</p>
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>iii.</span>Notices and Communications: </b>Any notice, consent or approval required or permitted
                        to be given in connection with this Agreement (in this Section referred to as a “Notice”)
                        must be in writing and is sufficiently given if delivered (whether in person, by email or
                        other personal method of delivery). Social Media acknowledgement is not acceptable.</p>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>iii.</span>Dispute Resolution: </b></p>
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:5px;">
                            Any and all claims, disputes, questions or controversies involving the Parties and
                            arising out of or in connection with this Agreement, or the execution, interpretation,
                            validity, performance, breach or termination hereof (collectively, “Dispute(s)”) that
                            cannot be finally resolved by the Parties within thirty (30) calendar days of the arising
                            of a Dispute by amicable negotiation and conciliation shall first be submitted for
                            settlement by informal arbitration to an arbitral panel consisting of the senior authorities.
                    </p>
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:5px;">
                            Arbitration - Any dispute which is not settled pursuant to Article 37(A) shall be
                            referred to a panel of arbitrators consisting of one arbitrator appointed by the petitioner
                            in party or parties, as the case may be, one arbitrator appointed by the respondent party
                            or respondent parties as the case may be and both the arbitrators shall appoint the
                            presiding arbitrator and the arbitration shall be conducted in accordance with the Indian
                            Arbitration and Conciliation Act, 1996 as amended from time to time. The venue of
                            Arbitration shall be <i>Madurai, Tamil Nadu, India.</i>
                    </p>
                </div>
                <div style='display:flex;margin-left:10px;padding-right:30px;padding-left:30px;margin-top:30px;'>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:500;">For the above <b>iZone</b> through its duly
                            authorized signatory</label>
                    </div>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:500;">For the <b>iClient</b> through its duly
                            authorized signatory</label>
                    </div>
                </div>
                <div style='display:flex;margin-left:10px;padding-right:30px;padding-left:30px;margin-top:30px;'>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">Mrs. Muthumari A</label>
                    </div>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">Ms. Priya</label>
                    </div>
                </div>
                <div style='display:flex;margin-left:10px;padding-right:30px;padding-left:30px;margin-top:10px;'>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            Date :</label>
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            06-Apr-2025</label>
                    </div>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            Date :</label>
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            06-Apr-2025</label>
                    </div>
                </div>
                <div style="display:flex;align-items:center !important;justify-content:end !important;margin-right:100px;margin-top:25px;margin-bottom:25px;">
                    <img src="{{asset('assets/phdizone_images/priya_sign.png')}}" style="height: 50px;width: 125px;">
                </div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;padding-bottom:20px;">
                <div Style="padding-top:80px">
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:20px;">
                        <label><span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">Scope of The Agreement</span></label>
                    </div>
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                        <label><span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">Providing Research Guidance on Appointment Basis</span></label>
                    </div>
                    <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                        <p style="text-align:justify;margin-left:10px;"><b>Background: </b>Experience and Skill Trained People for providing service to the client by
                            technical, reference, development and through document creation.</p>
                        <p style="text-align:justify;margin-left:10px;"><b>PhDiZone Solution: </b>PhDiZone is one of the leading research guidance providers all over
                            the world providing through Technology, Scholars opinion and Ideas. <b>Payments for
                                service will be confirmed through email only</b></p>
                    </div>
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;margin-right:50px;padding-top:10px;">
                        <label><span style="padding-left:10px;">Responsibilities of iClient</span></label>
                    </div>
                    <div style="font-size:14px; font-weight:500;color:black;text-align:left;margin-left:50px;margin-right:50px;padding-top:10px;">
                        <ol>
                            <li>Register with iZone.</li>
                            <li>Confirm all their requirements and through email only</li>
                            <li>No personal information neither iZone staff nor yourself will not be acceptable</li>
                            <li>Required documents must be provided to iZone only to the email provided for
                                communication & SPOC (Single Point of Contact).</li>
                            <li>Every Step of service and payment to be acknowledged</li>
                            <li>All payments in the favor of Elysium Technologies Private Limited only</li>
                            <li>Only registered iClient has rights to fix appointments for communication getting prior
                                approval from the business team.</li>
                            <li>Acknowledgment must be reverted back in a maximum of 15-20days.</li>
                            <li>Follow the terms & conditions of iZone. Duration of service is only dependent on your
                                acknowledgement through email.</li>
                        </ol>
                    </div>
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;margin-right:50px;padding-top:10px;">
                        <label><span style="padding-left:10px;">Responsibilities of PhDiZone</span></label>
                    </div>
                    <div style="font-size:14px; font-weight:500;color:black;text-align:left;margin-left:50px;margin-right:50px;padding-top:10px;">
                        <ol>
                            <li>Provide. Support through digital platforms or in person for supporting demand for
                                guidance.</li>
                            <li>Provide. Explanation of guidance document.</li>
                            <li>Provide. Source code and related documents after acknowledgement and NOC (No
                                Objection Certificate).</li>
                            <li>Provide NOC (No Objection Certificate) based on acknowledgement and payments.</li>
                            <li>Provide. SPOC (Single point of contact for communication).</li>
                            <li>Once acknowledged by iClient the paid money will not be returned back.</li>
                            <li>Update of the work will be provided as accepted through email by both parties.</li>
                            <li>Appointment Confirmation only provided by iZone.</li>
                            <li>No. of Reviews/correction and changes will be accepted only through email only.</li>
                            <li>iZone will not disclose your personal information/technical details of your work
                                without acceptance of written format to any third party.</li>
                        </ol>
                    </div>
                    <div style="display:flex;align-items:center !important;justify-content:end !important;margin-right:100px;margin-top:25px;margin-bottom:25px;">
                        <img src="{{asset('assets/phdizone_images/priya_sign.png')}}" style="height: 50px;width: 125px;">
                    </div>
                </div>
            </div>
        </div>
    </center>
</page>

@endsection