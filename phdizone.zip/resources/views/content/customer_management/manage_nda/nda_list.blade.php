@extends('layouts/layoutMaster')

@section('title', 'Manage NDA')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/toastr/toastr.scss',
'resources/assets/vendor/libs/animate-css/animate.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/clipboard/clipboard.js',
'resources/assets/vendor/libs/toastr/toastr.js'
])
@endsection

@section('page-script')
@endsection
@section('content')

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage NDA</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 py-0">
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">NDA No</th>
                            <th class="min-w-80px">NDA Date</th>
                            <th class="min-w-100px">Customer</th>
                            <th class="min-w-100px">Address</th>
                            <th class="min-w-100px">NDA Link</th>
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        <tr>
                            <td>
                                <label class="fs-7">GC/IZONE/2024/02346/03616</label>
                                <div class="d-block">
                                    <label class="badge bg-info text-white fs-8 fw-semibold">NDA Shared</label>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7">06-Apr-2025</label>
                            </td>
                            <td>
                                <label class="fs-7">Priya</label>
                                <div class="d-block">
                                    <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">priya@gmail.com</label>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7 text-wrap max-w-300px">1, Bharathiyar Street, Avaniyapuram, Madurai, Tamilnadu, India</label>
                            </td>
                            <td>
                                <label class="text-info fs-7 fw-bold me-1">Link is here</label>
                                <input type="hidden" id="coup_code_val_td_1" value="http://192.168.3.88:3000/manage_nda/nda_add" />
                                <a href="javascript:;" class="cpy-btn btn btn-sm btn-label-primary px-2 py-1" data-clipboard-action="copy" data-clipboard-target="#coup_code_val_td_1">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Copy"><i class="mdi mdi-content-copy fs-6 text-black"></i></span>
                                </a>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/manage_nda/nda_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="javascript:;" class="dropdown-item" onclick="print_nda('prt_nda');">
                                            <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Print</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label class="fs-7">GC/IZONE/2024/02346/03613</label>
                                <div class="d-block">
                                    <label class="badge bg-success text-black fs-8 fw-semibold">NDA Signed</label>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7">28-Mar-2025</label>
                            </td>
                            <td>
                                <label class="fs-7">Kavi Priya</label>
                                <div class="d-block">
                                    <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">kavipriya@gmail.com</label>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7 text-wrap max-w-300px">45A, Sannathi Street, Koripalayam, Madurai, Tamilnadu, India</label>
                            </td>
                            <td>
                                <label class="text-info fs-7 fw-bold me-1">Link is here</label>
                                <input type="hidden" id="coup_code_val_td_2" value="http://192.168.3.88:3000/manage_nda/nda_add" />
                                <a href="javascript:;" class="cpy-btn btn btn-sm btn-label-primary px-2 py-1" data-clipboard-action="copy" data-clipboard-target="#coup_code_val_td_2">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Copy"><i class="mdi mdi-content-copy fs-6 text-black"></i></span>
                                </a>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/manage_nda/nda_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/manage_nda/nda_print')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Print</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const clipboardList = [].slice.call(document.querySelectorAll('.cpy-btn'));

        if (ClipboardJS) {
            clipboardList.map(function(clipboardEl) {
                const clipboard = new ClipboardJS(clipboardEl);
                clipboard.on('success', function(e) {
                    if (e.action == 'copy') {
                        toastr['success']('', 'Copied to Clipboard!!');
                    }
                });
            });
        } else {
            clipboardList.map(function(clipboardEl) {
                clipboardEl.setAttribute('disabled', true);
            });
        }
    });
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

@endsection