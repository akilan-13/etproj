@extends('layouts/layoutMaster')

@section('title', 'Update Quotation')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- Users List Table -->

<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Quotation</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Lead Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Quotation</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Estimated No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Estimated No" value="EST-003669/07/2024" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Estimated Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" value="12-JUL-2024" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Validity Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_validity" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" value="20-JUL-2024" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Estimated Status<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Estimated Status</option>
                            <option value="1" selected>Accepted</option>
                            <option value="2">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Sales<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Sales Person</option>
                            <option value="1" selected>Sabana Barveen</option>
                            <option value="2">Mithra</option>
                            <option value="2">Salini </option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Email ID" value="priya@gmail.com" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Phone No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Phone No" value="9876543210" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Country</option>
                            <option value="1">Afghanistan</option>
                            <option value="2">Bolivia</option>
                            <option value="3">Canada</option>
                            <option value="4" selected>India</option>
                            <option value="5">Japan</option>
                            <option value="6">Kuwait</option>
                            <option value="7">Libya</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select State</option>
                            <option value="1">Andhra Pradesh</option>
                            <option value="2">Goa</option>
                            <option value="3">Karnataka</option>
                            <option value="4">Kerala</option>
                            <option value="5" selected>Tamil Nadu</option>
                            <option value="6">Telangana</option>
                            <option value="7">Uttarakhand</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select City</option>
                            <option value="1">Chennai</option>
                            <option value="2">Vellore</option>
                            <option value="3">Salem</option>
                            <option value="4">Tirunelveli</option>
                            <option value="5" selected>Madurai</option>
                            <option value="6">Dindigul</option>
                            <option value="7">Sivakasi</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Area / Street" value="1, Bharathiyar Street, Avaniyapuram" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Door No / Flat No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Door No / Flat No" value="1" />
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-12">
                            <h4 class="card-title mb-1 fw-bold">Service Details</h4>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
                            <select id="ser_cat" class="select3 form-select">
                                <option value="">Select Service Category</option>
                                <option value="1">Reasearch Services</option>
                                <option value="2">PHD Services</option>
                                <option value="3">Writing Services</option>
                                <option value="4" selected>Development Services</option>
                                <option value="5">Analysis Services</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
                            <select id="ser_sub_cat" class="select3 form-select">
                                <option value="">Select Service Sub Category</option>
                                <option value="1">Research Paper Writing Service </option>
                                <option value="2">Book Writing Service</option>
                                <option value="3">Scopus Indexed Journal </option>
                                <option value="4" selected>Python Development </option>
                                <option value="5">SPSS Analysis</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
                            <select id="duration" class="select3 form-select" data-style="btn-default" data-live-search="true">
                                <option value="">Select Duration</option>
                                <option value="1">3 - 5 Days</option>
                                <option value="2">5 - 7 Days</option>
                                <option value="3">7 - 9 Days</option>
                                <option value="4">10 - 15 Days</option>
                                <option value="5" selected>15 - 20 Days</option>
                                <option value="6">20 - 25 Days</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description<span class="text-danger">*</span><span class="mdi mdi-information-slab-circle" data-bs-toggle="tooltip" data-bs-placement="right" title="Enter Project Title and Information"></span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter Description" />
                        </div>
                        <div class="col-lg-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                            <select id="currency_format" class="select3 form-select" data-style="btn-default" data-live-search="true">
                                <option value="">Select Currency Format</option>
                                <option value="1">USD</option>
                                <option value="2">EUR</option>
                                <option value="3">GBP</option>
                                <option value="4">AUD</option>
                                <option value="5">INR</option>
                                <option value="6">KWD</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 d-flex align-items-center">
                        <div class="form-check form-check-inline mt-4">
                            <input class="form-check-input" type="checkbox" type="checkbox" id="add_on" name="add_on" checked onclick="edit_add_on_func();" />
                            <label class="text-black mb-1 fs-5 fw-semibold">Add On Services</label>
                        </div>
                    </div>
                </div>
                <div class="row mt-4" id="edit_view_add_on" name="edit_view_add_on">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-xl-6 mb-2">
                                <div class="card">
                                    <a class="card-body max-h-500px scroll-y">
                                        <div class="row">
                                            <div class="col-12 text-end">
                                                <label class="badge bg-info rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Free</label>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="edit_add_on_chk_all" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" checked />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" checked />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input edit_add_on_ver_chk" type="checkbox" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="card">
                                    <a class="card-body max-h-500px scroll-y">
                                        <div class="row">
                                            <div class="col-12 text-end">
                                                <label class="badge bg-success text-black fw-bold rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Paid</label>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="checkbox" id="edit_add_on_chk_all_paid" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="row">
                                                            <div class="col-lg-7">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input  edit_add_on_ver_chk_paid" type="checkbox" />
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-7">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input edit_add_on_ver_chk_paid" type="checkbox" />
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-7">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input edit_add_on_ver_chk_paid" type="checkbox" checked />
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-7">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input edit_add_on_ver_chk_paid" type="checkbox" checked />
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <h4 class="card-title mb-1 fw-bold">Payment Details</h4>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Enter Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter Amount" readonly value="62,000" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Add-On-Service Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Add-On-Service Amount" readonly value="1500" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Sub Total Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Sub Total Amount" readonly value="70,000" />
                        </div>
                        <div class="col-lg-2 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Enter GST(%)<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter GST" value="12" />
                        </div>
                        <div class="col-lg-2 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">GST Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter GST" value="10,000" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Total Amount<span class="text-danger">*</span></label>
                            <input type="text" class="form-control me-2" id="" placeholder="Total Amount" value="80,000" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                            <select id="payment_slot" name="payment_slot" class="select3 form-select" onchange="payment_slot_func();">
                                <option value="">Select Payment Slot</option>
                                <option value="single">Single</option>
                                <option value="dual" selected>Dual</option>
                                <option value="triple">Trible</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-12 mb-4">
                        <div class="card-action">
                            <div class="card-header bg-gray-300">
                                <div class="card-action-title">
                                    <div class="row w-100">
                                        <label class="col-lg-12 text-black fs-6 fw-bold">Work Details</label>
                                    </div>
                                </div>
                                <div class="card-action-element">
                                    <ul class="list-inline mb-0">
                                        <li class="list-inline-item">
                                            <a href="javascript:;" class="quotation_payment_acrd"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="collapse quotation_payment_acrd_body border">
                            <div class="card-body">
                                <div class="row">
                                    <div class="row mt-2" style="display:none;" id="view_single_payment_slot">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I"></textarea>
                                                </div>

                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-2" id="view_double_payment_slot">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I">To start the work</textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables">1.Technical discussion  2.Flow of the work (Novelty and Data Set)
                                                </textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note">1.Once you acknowledge the flow only, we will move on
                                                otherwise,updated flow will be shared.</textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot II<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I">(After taking the Demo)(Before taking the Delivery of Code)</textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables">1.Source Code 2.Pseudo Code 3.Demo through Running video 4.Results As per client specification-As per the Description 5.Software Installation
                                                </textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note">1.Each and every step will be acknowledged by you 2.Every Section and Module of the Coding part will be clearly explained in the Google meet.Entire Technical Knowledge will be given to you,until the client understands the concept 3.As per the acknowledged description.We will be work on it.
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-2" style="display:none;" id="view_triple_payment_slot">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot II<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot II"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Slot III<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Slot III"></textarea>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-lg-4">
                                <div class="row">
                                    <label class="text-dark fs-6 fw-semibold mb-2">Authorised Signature<span class="text-danger">*</span></label>
                                    <div class="col-lg-6">
                                        <div class="align-items-sm-center gap-4">
                                            <img src="{{asset('assets/phdizone_images/phdizone_icon.png')}}" alt="user-avatar" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="update_uploadedsignature" />
                                            <div class="button-wrapper">
                                                <div class="d-flex align-items-start mt-2 mb-2">
                                                    <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Signature Logo">
                                                        <i class="mdi mdi-tray-arrow-up"></i>
                                                        <input type="file" id="upload" class="file-in" hidden accept="image/png, image/jpeg" />
                                                    </label>
                                                    <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Signature Logo">
                                                        <i class="mdi mdi-reload"></i>
                                                    </button>
                                                </div>
                                                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <button type="reset" class="btn btn-outline-secondary me-2">Cancel</button>
                <a href="/manage_proposal" class="btn btn-primary me-3">
                    Update
                </a>
            </div>
        </div>
    </div>
    <!--Quotation Payment Accordion Start-->
    <script>
        'use strict';

        (function() {
            const quotation_payment_acrd = [].slice.call(document.querySelectorAll('.quotation_payment_acrd'));

            // Collapsible card
            // --------------------------------------------------------------------
            if (quotation_payment_acrd) {
                quotation_payment_acrd.map(function(quotation_payment_acrd_Element) {
                    quotation_payment_acrd_Element.addEventListener('click', event => {
                        event.preventDefault();
                        // Collapse the element
                        new bootstrap.Collapse(quotation_payment_acrd_Element.closest('.card').querySelector('.collapse.quotation_payment_acrd_body'));
                        // Toggle collapsed class in `.card-header` element
                        quotation_payment_acrd_Element.closest('.card-header').classList.toggle('collapsed');
                        // Toggle class mdi-chevron-down & mdi-chevron-up
                        Helpers._toggleClass(quotation_payment_acrd_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                    });
                });
            }

        })();
    </script>
    <!--Quotation Payment Accordion End-->
    <script>
        function edit_add_on_func() {
            var add_on = document.getElementById("add_on");
            var edit_view_add_on = document.getElementById("edit_view_add_on");

            if (add_on.checked) {
                edit_view_add_on.style.display = "block";
            } else {
                edit_view_add_on.style.display = "none";
            }
        }
    </script>

    <script>
        $('#edit_add_on_chk_all').change(function() {
            $('.edit_add_on_ver_chk').prop('checked', this.checked);
        });

        $('.edit_add_on_ver_chk').change(function() {
            if ($('.edit_add_on_ver_chk:checked').length == $('.edit_add_on_ver_chk').length) {
                $('#edit_add_on_chk_all').prop('checked', true);
            } else {
                $('#edit_add_on_chk_all').prop('checked', false);
            }

        });
    </script>

    <script>
        $('#edit_add_on_chk_all_paid').change(function() {
            $('.edit_add_on_ver_chk_paid').prop('checked', this.checked);
        });

        $('.edit_add_on_ver_chk_paid').change(function() {
            if ($('.edit_add_on_ver_chk_paid:checked').length == $('.edit_add_on_ver_chk_paid').length) {
                $('#edit_add_on_chk_all_paid').prop('checked', true);
            } else {
                $('#edit_add_on_chk_all_paid').prop('checked', false);
            }

        });
    </script>
    <script>
        function payment_slot_func() {
            var payment_slot = document.getElementById("payment_slot").value;
            var single = document.getElementById("single");
            var dual = document.getElementById("dual");
            var triple = document.getElementById("triple");

            if (payment_slot == "single") {
                view_single_payment_slot.style.display = "block";
                view_double_payment_slot.style.display = "none";
                view_triple_payment_slot.style.display = "none";
            } else if (payment_slot == "dual") {
                view_double_payment_slot.style.display = "block";
                view_single_payment_slot.style.display = "none";
                view_triple_payment_slot.style.display = "none";
            } else if (payment_slot == "triple") {
                view_triple_payment_slot.style.display = "block";
                view_single_payment_slot.style.display = "none";
                view_double_payment_slot.style.display = "none";
            } else {

            }
        }
    </script>

    <script>
        let logofile = document.getElementById('update_uploadedsignature');
        const fileInput = document.querySelector('.file-in'),
            resetFileInput = document.querySelector('.file-reset');

        if (logofile) {
            const resetImage = logofile.src;
            fileInput.onchange = () => {
                if (fileInput.files[0]) {
                    logofile.src = window.URL.createObjectURL(fileInput.files[0]);
                }
            };
            resetFileInput.onclick = () => {
                fileInput.value = '';
                logofile.src = resetImage;
            };
        }
    </script>


    @endsection