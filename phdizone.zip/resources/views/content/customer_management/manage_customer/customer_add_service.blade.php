@extends('layouts/layoutMaster')

@section('title', 'Add Service')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss'

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
'resources/assets/vendor/libs/dropzone/dropzone.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/form-wizard-icons.js')
@endsection
@section('content')

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="bs-stepper wizard-icons wizard-icons-example">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Add Service</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex align-items-center ms-4 mt-2">
            <label class="fs-3 fw-bold text-black me-1">Priya Dharshini</label>
            <label class="text-dark fs-6 fw-bold"> - </label>
            <label class="text-dark fs-6 fw-bold" title="Customer ID"> [ CUS-0003/24 ]</label>
        </div>
        <div class="bs-stepper-header">
            <!-- <div class="step" data-target="#basic-info">
                <button type="button" class="step-trigger">
                    <span>
                        <svg height="50px" width="50px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 392.517 392.517" xml:space="preserve" fill="#000000" stroke="#000000" stroke-width="0.00392517">
                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" stroke="#CCCCCC" stroke-width="4.710203999999999"></g>
                            <g id="SVGRepo_iconCarrier">
                                <path style="fill:#000000;" d="M70.359,147.507c6.012,0,10.925-4.848,10.925-10.925V71.03l22.885,8.145v72.081 c0,6.012,4.848,10.925,10.925,10.925h1.099c5.301,39.564,39.24,70.141,80.226,70.141s74.861-30.578,80.226-70.141h0.84 c6.012,0,10.925-4.848,10.925-10.925V79.176l37.495-13.317c10.214-3.879,9.051-17.907,0-20.558L199.846,0.63 c-2.392-0.84-4.913-0.84-7.24,0L66.739,45.301c-4.331,1.552-7.24,5.624-7.24,10.279v80.873 C59.434,142.594,64.283,147.507,70.359,147.507z M196.291,210.537c-28.897,0-53.01-20.881-58.182-48.291h116.364 C249.365,189.657,225.252,210.537,196.291,210.537z M266.432,140.396H125.955V86.933l66.586,23.661c2.392,0.84,4.848,0.84,7.24,0 l66.586-23.661v53.463H266.432z M196.226,22.545l93.285,33.099l-93.285,33.099l-93.285-33.099L196.226,22.545z"></path>
                                <path style="fill:#FFFFFF;" d="M138.109,162.246c5.107,27.41,29.22,48.291,58.182,48.291c28.897,0,53.01-20.881,58.182-48.291 H138.109z"></path>
                                <g>
                                    <path style="fill:#56ACE0;" d="M192.606,110.529L126.02,86.869v53.463h140.541V86.869l-66.715,23.661 C197.454,111.37,194.998,111.37,192.606,110.529z"></path>
                                    <polygon style="fill:#56ACE0;" points="102.941,55.58 196.226,88.743 289.511,55.58 196.226,22.545 "></polygon>
                                </g>
                                <path style="fill:#FFC10D;" d="M313.43,370.796c7.046-0.129,11.055-5.56,10.925-10.796v-33.358c0-8.016-4.461-15.451-11.766-19.394 c-35.556-19.265-75.83-29.737-116.428-30.513c-40.21,0.776-80.42,11.378-115.976,30.513c-7.24,3.943-11.766,11.378-11.766,19.394 v33.228c0,6.012,4.848,10.925,10.925,10.925"></path>
                                <path style="fill:#000000;" d="M322.868,287.984c-38.659-20.881-82.295-32.323-126.836-33.164 c-44.024,0.84-87.725,12.283-126.319,33.164c-14.287,7.758-23.273,22.497-23.273,38.529v33.293 c0,18.036,14.675,32.711,32.711,32.711h234.214c17.842,0,32.711-14.352,32.711-32.711v-33.293 C346.141,310.545,337.22,295.677,322.868,287.984z M324.355,359.871c0.129,5.301-3.879,10.667-10.925,10.796h-24.954v-17.519 c0-6.012-4.848-10.925-10.925-10.925c-6.077,0-10.99,4.848-10.99,10.925v17.648H125.955v-17.648c0-6.012-4.848-10.925-10.925-10.925 c-6.077,0-10.925,4.848-10.925,10.925v17.648H79.151c-6.012,0-10.925-4.848-10.925-10.925v-33.293 c0-8.016,4.461-15.451,11.766-19.394c35.556-19.265,75.83-29.737,115.976-30.513c40.663,0.776,80.873,11.378,116.428,30.513 c7.24,3.943,11.766,11.378,11.766,19.394v33.293H324.355z"></path>
                            </g>
                        </svg>
                    </span>
                    <span class="pt-2 bs-stepper-label text-black fw-bold">Basic Info</span>
                </button>
            </div>
            <div class="line">
                <i class="mdi mdi-arrow-right-thin fs-2"></i>
            </div> -->
            <div class="step" data-target="#service_info">
                <button type="button" class="step-trigger">
                    <span class="bs-stepper-icon">
                        <svg height="220px" width="220px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 392.598 392.598" xml:space="preserve" fill="#000000">
                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                            <g id="SVGRepo_iconCarrier">
                                <path style="fill:#FFFFFF;" d="M45.156,256.453c0-6.012,4.848-10.925,10.925-10.925s10.925,4.848,10.925,10.925v8.857h16.356v-8.857 c0-6.012,4.848-10.925,10.925-10.925c6.012,0,10.925,4.848,10.925,10.925v8.857h200.857c-9.891-6.206-18.941-13.511-27.022-21.786 H43.733V124.38h21.333c6.012,0,10.925-4.848,10.925-10.925c0-6.012-4.848-10.925-10.925-10.925H43.733V80.226h43.184 c6.012,0,10.925-4.848,10.925-10.925c0-6.012-4.848-10.925-10.925-10.925H43.604V43.442h235.378 c8.145-8.275,17.131-15.58,27.022-21.786H32.743c-6.012,0-10.925,4.848-10.925,10.925v221.867c0,6.012,4.848,10.925,10.925,10.925 h12.412V256.453z"></path>
                                <path style="fill:#f47507;" d="M43.604,58.505h43.184c6.012,0,10.925,4.848,10.925,10.925c0,6.012-4.848,10.925-10.925,10.925 H43.604v22.303h21.333c6.012,0,10.925,4.848,10.925,10.925c0,6.012-4.784,10.925-10.796,10.925H43.604v119.143h235.378 c-25.212-25.859-40.727-61.091-40.727-100.008S253.77,69.56,278.982,43.636H43.604V58.505z"></path>
                                <g>
                                    <path style="fill:#FFFFFF;" d="M370.715,24.178c-11.766,4.719-22.432,17.002-30.772,34.069c9.503-4.655,19.846-7.822,30.772-9.051 V24.178z"></path>
                                    <path style="fill:#FFFFFF;" d="M340.008,228.978c8.275,17.067,18.941,29.285,30.772,34.004v-24.954 C359.79,236.735,349.511,233.568,340.008,228.978z"></path>
                                    <path style="fill:#FFFFFF;" d="M292.428,61.026c7.046,1.422,14.158,2.651,21.269,3.62c4.267-11.507,9.374-21.786,15.192-30.578 C315.055,40.727,302.772,49.907,292.428,61.026z"></path>
                                    <path style="fill:#FFFFFF;" d="M287.321,154.44h-26.764c1.616,18.941,7.758,36.525,17.067,51.911 c9.438-2.069,18.941-3.879,28.444-5.301C295.984,187.863,289.261,171.83,287.321,154.44z"></path>
                                    <path style="fill:#FFFFFF;" d="M292.04,225.681c10.343,11.313,22.885,20.622,36.784,27.345 c-5.947-8.986-11.055-19.394-15.321-31.095C306.263,223.03,299.152,224.323,292.04,225.681z"></path>
                                    <path style="fill:#FFFFFF;" d="M306.392,85.592c-9.568-1.487-19.071-3.232-28.509-5.301c-9.503,15.515-15.58,33.293-17.39,52.364 h26.764C289.261,115.071,296.113,98.909,306.392,85.592z"></path>
                                </g>
                                <g>
                                    <path style="fill:#56ACE0;" d="M370.78,91.345c-13.899-0.323-27.798-1.228-41.632-2.715c-3.426,13.511-5.624,28.444-6.4,44.024 h48.032V91.345L370.78,91.345z"></path>
                                    <path style="fill:#56ACE0;" d="M328.954,197.947c13.899-1.487,27.798-2.392,41.826-2.715V154.44h-48.032 C323.394,169.891,325.592,184.63,328.954,197.947z"></path>
                                    <path style="fill:#56ACE0;" d="M340.008,228.978c9.438,4.655,19.782,7.822,30.772,9.051v-20.881 c-11.636,0.323-23.402,1.034-35.103,2.133C337.034,222.707,338.457,225.875,340.008,228.978z"></path>
                                    <path style="fill:#56ACE0;" d="M370.715,49.196c-10.925,1.228-21.269,4.396-30.772,9.051c-1.422,2.909-2.78,5.947-4.073,9.115 c11.572,1.164,23.208,1.875,34.844,2.133L370.715,49.196L370.715,49.196z"></path>
                                    <path style="fill:#56ACE0;" d="M287.321,132.655h13.511c0.711-16.679,2.909-32.453,6.465-46.933 c-0.323-0.065-0.646-0.065-0.84-0.129C296.242,98.974,289.325,115.071,287.321,132.655z"></path>
                                    <path style="fill:#56ACE0;" d="M287.321,154.57c2.004,17.39,8.727,33.293,18.747,46.61c0.323-0.129,0.711-0.129,1.099-0.259 c-3.491-14.352-5.624-29.931-6.271-46.352H287.321z"></path>
                                    <path style="fill:#56ACE0;" d="M196.299,339.459c-49.972,0-89.535,14.933-102.335,31.289h204.541 C285.834,354.392,246.271,339.459,196.299,339.459z"></path>
                                </g>
                                <path style="fill:#FFFFFF;" d="M169.406,318.901c8.598-0.84,17.648-1.293,26.893-1.293s18.23,0.453,26.893,1.293V287.16h-53.721 v31.741H169.406z"></path>
                                <path style="fill:#194F82;" d="M381.705,0H32.743C14.707,0,0.032,14.675,0.032,32.711v221.737c0,18.036,14.675,32.711,32.711,32.711 H147.62v34.909c-47.709,9.18-79.774,31.741-79.774,59.604c0,6.012,4.848,10.925,10.925,10.925h234.99 c6.012,0,10.925-4.848,10.925-10.925c0-27.798-32.065-50.36-79.774-59.604V287.16H381.64c6.012,0,10.925-4.848,10.925-10.925v-0.129 V11.055v-0.129C392.566,4.848,387.717,0,381.705,0z M93.964,370.747c12.671-16.356,52.299-31.289,102.335-31.289 s89.535,14.933,102.335,31.289H93.964z M21.818,254.448V32.711c0-6.012,4.848-10.925,10.925-10.925h273.261 c-9.891,6.206-18.941,13.511-27.022,21.786c-25.212,25.859-40.727,61.091-40.727,100.008s15.515,74.085,40.727,100.008 c8.145,8.275,17.131,15.58,27.022,21.786H105.212v-8.857c0-6.012-4.848-10.925-10.925-10.925c-6.012,0-10.925,4.848-10.925,10.925 v8.857H67.006v-8.857c0-6.012-4.848-10.925-10.925-10.925s-10.925,4.848-10.925,10.925v8.857H32.743 C26.731,265.374,21.818,260.461,21.818,254.448z M370.78,49.196V69.56c-11.636-0.323-23.273-1.034-34.844-2.133 c1.228-3.168,2.651-6.271,4.073-9.115c8.275-17.067,19.006-29.35,30.772-34.069L370.78,49.196L370.78,49.196z M328.824,253.091 c-13.899-6.788-26.44-16.097-36.784-27.345c7.111-1.422,14.287-2.65,21.463-3.685C317.705,233.568,322.877,244.105,328.824,253.091z M322.747,154.44h48.032v40.792c-13.964,0.323-27.927,1.228-41.826,2.715C325.592,184.695,323.394,169.891,322.747,154.44z M322.747,132.655c0.711-15.709,2.909-30.513,6.4-44.024c13.834,1.487,27.733,2.392,41.632,2.715v41.309H322.747z M307.362,85.786 c-3.556,14.545-5.818,30.19-6.465,46.933h-13.576h-26.764c1.681-19.071,7.887-36.848,17.39-52.364 c9.438,2.069,19.006,3.879,28.509,5.301C306.715,85.721,307.038,85.721,307.362,85.786z M287.257,154.44h13.576 c0.711,16.485,2.844,32.065,6.271,46.352c-0.388,0.065-0.711,0.129-1.099,0.129c-9.503,1.487-19.006,3.232-28.444,5.301 c-9.374-15.451-15.386-33.099-17.067-51.911h26.764V154.44z M340.008,228.978c-1.487-3.103-2.909-6.271-4.331-9.632 c11.636-1.164,23.337-1.875,35.103-2.133v20.881v25.018C358.949,258.263,348.283,246.044,340.008,228.978z M313.697,64.646 c-7.111-1.099-14.222-2.327-21.269-3.62c10.279-11.119,22.626-20.234,36.461-26.958C323.006,42.861,317.899,53.139,313.697,64.646z M223.192,318.901c-8.598-0.84-17.648-1.293-26.893-1.293c-9.244,0-18.23,0.453-26.893,1.293V287.16h53.721v31.741H223.192z"></path>
                            </g>
                        </svg>
                    </span>
                    <span class="bs-stepper-label text-black fw-bold">Service Info</span>
                </button>
            </div>

            <div class="line">
                <i class="mdi mdi-arrow-right-thin fs-2"></i>
            </div>
            <div class="step" data-target="#payment_other_info">
                <button type="button" class="step-trigger">
                    <span class="bs-stepper-icon">
                        <svg height="200px" width="200px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 505 505" xml:space="preserve" fill="#000000">
                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                            <g id="SVGRepo_iconCarrier">
                                <circle style="fill:#027cd6;" cx="252.5" cy="252.5" r="252.5"></circle>
                                <path style="fill:#f0f6ff;" d="M462.7,286.7L295.4,89c-7-8.2-19.3-9.3-27.5-2.3L148.6,187.6c-8.2,7-9.3,19.3-2.3,27.5l167.2,197.7 c7,8.2,19.3,9.3,27.5,2.3l119.3-100.9C468.6,307.2,469.6,294.9,462.7,286.7z"></path>
                                <rect x="175.361" y="212.374" transform="matrix(-0.6458 -0.7635 0.7635 -0.6458 355.117 632.8896)" style="fill:#324452;" width="297.998" height="43.4"></rect>
                                <path style="fill:#FFFFFF;" d="M377.8,163.1l-273.1-2.3c-11.3-0.1-20.5,9-20.6,20.3l-1.2,147.3c-0.1,11.3,9,20.5,20.3,20.6 l273.1,2.3c11.3,0.1,20.5-9,20.6-20.3l1.2-147.3C398.1,172.4,389.1,163.2,377.8,163.1z"></path>
                                <path style="fill:#f47507;" d="M382.7,278.9l0.4-43.2c-31.9-0.4-57.5-26.5-57.3-58.5l-169.1-1.4c-0.3,32-26.5,57.8-58.5,57.5 l-0.4,43.1c32,0.3,57.8,26.4,57.6,58.5l169.1,1.4C324.7,304.4,350.8,278.8,382.7,278.9z"></path>
                                <ellipse transform="matrix(0.0083 -1 1 0.0083 -17.6977 494.3711)" style="fill:#FFFFFF;" cx="240.409" cy="256.109" rx="60.202" ry="43.602"></ellipse>
                                <path style="fill:#f47507;" d="M242.7,280.3l-0.1,7.5h-5.1l0.1-7.3c-4.7-0.1-9.1-1.2-13.1-3.3l0.1-9.6c1.3,1.1,3.3,2.1,6,3.1 c2.7,0.9,5,1.5,7.1,1.7l0.1-12.6c-5.4-2.1-9.1-4.3-11-6.6c-2-2.4-2.9-5.2-2.9-8.6c0-3.6,1.3-6.7,3.9-9.3c2.6-2.5,6-4,10.3-4.4 l0.1-6.5h5.1l-0.1,6.3c4.9,0.3,8.5,1.1,10.9,2.5l-0.1,9.4c-3.2-2-6.9-3.2-10.9-3.7l-0.1,13.2c5.1,1.9,8.7,4,10.9,6.4 c2.2,2.4,3.3,5.2,3.2,8.6c0,3.8-1.3,6.9-3.8,9.3C250.8,278.5,247.2,279.9,242.7,280.3z M237.9,249.9l0.1-11c-3.2,0.6-4.8,2.2-4.9,5 C233.1,246.3,234.7,248.3,237.9,249.9z M242.8,261.7l-0.1,10.5c3.3-0.5,5-2.1,5-4.9C247.8,265,246.1,263.1,242.8,261.7z"></path>
                            </g>
                        </svg>
                    </span>
                    <span class="bs-stepper-label text-black fw-bold">Payment & Other info</span>
                </button>
            </div>
        </div>
        <div class="bs-stepper-content">
            <form onSubmit="return false">
                <!-- course_info -->
                <div id="basic-info" class="content">
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Course Category<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select">
                                <option value="">Select Course Category</option>
                                <option value="1">Business Management</option>
                                <option value="2">Network Management</option>
                                <option value="3" selected>Programming Training</option>
                                <option value="4">Data Analyst</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Course Sub Category<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select">
                                <option value="">Select Course Sub Category</option>
                                <option value="1" selected>Application Development</option>
                                <option value="2">Expert</option>
                                <option value="3">Web Development</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Course Type<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select">
                                <option value="">Select Course Type</option>
                                <option value="1">Tesbo</option>
                                <option value="2">Classic</option>
                                <option value="3">Slash</option>
                                <option value="4" selected>Profesional</option>
                                <option value="5">Crash</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Course<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select" data-placeholder="Select Course job Role">
                                <option value="">Select Course</option>
                                <option value="1" selected>Python For Data Science</option>
                                <option value="2">Core java</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration (In Days)</label>
                            <!-- <input type="text" class="form-control" id="" placeholder="Duration (In Days)" value="90 Days"/> -->
                            <input type="text" readonly class="form-control" id="exampleFormControlReadOnlyInputPlain1" value="90" readonly />

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration (In Hours)</label>
                            <input type="text" readonly class="form-control" id="exampleFormControlReadOnlyInputPlain1" value="120" readonly />

                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button class="btn btn-outline-secondary btn-sm btn-prev" disabled> <i class="mdi mdi-arrow-left-thin fs-2 me-sm-1"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </button>
                        <button class="btn btn-primary btn-sm btn-next"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="mdi mdi-arrow-right-thin fs-3"></i></button>
                    </div>
                </div>
                <!-- service_info -->
                <!-- service_info -->
                <div id="service_info" class="content">
                    <div>
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <a href="/services/manage_service/service_add" class="ms-2 btn btn-sm fw-bold btn-primary">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Service
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row mt-4">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Service Name<span class="text-danger">*</span></label>
                                    <select id="ser_name" class="select3 form-select">
                                        <option value="">Select Service Name</option>
                                        <option value="1">Computer Science - Blockchain Technology - ML/DL</option>
                                        <option value="2">5G Botnet Detection</option>
                                        <option value="3">Depression Detection</option>
                                        <option value="4">Audio Using Sentiment Analysis</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
                                    <select id="" class="select3 form-select">
                                        <option value="">Select Service Category</option>
                                        <option value="1">Reasearch Services</option>
                                        <option value="2">PHD Services</option>
                                        <option value="3">Writing Services</option>
                                        <option value="4" selected>Development Services</option>
                                        <option value="5">Analysis Services</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
                                    <select id="ser_sub_cat" class="select3 form-select">
                                        <option value="">Select Service Sub Category</option>
                                        <option value="1">Research Paper Writing Service </option>
                                        <option value="2">Book Writing Service</option>
                                        <option value="3">Scopus Indexed Journal </option>
                                        <option value="4" selected>Python Development </option>
                                        <option value="5">SPSS Analysis</option>
                                    </select>
                                </div>
                                <!-- <div class="col-lg-4">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
                                    <select id="duration" class="select3 form-select" data-style="btn-default" data-live-search="true">
                                        <option value="">Select Duration</option>
                                        <option value="1">3 - 5 Days</option>
                                        <option value="2">5 - 7 Days</option>
                                        <option value="3">7 - 9 Days</option>
                                        <option value="4">10 - 15 Days</option>
                                        <option value="5" selected>15 - 20 Days</option>
                                        <option value="6">20 - 25 Days</option>
                                    </select>
                                </div> -->
                                <div class="col-lg-4 mb-3 d-flex align-items-center">
                                    <div class="form-check form-check-inline mt-4">
                                        <input class="form-check-input" type="checkbox" id="properties" name="properties" onclick="properties_func();" />
                                        <label class="text-black mb-1 fs-5 fw-semibold">Set Properties</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="view_properties" name="view_properties" style="display:none;">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Title<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Title Name" value="Computer Science- BlockChain technology-ML/DL" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Language<span class="text-danger">*</span></label>
                                        <select id="language" class="select3 form-select">
                                            <option value="">Select Language</option>
                                            <option value="1" selected>Python</option>
                                            <option value="2">Java</option>
                                            <option value="3">VLSI</option>
                                            <option value="4">PHP</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Domain<span class="text-danger">*</span></label>
                                        <select id="domain" class="select3 form-select">
                                            <option value="">Select Domain</option>
                                            <option value="1" selected>Data Mining</option>
                                            <option value="2">Image Processing</option>
                                            <option value="3">Cloud Computing</option>
                                            <option value="4">Big Data</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Database<span class="text-danger">*</span></label>
                                        <select id="database" class="select3 form-select" name="database" onchange="database_func();">
                                            <option value="">Select Database</option>
                                            <option value="yes" selected>Yes</option>
                                            <option value="no">No</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3" id="view_database" name="view_database">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Database Name<span class="text-danger">*</span></label>
                                        <select id="database_name" class="select3 form-select">
                                            <option value="">Select Database</option>
                                            <option value="1" selected>MySQL</option>
                                            <option value="2">Oracle</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Algorithms<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Algorithms Name" value="Machine Learning, Deep Learning" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Machine Learning</label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Algorithms Name" value="Decision Tree Algorithm KNN Algorithm" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Deep Learning</label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Algorithms Name" value="ANN Algorithm CNN Algorithm" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Description" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <label class="text-black mb-1 fs-5 fw-semibold mt-2">Add On Services</label>
                        <div class="row mt-2" id="view_add_on" name="view_add_on">
                            <div class="col-lg-12">
                                <label class="col-12 text-dark mb-3 fs-6 fw-semibold">Free Services</label>
                                <div class="row">
                                    <div class="col-lg-3 mb-3 align-items-center">
                                        <div class="custom-option custom-option-basic ">
                                            <label class="custom-option-content">
                                                <span class="custom-option-header">
                                                    <span class="h6 mb-0">Literature Writing</span>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-3 align-items-center">
                                        <div class="custom-option custom-option-basic ">
                                            <label class="custom-option-content">
                                                <span class="custom-option-header">
                                                    <span class="h6 mb-0">Plagiarism Checking</span>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-3 align-items-center">
                                        <div class="custom-option custom-option-basic ">
                                            <label class="custom-option-content">
                                                <span class="custom-option-header">
                                                    <span class="h6 mb-0">Grammer Checking</span>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-3 align-items-center">
                                        <div class="custom-option custom-option-basic ">
                                            <label class="custom-option-content">
                                                <span class="custom-option-header">
                                                    <span class="h6 mb-0">Proof Reading</span>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <label class="col-12 text-dark mb-3 fs-6 fw-semibold">Paid Services</label>
                                <div class="row">
                                    <div class="col-lg-3 mb-3 align-items-center">
                                        <div class="custom-option custom-option-basic ">
                                            <label class="custom-option-content">
                                                <span class="custom-option-header">
                                                    <span class="h6 mb-0">Plagiarism Checking</span>
                                                </span>
                                                <div class="custom-option-body mt-2">
                                                    <span class="badge bg-success text-black fw-bold">1 Hour</span>
                                                    <span class="text-info ms-4 fw-bold">
                                                        <span class="mdi mdi-currency-rupee"></span>
                                                        <span>750</span>
                                                    </span>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-3 align-items-center">
                                        <div class="custom-option custom-option-basic ">
                                            <label class="custom-option-content">
                                                <span class="custom-option-header">
                                                    <span class="h6 mb-0">Poof Reading</span>
                                                </span>
                                                <div class="custom-option-body mt-2">
                                                    <span class="badge bg-success text-black fw-bold">1 Hour</span>
                                                    <span class="text-info ms-4 fw-bold">
                                                        <span class="mdi mdi-currency-rupee"></span>
                                                        <span>750</span>
                                                    </span>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button class="btn btn-outline-secondary btn-sm btn-prev"> <i class="mdi mdi-arrow-left-thin fs-2 me-sm-1"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </button>
                        <button class="btn btn-primary btn-sm btn-next"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="mdi mdi-arrow-right-thin fs-3"></i></button>
                    </div>
                </div>
                <!-- payment_other_info -->
                <div id="payment_other_info" class="content">
                    <div class="row">
                        <div>
                            <label class="text-black mb-1 fs-4 fw-bold mt-4">Payment Information</label>
                            <span class="me-1 ms-1">-</span>
                            <span class="badge bg-warning text-black fw-bold">Partially Paid</span>
                        </div>
                        <div class="col-lg-12">
                            <div class="row mt-2">
                                <label class="text-black mb-1 fs-5 fw-semibold">Transaction Details</label>
                            </div>
                            <div class="row mt-4">
                                <div class="col-lg-6">
                                    <div class="row">
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-6 fw-bold">Payment Type</label>
                                            <label class="col-7 text-black fs-7 fw-semibold">Bank</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-6 fw-bold">Bank Name</label>
                                            <label class="col-7 text-black fs-7 fw-semibold">TMB</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-6 fw-bold">Account No</label>
                                            <label class="col-7 text-black fs-7 fw-semibold">20272560000045</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row">
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-6 fw-bold">Branch Name</label>
                                            <label class="col-7 text-black fs-7 fw-semibold">Anna Nagar, Madurai</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-6 fw-bold">IFSC Code</label>
                                            <label class="col-7 text-black fs-7 fw-semibold">HDFC0002027</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-6 fw-bold">Amount</label>
                                            <label class="col-7 text-black fs-7 fw-semibold">
                                                <span>Rs.</span>
                                                <span>40,000</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">Sub Total Amount</label>
                                <div class="d-block mt-2">
                                    <label class="badge bg-info text-white mb-1 fs-6 fw-bold">70,000</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">Add On Services</label>
                                <div class="d-block mt-2">
                                    <label class="badge bg-primary text-white mb-1 fs-6 fw-bold">1,500</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">Actual Amount</label>
                                <div class="d-block mt-2">
                                    <label class="badge text-black mb-1 fs-6 fw-bold" style="background-color:#1ab69d;">70,000</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">GST (%)</label>
                                <div class="d-block mt-2">
                                    <label class="badge bg-secondary text-white mb-1 fs-6 fw-bold">12</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">GST (12%) Amount</label>
                                <div class="d-block mt-2">
                                    <label class="badge text-white mb-1 fs-6 fw-bold" style="background-color:#f47507;">10,000</label>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">Total Amount</label>
                                <div class="d-block mt-2">
                                    <label class="badge text-white mb-1 fs-6 fw-bold" style="background-color:#5e8c36;">80,000</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">Paid Amount</label>
                                <div class="d-block mt-2">
                                    <label class="badge bg-warning text-black mb-1 fs-6 fw-bold">40,000</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="text-center">
                                <label class="text-black mb-1 fs-5 fw-bold">Due Amount</label>
                                <div class="d-block mt-2">
                                    <label class="badge bg-danger text-white mb-1 fs-6 fw-bold">40,0000</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button class="btn btn-outline-secondary btn-sm btn-prev"> <i class="mdi mdi-arrow-left-thin fs-2 me-sm-1"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </button>
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_create_customer">Create Customer</a>
                        <!-- <button class="btn btn-primary">Submit</button> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Customer End Wizard -->
    <!-- <div class="col-lg-4 py-4 px-4">
        <label class="text-dark mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
        <select id="" class="select3 form-select">
            <option value="">Select Country</option>
            <option value="1">Afghanistan</option>
            <option value="2">Bolivia</option>
            <option value="3">Canada</option>
            <option value="4" selected>India</option>
            <option value="5">Japan</option>
            <option value="6">Kuwait</option>
            <option value="7">Libya</option>
        </select>
    </div> -->
</div>

<!--begin::Modal - Add batch-->
<div class="modal fade" id="kt_modal_add_batch" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Batch</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Batch Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Batch Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Course Type<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Course Type</option>
                            <option value="1">Tesbo</option>
                            <option value="2">Classic</option>
                            <option value="3">Slash</option>
                            <option value="4">Profesional</option>
                            <option value="5">Crash</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Course<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Course</option>
                            <option value="1">Python For Data Science</option>
                            <option value="2">Core java</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Slot<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Slot</option>
                            <option value="1">Morning Slot - Week Day - 11.00 AM - 14:00 PM</option>
                            <option value="2">Evening Slot - Week End - 14:00 PM - 16:00 PM</option>
                            <option value="2">Alternate Slot - Week Day - 09:00 AM - 11:00 AM</option>
                        </select>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Starting Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="batch_star_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Ending Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="batch_end_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Class Room<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Class Room</option>
                            <option value="1">Class A</option>
                            <option value="2">Class B</option>
                            <option value="3">Class C</option>
                            <option value="3">Class D</option>
                            <option value="3">Class E</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Maximum students<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Maximum Students" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Allocated Staff<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select" multiple>
                            <option value="">Select Staff</option>
                            <option value="1">Sabana</option>
                            <option value="2">Nila</option>
                            <option value="3">Vasanth</option>
                            <option value="3">Divya</option>
                            <option value="3">Madhu</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Batch</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
</div>
<!--end::Modal - Add Batch-->


<!--begin::Modal - Add on Course Confirmation-->
<div class="modal fade" id="kt_modal_add_course" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Add Course ?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya</label>
                    <span class="ms-2 me-2">-</span>
                    <label>CUS-0001/24</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <a href="/sales/manage_customer" class="btn btn-primary me-3">Yes</a>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add on Course Confirmation-->

<script>
    function properties_func() {
        var properties = document.getElementById("properties");
        var view_properties = document.getElementById("view_properties");

        if (properties.checked) {
            view_properties.style.display = "block";
        } else {
            view_properties.style.display = "none";
        }
    }
</script>

@endsection