@extends('layouts/layoutMaster')

@section('title', 'Create Invoice')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection
@section('content')


<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Invoice</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Lead Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Invoice</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name">
                                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
                            </label>
                            <label class="fs-5 align-items-center text-black fw-semibold">
                                <span>Priya Dharshini</span>
                                <span class="badge bg-danger text-white fs-8 rounded">F</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div class="row">
                            <div class="justify-content-start">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">
                                    <i class="mdi mdi-card-account-mail-outline fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-semibold">
                                    <span>priya@gmail.com</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-2">
                        <div class="row">
                            <div class="justify-content-start">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Address">
                                    <i class="mdi mdi-map-marker-outline fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-semibold">
                                    <label class="">1</label>,
                                    <label class="text-truncate max-w-250px" title="Bharathiyar Street, Avaniyapuram">Bharathiyar Street, Avaniyapuram</label>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-1">
                        <div class="row">
                            <div class="justify-content-start">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Location">
                                    <i class="mdi mdi-map-check-outline fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-semibold">
                                    <span>India</span><span>,</span>
                                    <span>Tamilnadu</span><span>,</span>
                                    <span>Madurai</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row">
                    <div class="justify-content-start">
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Phone No">
                            <i class="mdi mdi-phone-plus fs-3 text-black"></i>
                        </label>
                        <label class="fs-6 align-items-center text-black fw-semibold">
                            <span>9876543210</span>
                        </label>
                    </div>
                </div>
                <div class="row">
                    <div class="justify-content-start">
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch Name">
                            <i class="mdi mdi-source-branch fs-3 text-black"></i>
                        </label>
                        <label class="fs-6 align-items-center text-black fw-semibold">
                            <span>Madurai Anna Nagar</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2">
                <div class="row">
                    <div class="justify-content-start">
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Work Name">
                            <i class="mdi mdi-desktop-classic fs-3 text-black"></i>
                        </label>
                        <label class="fs-6 align-items-center text-black fw-semibold">
                            <label class="">Priya Dharshini Work Details</label>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Invoice Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Due Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_validity" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <h5 class="card-title mb-1 fw-bold">Service Details</h5>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-50px">S.No</th>
                                    <th class="min-w-150px">Service</th>
                                    <th class="min-w-150px">Package / Qty</th>
                                    <th class="min-w-100px">Price</th>
                                    <th class="min-w-100px">Add On Services</th>
                                    <th class="min-w-50px">Amount</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                                <tr>
                                    <td>1</td>
                                    <td>
                                        <label class="fs-7 text-black fw-bold">Writing Services</label>
                                        <div class="d-block">
                                            <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</label>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Content Writing">Content Writing</label>
                                        <div class="text-center">
                                            <label class="badge bg-info text-white">1</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-black fw-bold mb-2">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">50,000.00</span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-black fw-bold mb-2">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">2,000.00</span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-black fw-bold mb-2">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">52,000.00</span>
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>
                                        <label class="fs-7 text-black fw-bold">Development Services</label>
                                        <div class="d-block">
                                            <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Python Development">Python Development</label>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coding Development">Coding Development</label>
                                        <div class="text-center">
                                            <label class="badge bg-info text-white">1</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-black fw-bold mb-2">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">60,000.00</span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-black fw-bold mb-2">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">2,000.00</span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-black fw-bold mb-2">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">62,000.00</span>
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-lg-12 mb-2 d-flex justify-content-end align-items-center flex-wrap">
                                <label class="text-black fs-6 fw-bold">Grand Total </label>
                                <span class="me-1 ms-1">:</span>
                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                <label class="text-black fs-6 fw-semibold ms-1">1,14,000</label>
                            </div>
                            <div class="col-lg-12 mb-2 d-flex justify-content-end align-items-center flex-wrap">
                                <label class="text-black fs-6 fw-bold">Discount
                                    <span>(10%)</span></label>
                                <span class="me-1 ms-1">:</span>
                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                <label class="text-black fs-6 fw-semibold ms-1">11,400</label>
                            </div>
                            <!-- <div class="col-lg-12 mb-2 d-flex justify-content-end align-items-center flex-wrap">
                                <label class="text-black fs-6 fw-bold">GST
                                    <span>(18%)</span></label>
                                <span class="me-1 ms-1">:</span>
                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                <label class="text-black fs-6 fw-semibold ms-1">18,468</label>
                            </div> -->
                            <div class="col-lg-12 mb-2 d-flex justify-content-end align-items-center flex-wrap">
                                <label class="text-black fs-6 fw-bold">GST
                                    <span>(18%)</span></label>
                                <span class="me-1 ms-1">:</span>
                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                <label class="text-black fs-6 fw-semibold ms-1">18,468</label>
                            </div>
                            <div class="col-lg-12 mb-2 d-flex justify-content-end align-items-center flex-wrap">
                                <label class="text-black fs-6 fw-bold">Total Amount</label>
                                <span class="me-1 ms-1">:</span>
                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                <label class="text-black fs-6 fw-bold ms-1">1,43,868</label>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="row mt-4">
                    <div class="col-lg-3 mb-3">
                        <div class="text-center">
                            <label class="text-black mb-1 fs-6 fw-bold">Grant Total Amount</label>
                            <div class="d-block mt-2">
                                <label class="badge bg-secondary text-white mb-1 fs-6 fw-semibold">
                                    <span class="mdi mdi-currency-rupee"></span>
                                    <span>1,22,000</span></label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <div class="text-center">
                            <label class="text-black mb-1 fs-6 fw-bold">Discount (10%)</label>
                            <div class="d-block mt-2">
                                <label class="badge text-white mb-1 fs-6 fw-semibold" style="background-color:#5e8c36;">
                                    <span class="mdi mdi-currency-rupee"></span>
                                    <span>12,200</span></label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <div class="text-center">
                            <label class="text-black mb-1 fs-6 fw-bold">GST (18%)</label>
                            <div class="d-block mt-2">
                                <label class="badge bg-primary text-white mb-1 fs-6 fw-semibold">
                                    <span class="mdi mdi-currency-rupee"></span>
                                    <span>21,960</span></label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <div class="text-center">
                            <label class="text-black mb-1 fs-6 fw-bold">Total Amount</label>
                            <div class="d-block mt-2">
                                <label class="badge bg-success text-black mb-1 fs-6 fw-semibold">
                                    <span class="mdi mdi-currency-rupee"></span>
                                    <span>1,31,760</span></label>
                                </label>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <h5 class="card-title mb-1 fw-bold">Payment Details</h5>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-50px">S.No</th>
                                    <th class="min-w-150px">Payment ID</th>
                                    <th class="min-w-150px">Payment Mode</th>
                                    <th class="min-w-100px">Paid Amount</th>
                                    <th class="min-w-50px">Balance amount</th>
                                    <th class="min-w-100px">Due Date</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                                <tr>
                                    <td>1</td>
                                    <td class="text-center">
                                        <label class="fs-7 text-black fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment ID">5923</label>
                                        <div class="d-block">
                                            <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice Date">20-Sep-2024</label>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <label class="text-black">Bank</label>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-black fw-bold mb-2 badge bg-success">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">71,934</span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block" align="right">
                                            <label class="fs-8 text-white fw-bold mb-2 badge bg-info">
                                                <span class="mdi mdi-currency-rupee fw-bold fs-8"></span>
                                                <span class="fs-7">71,934</span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Due Date">30-Sep-2024</label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div Class="row">
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Payment Status<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select">
                                <option value="">Select Invoice Status</option>
                                <option value="1">Partially Paid</option>
                                <option value="2">Fully Paid</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
                            <select id="payment" name="payment" class="select3 form-select" onchange="payment_func();">
                                <option value="">Select Payment Mode</option>
                                <option value="cash">Cash</option>
                                <option value="check">Cheque</option>
                                <option value="paypal">PayPal</option>
                                <option value="gpay">GPay</option>
                                <option value="bank">Bank</option>
                            </select>
                        </div>
                    </div>
                    <div id="cash_det" style="display: none !important;">
                        <div class="row mt-2">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Cash Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Cash Amount" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div id="check_det" style="display: none !important;">
                        <div class="row mt-4">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                <select id="" class="select3 form-select">
                                    <option value="">Select Bank</option>
                                    <option value="">TMB</option>
                                    <option value="">Indian</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Cheque No<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Cheque No" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div id="gpay_det" style="display: none !important;">
                        <div class="row mt-2">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div id="paypal_det" style="display: none !important;">
                        <div class="row mt-2">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Amount" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div id="bank_det" style="display: none !important;">
                        <div class="row mt-2">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                <select id="" class="select3 form-select">
                                    <option value="">Select Bank</option>
                                    <option value="">TMB</option>
                                    <option value="">Indian</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Account Number<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Account Number" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter Branch Name" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="" placeholder="Enter IFSC Code" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-outline-secondary me-2">Cancel</button>
            <a href="/manage_customer" class="btn btn-primary me-3">
                Create
            </a>
        </div>
    </div>
</div>

<!--Quotation Payment Accordion Start-->
<script>
    $('.course_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_course_question').length);
        let $clone = $('.form-repeater_course_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_course_question:first').slideDown();
        if (bt == 1) {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.cat_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_course_question .cat_butt_del_question', e => {
        var bt = parseFloat($('.cat_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_course_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.cat_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    let logofile = document.getElementById('uploadedsignature');
    const fileInput = document.querySelector('.file-in'),
        resetFileInput = document.querySelector('.file-reset');

    if (logofile) {
        const resetImage = logofile.src;
        fileInput.onchange = () => {
            if (fileInput.files[0]) {
                logofile.src = window.URL.createObjectURL(fileInput.files[0]);
            }
        };
        resetFileInput.onclick = () => {
            fileInput.value = '';
            logofile.src = resetImage;
        };
    }
</script>

<script>
    function add_on_func() {
        var add_on = document.getElementById("add_on");
        var view_add_on = document.getElementById("view_add_on");

        if (add_on.checked) {
            view_add_on.style.display = "block";
        } else {
            view_add_on.style.display = "none";
        }
    }
</script>
<script>
    function package_on_func() {
        var package_on = document.getElementById("package_on");
        var view_package = document.getElementById("view_package");
        var view_service_on = document.getElementById("view_service_on");
        if (package_on.checked) {
            view_package.style.display = "block";
            view_service_on.style.display = "none";
        } else {
            view_package.style.display = "none";
        }
    }
</script>
<script>
    function service_on_func() {
        var service_on = document.getElementById("service_on");
        var view_service_on = document.getElementById("view_service_on");
        var view_package = document.getElementById("view_package");
        var amount_view = document.getElementById("amount_view");
        var chapter_view = document.getElementById("chapter_view");
        var wrk_hrs_view = document.getElementById("wrk_hrs_view");
        var wrk_days_view = document.getElementById("wrk_days_view");
        var description_view = document.getElementById("description_view");
        var amount_view_2 = document.getElementById("amount_view_2");
        var no_of_pages_view_2 = document.getElementById("no_of_pages_view_2");
        var wrk_hrs_view_2 = document.getElementById("wrk_hrs_view_2");
        var description_view_2 = document.getElementById("description_view_2");
        if (service_on.checked) {
            view_service_on.style.display = "block";
            view_package.style.display = "none";
            amount_view_2.style.display = "none";
            no_of_pages_view_2.style.display = "none";
            chapter_view_2.style.display = "none";
            wrk_hrs_view_2.style.display = "none";
            amount_view.style.display = "none";
            no_of_pages_view.style.display = "none";
            chapter_view.style.display = "none";
            wrk_hrs_view.style.display = "none";
            description_view.style.display = "none";
            description_view_2.style.display = "none";
            wrk_days_view.style.display = "none";
        } else {
            view_service_on.style.display = "none";
        }
    }
</script>
<script>
    function package_name_func() {
        var package_name = document.getElementById("package_name").value;
        var amount_view = document.getElementById("amount_view");
        var chapter_view = document.getElementById("chapter_view");
        var wrk_hrs_view = document.getElementById("wrk_hrs_view");
        var wrk_days_view = document.getElementById("wrk_days_view");
        var description_view = document.getElementById("description_view");
        var amount_view_2 = document.getElementById("amount_view_2");
        var no_of_pages_view_2 = document.getElementById("no_of_pages_view_2");
        var wrk_hrs_view_2 = document.getElementById("wrk_hrs_view_2");

        if (package_name == "paper_write_1") {
            amount_view.style.display = "block";
            no_of_pages_view.style.display = "block";
            chapter_view.style.display = "block";
            wrk_hrs_view.style.display = "block";
            wrk_days_view.style.display = "block";
            description_view.style.display = "block";
            amount_view_2.style.display = "none";
            no_of_pages_view_2.style.display = "none";
            chapter_view_2.style.display = "none";
            wrk_hrs_view_2.style.display = "none";
            description_view_2.style.display = "none";
        } else if (package_name == "paper_write_2") {
            amount_view_2.style.display = "block";
            no_of_pages_view_2.style.display = "block";
            chapter_view_2.style.display = "block";
            wrk_hrs_view_2.style.display = "block";
            amount_view.style.display = "none";
            no_of_pages_view.style.display = "none";
            chapter_view.style.display = "none";
            wrk_hrs_view.style.display = "none";
            description_view.style.display = "none";
            description_view_2.style.display = "block";
        } else {
            amount_view.style.display = "none";
            no_of_pages_view.style.display = "none";
            chapter_view.style.display = "none";
            wrk_hrs_view.style.display = "none";
            amount_view_2.style.display = "none";
            no_of_pages_view_2.style.display = "none";
            chapter_view_2.style.display = "none";
            wrk_hrs_view_2.style.display = "none";
            description_view.style.display = "none";
        }
    }
</script>
<script>
    function page_count_func() {
        var total_pages = document.getElementById("total_pages").value;
        var pages_view = document.getElementById("pages_view");
        var two_pages_view = document.getElementById("two_pages_view");
        var one_pages = document.getElementById("one_pages");
        if (total_pages == "one_pages") {
            pages_view.style.display = "block";
            two_pages_view.style.display = "none";
        } else if (total_pages == "two_pages") {
            pages_view.style.display = "none";
            two_pages_view.style.display = "block";
        } else {
            pages_view.style.display = "none";
        }
    }
</script>

<script>
    function service_properties_func() {
        var service_prod_add = document.getElementById("service_prod_add");
        var service_product_view = document.getElementById("service_product_view");

        if (service_prod_add.checked) {
            service_product_view.style.display = "block";
        } else {
            service_product_view.style.display = "none";
        }
    }
</script>

<script>
    $('#add_on_chk_all').change(function() {
        $('.add_on_ver_chk').prop('checked', this.checked);
    });

    $('.add_on_ver_chk').change(function() {
        if ($('.add_on_ver_chk:checked').length == $('.add_on_ver_chk').length) {
            $('#add_on_chk_all').prop('checked', true);
        } else {
            $('#add_on_chk_all').prop('checked', false);
        }

    });
</script>

<script>
    $('#add_on_chk_all_paid').change(function() {
        $('.add_on_ver_chk_paid').prop('checked', this.checked);
    });

    $('.add_on_ver_chk_paid').change(function() {
        if ($('.add_on_ver_chk_paid:checked').length == $('.add_on_ver_chk_paid').length) {
            $('#add_on_chk_all_paid').prop('checked', true);
        } else {
            $('#add_on_chk_all_paid').prop('checked', false);
        }

    });
</script>
<script>
    $('.service_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_add').length);
        let $clone = $('.form-repeater_service_add').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_add:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_add .service_butt_del', e => {
        var bt = parseFloat($('.service_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_add').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    function template_slot_func() {
        var template_slot = document.getElementById("template_slot").value;
        var template_1 = document.getElementById("template_1");
        var template_2 = document.getElementById("template_2");

        if (template_slot == "template_1") {
            view_single_template_slot.style.display = "block";
            view_double_template_slot.style.display = "none";
        } else if (template_slot == "template_2") {
            view_double_template_slot.style.display = "block";
            view_single_template_slot.style.display = "none";
        } else {

        }
    }
</script>

<script>
    function payment_func() {
        var payment = document.getElementById("payment").value;
        var cash_det = document.getElementById("cash_det");
        var check_det = document.getElementById("check_det");
        var gpay_det = document.getElementById("gpay_det");
        var paypal_det = document.getElementById("paypal_det");
        var bank_det = document.getElementById("bank_det");
        if (payment == "cash") {
            cash_det.style.display = "block";
            check_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "check") {
            check_det.style.display = "block";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "gpay") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "block";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "paypal") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "none";
            paypal_det.style.display = "block";
        } else if (payment == "bank") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "block";
            paypal_det.style.display = "none";
        } else {
            cash_det.style.display = "none";
            check_det.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +

            "<'table-responsive'tr>"

        // "<'row'" +
        // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>"


    });
</script>
@endsection