@extends('layouts/layoutMaster')

@section('title', 'Create Customer')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')


<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Customer</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Customer Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Customer</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <h4 class="text-black mb-1 fw-bold">Basic Information</h4>
            <div class="col-lg-12">
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Customer Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Customer Name" value="Priya Dharshini" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                            <label class="form-check-label" for="inlineRadio1">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" checked />
                            <label class="form-check-label" for="inlineRadio2">Female</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" />
                            <label class="form-check-label" for="inlineRadio3">Others</label>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Email ID" value="priya@gmail.com" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Mobile Number" value="9876543210" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Alternate Mobile Number" value="9876543210" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Country</option>
                            <option value="1">Afghanistan</option>
                            <option value="2">Bolivia</option>
                            <option value="3">Canada</option>
                            <option value="4" selected>India</option>
                            <option value="5">Japan</option>
                            <option value="6">Kuwait</option>
                            <option value="7">Libya</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select State</option>
                            <option value="1">Andhra Pradesh</option>
                            <option value="2">Goa</option>
                            <option value="3">Karnataka</option>
                            <option value="4">Kerala</option>
                            <option value="5" selected>Tamil Nadu</option>
                            <option value="6">Telangana</option>
                            <option value="7">Uttarakhand</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select City</option>
                            <option value="1">Chennai</option>
                            <option value="2">Vellore</option>
                            <option value="3">Salem</option>
                            <option value="4">Tirunelveli</option>
                            <option value="5" selected>Madurai</option>
                            <option value="6">Dindigul</option>
                            <option value="7">Sivakasi</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Area/ Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Area/ Street" value="Bharathiyar Street" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Door No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Door No" value="1" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Pincode" value="625012" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">University</label>
                        <select id="" class="select3 form-select">
                            <option value="">Select University</option>
                            <option value="1" selected>Madurai Kamarajar University</option>
                            <option value="2">Dindugal Anna University</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Guide Name</label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Guide Name" value="Velu Selvi" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Lead Type</option>
                            <option value="1">Employee</option>
                            <option value="2" selected>Student</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Lead Source</option>
                            <option value="1">Email</option>
                            <option value="2" selected>Website</option>
                            <option value="2">Facebook</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <h4 class="text-black mb-1 fw-bold mt-4">Service Information</h4>
            <div class="col-lg-12">
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Service Category</option>
                            <option value="1">Reasearch Services</option>
                            <option value="2">PHD Services</option>
                            <option value="3">Writing Services</option>
                            <option value="4" selected>Development Services</option>
                            <option value="5">Analysis Services</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
                        <select id="ser_sub_cat" class="select3 form-select">
                            <option value="">Select Service Sub Category</option>
                            <option value="1">Research Paper Writing Service </option>
                            <option value="2">Book Writing Service</option>
                            <option value="3">Scopus Indexed Journal </option>
                            <option value="4" selected>Python Development </option>
                            <option value="5">SPSS Analysis</option>
                        </select>
                    </div>
                    <div class="col-lg-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
                        <select id="duration" class="select3 form-select" data-style="btn-default" data-live-search="true">
                            <option value="">Select Duration</option>
                            <option value="1">3 - 5 Days</option>
                            <option value="2">5 - 7 Days</option>
                            <option value="3">7 - 9 Days</option>
                            <option value="4">10 - 15 Days</option>
                            <option value="5" selected>15 - 20 Days</option>
                            <option value="6">20 - 25 Days</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3 d-flex align-items-center">
                        <div class="form-check form-check-inline mt-4">
                            <input class="form-check-input" type="checkbox" id="properties" name="properties" onclick="properties_func();" />
                            <label class="text-black mb-1 fs-5 fw-semibold">Set Properties</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" id="view_properties" name="view_properties" style="display:none;">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Title<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Title Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Language<span class="text-danger">*</span></label>
                            <select id="language" class="select3 form-select">
                                <option value="">Select Language</option>
                                <option value="1">Python</option>
                                <option value="2">Java</option>
                                <option value="3">VLSI</option>
                                <option value="4">PHP</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Domain<span class="text-danger">*</span></label>
                            <select id="domain" class="select3 form-select">
                                <option value="">Select Domain</option>
                                <option value="1">Data Mining</option>
                                <option value="2">Image Processing</option>
                                <option value="3">Cloud Computing</option>
                                <option value="4">Big Data</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Database<span class="text-danger">*</span></label>
                            <select id="database" class="select3 form-select" name="database" onchange="database_func();">
                                <option value="">Select Database</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3" id="view_database" name="view_database" style="display:none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Database Name<span class="text-danger">*</span></label>
                            <select id="database_name" class="select3 form-select">
                                <option value="">Select Database</option>
                                <option value="1">MySQL</option>
                                <option value="2">Oracle</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Algorithms<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="" placeholder="Enter Algorithms Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Machine Learning</label>
                            <input type="text" class="form-control" id="" placeholder="Enter Algorithms Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Deep Learning</label>
                            <input type="text" class="form-control" id="" placeholder="Enter Algorithms Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <input type="text" class="form-control" id="" placeholder="Enter Description" />
                        </div>
                    </div>
                </div>
            </div>
            <label class="text-black mb-1 fs-5 fw-semibold">Add On Services</label>
            <div class="row" id="view_add_on" name="view_add_on">
                <div class="col-lg-12">
                    <label class="col-12 text-dark mb-3 fs-6 fw-semibold">Free Services</label>
                    <div class="row">
                        <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Literature Writing</span>
                                    </span>
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Plagiarism Checking</span>
                                    </span>
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Grammer Checking</span>
                                    </span>
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Proof Reading</span>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <label class="col-12 text-dark mb-3 fs-6 fw-semibold">Paid Services</label>
                    <div class="row">
                        <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Plagiarism Checking</span>
                                    </span>
                                    <div class="custom-option-body mt-2">
                                        <span class="badge bg-success text-black fw-bold">1 Hour</span>
                                        <span class="text-info ms-4 fw-bold">
                                            <span class="mdi mdi-currency-rupee"></span>
                                            <span>750</span>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <!-- <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Plagiarism Checking</span>
                                    </span>
                                    <div class="custom-option-body mt-2">
                                        <span class="badge bg-success text-black fw-bold">2 Hour</span>
                                        <span class="text-info ms-4 fw-bold">
                                            <span class="mdi mdi-currency-rupee"></span>
                                            <span>1500</span>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </div> -->
                        <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Poof Reading</span>
                                    </span>
                                    <div class="custom-option-body mt-2">
                                        <span class="badge bg-success text-black fw-bold">1 Hour</span>
                                        <span class="text-info ms-4 fw-bold">
                                            <span class="mdi mdi-currency-rupee"></span>
                                            <span>750</span>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <!-- <div class="col-lg-3 mb-3 align-items-center">
                            <div class="custom-option custom-option-basic ">
                                <label class="custom-option-content">
                                    <span class="custom-option-header">
                                        <span class="h6 mb-0">Plagiarism Checking</span>
                                    </span>
                                    <div class="custom-option-body mt-2">
                                        <span class="badge bg-success text-black fw-bold">1 Hour</span>
                                        <span class="text-info ms-4 fw-bold">
                                            <span class="mdi mdi-currency-rupee"></span>
                                            <span>750</span>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div>
                <label class="text-black mb-1 fs-4 fw-bold mt-4">Payment Information</label>
                <span class="me-1 ms-1">-</span>
                <span class="badge bg-warning text-black fw-bold">Partially Paid</span>
            </div>
            <div class="col-lg-12">
                <div class="row mt-2">
                    <label class="text-black mb-1 fs-5 fw-semibold">Transaction Details</label>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-6 fw-bold">Payment Type</label>
                                <label class="col-7 text-black fs-7 fw-semibold">Bank</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-6 fw-bold">Bank Name</label>
                                <label class="col-7 text-black fs-7 fw-semibold">TMB</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-6 fw-bold">Account No</label>
                                <label class="col-7 text-black fs-7 fw-semibold">20272560000045</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-6 fw-bold">Branch Name</label>
                                <label class="col-7 text-black fs-5 fw-semibold">Anna Nagar, Madurai</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-6 fw-bold">IFSC Code</label>
                                <label class="col-7 text-black fs-6 fw-semibold">HDFC0002027</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-6 fw-bold">Amount</label>
                                <label class="col-7 text-black fs-6 fw-semibold">
                                    <span>Rs.</span>
                                    <span>40,000</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Sub Total Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-info text-white mb-1 fs-6 fw-bold">70,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Add On Services</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-primary text-white mb-1 fs-6 fw-bold">1,500</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Actual Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge text-black mb-1 fs-6 fw-bold" style="background-color:#1ab69d;">70,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">GST (%)</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-secondary text-white mb-1 fs-6 fw-bold">12</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">GST (12%) Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge text-white mb-1 fs-6 fw-bold" style="background-color:#f47507;">10,000</label>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Total Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge text-white mb-1 fs-6 fw-bold" style="background-color:#5e8c36;">80,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Paid Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-warning text-black mb-1 fs-6 fw-bold">40,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Due Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-danger text-white mb-1 fs-6 fw-bold">40,0000</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-outline-secondary me-2">Cancel</button>
            <a href="/manage_customer" class="btn btn-primary me-3">
                Create
            </a>
        </div>
    </div>
</div>

<script>
    function database_func() {
        var database = document.getElementById("database").value;
        var view_database = document.getElementById("view_database");

        if (database == "yes") {
            view_database.style.display = "block";
        } else {
            view_database.style.display = "none";
        }
    }
</script>

<script>
    function properties_func() {
        var properties = document.getElementById("properties");
        var view_properties = document.getElementById("view_properties");

        if (properties.checked) {
            view_properties.style.display = "block";
        } else {
            view_properties.style.display = "none";
        }
    }
</script>
<script>
    $('.quotation_info_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_quotation_info').length);
        let $clone = $('.form-repeater_quotation_info').first().clone().hide();
        $clone.insertBefore('.form-repeater_quotation_info:first').slideDown();
        if (bt == 1) {
            $('.quotation_del').attr('style', 'display: block !important');
        } else {
            $('.quotation_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_quotation_info .quotation_del', e => {
        var bt = parseFloat($('.quotation_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_quotation_info').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.quotation_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<!--end::Modal - Customer Payment-->
<script>
    function payment_func() {
        var payment = document.getElementById("payment").value;
        var cash_det = document.getElementById("cash_det");
        var check_det = document.getElementById("check_det");
        var gpay_det = document.getElementById("gpay_det");
        var paypal_det = document.getElementById("paypal_det");
        var bank_det = document.getElementById("bank_det");
        if (payment == "cash") {
            cash_det.style.display = "block";
            check_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "check") {
            check_det.style.display = "block";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "gpay") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "block";
            paypal_det.style.display = "none";
            bank_det.style.display = "none";
        } else if (payment == "paypal") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "none";
            paypal_det.style.display = "block";
        } else if (payment == "bank") {
            check_det.style.display = "none";
            cash_det.style.display = "none";
            gpay_det.style.display = "none";
            bank_det.style.display = "block";
            paypal_det.style.display = "none";
        } else {
            cash_det.style.display = "none";
            check_det.style.display = "none";
        }
    }
</script>

@endsection