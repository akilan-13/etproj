@extends('layouts/layoutMaster')

@section('title', 'Manage Customer')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')

<!-- Customer List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Customer</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-end align-items-center flex-wrap">
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" title="Export">
                <i class="mdi mdi-calendar-export-outline"></i>
            </a>
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" id="filter" title="Filter">
                <i class="mdi mdi-filter-outline text-center"></i>
            </a>
        </div>
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Customer ID</label>
                    <input type="text" class="form-control" id="" placeholder="Enter Customer ID" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Customer</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Priya</option>
                        <option value="2">Iniya</option>
                        <option value="3">Sabana</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Gender</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                        <option value="3">Others</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Mobile No</label>
                    <input type="text" class="form-control" id="" placeholder="Enter Mobile No" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Course Type</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Professional</option>
                        <option value="2">Tesbo</option>
                        <option value="3">Slash</option>
                        <option value="4">Classic</option>
                        <option value="5">Crash</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Course</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Python For Data Science</option>
                        <option value="2">Core Java</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Batch</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Batch 1</option>
                        <option value="2">Batch 2</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Morning Slot</option>
                        <option value="2">Evening Slot</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot Type</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Weekday Slot</option>
                        <option value="2">Weekend Slot</option>
                        <option value="3">Alternate Slot</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center gap-2">
            <div class="d-flex align-items-center px-1 py-1">
                <label class="bg-danger rounded border border-dark w-25px h-25px me-1" style="background-color: #ffa5a3 !important;"> </label>
                <label class="fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Minimum Product Cost">MPC Value Not Paid</label>
            </div>
            <div class="d-flex align-items-center px-1 py-1">
                <label class="bg-danger rounded border border-dark w-25px h-25px me-1" style="background-color: #cdf3ff !important;"> </label>
                <label class="fs-7 fw-semibold text-black">Batch Not Assigned</label>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-200px">Customer</th>
                            <th class="min-w-200px">Course / Payment Progress</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-100px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        <tr>
                            <td>
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1">Priya</span>
                                            <span><i class="mdi mdi-face-woman text-danger"></i></span>
                                        </label>
                                        <div class="d-block text-primary fs-8" title="Email ID">priya@gmail.com</div>
                                        <div>
                                            <span class="badge bg-success text-black fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Accepted for Fees Schedule">Accepted for FS</span>
                                            <!-- <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Extended Date Accepted"><i class="mdi mdi mdi-help-circle text-dark"></i></a> -->
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex px-1 align-items-center">
                                    <a href="#" class="d-inline-flex position-relative ">
                                        <div class="progress rounded h-80px w-40px rotate-180 border border-gray-400i shadow-lg" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated h-50 w-100 rotate-180" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ffa500">
                                                <span class="text-black fw-bold mb-1">50%</span>
                                            </div>
                                        </div>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Count">2</span>
                                    </a>
                                    <div class="mb-0 align-items-center ms-2">
                                        <label class="fs-7" title="Course">Python For Data Science</label>
                                        <div class="d-flex text-primary fs-8">
                                            <div class="text-danger fs-8" title="Batch">Batch 1</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Professional</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Python For Data Science">Python For Data Science</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 1
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-black fw-bold w-50" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ffa500">50% Course</div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  w-50 text-black fw-bold" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ffa500">50% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <hr class="bg-gray-400">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Tesbo</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Core Java">Core Java</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 1
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-black fw-bold w-50" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ffa500">50% Course</div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated text-black fw-bold w-75" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ec9629">75% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-block">
                                            <div class="progress rounded h-20px w-250px border shadow-lg border-gray-400i  ">
                                                <div class="progress-bar text-black fw-bold w-75" role="progressbar" style="background-color: #ec9629" aria-valuemin="0" aria-valuemax="100">75% Payment</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/sales/manage_customer/payment" target="_blank" class="btn btn-icon btn-sm me-2" title="Payment">
                                        <i class="mdi mdi-account-credit-card-outline fs-3 text-danger"></i>
                                    </a>
                                    <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/sales/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/sales/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr style="background-color: #ffa5a3 !important;">
                            <td>
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1">Sakthi</span>
                                            <span><i class="mdi mdi-face-woman text-black"></i></span>
                                        </label>
                                        <div class="d-block text-black fs-8" title="Email ID">sakthi@gmail.com</div>
                                        <div>
                                            <!-- <span class="badge bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Date Extended" data-bs-toggle="modal" data-bs-target="#kt_modal_request_for_fsc"></span> -->
                                            <a href="javascript:;" class="badge bg-info text-white fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_request_for_fsc"><span>Requested for FS</span></a>

                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex px-1 align-items-center">
                                    <a href="#">
                                        <div class="progress rounded h-80px w-40px rotate-180 border border-gray-400i shadow-lg" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated h-100 w-0 rotate-180" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0% !important;background: #ff0000">
                                                <span class=" text-black fw-bold mb-1">0%</span>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="mb-0 align-items-center ms-2">
                                        <label class="fs-7" title="Course">Python For Data Science</label>
                                        <div class="d-flex text-primary fs-8">
                                            <div class="text-black fs-8" title="Batch">Batch 1</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information text-black fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Professional</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Python For Data Science">Python For Data Science</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 1
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-black fw-bold w-0" role="progressbar" aria-valuemin="0" style="width:0% ! important; background: #ff0000" aria-valuemax="100">0% Course</div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-white fw-bold w-5" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background:  #ff0000;">5% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-block">
                                            <a href="#" class="d-inline-flex position-relative ">
                                                <div class="progress bg-label-info rounded h-20px w-250px border shadow-lg border-gray-400i ">
                                                    <div class="progress-bar progress-bar-striped  progress-bar-animated text-white fw-bold w-5" role="progressbar" style="background: #ff0000" aria-valuemin="0" aria-valuemax="100">5% Payment</div>
                                                </div>
                                                <span class="ms-2 badge badge-center border bg-info" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Initial Fees Remainder Days">02</span>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/sales/manage_customer/payment" target="_blank" class="btn btn-icon btn-sm me-2" title="Payment">
                                        <i class="mdi mdi-account-credit-card-outline fs-3 text-danger"></i>
                                    </a>
                                    <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/sales/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/sales/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1">Iniya</span>
                                            <span><i class="mdi mdi-face-woman text-danger"></i></span>
                                        </label>
                                        <div class="d-block text-primary fs-8" title="Email ID">iniya@gmail.com</div>
                                        <div class="mt-2 animation-blink badge bg-danger text-white fw-bold  fs-8">Course Date Extended</div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex px-1 align-items-center">
                                    <a href="#" class="d-inline-flex position-relative ">
                                        <div class="progress rounded h-80px w-40px rotate-180 border border-gray-400i shadow-lg" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Progress">
                                            <div class="progress-bar progress-bar-striped h-75 w-100 rotate-180" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ec9629">
                                                <span class=" text-black fw-bold mb-1">75%</span>
                                            </div>
                                        </div>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Count">2</span>
                                    </a>
                                    <div class="mb-0 align-items-center ms-2">
                                        <label class="fs-7" title="Course">Core Java</label>
                                        <div class="d-flex fs-8">
                                            <div class="text-danger fs-8" title="Batch">Batch 2</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Tesbo</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Core Java">Core Java</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 2
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-black fw-bold w-75" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="background: #ec9629">75% Course</div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated text-black fw-bold w-50" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ffa500">50% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <hr class="bg-gray-400">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Professional</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Python For Data Science">Python For Data Science</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 1
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped  text-black fw-bold" style="width: 0% !important; background: #ff0000" aria-valuenow="0" role="progressbar" aria-valuemin="0" aria-valuemax="100">0% Course</div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated text-black fw-bold w-50" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ffa500">50% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-block">
                                            <div class="progress rounded h-20px w-250px border shadow-lg border-gray-400i ">
                                                <div class="progress-bar progress-bar-striped  progress-bar-animated text-black fw-bold w-50" role="progressbar" style="background: #ffa500" aria-valuemin="0" aria-valuemax="100">50% Payment</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/sales/manage_customer/payment" target="_blank" class="btn btn-icon btn-sm me-2" title="Payment">
                                        <i class="mdi mdi-account-credit-card-outline fs-3 text-black"></i>
                                    </a>
                                    <!-- <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                        <span class="badge bg-primary rounded-pill position-absolute top-0 start-100 translate-middle fs-9 px-0 py-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course"><i class="mdi mdi-check fs-9"></i></span>
                                    </a> -->
                                    <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/sales/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/sales/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1">Madhu</span>
                                            <span><i class="mdi mdi-face-woman text-danger"></i></span>
                                        </label>
                                        <div class="d-block text-primary fs-8" title="Email ID">madhu@gmail.com</div>
                                        <div>
                                            <span class="badge bg-warning text-black fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Rejected for Fees Schedule">Rejected for FS</span>
                                            <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Already Overdue"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex px-1 align-items-center">
                                    <a href="#" class="d-inline-flex position-relative ">
                                        <div class="progress rounded h-80px w-40px rotate-180 border border-gray-400i shadow-lg" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Progress">
                                            <div class="progress-bar progress-bar-striped  h-100 w-100 rotate-180" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #008000;">
                                                <span class="text-white fw-bold mb-1">100%</span>
                                            </div>
                                        </div>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Count">2</span>
                                    </a>
                                    <div class="mb-0 align-items-center ms-2">
                                        <label class="fs-7" title="Course">Core Python</label>
                                        <div class="d-flex  fs-8">
                                            <div class="text-danger fs-8" title="Batch">Batch 4</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Tesbo</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Core Java">Core Python</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 1
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-white fw-bold w-100" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="background: #008000">100% Course
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-black fw-bold w-50" role="progressbar" aria-valuemin="0" style="background: #ec9629" aria-valuemax="100">75% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <hr class="bg-gray-400">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Professional</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Python For Data Science">Python For Data Science</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 1
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-black fw-bold" style="width: 0% !important; background: #ff0000" aria-valuenow="0" role="progressbar" aria-valuemin="0" aria-valuemax="100">0% Course</div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="col-12">
                                                                <div class="progress  mb-2 h-15px border border-dark">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated text-black fw-bold w-50" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ffa500">50% Payment</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-block">
                                            <div class="progress rounded h-20px w-250px border shadow-lg border-gray-400i  ">
                                                <div class="progress-bar text-black fw-bold w-75" role="progressbar" style="background-color: #ec9629" aria-valuemin="0" aria-valuemax="100">75% Payment</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/sales/manage_customer/payment" target="_blank" class="btn btn-icon btn-sm me-2" title="Payment">
                                        <i class="mdi mdi-account-credit-card-outline fs-3 text-black"></i>
                                    </a>
                                    <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/sales/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/sales/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1">Sabana</span>
                                            <label><i class="mdi mdi-face-woman text-danger"></i></label>
                                            <span><i class="mdi mdi-cake-variant-outline animation-blink text-primary fs-4"></i></span>
                                        </label>
                                        <div class="d-block text-primary fs-8" title="Email ID">sabanabarveen@gmail.com</div>
                                    </div>
                                </div>
                            </td>
                            <!-- <td>
                                <label>8585457845</label>
                                <div class="d-block">

                                </div>
                            </td> -->
                            <td>
                                <div class="d-flex px-1 align-items-center">
                                    <a href="#" class="">
                                        <div class="progress rounded h-80px w-40px rotate-180 border border-gray-400i shadow-lg" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated h-25 w-100 rotate-180" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="background: #ff0000">
                                                <span class="text-white fw-bold mb-1">25%</span>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="mb-0 align-items-center ms-2">
                                        <label class="fs-7" title="Course">Python For Data Science</label>
                                        <div class="d-flex text-primary fs-8">
                                            <div class="text-danger fs-8" title="Batch">Batch 3</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">
                                                            <span class="badge bg-info fw-bold">Professional</span></label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Python For Data Science">Python For Data Science</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 3
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-white fw-bold w-25" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="background: #ff0000">25% Course
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress  mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated  text-white fw-bold w-100" role="progressbar" aria-valuemin="0" style="background: #008000" aria-valuemax="100">100% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-block">
                                            <div class="progress rounded h-20px w-250px border shadow-lg border-gray-400i ">
                                                <div class="progress-bar progress-bar-striped  progress-bar-animated text-white fw-bold w-100" role="progressbar" style="background: #008000" aria-valuemin="0" aria-valuemax="100">100% Payment</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/sales/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/sales/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr style="background-color: #cdf3ff !important;">
                            <td>
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1">Dharshini</span>
                                            <span><i class="mdi mdi-face-woman text-black"></i></span>
                                        </label>
                                        <div class="d-block text-primary fs-8" title="Email ID">dharshini@gmail.com</div>

                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex px-1 align-items-center">
                                    <a href="#">
                                        <div class="progress rounded h-80px w-40px rotate-180 border border-gray-400i shadow-lg" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated h-100 w-0 rotate-180" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0% !important; background: #ff0000">
                                                <span class=" text-black fw-bold mb-1">0%</span>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="mb-0 align-items-center ms-2">
                                        <label class="fs-7" title="Course">Core Python</label>
                                        <div class="d-flex  fs-8">
                                            <div class="text-black fs-8" title="Batch">Batch 6</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Type</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Tesbo</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Course</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold" title="Core Java">Core Python</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Batch</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Batch 6
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Slot</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Morning Slot
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Staff</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Madhu
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Duration</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">
                                                            <span class="badge bg-success text-black fs-8 fw-bold" title="Start Date">15-Jun-2024</span>
                                                            <span class="text-black fs-8 fw-bold me-1 ms-1">|</span>
                                                            <span class="badge bg-danger text-black fs-8 fw-bold" title="End Date">15-Sep-2024</span>
                                                        </label>
                                                    </div>
                                                    <div class="row my-4">
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated text-black fw-bold w-0" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0% !important; background: #ff0000">0% Course
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="progress mb-2 h-15px border border-dark">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated w-50 text-black fw-bold" role="progressbar" aria-valuemin="0" style="background: #ec9629" aria-valuemax="100">75% Payment</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-block">
                                            <div class="progress rounded h-20px w-250px border shadow-lg border-gray-400i  ">
                                                <div class="progress-bar text-black fw-bold w-75" role="progressbar" style="background-color: #ec9629" aria-valuemin="0" aria-valuemax="100">75% Payment</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/sales/manage_customer/payment" target="_blank" class="btn btn-icon btn-sm me-2" title="Payment">
                                        <i class="mdi mdi-account-credit-card-outline fs-3 text-black"></i>
                                    </a>
                                    <!-- <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                        <span class="badge bg-primary rounded-pill position-absolute top-0 start-100 translate-middle fs-9 px-0 py-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course"><i class="mdi mdi-check fs-9"></i></span>
                                    </a> -->
                                    <a href="{{url('/sales/manage_customer/customer_add_course')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Course">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/sales/manage_customer/batch_add_course')}}" target="_blank" class="dropdown-item"> <span> <i class="mdi mdi-badge-account-horizontal-outline fs-3 text-black me-1"></i>Assign Batch</span></a>
                                        <a href="{{url('/sales/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/sales/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Delete Customer-->
<div class="modal fade" id="kt_modal_delete_customer" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                delete Customer ?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya</label>
                    <span class="ms-2 me-2">-</span>
                    <label>EACUS-0001/24</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Customer-->


<!--begin::Modal - Request For FSC-->
<div class="modal fade" id="kt_modal_request_for_fsc" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Requested for Fees Schedule Count</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-6 mb-3 text-center">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Previous Allocated Count</label>
                        <div class="d-block">
                            <div class="badge bg-info mb-1 fs-6 fw-semibold">02</div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3 text-center">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Extended Count</label>
                        <div class="d-block">
                            <div class="badge bg-warning text-black mb-1 fs-6 fw-semibold">01</div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason</label>
                        <div class="d-block">
                            <label class="text-dark mb-1 fs-6 fw-bold">&emsp;&emsp;-</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_acpt" name="fsc_status" onclick="fsc_sts_func('accept');" checked />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Approved</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_rejt" name="fsc_status" onclick="fsc_sts_func('reject');" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Rejected</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3" id="rejct_tbox" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Reason"></textarea>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal" id="smt_butt">Approved</a>
                    </div>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Request For FSC-->

<script>
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Rejected";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        }
    }
</script>
<style>
    #course {
        /* background-image: linear-gradient(to bottom, #1397c7, #007fbe, #0066b3, #004da4, #11318f); */
        background: rgb(13, 214, 80);
        background: linear-gradient(90deg, rgba(13, 214, 80, 1) 0%, rgba(64, 121, 9, 1) 35%, rgba(134, 255, 0, 1) 100%);
    }
</style>

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection