@extends('layouts/layoutMaster')

@section('title', 'View Customer')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

@section('content')

<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">View Customer Details</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Customer</a>
                </li>
            </ol>
        </nav>
    </div>
    <!-- Customer View Details -->
    <div class="card-body">
        <h5 class="title mb-1 fw-bold">Basic Information</h5>
        <div class="row mt-4">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Priya</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Gender</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Female</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Date of Birth</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">14-Sep-1999</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Mobile Number</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Alternate Number</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">priya@gmail.com</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">University Name</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Madurai kamarajar University</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Guide Name</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Roshini</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Lead Type</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Student</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Lead Source</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Website</label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Door No / Flat No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">12</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">City</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Madurai</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">State</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Tamil Nadu</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Country</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">India</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Area / street</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">IInd Floor, B Block, Elysium Campus, Church
                        Rd, Anna Nagar</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Pin Code</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">625012</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Address</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">12, IInd Floor, B Block, Elysium Campus, Church
                        Rd, Anna Nagar, Madurai, Tamil Nadu, India Pincode-625012. </label>
                </div>
            </div>
        </div>
        <label class="fs-5 text-black mb-1 fw-bold mt-4">Service Information</label>
        <div class="row mt-4">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Service Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 fs-6 fw-bold">
                        <span class="badge bg-danger">Development Service</span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Service Sub Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Python Development</label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Duration (In Days)</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">15 - 20 Days</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Set Properties</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">
                        <span class="badge bg-primary">Yes</span>
                    </label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Title</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 fs-6 fw-bold text-black">Computer Science- BlockChain technology-ML/DL</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Language</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Python</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Domain</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Cybersecurity</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Database</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">
                        No
                    </label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Algorithms</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Machine Learning, Deep Learnings</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Machine Learning</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">Decision Tree Algorithms, KNN Algorithms
                    </label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-black fs-7 fw-semibold">Deep Learning</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold">ANN Algorithms, CNN Algorithms
                    </label>
                </div>
            </div>
        </div>
        <div class="row">
            <div>
                <label class="text-black mb-1 fs-4 fw-bold mt-4">Payment Information</label>
                <span class="me-1 ms-1">-</span>
                <span class="badge bg-warning text-black fw-bold">Partially Paid</span>
            </div>
            <div class="col-lg-12">
                <div class="row mt-2">
                    <label class="text-black mb-1 fs-5 fw-semibold">Transaction Details</label>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-7 fw-semibold">Payment Type</label>
                                <label class="col-7 text-black fs-6 fw-bold">Bank</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-7 fw-semibold">Bank Name</label>
                                <label class="col-7 text-black fs-6 fw-bold">TMB</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-7 fw-semibold">Account No</label>
                                <label class="col-7 text-black fs-6 fw-bold">20272560000045</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-7 fw-semibold">Branch Name</label>
                                <label class="col-7 text-black fs-6 fw-bold">Anna Nagar, Madurai</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-7 fw-semibold">IFSC Code</label>
                                <label class="col-7 text-black fs-6 fw-bold">HDFC0002027</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-5 text-black fs-7 fw-semibold">Amount</label>
                                <label class="col-7 text-black fs-6 fw-bold">
                                    <span>Rs.</span>
                                    <span>40,000</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Sub Total Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-info text-white mb-1 fs-6 fw-bold">70,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Add On Services</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-primary text-white mb-1 fs-6 fw-bold">1,500</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Actual Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge text-black mb-1 fs-6 fw-bold" style="background-color:#1ab69d;">70,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">GST (%)</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-secondary text-white mb-1 fs-6 fw-bold">12</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">GST (12%) Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge text-white mb-1 fs-6 fw-bold" style="background-color:#f47507;">10,000</label>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Total Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge text-white mb-1 fs-6 fw-bold" style="background-color:#5e8c36;">80,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Paid Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-warning text-black mb-1 fs-6 fw-bold">40,000</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="text-center">
                    <label class="text-black mb-1 fs-5 fw-bold">Due Amount</label>
                    <div class="d-block mt-2">
                        <label class="badge bg-danger text-white mb-1 fs-6 fw-bold">40,0000</label>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Customer View Details End-->
</div>

@endsection