@extends('layouts/layoutMaster')

@section('title', 'Create Quotation')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection
@section('content')


<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Quotation</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Lead Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Quotation</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name">
                                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
                            </label>
                            <label class="fs-5 align-items-center text-black fw-bold">
                                <span>Priya Dharshini</span>
                                <span class="badge bg-danger text-white fs-8 rounded">F</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div class="row">
                            <div class="justify-content-start">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Phone No">
                                    <i class="mdi mdi-phone-plus fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-bold">
                                    <span>9876543210</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">
                                <i class="mdi mdi-laptop fs-3 text-black"></i>
                            </label>
                            <label class="fs-6 align-items-center text-black fw-bold">
                                <span class="badge bg-info text-white fw-bold">Development Service</span>
                            </label>
                        </div>
                    </div> -->
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-2">
                        <div class="row">
                            <div class="justify-content-start">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">
                                    <i class="mdi mdi-card-account-mail-outline fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-bold">
                                    <span>priya@gmail.com</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div class="row">
                            <div class="justify-content-start">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Address">
                                    <i class="mdi mdi-map-marker-outline fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-bold">
                                    <span>1</span>
                                    <span>,</span>
                                    <span>Bharathiyar Street, Avaniyapuram</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Location">
                                <i class="mdi mdi-map-check-outline fs-3 text-black"></i>
                            </label>
                            <label class="fs-6 align-items-center text-black fw-bold">
                                <span>India</span><span>,</span>
                                <span>Tamilnadu</span><span>,</span>
                                <span>Madurai</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">
                                <i class="mdi mdi-desktop-classic fs-3 text-black"></i>
                            </label>
                            <label class="fs-6 align-items-center text-black fw-bold">
                                <span>Computer Science- BlockChain technology-ML/DL</span><span>
                            </label>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Estimated No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Estimated No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Estimated Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_date" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Validity Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="quotation_validity" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Estimated Status<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Estimated Status</option>
                            <option value="1">Accepted</option>
                            <option value="2">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Sales<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Sales Person</option>
                            <option value="1">Sabana Barveen</option>
                            <option value="2">Mithra</option>
                            <option value="2">Salini </option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="row mt-4">
                        <div class="col-lg-12">
                            <h4 class="card-title mb-1 fw-bold">Service Details</h4>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Service Category<span class="text-danger">*</span></label>
                            <select id="" class="select3 form-select">
                                <option value="">Select Service Category</option>
                                <option value="1">Reasearch Services</option>
                                <option value="2">PHD Services</option>
                                <option value="3">Writing Services</option>
                                <option value="4">Development Services</option>
                                <option value="5">Analysis Services</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Service Sub Category<span class="text-danger">*</span></label>
                            <select id="ser_sub_cat" class="select3 form-select">
                                <option value="">Select Service Sub Category</option>
                                <option value="1">Research Paper Writing Service </option>
                                <option value="2">Book Writing Service</option>
                                <option value="3">Scopus Indexed Journal </option>
                                <option value="4">Python Development </option>
                                <option value="5">SPSS Analysis</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
                            <select id="duration" class="select3 form-select" data-style="btn-default" data-live-search="true">
                                <option value="">Select Duration</option>
                                <option value="1">3 - 5 Working Days</option>
                                <option value="2">5 - 7 Working Days</option>
                                <option value="3">7 - 9 Working Days</option>
                                <option value="4">10 - 15 Working Days</option>
                                <option value="5">15 - 20 Working Days</option>
                                <option value="6">20 - 25 Working Days</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                            <select id="currency_format" class="select3 form-select" data-style="btn-default" data-live-search="true">
                                <option value="">Select Currency Format</option>
                                <option value="1">USD</option>
                                <option value="2">EUR</option>
                                <option value="3">GBP</option>
                                <option value="4">AUD</option>
                                <option value="5">INR</option>
                                <option value="6">KWD</option>
                            </select>
                        </div>
                        <div class="col-lg-4 d-flex align-items-center">
                            <div class="form-check form-check-inline mt-4">
                                <input class="form-check-input" type="checkbox" type="checkbox" id="add_on" name="add_on" onclick="add_on_func();" />
                                <label class="text-black mb-1 fs-5 fw-semibold">Add On Services</label>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4" id="view_add_on" name="view_add_on" style="display:none;">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-xl-6 mb-2">
                                    <div class="card">
                                        <a class="card-body max-h-500px scroll-y">
                                            <div class="row">
                                                <div class="col-12 text-end">
                                                    <label class="badge bg-info rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Free</label>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="checkbox" id="add_on_chk_all" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Plagiarism Check</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input add_on_ver_chk" type="checkbox" />
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Proof Reading </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="card">
                                        <a class="card-body max-h-500px scroll-y">
                                            <div class="row">
                                                <div class="col-12 text-end">
                                                    <label class="badge bg-success text-black fw-bold rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Paid</label>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input" type="checkbox" id="add_on_chk_all_paid" />
                                                            <label class="text-dark mb-1 fs-6 fw-semibold">Select All</label>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input  add_on_ver_chk_paid" type="checkbox" />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Literature Review</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input add_on_ver_chk_paid" type="checkbox" />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input add_on_ver_chk_paid" type="checkbox" />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-7">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input add_on_ver_chk_paid" type="checkbox" />
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Grammer Checking</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">1 Hour</label>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <label class="text-danger mb-1 fs-6 fw-semibold">750</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-12">
                            <h4 class="card-title mb-1 fw-bold">Payment Details</h4>
                        </div>
                        <div class="row mt-4">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Enter Amount<span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Add-On-Service Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control me-2" id="" placeholder="Add-On-Service Amount" readonly value="1500" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Sub Total Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control me-2" id="" placeholder="Sub Total Amount" readonly value="70,000" />
                            </div>
                            <div class="col-lg-2 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Enter GST(%)<span class="text-danger">*</span></label>
                                <input type="text" class="form-control me-2" id="" placeholder="Enter GST" />
                            </div>
                            <div class="col-lg-2 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">GST Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control me-2" id="" placeholder="Enter GST" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Total Amount<span class="text-danger">*</span></label>
                                <input type="text" class="form-control me-2" id="" placeholder="Total Amount" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                                <select id="payment" name="payment" class="select3 form-select">
                                    <option value="">Select Payment Slot</option>
                                    <option value="1">Single</option>
                                    <option value="2">Dual</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Template<span class="text-danger">*</span></label>
                                <select id="template_slot" name="template_slot" class="select3 form-select" onchange="template_slot_func();">
                                    <option value="">Select Template</option>
                                    <option value="template_1">Template 1</option>
                                    <!-- <option value="template_2">Template 2</option> -->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="accordion accordion-popout" id="slot_details">
                                    <div class="accordion-item active">
                                        <h2 class="accordion-header" id="headingPopoutOne">
                                            <button type="button" class="accordion-button" data-bs-toggle="collapse" data-bs-target="#slot_detailsOne" aria-expanded="true" aria-controls="slot_detailsOne">
                                                <span class="text-black fw-bold">Slot Details</span>
                                            </button>
                                        </h2>
                                        <div id="slot_detailsOne" class="accordion-collapse collapse show" aria-labelledby="headingPopoutOne" data-bs-parent="#slot_details">
                                            <div class="accordion-body">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="row mt-2" style="display:none;" id="view_single_template_slot">
                                                            <div class="col-lg-12">
                                                                <div class="row">
                                                                    <div class="col-lg-2 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Slot</label>
                                                                        <textarea class="form-control " rows="7" id="" placeholder="Enter Slot" disabled>(To Start The Work)</textarea>
                                                                    </div>
                                                                    <div class="col-lg-4 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables</label>
                                                                        <div id="create_slot1" class="scroll-y max-h-150px">
                                                                            <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                                <ul>
                                                                                    <li><span style="color: rgb(0, 0, 0);">Technical Discussion</span></li>
                                                                                    <li><span style="color: rgb(0, 0, 0);">Flow of the Work (Novelty and Dataset)</span></li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-4 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Note</label>
                                                                        <div id="create_slot_note1" class="scroll-y max-h-150px">
                                                                            <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                                <p style="color: black !important;">Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-2 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Amount</label><span class="text-danger">*</span>
                                                                        <input type="text" class="form-control" placeholder="Enter Amount" value="" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <div class="row">
                                                                    <div class="col-lg-2 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Slot</label>
                                                                        <textarea class="form-control " rows="7" id="" placeholder="Enter Slot" disabled>(After taking the Demo)(Before taking the Delivery of Coding)</textarea>
                                                                    </div>
                                                                    <div class="col-lg-4 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables</label>
                                                                        <div id="create_slot2" class="scroll-y max-h-150px">
                                                                            <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                                <ul>
                                                                                    <li><span>Source Code</span></li>
                                                                                    <li><span>Pseudo Code</span></li>
                                                                                    <li><span>Demo through Running video</span></li>
                                                                                    <li><span>Results As per client specification-As per the Description</span></li>
                                                                                    <li><span>Software Installation</span></li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-4 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Note</label>
                                                                        <div id="create_slot_note2" class="scroll-y max-h-150px">
                                                                            <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                                <ul>
                                                                                    <li><span>Each and every step will be acknowledged by you</span></li>
                                                                                    <li><span>Every Section and Module of the Coding part will be clearly explained in the Google meet.Entire Technical Knowledge will be given to you,until the client understands the concept</span></li>
                                                                                    <li><span>As per the acknowledged description.We will be work on it</span></li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-2 mb-3">
                                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Amount</label><span class="text-danger">*</span>
                                                                        <input type="text" class="form-control" placeholder="Enter Amount" value="" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row mt-2" style="display:none;" id="view_double_template_slot">
                                                        <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="4" id="" placeholder="Enter Slot I"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                                    <div id="create_slot2" class="scroll-y max-h-70px">
                                                                        <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                                    <div id="create_slot_note2" class="scroll-y max-h-70px">
                                                                        <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot II<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="4" id="" placeholder="Enter Slot II"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                                    <div id="create_slot3" class="scroll-y max-h-70px">
                                                                        <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                                    <div id="create_slot_note3" class="scroll-y max-h-70px">
                                                                        <div class="ql-editor" data-gramm="false" contenteditable="true" data-placeholder="Type Something...">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row mt-2" style="display:none;" id="view_triple_template_slot">
                                                        <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot I<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Slot I"></textarea>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot II<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Slot II"></textarea>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot III<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Slot III"></textarea>
                                                                </div>
                                                                <div class="col-lg-2 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Amount"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Deliverables"></textarea>
                                                                </div>
                                                                <div class="col-lg-4 mb-3">
                                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Note<span class="text-danger">*</span></label>
                                                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Note"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-lg-4">
                                <div class="row">
                                    <label class="text-dark fs-6 fw-semibold mb-2">Authorised Signature<span class="text-danger">*</span></label>
                                    <div class="col-lg-6">
                                        <div class="align-items-sm-center gap-4">
                                            <img src="{{asset('assets/phdizone_images/phdizone_icon.png')}}" alt="user-avatar" class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid" id="uploadedsignature" />
                                            <div class="button-wrapper">
                                                <div class="d-flex align-items-start mt-2 mb-2">
                                                    <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Signature">
                                                        <i class="mdi mdi-tray-arrow-up"></i>
                                                        <input type="file" id="upload" class="file-in" hidden accept="image/png, image/jpeg" />
                                                    </label>
                                                    <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Signature">
                                                        <i class="mdi mdi-reload"></i>
                                                    </button>
                                                </div>
                                                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <button type="reset" class="btn btn-outline-secondary me-2">Cancel</button>
                <a href="/manage_proposal" class="btn btn-primary me-3">
                    Create
                </a>
            </div>
        </div>
    </div>

    <script>
        let logofile = document.getElementById('uploadedsignature');
        const fileInput = document.querySelector('.file-in'),
            resetFileInput = document.querySelector('.file-reset');

        if (logofile) {
            const resetImage = logofile.src;
            fileInput.onchange = () => {
                if (fileInput.files[0]) {
                    logofile.src = window.URL.createObjectURL(fileInput.files[0]);
                }
            };
            resetFileInput.onclick = () => {
                fileInput.value = '';
                logofile.src = resetImage;
            };
        }
    </script>

    <script>
        function add_on_func() {
            var add_on = document.getElementById("add_on");
            var view_add_on = document.getElementById("view_add_on");

            if (add_on.checked) {
                view_add_on.style.display = "block";
            } else {
                view_add_on.style.display = "none";
            }
        }
    </script>

    <script>
        $('#add_on_chk_all').change(function() {
            $('.add_on_ver_chk').prop('checked', this.checked);
        });

        $('.add_on_ver_chk').change(function() {
            if ($('.add_on_ver_chk:checked').length == $('.add_on_ver_chk').length) {
                $('#add_on_chk_all').prop('checked', true);
            } else {
                $('#add_on_chk_all').prop('checked', false);
            }

        });
    </script>

    <script>
        $('#add_on_chk_all_paid').change(function() {
            $('.add_on_ver_chk_paid').prop('checked', this.checked);
        });

        $('.add_on_ver_chk_paid').change(function() {
            if ($('.add_on_ver_chk_paid:checked').length == $('.add_on_ver_chk_paid').length) {
                $('#add_on_chk_all_paid').prop('checked', true);
            } else {
                $('#add_on_chk_all_paid').prop('checked', false);
            }

        });
    </script>

    <script>
        $('.quotation_info_add').on('click', e => {
            var bt = parseFloat($('.form-repeater_quotation_info').length);
            let $clone = $('.form-repeater_quotation_info').first().clone().hide();
            $clone.insertBefore('.form-repeater_quotation_info:first').slideDown();
            if (bt == 1) {
                $('.quotation_del').attr('style', 'display: block !important');
            } else {
                $('.quotation_del').attr('style', 'display: block !important');
            }
        });

        $(document).on('click', '.form-repeater_quotation_info .quotation_del', e => {
            var bt = parseFloat($('.quotation_del').length);
            // alert(bt);
            $(e.target).closest('.form-repeater_quotation_info').slideUp(400, function() {
                $(this).remove()
            });
            if (bt == 2) {
                $('.quotation_del').attr('style', 'display: none !important');
            } else {}
        });
    </script>

    <script>
        function template_slot_func() {
            var template_slot = document.getElementById("template_slot").value;
            var template_1 = document.getElementById("template_1");
            var template_2 = document.getElementById("template_2");

            if (template_slot == "template_1") {
                view_single_template_slot.style.display = "block";
                view_double_template_slot.style.display = "none";
            } else if (template_slot == "template_2") {
                view_double_template_slot.style.display = "block";
                view_single_template_slot.style.display = "none";
            } else {

            }
        }
    </script>

    @endsection