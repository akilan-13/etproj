@extends('layouts/layoutMaster')

@section('title', 'Manage Customer')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')

<!-- Customer List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Customer</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-end align-items-center flex-wrap">
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" title="Export">
                <i class="mdi mdi-calendar-export-outline"></i>
            </a>
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" id="filter" title="Filter">
                <i class="mdi mdi-filter-outline text-center"></i>
            </a>
            <!-- <a href="{{url('/manage_customer/customer_add')}}" class="btn btn-sm fw-bold btn-primary me-2 mb-2">
                <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Customer
            </a> -->
        </div>
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Customer ID</label>
                    <input type="text" class="form-control" id="" placeholder="Enter Customer ID" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Customer</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Priya</option>
                        <option value="2">Iniya</option>
                        <option value="3">Sabana</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Gender</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                        <option value="3">Others</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Mobile No</label>
                    <input type="text" class="form-control" id="" placeholder="Enter Mobile No" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Course Type</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Professional</option>
                        <option value="2">Tesbo</option>
                        <option value="3">Slash</option>
                        <option value="4">Classic</option>
                        <option value="5">Crash</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Course</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Python For Data Science</option>
                        <option value="2">Core Java</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Batch</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Batch 1</option>
                        <option value="2">Batch 2</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Morning Slot</option>
                        <option value="2">Evening Slot</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Slot Type</label>
                    <select id="" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Weekday Slot</option>
                        <option value="2">Weekend Slot</option>
                        <option value="3">Alternate Slot</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">Customer</th>
                            <th class="min-w-100px">Service</th>
                            <th class="min-w-100px">Project</th>
                            <th class="min-w-100px">Status</th>
                            <th class="min-w-100px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        <tr>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label>
                                        <span class="fs-7 me-1">Priya Dharshini</span>
                                        <span class="badge bg-danger text-white fs-8 rounded">F</span>
                                    </label>
                                    <div class="d-block text-dark fs-8" title="Email ID">priya@gmail.com</div>
                                </div>
                                <div class="mt-1">
                                    <span class="badge bg-success text-black fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Accepted for Fees Schedule">Accepted for FS</span>
                                </div>
                            </td>
                            <td>
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Development Services</label>
                                <div class="d-block">
                                    <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">Python Services</label>
                                </div>
                                <!-- <label class="badge bg-warning text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add-on-Services">Yes</label> -->
                                <div class="d-block">
                                    <label class="text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add-on-Services">
                                        <span class="mdi mdi-plus-network-outline"></span>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label class="max-w-150px text-truncate" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Computer Science- BlockChain technology-ML/DL">Computer Science- BlockChain technology-ML/DL</label>
                                    <div class="d-flex text-primary fs-8">
                                        <div class="d-block">
                                            <label class="badge bg-info fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">Partially Paid</label>
                                        </div>
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Sub Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fw-bold fs-8">70,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">GST (18%)</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">10,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-success     fs-8 fw-bold">80,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Paid Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">40,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Due Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-danger fs-8 fw-bold">40,000</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-center">
                                <!-- <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_nda" data-bs-placement="bottom" title="NDA">
                                    <span class="text-black fw-bold"> <span class="mdi mdi-file-sign fs-3"></span></span></a> -->
                                <div class="text-primary fs-8">
                                    <div class="d-block">
                                        <label class="badge bg-secondary text-white fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Process Status">-</label>
                                    </div>
                                    <!-- <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <div class="text-end">
                                                    <label class="text-black fs-8 fw-semibold badge bg-warning text-end fw-bold">
                                                        <span>12</span>
                                                        <span>/</span>
                                                        <span>20 Days</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Technical Discussion, Flow of the Work</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Source Code , Pseudo Code</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Technical Discussion, Flow of the Work</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Software Installation</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-alpha-x-circle-outline text-danger fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Support Section</label>
                                            </div>
                                        </div> -->
                                </div>
                                <!-- <div class="mt-1">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_nda">
                                        <span class="text-danger fw-bold">NDA</span></a>
                                </div> -->
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/manage_customer/customer_invoice_add" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Invoice">
                                        <i class="mdi mdi-cash-sync text-danger fs-2"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_nda" data-bs-placement="bottom" title="NDA">
                                        <i class="mdi mdi-file-sign text-black fs-3"></i>
                                    </a>
                                    <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_quotation" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal">
                                        <i class="mdi mdi-note-plus-outline fs-3"></i>
                                    </a>
                                    <!-- <a href="javascript:;" class="fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_quotation">Quotation</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_invoice">Invoice</a>
                                    </div> -->
                                    <!-- <a href="/manage_customer/customer_invoice" data-bs-toggle="tooltip" data-bs-placement="bottom" target="_blank" class="btn btn-icon btn-sm me-2" title="Add Invoice">
                                        <i class="mdi mdi-invoice-text-edit-outline fs-3 text-black"></i>
                                    </a> -->
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <!-- <a href="/sales/manage_lead/lead_worklist" class="dropdown-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Work List">
                                            <i class="mdi mdi-list-box-outline fs-3 text-black me-1"></i>Work List
                                        </a>
                                        <a href="/production/manage_cre/project_view" class="dropdown-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Work Assign">
                                            <i class="mdi mdi-clipboard-check-outline fs-3 text-black me-1"></i>Work Assign
                                        </a> -->
                                        <a href="{{url('/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('customer/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label>
                                        <span class="fs-7 me-1">Sharmila</span>
                                        <span class="badge bg-danger text-white fs-8 rounded">F</span>
                                    </label>
                                    <div class="d-block text-dark fs-8" title="Email ID">sharmi@gmail.com</div>
                                </div>
                            </td>
                            <td>
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Writing Services</label>
                                <div class="d-block">
                                    <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">Thesis Writing</label>
                                </div>
                                <div class="d-block">
                                    <label class="text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add-on-Services">
                                        <span class="mdi mdi-plus-network-outline"></span>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label class="max-w-150px text-truncate" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Scopues Q1/Q2 Research Paper">Scopues Q1/Q2 Research Paper</label>
                                    <div class="d-flex text-primary fs-8">
                                        <div class="d-block">
                                            <label class="badge bg-success text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">Paid</label>
                                        </div>
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Sub Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fw-bold fs-8">70,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">GST (18%)</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">10,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-success fs-8 fw-bold">80,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Paid Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">80,000</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <!-- <div class="text-center">
                                    <label>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_nda" data-bs-placement="bottom" title="NDA">
                                            <span class="text-black fw-bold"> <span class="mdi mdi-file-sign fs-3"></span></span></a>
                                    </label>
                                </div> -->
                                <div class="mb-0 align-items-center">
                                    <div class="d-flex text-primary fs-8">
                                        <div class="d-block">
                                            <label class="badge bg-secondary text-white fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Process Status">30% Completed</label>
                                        </div>
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <div class="text-end">
                                                    <label class="text-black fs-8 fw-semibold badge bg-warning text-end fw-bold">
                                                        <span>12</span>
                                                        <span>/</span>
                                                        <span>20 Days</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Technical Discussion, Flow of the Work</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Source Code , Pseudo Code</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Technical Discussion, Flow of the Work</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Software Installation</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-alpha-x-circle-outline text-danger fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Support Section</label>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="mt-1 text-center">
                                        <label>
                                            <span class="text-info fw-bold">NDA Shared</span>
                                        </label>
                                    </div> -->
                                </div>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/manage_customer/payment" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Payment">
                                        <i class="mdi mdi-cash-sync text-danger fs-2"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_nda_generation" title="NDA Shared">
                                        <i class="mdi mdi-file-sign text-info fs-3"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2 d-inline-flex position-relative" data-bs-toggle="modal" data-bs-placement="bottom" title="" data-bs-target="#kt_modal_view_quotation">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Quotation">02</span>
                                    </a>
                                    <!-- <a href="javascript:;" data-bs-toggle="modal" data-bs-placement="bottom" data-bs-toggle="modal" data-bs-target="#kt_modal_add_service" class="btn btn-icon btn-sm me-2" title="Add Service">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a> -->
                                    <!-- <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_nda" data-bs-placement="bottom" title="NDA">
                                        <span class="text-black fw-bold"> <span class="mdi mdi-file-sign fs-3"></span></span></a> -->
                                    <!-- <a href="/manage_customer/customer_invoice" target="_blank" class="btn btn-icon btn-sm me-2 d-inline-flex position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Invoice">
                                        <i class="mdi mdi-invoice-text-edit-outline fs-3 text-black"></i>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Invoice Completed"><i class="mdi mdi-check"></i></span>
                                    </a> -->
                                    <!-- <a href="{{url('/manage_customer/customer_add_service')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Service">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                    </a> -->
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="/sales/manage_lead/lead_worklist" class="dropdown-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Work List">
                                            <i class="mdi mdi-list-box-outline fs-3 text-black me-1"></i>Work List
                                        </a>
                                        <a href="/production/manage_cre/project_view" class="dropdown-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Work Assign">
                                            <i class="mdi mdi-clipboard-check-outline fs-3 text-black me-1"></i>Work Assign
                                        </a>
                                        <a href="{{url('/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('customer/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label>
                                        <span class="fs-7 me-1">Kishore</span>
                                        <span class="badge bg-info text-white fs-8 rounded">M</span>
                                    </label>
                                    <div class="d-block text-dark fs-8" title="Email ID">kishore@gmail.com</div>
                                </div>
                                <div>
                                    <a href="javascript:;" class="badge bg-primary text-white fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_request_for_fsc"><span>Requested for FS</span></a>
                                </div>
                            </td>
                            <td>
                                <label>
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Development Services</span>
                                    <span class="badge badge-center border rounded-pill bg-info text-white fw-bold rounded fs-9" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Count">02</span>
                                </label>
                                <div class="d-block">
                                    <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">Python Services</label>
                                    <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                        <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                    </a>
                                    <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-8 fw-semibold">Category</label>
                                            <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                            <label class="col-6 text-black fw-bold fs-8">Development Service</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-8 fw-semibold">Sub Category</label>
                                            <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-8 fw-bold">Python Services</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-8 fw-semibold">Add On Services</label>
                                            <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                            <label class="col-6 text-success fs-8 fw-bold">
                                                <span class="badge bg-secondary text-white fw-bold">No</span></label>
                                        </div>
                                        <hr class="bg-gray-400">
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-8 fw-semibold">Category</label>
                                            <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                            <label class="col-6 text-black fw-bold fs-8">Development Service</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-8 fw-semibold">Sub Category</label>
                                            <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-8 fw-bold">Python Services</label>
                                        </div>
                                        <div class="row mb-2">
                                            <label class="col-5 text-black fs-8 fw-semibold">Add On Services</label>
                                            <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                            <label class="col-6 text-success fs-8 fw-bold">
                                                <span class="badge bg-warning text-black fw-bold">Yes</span></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-block">
                                    <!-- <label class="badge bg-secondary text-white fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add-on-Services">No</label> -->

                                </div>
                            </td>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label class="max-w-150px text-truncate" data-bs-toggle="tooltip" data-bs-placement="bottom" title="5G Botnet Detection ML/DL">5G Botnet Detection ML/DL</label>
                                    <div class="d-flex text-primary fs-8">
                                        <div class="d-block">
                                            <label class="badge bg-info fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">Partially Paid</label>
                                        </div>
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Sub Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fw-bold fs-8">70,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">GST (18%)</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">10,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-success     fs-8 fw-bold">80,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Paid Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">40,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Due Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-danger fs-8 fw-bold">40,000</label>
                                            </div>
                                            <hr class="bg-gray-400">
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Sub Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fw-bold fs-8">80,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">GST (18%)</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">10,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-success fs-8 fw-bold">90,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Paid Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">45,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Due Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-danger fs-8 fw-bold">45,000</label>
                                            </div>
                                        </div>
                                        <hr>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <!-- <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Duration">15 - 20 Days</label> -->
                                    <div class="d-flex text-primary fs-8">
                                        <div class="d-block">
                                            <label class="badge bg-secondary text-white fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Process Status">40% Completed</label>
                                        </div>
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <div class="text-end">
                                                    <label class="text-black fs-8 fw-semibold badge bg-warning text-end fw-bold">
                                                        <span>12</span>
                                                        <span>/</span>
                                                        <span>20 Days</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Technical Discussion, Flow of the Work</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Source Code</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Pseudo Code</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Software Installation</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-alpha-x-circle-outline text-danger fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Support Section</label>
                                            </div>
                                            <hr class="bg-gray-400">
                                            <div class="row mb-2">
                                                <div class="text-end">
                                                    <label class="text-black fs-8 fw-semibold badge bg-warning text-end fw-bold">
                                                        <span>12</span>
                                                        <span>/</span>
                                                        <span>20 Days</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">About The Process & Flow of the Work</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Source Code , Pseudo Code</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Accuracy Need above 80%</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Comparision Graph ML/DL</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-alpha-x-circle-outline text-danger fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Support Section</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/manage_customer/payment" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Payment">
                                        <i class="mdi mdi-cash-sync text-danger fs-2"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2 d-inline-flex position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                        <i class="mdi mdi-file-sign fs-3 text-black"></i>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA Signed"><i class="mdi mdi-check"></i></span>
                                    </a>
                                    <a href="{{url('/manage_customer/customer_add_service')}}" class="btn btn-icon btn-sm me-2 d-inline-flex position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Added"><i class="mdi mdi-check"></i></span>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="/sales/manage_lead/lead_worklist" class="dropdown-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Project">
                                            <i class="mdi mdi-list-box-outline fs-3 text-black me-1"></i>Work List
                                            <span><i class="mdi mdi-check-circle text-primary"></i></span>
                                        </a>
                                        <a href="/production/manage_cre/project_view" class="dropdown-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Check List">
                                            <i class="mdi mdi-clipboard-check-outline fs-3 text-black me-1"></i>Work Assign
                                            <span><i class="mdi mdi-check-circle text-primary"></i></span>
                                        </a>
                                        <a href="{{url('/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('customer/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label>
                                        <span class="fs-7 me-1">Deepak</span>
                                        <span class="badge bg-info text-white fs-8 rounded">M</span>
                                    </label>
                                    <div class="d-block text-dark fs-8" title="Email ID">deepak@gmail.com</div>
                                </div>
                                <div class="mt-1">
                                    <span class="badge bg-warning text-black fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Rejected for Fees Schedule">Rejected for FS</span>
                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Already Overdue"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                </div>
                            </td>
                            <td>
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">Development Services</label>
                                <div class="d-block">
                                    <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">Python Services</label>
                                </div>
                                <!-- <div class="d-block">
                                    <label class="badge bg-secondary text-white fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add-on-Services">No</label>
                                </div> -->
                            </td>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <label class="max-w-150px text-truncate" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sentiment Analysis">Sentiment Analysis</label>
                                    <div class="d-flex text-primary fs-8">
                                        <div class="d-block">
                                            <label class="badge bg-info fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount">Partially Paid</label>
                                        </div>
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Sub Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fw-bold fs-8">70,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">GST (18%)</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">10,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Total Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-success     fs-8 fw-bold">80,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Paid Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-8 fw-bold">40,000</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-5 text-black fs-8 fw-semibold">Due Amount</label>
                                                <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                <label class="col-6 text-danger fs-8 fw-bold">40,000</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="mb-0 align-items-center">
                                    <!-- <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Duration">15 - 20 Days</label> -->
                                    <div class="d-flex text-primary fs-8">
                                        <div class="d-block">
                                            <label class="badge bg-secondary text-white fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Process Status">50% Completed</label>
                                        </div>
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9 text-dark"></i>
                                        </a>
                                        <div class="dropdown-menu py-4 px-4 text-black scroll-y w-350px max-h-250px">
                                            <div class="row mb-2">
                                                <div class="text-end">
                                                    <label class="text-black fs-8 fw-semibold badge bg-warning text-end fw-bold">
                                                        <span>12</span>
                                                        <span>/</span>
                                                        <span>20 Days</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Technical Discussion, Flow of the Work</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-check-circle text-success fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Source Code </label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Pseudo Code</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-minus-circle-outline text-warning fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Software Installation</label>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-1">
                                                    <span class="mdi mdi-alpha-x-circle-outline text-danger fw-bold fs-5"></span>
                                                </label>
                                                <label class="col-11 text-black fs-8 fw-semibold">Support Section</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="/manage_customer/add_invoice" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Payment">
                                        <i class="mdi mdi-cash-sync text-danger fs-2"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2 d-inline-flex position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                        <i class="mdi mdi-file-sign fs-3 text-black"></i>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA Signed"><i class="mdi mdi-check"></i></span>
                                    </a>
                                    <a href="{{url('/manage_customer/customer_add_service')}}" class="btn btn-icon btn-sm me-2 d-inline-flex position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                        <i class="mdi mdi-notebook-plus-outline fs-3 text-black"></i>
                                        <span class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Added"><i class="mdi mdi-check"></i></span>
                                    </a>
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="/sales/manage_lead/lead_worklist" class="dropdown-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Check List">
                                            <i class="mdi mdi-list-box-outline fs-3 text-black me-1"></i>Work List
                                        </a>
                                        <a href="{{url('/manage_customer/customer_view')}}" target="_blank" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('customer/manage_customer/customer_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_customer"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Delete Customer-->
<div class="modal fade" id="kt_modal_delete_customer" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                delete Customer ?
                <!-- <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya</label>
                    <span class="ms-2 me-2">-</span>
                    <label>EACUS-0001/24</label>
                </div> -->
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Customer-->

<!--begin::Modal - Add Service-->
<div class="modal fade" id="kt_modal_add_service" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Add Service</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12 mt-4">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="quotation" name="quotation" onclick="quotation_sts_func();" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Generate Quotation</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="invoice" name="quotation" onclick="invoice_sts_func();" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Generate Invoice</label>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4" id="quotation_tbox" style="display: none!important;">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="/manage_proposal/proposal_add" target="_blank" class="btn btn-primary">Create Quotation</a>
                    </div>
                    <!-- <div class="d-flex justify-content-center align-items-center mt-4" id="invoice_tbox" style="display: none!important;">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="/manage_proposal/proposal_add" target="_blank" class="btn btn-primary">Create Invoice</a>
                    </div> -->
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Service-->


<!--begin::Modal - Request For FSC-->
<div class="modal fade" id="kt_modal_request_for_fsc" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Requested for Fees Schedule Count</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-6 mb-3 text-center">
                        <div class="row mb-2">
                            <label class="col-6 text-black fs-7 fw-semibold">Slot Count</label>
                            <label class="col-6 text-white fs-6 fw-bold">
                                <span class="badge bg-info">02</span>
                            </label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-6 text-black fs-7 fw-semibold">Total Amount</label>
                            <label class="col-6 text-black fs-6 fw-bold">80,000
                            </label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-6 text-black fs-7 fw-semibold">Paid Amount</label>
                            <label class="col-6 text-black fs-6 fw-bold">40,000
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3 text-center">
                        <div class="row mb-2">
                            <label class="col-7 text-black fs-7 fw-semibold">Extended Count</label>
                            <label class="col-5 text-white fs-6 fw-bold">
                                <span class="badge bg-secondary">01</span>
                            </label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 text-black fs-7 fw-semibold">Due Date</label>
                            <label class="col-7 text-danger fs-6 fw-bold">30-Aug-2024
                            </label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-6 text-black fs-7 fw-semibold">Amount</label>
                            <label class="col-6 text-black fs-6 fw-bold">20,000
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason</label>
                        <div class="d-block">
                            <label class="text-dark mb-1 fs-6 fw-bold">&emsp;&emsp;-</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_acpt" name="fsc_status" onclick="fsc_sts_func('accept');" checked />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Approved</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_rejt" name="fsc_status" onclick="fsc_sts_func('reject');" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Rejected</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3" id="rejct_tbox" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Reason"></textarea>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal" id="smt_butt">Approved</a>
                    </div>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Request For FSC-->
<!--begin::Modal - Customer Inactivate-->
<div class="modal fade" id="kt_modal_lead_nda" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Generate NDA?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya Dharshini</label>
                    <!-- <span class="ms-2 me-2">-</span>
                        <label>LD-0006/24</label> -->
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <!-- <a href="/manage_nda/nda_print" target="_blank" class="btn btn-primary me-3">
                    Yes
                </a> -->
                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_nda_generation" class="btn btn-primary me-3">
                    Yes
                </a>
                <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Customer Inactivate-->
<!--begin::Modal - Lead Check List-->
<div class="modal fade" id="kt_modal_view_quotation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Proposal Detail
                    </h3>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="{{url('/manage_proposal/proposal_edit')}}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                <span> <i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span></a>
                            <a href="{{url('/manage_proposal/proposal_view')}}" target="_blank" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                            </a>
                            <a href="{{url('/manage_invoice/invoice_add')}}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                <i class="mdi mdi-invoice-edit-outline fs-3 text-black"></i>
                            </a>
                            <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i></span></a>
                            <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_quotation_chat"><span> <i class="mdi mdi-invoice-text-send-outline fs-3 text-black me-1"></i></span></a>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-2">
                            <label class="col-4 text-black fs-6 fw-bold">Proposal No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-semibold">PRO-003670/04/2025</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-4 text-black fs-6 fw-bold">Proposal Date</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-semibold">19-Sep-2024</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-4 text-black fs-6 fw-bold">Validity Date</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-danger fs-6 fw-semibold">24-Sep-2024</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-4 text-black fs-6 fw-bold">Amount</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-info fs-6 fw-semibold">80,00,000</label>
                        </div>
                        <div class="col-lg-6"></div>
                        <!-- <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-200px">Estimated No</th>
                                        <th class="min-w-100px">Date</th>
                                        <th class="min-w-100px">Amount</th>
                                        <th class="min-w-150px">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    <tr class="bg-label-success">
                                        <td>
                                            <div>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated No">EST-003670/07/2024</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated  Date">12-JUL-2024</label>
                                            <div class="d-block">
                                                <label class="d-block text-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">20-Jul-2024</label>
                                            </div>
                                        </td>
                                        <td align="right">
                                            <label class="fs-8 text-black fw-bold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Quotation Amount">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">80,000.00</span>
                                            </label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="{{url('/manage_proposal/proposal_view')}}" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_invoice/invoice_add')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                    <i class="mdi mdi-invoice-edit-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_proposal/proposal_print')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                    <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i></span></a>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated No">EST-003669/07/2024</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated  Date">21-JUL-2024</label>
                                            <div class="d-block">
                                                <label class="d-block text-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">23-Jul-2024</label>
                                            </div>
                                        </td>
                                        <td align="right">
                                            <label class="fs-8 text-black fw-bold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Quotation Amount">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">85,000.00</span>
                                            </label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="{{url('/manage_proposal/proposal_view')}}" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_invoice/invoice_add')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                    <i class="mdi mdi-invoice-edit-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_proposal/proposal_print')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                    <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i></span></a>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table> -->
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Lead Check List-->

<!--begin::Modal - Lead Check List-->
<div class="modal fade" id="kt_modal_nda_generation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">NDA Generated
                    </h3>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="{{url('/manage_nda/nda_print')}}" target="_blank" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                            </a>
                            <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i></span></a>
                            <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_quotation_chat"><span> <i class="mdi mdi-invoice-text-send-outline fs-3 text-black me-1"></i></span></a>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-2">
                            <label class="col-4 text-black fs-6 fw-bold">Created Date</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-semibold">23-Sep-2024</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-4 text-black fs-6 fw-bold">NDA ID</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-semibold">GC/IZONE/2024/02346/03614</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-4 text-black fs-6 fw-bold">NDA Link</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-danger fs-6 fw-semibold">
                                <div class="row">
                                    <div class="col-lg-9">
                                        <div class="d-flex flex-wrap">
                                            <div class="input">
                                                <input class="form-control" id="clipboard-example-input" type="text" value="http://127.0.0.1:8000/manage_nda/nda_print" />
                                                <!-- <label class="" value="Copy Me"></label> -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <button class=" clipboard-btn btn btn-primary mx-2" data-clipboard-action="copy" data-clipboard-target="#clipboard-example-input">
                                            <i class="mdi mdi-content-copy"></i>
                                        </button>
                                    </div>
                                    <!-- <button class="clipboard-btn btn btn-primary" data-clipboard-action="cut" data-clipboard-target="#clipboard-example-input">
                                        Cut
                                    </button> -->
                                </div>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Lead Check List-->

<script>
    function quotation_sts_func() {
        var quotation = document.getElementById('quotation');
        var quotation_tbox = document.getElementById('quotation_tbox');
        var invoice = document.getElementById('invoice');
        var invoice_tbox = document.getElementById('invoice_tbox');
        if (quotation.click) {
            document.getElementById("quotation_tbox").style.display = "block";
            document.getElementById("invoice_tbox").style.display = "none";
        } else {

        }
    }
</script>
<script>
    function invoice_sts_func() {
        var quotation = document.getElementById('quotation');
        var quotation_tbox = document.getElementById('quotation_tbox');
        var invoice = document.getElementById('invoice');
        var invoice_tbox = document.getElementById('invoice_tbox');
        if (invoice.click) {
            document.getElementById("invoice").style.display = "block";
            document.getElementById("quotation_tbox").style.display = "none";
        } else {

        }

    }
</script>
<script>
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Create Invoice";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Create Quotation";

        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Create Invoice";
        }
    }
</script>

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<!--begin::Modal -Quotation-->
<div class="modal fade" id="kt_modal_lead_quotation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Generate Proposal?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya</label>
                    <!-- <span class="ms-2 me-2">-</span>
                    <label>LD-0006/24</label> -->
                </div>
            </div>

            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <a href="/manage_proposal/proposal_add" class="btn btn-primary me-3">
                    Yes
                </a>
                <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Quotation-->

<!--begin::Modal -Invoice-->
<div class="modal fade" id="kt_modal_lead_invoice" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Generate Invoice?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya</label>
                    <!-- <span class="ms-2 me-2">-</span>
                    <label>LD-0006/24</label> -->
                </div>
            </div>

            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <a href="/manage_invoice/invoice_add" class="btn btn-primary me-3">
                    Yes
                </a>
                <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Invoice-->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection