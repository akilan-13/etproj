@extends('layouts/layoutMaster')

@section('title', 'Payment Process')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms_file_upload.js')
@endsection


@section('content')
<!-- Users List Table -->
<div class="card">
  <div class="card-header border-bottom pb-1">
    <h5 class="card-title mb-1">Payment Process</h5>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-arrow-right-thin fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Customer</a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-arrow-right-thin fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Manage Customer</a>
        </li>
      </ol>
    </nav>
  </div>
  <div class="card-body">
    <!-------------- Single Service Starts----------------->
    <!-- <div class="row">
      <div class="col-lg-3">
        <div class="row">
          <div class="col-lg-12 mb-1">
            <div class="justify-content-start">
              <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name">
                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
              </label>
              <label class="fs-5 align-items-center text-black fw-bold">
                <span>Priya Dharshini</span>
                <span class="badge bg-danger text-white fs-8 rounded">F</span>
              </label>
            </div>
          </div>
          <div class="col-lg-12 mb-1">
            <div class="justify-content-start">
              <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">
                <i class="mdi mdi-email-sync-outline fs-3 text-black"></i>
              </label>
              <label class="fs-7 align-items-center text-info fw-bold">
                <span>priya@gmail.com</span>
              </label>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3">
        <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
        <input type="text" class="form-control" id="exampleFormControlReadOnlyInputPlain1" value="Development Service" readonly />
      </div>
      <div class="col-lg-4">
        <label class="text-black mb-1 fs-6 fw-semibold">Service Name</label>
        <input type="text" class="form-control" id="exampleFormControlReadOnlyInputPlain1" value="Computer Science- BlockChain technology-ML/DL" readonly />
      </div>
      <div class="col-lg-2 mb-3" onmouseover="update_fees_schd_cnt_mse_over_func(this)" onmouseout="update_fees_schd_cnt_mse_out_func(this)">
        <label class="text-black mb-1 fs-6 fw-semibold">Fees Slot</label>
        <div class="d-block">
          <a href="javascript:;" class="badge bg-success mb-1 fs-6 fw-semibold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Count">00</a>
          <label class="text- mb-1 fs-5 fw-bold">/</label>
          <a href="javascript:;" class="badge bg-danger mb-1 fs-6 fw-semibold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Overall Count">04</a>
          <a href="javascript:;" class="btn btn-icon btn-sm ms-1" data-bs-toggle="modal" data-bs-target="#kt_modal_update_fees_schd_cnt" title="Update Fees Schedule Count" id="update_fees_schd_cnt" style="visibility: hidden !important;">
            <i class="mdi mdi-square-edit-outline fs-4 text-black"></i>
          </a>
        </div>
      </div>
    </div> -->
    <!-------------- Single Service Ends----------------->

    <!-------------- Multiple Service Starts----------------->
    <div class="row">
      <div class="col-lg-3">
        <div class="row">
          <div class="col-lg-12 mb-1">
            <div class="justify-content-start">
              <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name">
                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
              </label>
              <label class="fs-5 align-items-center text-black fw-bold">
                <span>Priya Dharshini</span>
                <span class="badge bg-danger text-white fs-8 rounded">F</span>
              </label>
            </div>
          </div>
          <div class="col-lg-12 mb-1">
            <div class="justify-content-start">
              <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">
                <i class="mdi mdi-email-sync-outline fs-3 text-black"></i>
              </label>
              <label class="fs-7 align-items-center text-info fw-bold">
                <span>priya@gmail.com</span>
              </label>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3">
        <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
        <select id="" class="select3 form-select">
          <option value="">Select Service Category</option>
          <option value="1">Reasearch Services</option>
          <option value="2">PHD Services</option>
          <option value="3">Writing Services</option>
          <option value="4">Development Services</option>
          <option value="5">Analysis Services</option>
        </select>
      </div>
      <div class="col-lg-4">
        <div class="row">
          <div class="col-lg-12 mb-1">
            <div class="row">
              <label class="text-black mb-1 fs-6 fw-semibold">Service Name</label>
              <select id="" class="select3 form-select">
                <option value="">Select Service Name</option>
                <option value="1">Computer Science- BlockChain technology-ML/DL</option>
                <option value="2">Computer Science- BlockChain technology-ML/DL</option>
                <option value="3">Computer Science- BlockChain technology-ML/DL</option>
                <option value="4">Computer Science- BlockChain technology-ML/DL</option>
                <option value="5">Computer Science- BlockChain technology-ML/DL</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-2 mb-3" onmouseover="update_fees_schd_cnt_mse_over_func(this)" onmouseout="update_fees_schd_cnt_mse_out_func(this)">
        <label class="text-black mb-1 fs-6 fw-semibold">Fees Slot</label>
        <div class="d-block">
          <a href="javascript:;" class="badge bg-success mb-1 fs-6 fw-semibold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Count">01</a>
          <label class="text- mb-1 fs-5 fw-bold">/</label>
          <a href="javascript:;" class="badge bg-danger mb-1 fs-6 fw-semibold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Overall Count">02</a>
          <a href="javascript:;" class="btn btn-icon btn-sm ms-1" data-bs-toggle="modal" data-bs-target="#kt_modal_update_fees_schd_cnt" title="Update Fees Schedule Count" id="update_fees_schd_cnt" style="visibility: hidden !important;">
            <i class="mdi mdi-square-edit-outline fs-4 text-black"></i>
          </a>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-lg-4 mb-3">
        <div class="text-center">
          <label class="text-black mb-1 fs-5 fw-bold">Total Amount</label>
          <div class="d-block mt-2">
            <label class="badge bg-success text-black mb-1 fs-6 fw-bold">
              <span class="mdi mdi-currency-rupee"></span>
              <span>80,000</span></label>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-3">
        <div class="text-center">
          <label class="text-black mb-1 fs-5 fw-bold">Paid Amount</label>
          <div class="d-block mt-2">
            <label class="badge bg-info text-white mb-1 fs-6 fw-bold">
              <span class="mdi mdi-currency-rupee"></span>
              <span>40,000</span></label>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-3">
        <div class="text-center">
          <label class="text-black mb-1 fs-5 fw-bold">Balance Amount</label>
          <div class="d-block mt-2">
            <label class="badge bg-warning text-black mb-1 fs-6 fw-bold">
              <span class="mdi mdi-currency-rupee"></span>
              <span>40,000</span></label>
          </div>
        </div>
      </div>
    </div>
    <label class="text-black my-4 fs-4 fw-bold">Fees Schedule</label>
    <div class="row">
      <div class="col-lg-12 mb-3">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-80px">Slot</th>
              <th class="min-w-80px">Payment Date</th>
              <th class="min-w-125px"><span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Due Date">DueDate</span></th>
              <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amt">Schd Amt</th>
              <th class="min-w-100px">Paid Amt</th>
              <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amt">Bal Amt</th>
              <th class="min-w-80px">Status</th>
              <th class="min-w-50px">Actions</th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            <tr>
              <td>Slot 1</td>
              <td>12-JUL-2024</td>
              <td align="center">12-JUL-2024</td>
              <td align="right">
                <label class="text-info fw-bold fs-7">
                  <!-- <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span> -->
                  <span class="fs-7">40,000.00</span>
                </label>
              </td>
              <td align="right">
                <label class="text-black fw-bold fs-7">
                  <!-- <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span> -->
                  <span class="fs-7">1,000.00</span>
                </label>
              </td>
              <td align="right">
                <label class="text-danger fw-bold fs-7">
                  <!-- <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span> -->
                  <span class="fs-7">35,000.00</span>
                </label>
              </td>
              <td>
                <label class="badge bg-success text-black fw-semibold">Paid</label>
                <!-- <label class="badge bg-danger fw-semibold">Pending</label> -->
              </td>
              <td></td>
            </tr>
            <tr>
              <td>Slot 2</td>
              <td>
                <div class="input-group input-group-merge w-150px">
                  <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                  <input type="text" id="cus_third_pymt_dt" placeholder="Select Date" class="form-control fs-7" value="20-Aug-2024" />
                </div>
              </td>
              <td align="center">20-Aug-2024</td>
              <td align="right">
                <label class="text-info fw-bold fs-7">
                  <!-- <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span> -->
                  <span class="fs-7">40,000.00</span>
                </label>
              </td>
              <td align="right">
                <label class="text-black fw-bold fs-7">
                  <!-- <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span> -->
                  <span class="fs-7">1,000.00</span>
                </label>
              </td>
              <td align="right">
                <label class="text-danger fw-bold fs-7">
                  <!-- <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span> -->
                  <span class="fs-7">35,000.00</span>
                </label>
              </td>
              <td>
                <!-- <label class="badge bg-success text-black fw-semibold fs-6">Paid</label> -->
                <label class="badge bg-danger fw-semibold">Pending</label>
              </td>
              <td>
                <a href="javascript:;" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_payment_option" id="pay_now_butt">Pay</a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="d-flex justify-content-end align-items-center mt-4">
      <a href="/sales/manage_customer" class="btn btn-secondary me-3">Cancel</a>
      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_update_payment">Update Payment</button>
    </div>
  </div>
</div>



<!--begin::Modal - Update Fees Schedule Count-->
<div class="modal fade" id="kt_modal_update_fees_schd_cnt" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Fees Slot</h3>
        </div>
        <div class="row mt-4">
          <div class="col-lg-4 mb-3">
            <div class="text-center">
              <label class="text-black mb-1 fs-6 fw-bold">Total Slot Count</label>
              <div class="d-block mt-2">
                <label>
                  <span class="badge bg-warning text-black mb-1 fs-7 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Slot">01</span>
                  <span>/</span>
                  <span class="badge bg-success text-black mb-1 fs-7 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Slot">02</span></label>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-3">
            <div class="text-center">
              <label class="text-black mb-1 fs-6 fw-bold">Total Amount</label>
              <div class="d-block mt-2">
                <label class="badge bg-info text-white mb-1 fs-6 fw-bold">
                  <span>80,000</span></label>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-3">
            <div class="text-center">
              <label class="text-black mb-1 fs-6 fw-bold">Paid Amount</label>
              <div class="d-block mt-2">
                <label class="badge bg-secondary text-white mb-1 fs-6 fw-bold">
                  <span>80,000</span></label>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Fees Extended Slot<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Fees Extended Slot" value="01" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Due Date<span class="text-danger">*</span></label>
            <input type="text" id="cus_second_pymt_dt" placeholder="Select Date" class="form-control fs-7" value="20-Aug-2024" />
          </div>
          <div class="col-lg-6 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Due Amount<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Due Amount" value="20,000" />
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
            <textarea class="form-control" rows="3" id="" placeholder="Enter Reason"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#kt_modal_approval_confirmation">Send for Approval</button>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Fees Schedule Count-->

<!--begin::Modal - Add Payment Option-->
<div class="modal fade" id="kt_modal_payment_option" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Payment Mode</h3>
        </div>
        <div class="row mb-4">
          <div class="col-lg-2">
            <label class="mb-1 fs-5 fw-semibold text-black">Slot 2</label>
          </div>
          <div class="col-lg-8">
            <label class="mb-1 fs-5 fw-semibold text-black">Schedule Amount</label>
            <span class="fs-5 ms-4 text-info fw-bold">40,000</span>
          </div>
        </div>

        <div class="row mt-4">
          <div class="col-lg-4">
            <label class="text-dark mb-1 fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
            <select id="payment" name="payment" class="select3 form-select" onchange="payment_func();">
              <option value="">Select Payment Mode</option>
              <option value="cash">Cash</option>
              <option value="check">Cheque</option>
              <option value="paypal">PayPal</option>
              <option value="gpay">GPay</option>
              <option value="bank">Bank</option>
            </select>
          </div>
        </div>
        <div id="cash_det" style="display: none !important;">
          <div class="row mt-4">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Cash Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Cash Amount" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
            </div>
          </div>
        </div>
        <div id="check_det" style="display: none !important;">
          <div class="row mt-4">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Bank</option>
                <option value="">TMB</option>
                <option value="">Indian</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Cheque No<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Cheque No" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Amount" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
            </div>
          </div>
        </div>
        <div id="gpay_det" style="display: none !important;">
          <div class="row mt-4">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Amount" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
            </div>
          </div>
        </div>
        <div id="paypal_det" style="display: none !important;">
          <div class="row mt-4">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Transaction ID" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter UPI ID" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Amount" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
            </div>
          </div>
        </div>
        <div id="bank_det" style="display: none !important;">
          <div class="row mt-4">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
              <select id="" class="select3 form-select">
                <option value="">Select Bank</option>
                <option value="">TMB</option>
                <option value="">Indian</option>
              </select>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Account Number<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Account Number" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter Branch Name" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="" placeholder="Enter IFSC Code" />
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
          <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
          <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Paid</a>
        </div>
        <!--end::Modal body-->
      </div>
      <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
  </div>
</div>
<!--end::Modal - Add Payment Option-->

<!--begin::Modal - Approval Confirmation-->
<div class="modal fade" id="kt_modal_approval_confirmation" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">&#10004;</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Your Request has been Successfully Sent to BH for Approval
        <div class="d-block fw-bold fs-5 py-2">
          <label>Priya</label>
          <span class="ms-2 me-2">-</span>
          <label>EACU-0001/24</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-6">
        <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">OK</a>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Approval Confirmation-->


<!--begin::Modal - Payment Confirmation-->
<div class="modal fade" id="kt_modal_update_payment" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Update Payment ?
        <div class="d-block fw-bold fs-5 py-2">
          <label>Priya</label>
          <span class="ms-2 me-2">-</span>
          <label>EACUS-0001/24</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <a href="/sales/manage_customer" class="btn btn-primary me-3">Yes</a>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Payment Confirmation-->

<script>
  function update_fees_schd_cnt_mse_over_func(val) {
    document.getElementById("update_fees_schd_cnt").style.setProperty("visibility", "visible", "important");
    document.getElementById("view_fees_pymt_schd").style.setProperty("visibility", "visible", "important");
  }

  function update_fees_schd_cnt_mse_out_func(val) {
    document.getElementById("update_fees_schd_cnt").style.setProperty("visibility", "hidden", "important");
    document.getElementById("view_fees_pymt_schd").style.setProperty("visibility", "hidden", "important");
  }
</script>

<script>
  function cus_payment_chk_func(val) {
    var cus_cash_tbox = document.getElementById('cus_cash_tbox');
    var cus_cheque_tbox = document.getElementById('cus_cheque_tbox');
    var cus_gpay_tbox = document.getElementById('cus_gpay_tbox');

    if (val == 'cash') {
      cus_cash_tbox.style.display = "block";
      cus_cheque_tbox.style.display = "none";
      cus_gpay_tbox.style.display = "none";
    } else if (val == 'cheque') {
      cus_cash_tbox.style.display = "none";
      cus_cheque_tbox.style.display = "block";
      cus_gpay_tbox.style.display = "none";
    } else if (val == 'google_pay') {
      cus_cash_tbox.style.display = "none";
      cus_cheque_tbox.style.display = "none";
      cus_gpay_tbox.style.display = "block";
    } else {
      cus_cash_tbox.style.display = "none";
      cus_cheque_tbox.style.display = "none";
      cus_gpay_tbox.style.display = "none";
    }
  };
</script>

<script>
  function payment_func() {
    var payment = document.getElementById("payment").value;
    var cash_det = document.getElementById("cash_det");
    var check_det = document.getElementById("check_det");
    var gpay_det = document.getElementById("gpay_det");
    var paypal_det = document.getElementById("paypal_det");
    var bank_det = document.getElementById("bank_det");
    if (payment == "cash") {
      cash_det.style.display = "block";
      check_det.style.display = "none";
      gpay_det.style.display = "none";
      paypal_det.style.display = "none";
      bank_det.style.display = "none";
    } else if (payment == "check") {
      check_det.style.display = "block";
      cash_det.style.display = "none";
      gpay_det.style.display = "none";
      paypal_det.style.display = "none";
      bank_det.style.display = "none";
    } else if (payment == "gpay") {
      check_det.style.display = "none";
      cash_det.style.display = "none";
      gpay_det.style.display = "block";
      paypal_det.style.display = "none";
      bank_det.style.display = "none";
    } else if (payment == "paypal") {
      check_det.style.display = "none";
      cash_det.style.display = "none";
      gpay_det.style.display = "none";
      bank_det.style.display = "none";
      paypal_det.style.display = "block";
    } else if (payment == "bank") {
      check_det.style.display = "none";
      cash_det.style.display = "none";
      gpay_det.style.display = "none";
      bank_det.style.display = "block";
      paypal_det.style.display = "none";
    } else {
      cash_det.style.display = "none";
      check_det.style.display = "none";
    }
  }
</script>

<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    // "iDisplayLength": "10000",
    "paging": false,
    // "pageLength": 100,
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-12 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
@endsection