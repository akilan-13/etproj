@extends('layouts/layoutMaster')

@section('title', 'View Manage Users')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
  <div class="card-header border-bottom pb-1">
    <h5 class="card-title mb-1">View Manage Users</h5>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-arrow-right-thin fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Users Management</a>
        </li>
      </ol>
    </nav>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-6">
        <div class="row mb-2">
          <label class="col-4 mb-2 fs-6 fw-semibold">Role</label>
          <label class="col-1 mb-2 fs-6 fw-bold">:</label>
          <label class="col-7 mb-2 fs-6 fw-bold text-black">GM</label>
        </div>
      </div>
    </div>
    <div class="d-flex justify-content-end align-items-center py-4">
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
        <label class="text-dark fs-6 fw-semibold">Select All</label>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 mb-4">
        <div class="card-action">
          <div class="card-header" style="background-color: #e7a368 !important;">
            <div class="card-action-title">
              <div class="d-flex align-items-center">
                <div class="form-check form-check-inline">
                  <input class="form-check-input " type="checkbox" name="" id="" checked disabled />
                  <label class="text-black fs-6 fw-bold">Dashboards</label>
                </div>
              </div>
            </div>
            <div class="card-action-element">
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="javascript:;" class="dashboards_view"><i class="mdi mdi-chevron-up fs-3"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="collapse dashboards_body_view border">
          <div class="card-body">

          </div>
        </div>
      </div>
      <div class="col-lg-12 mb-4">
        <div class="card-action">
          <div class="card-header" style="background-color: #e7a368 !important;">
            <div class="card-action-title">
              <div class="d-flex align-items-center">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                  <label class="text-black fs-6 fw-bold">Marketing</label>
                </div>
              </div>
            </div>
            <div class="card-action-element">
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="javascript:;" class="marketing_view"><i class="mdi mdi-chevron-up fs-3"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="collapse marketing_body_view border">
          <div class="card-body">

          </div>
        </div>
      </div>
      <div class="col-lg-12 mb-4">
        <div class="card-action">
          <div class="card-header" style="background-color: #e7a368 !important;">
            <div class="card-action-title">
              <div class="d-flex align-items-center">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                  <label class="text-black fs-6 fw-bold">Lead Management</label>
                </div>
              </div>
            </div>
            <div class="card-action-element">
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="javascript:;" class="lead_management_view"><i class="mdi mdi-chevron-up fs-3"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="collapse lead_management_body_view border">
          <div class="card-body">
            <div class="row">
              <div class="col-lg-12 mb-4">
                <div class="card-action">
                  <div class="card-header" style="background-color:#6fb7d5;">
                    <div class="card-action-title">
                      <div class="d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-bold">Raw Lead</label>
                        </div>
                      </div>
                    </div>
                    <div class="card-action-element">
                      <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                          <a href="javascript:;" class="lead_management_raw_lead_view"><i class="mdi mdi-chevron-up fs-3"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="collapse lead_management_raw_lead_body_view border">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Edit</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Import</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Export</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="raw_lead_view" id="view_all" disabled />
                          <label class="text-black fs-6 fw-semibold">View All</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="raw_lead_view" id="view_self" checked disabled />
                          <label class="text-black fs-6 fw-semibold">View Self</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-4">
                <div class="card-action">
                  <div class="card-header" style="background-color:#6fb7d5;">
                    <div class="card-action-title">
                      <div class="d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-bold">Lead</label>
                        </div>
                      </div>
                    </div>
                    <div class="card-action-element">
                      <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                          <a href="javascript:;" class="lead_management_lead_view"><i class="mdi mdi-chevron-up fs-3"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="collapse lead_management_lead_body_view border">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Quick Lead</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Add</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Edit</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Delete</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">View</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Followup</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Check List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Customer</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Chat</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Import</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Export</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Quotation</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Invoice</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Work List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Requirments</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="lead_view" id="view_all" disabled />
                          <label class="text-black fs-6 fw-semibold">View All</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="lead_view" id="view_self" checked disabled />
                          <label class="text-black fs-6 fw-semibold">View Self</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-4">
                <div class="card-action">
                  <div class="card-header" style="background-color:#6fb7d5;">
                    <div class="card-action-title">
                      <div class="d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-bold">Manage Requirments</label>
                        </div>
                      </div>
                    </div>
                    <div class="card-action-element">
                      <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                          <a href="javascript:;" class="lead_management_requirment_view"><i class="mdi mdi-chevron-up fs-3"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="collapse lead_management_requirment_body_view border">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">List</label>
                        </div>
                      </div>
                      <!-- <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Edit</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Delete</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">View</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Add Course</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Add Batch</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Payment</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                          <label class="text-black fs-6 fw-semibold">Import</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="customer_view" id="view_all" disabled />
                          <label class="text-black fs-6 fw-semibold">View All</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="customer_view" id="view_self" checked disabled />
                          <label class="text-black fs-6 fw-semibold">View Self</label>
                        </div>
                      </div> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!--View Dashboards Accordion Start-->
<script>
  'use strict';

  (function() {
    const dashboards_view = [].slice.call(document.querySelectorAll('.dashboards_view'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (dashboards_view) {
      dashboards_view.map(function(dashboards_view_Element) {
        dashboards_view_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(dashboards_view_Element.closest('.card').querySelector('.collapse.dashboards_body_view'));
          // Toggle collapsed class in `.card-header` element
          dashboards_view_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(dashboards_view_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--View Dashboards Accordion End-->
<!--View Marketing Accordion Start-->
<script>
  'use strict';

  (function() {
    const marketing_view = [].slice.call(document.querySelectorAll('.marketing_view'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (marketing_view) {
      marketing_view.map(function(marketing_view_Element) {
        marketing_view_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(marketing_view_Element.closest('.card').querySelector('.collapse.marketing_body_view'));
          // Toggle collapsed class in `.card-header` element
          marketing_view_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(marketing_view_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--View Marketing Accordion End-->
<!--View Sales Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_management_view = [].slice.call(document.querySelectorAll('.lead_management_view'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_management_view) {
      lead_management_view.map(function(lead_management_view_Element) {
        lead_management_view_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_management_view_Element.closest('.card').querySelector('.collapse.lead_management_body_view'));
          // Toggle collapsed class in `.card-header` element
          lead_management_view_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_management_view_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--View Sales Accordion End-->
<!--View Sales -> Raw Lead Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_management_raw_lead_view = [].slice.call(document.querySelectorAll('.lead_management_raw_lead_view'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_management_raw_lead_view) {
      lead_management_raw_lead_view.map(function(lead_management_raw_lead_view_Element) {
        lead_management_raw_lead_view_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_management_raw_lead_view_Element.closest('.card').querySelector('.collapse.lead_management_raw_lead_body_view'));
          // Toggle collapsed class in `.card-header` element
          lead_management_raw_lead_view_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_management_raw_lead_view_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--View Sales -> Raw Lead Accordion End-->
<!--View Sales -> Lead Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_management_lead_view = [].slice.call(document.querySelectorAll('.lead_management_lead_view'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_management_lead_view) {
      lead_management_lead_view.map(function(lead_management_lead_view_Element) {
        lead_management_lead_view_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_management_lead_view_Element.closest('.card').querySelector('.collapse.lead_management_lead_body_view'));
          // Toggle collapsed class in `.card-header` element
          lead_management_lead_view_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_management_lead_view_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--View Sales -> Lead Accordion End-->
<!--View Sales -> Customer Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_management_requirment_view = [].slice.call(document.querySelectorAll('.lead_management_requirment_view'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_management_requirment_view) {
      lead_management_requirment_view.map(function(lead_management_requirment_view_Element) {
        lead_management_requirment_view_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_management_requirment_view_Element.closest('.card').querySelector('.collapse.lead_management_requirment_body_view'));
          // Toggle collapsed class in `.card-header` element
          lead_management_requirment_view_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_management_requirment_view_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--View Sales -> Customer Accordion End-->
@endsection