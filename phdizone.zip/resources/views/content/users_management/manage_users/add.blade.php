@extends('layouts/layoutMaster')

@section('title', 'Create Manage Users')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
  <div class="card-header border-bottom pb-1">
    <h5 class="card-title mb-1">Create Manage Users</h5>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-arrow-right-thin fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Users Management</a>
        </li>
      </ol>
    </nav>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-3">
        <label class="text-dark mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
        <select id="" class="select3 form-select">
          <option value="">Select Role</option>
          <option value="1">MD</option>
          <option value="2">GM</option>
          <option value="3">AM</option>
          <option value="4">AE</option>
          <option value="5">BH</option>
          <option value="6">PC</option>
        </select>
      </div>
    </div>
    <div class="d-flex justify-content-end align-items-center py-4">
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox" name="" id="" />
        <label class="text-dark fs-6 fw-semibold">Select All</label>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 mb-4">
        <div class="card-action">
          <div class="card-header" style="background-color: #e7a368 !important;">
            <div class="card-action-title">
              <div class="d-flex align-items-center">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="" id="" />
                  <label class="text-black fs-6 fw-bold">Dashboards</label>
                </div>
              </div>
            </div>
            <div class="card-action-element">
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="javascript:;" class="dashboards_add"><i class="mdi mdi-chevron-up fs-3"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="collapse dashboards_body_add border">
          <div class="card-body">

          </div>
        </div>
      </div>
      <div class="col-lg-12 mb-4">
        <div class="card-action">
          <div class="card-header" style="background-color: #e7a368 !important;">
            <div class="card-action-title">
              <div class="d-flex align-items-center">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="" id="" />
                  <label class="text-black fs-6 fw-bold">Marketing Management</label>
                </div>
              </div>
            </div>
            <div class="card-action-element">
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="javascript:;" class="marketing_add"><i class="mdi mdi-chevron-up fs-3"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="collapse marketing_body_add border">
          <div class="card-body">

          </div>
        </div>
      </div>
      <div class="col-lg-12 mb-4">
        <div class="card-action">
          <div class="card-header" style="background-color: #e7a368 !important;">
            <div class="card-action-title">
              <div class="d-flex align-items-center">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="" id="" />
                  <label class="text-black fs-6 fw-bold">Lead Management</label>
                </div>
              </div>
            </div>
            <div class="card-action-element">
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="javascript:;" class="lead_add"><i class="mdi mdi-chevron-up fs-3"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="collapse lead_body_add border">
          <div class="card-body">
            <div class="row">
              <div class="col-lg-12 mb-4">
                <div class="card-action">
                  <div class="card-header" style="background-color:#6fb7d5;">
                    <div class="card-action-title">
                      <div class="d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-bold">Raw Lead</label>
                        </div>
                      </div>
                    </div>
                    <div class="card-action-element">
                      <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                          <a href="javascript:;" class="lead_raw_lead_add"><i class="mdi mdi-chevron-up fs-3"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="collapse lead_raw_lead_body_add border">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Edit</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Import</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Export</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="raw_lead" id="view_all" />
                          <label class="text-black fs-6 fw-semibold">View All</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="raw_lead" id="view_self" />
                          <label class="text-black fs-6 fw-semibold">View Self</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-4">
                <div class="card-action">
                  <div class="card-header" style="background-color:#6fb7d5;">
                    <div class="card-action-title">
                      <div class="d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-bold">Lead</label>
                        </div>
                      </div>
                    </div>
                    <div class="card-action-element">
                      <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                          <a href="javascript:;" class="lead_man_lead_add"><i class="mdi mdi-chevron-up fs-3"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="collapse lead_man_lead_body_add border">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Quick Lead</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Add</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Edit</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Delete</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">View</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Followup</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Check List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Customer</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Chat</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Import</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Export</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Quotation</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Invoice</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Work List</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Requirments</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="lead" id="view_all" />
                          <label class="text-black fs-6 fw-semibold">View All</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="lead" id="view_self" />
                          <label class="text-black fs-6 fw-semibold">View Self</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-4">
                <div class="card-action">
                  <div class="card-header" style="background-color:#6fb7d5;">
                    <div class="card-action-title">
                      <div class="d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-bold">Manage Requirments</label>
                        </div>
                      </div>
                    </div>
                    <div class="card-action-element">
                      <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                          <a href="javascript:;" class="lead_requirment_add"><i class="mdi mdi-chevron-up fs-3"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="collapse lead_requirment_body_add border">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">List</label>
                        </div>
                      </div>
                      <!-- <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Edit</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Delete</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">View</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Add Course</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Add Batch</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Payment</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Import</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="" id="" />
                          <label class="text-black fs-6 fw-semibold">Export</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="customer" id="view_all" />
                          <label class="text-black fs-6 fw-semibold">View All</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="customer" id="view_self" />
                          <label class="text-black fs-6 fw-semibold">View Self</label>
                        </div>
                      </div> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="d-flex justify-content-end align-items-center mt-4">
      <a href="/users/manage_users" class="btn btn-secondary me-3">Cancel</a>
      <a href="javascript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_confirm_create_manage_users">Create Manage Users</a>
    </div>
  </div>
</div>


<!--begin::Modal - Confirm Create Manage Users-->
<div class="modal fade" id="kt_modal_confirm_create_manage_users" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Create Manage Users ?</div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <a href="/users/manage_users" class="btn btn-primary me-3">Yes</a>
        <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirm Create Manage Users-->



<script>
  function branch_type_func() {
    var branch_type = document.getElementById("branch_type").value;
    var branch_tbox = document.getElementById("branch_tbox");
    var franc_tbox = document.getElementById("franc_tbox");
    if (branch_type == "branch") {
      branch_tbox.style.display = "block";
      franc_tbox.style.display = "none";
    } else if (branch_type == "franc") {
      branch_tbox.style.display = "none";
      franc_tbox.style.display = "block";
    } else {
      branch_tbox.style.display = "none";
      franc_tbox.style.display = "none";
    }
  }
</script>
<!--Create Dashboards Accordion Start-->
<script>
  'use strict';

  (function() {
    const dashboards_add = [].slice.call(document.querySelectorAll('.dashboards_add'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (dashboards_add) {
      dashboards_add.map(function(dashboards_add_Element) {
        dashboards_add_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(dashboards_add_Element.closest('.card').querySelector('.collapse.dashboards_body_add'));
          // Toggle collapsed class in `.card-header` element
          dashboards_add_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(dashboards_add_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--Create Dashboards Accordion End-->
<!--Create Marketing Accordion Start-->
<script>
  'use strict';

  (function() {
    const marketing_add = [].slice.call(document.querySelectorAll('.marketing_add'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (marketing_add) {
      marketing_add.map(function(marketing_add_Element) {
        marketing_add_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(marketing_add_Element.closest('.card').querySelector('.collapse.marketing_body_add'));
          // Toggle collapsed class in `.card-header` element
          marketing_add_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(marketing_add_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--Create Marketing Accordion End-->
<!--Create Sales Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_add = [].slice.call(document.querySelectorAll('.lead_add'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_add) {
      lead_add.map(function(lead_add_Element) {
        lead_add_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_add_Element.closest('.card').querySelector('.collapse.lead_body_add'));
          // Toggle collapsed class in `.card-header` element
          lead_add_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_add_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--Create Sales Accordion End-->
<!--Create Sales -> Raw Lead Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_raw_lead_add = [].slice.call(document.querySelectorAll('.lead_raw_lead_add'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_raw_lead_add) {
      lead_raw_lead_add.map(function(lead_raw_lead_add_Element) {
        lead_raw_lead_add_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_raw_lead_add_Element.closest('.card').querySelector('.collapse.lead_raw_lead_body_add'));
          // Toggle collapsed class in `.card-header` element
          lead_raw_lead_add_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_raw_lead_add_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--Create Sales -> Raw Lead Accordion End-->
<!--Create Sales -> Lead Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_man_lead_add = [].slice.call(document.querySelectorAll('.lead_man_lead_add'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_man_lead_add) {
      lead_man_lead_add.map(function(lead_man_lead_add_Element) {
        lead_man_lead_add_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_man_lead_add_Element.closest('.card').querySelector('.collapse.lead_man_lead_body_add'));
          // Toggle collapsed class in `.card-header` element
          lead_man_lead_add_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_man_lead_add_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--Create Sales -> Lead Accordion End-->
<!--Create Sales -> Customer Accordion Start-->
<script>
  'use strict';

  (function() {
    const lead_requirment_add = [].slice.call(document.querySelectorAll('.lead_requirment_add'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (lead_requirment_add) {
      lead_requirment_add.map(function(lead_requirment_add_Element) {
        lead_requirment_add_Element.addEventListener('click', event => {
          event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(lead_requirment_add_Element.closest('.card').querySelector('.collapse.lead_requirment_body_add'));
          // Toggle collapsed class in `.card-header` element
          lead_requirment_add_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(lead_requirment_add_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--Create Sales -> Customer Accordion End-->
@endsection