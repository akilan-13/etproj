@extends('layouts/layoutMaster')

@section('title', 'Update Branch')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <h5 class="mb-1 text-black" id="brch_fran_tle">Update Branch</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Branch</a>
                </li>
            </ol>
        </nav>
    </div>
</div>
<div class="card">
    <div class="card-body mb-2 px-4 pb-2">
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Company</option>
                    <option value="1" selected>Elysium Technologies Pvt Ltd</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Entity</option>
                    <option value="1" selected>phdizone</option>
                    <option value="1">Elysium Pro</option>
                    <option value="1">MyProjectBazaar</option>
                    <option value="1">ClickMyProject</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input" type="radio" name="brch_fran_chk" id="branch_chk" checked onchange="branch_franchise_func(1);">
                    <label class="form-check-label fs-5 fw-bold" for="branch_chk">Branch</label>
                </div>
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input" type="radio" name="brch_fran_chk" id="franchise_chk" onchange="branch_franchise_func(2);">
                    <label class="form-check-label fs-5 fw-bold" for="franchise_chk">Franchise</label>
                </div>
            </div>
            <div class="col-lg-4 mb-3" id="branch_tbox">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Branch Name" value="Phdizone Madurai Branch" />
            </div>
            <div class="col-lg-4 mb-3" id="bussiness_tbox" style="display: none;">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Name" />
            </div>
            <div class="col-lg-4 mb-3" id="fran_tbox" style="display: none;">
                <label class="text-black mb-1 fs-6 fw-semibold">Franchise Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Franchise Name" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Category<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Branch Category</option>
                    <option value="1" selected>Branch - CICO</option>
                    <option value="2">Branch - CIFO</option>
                    <option value="3">Branch - FICO</option>
                    <option value="3">Branch - FIFO</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Country</option>
                    <option value="1">USA</option>
                    <option value="2">UAE</option>
                    <option value="3" selected>India</option>
                    <option value="4">South Africa</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select State</option>
                    <option value="1" selected>Tamilnadu</option>
                    <option value="2">Andhra Pradesh</option>
                    <option value="3">Kerala</option>
                    <option value="4">Karnataka</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select City</option>
                    <option value="1" selected>Madurai</option>
                    <option value="2">Virudhunagar</option>
                    <option value="3">Thirunelveli</option>
                    <option value="4">Coimbatore</option>
                    <option value="5">Chennai</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Area / Street" value="Ist & IInd Floor, A, Block, Elysium Campus, Church Rd, Anna Nagar" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Door/Flat No" value="229" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Pincode" value="625020" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">City Short Code<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter City Short Code" value="MDU" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Call Tracker Company ID</label>
                <input type="text" class="form-control" placeholder="Enter Call Tracker Company ID" value="3" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Mobile No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Mobile No" value="9944049888" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Email ID<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Email ID" value="presale@phdizone.com" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Communication Email ID<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Communication Email ID" value="presale@phdizone.com" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Location URL" value="https://maps.app.goo.gl/KP6MjioCEYKAat2b8" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Website URL" value="https://phdizone.com/" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Facebook Link</label>
                <input type="text" class="form-control" placeholder="Enter Facebook Link" value="https://www.facebook.com/PhDiZone" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Instagram Link</label>
                <input type="text" class="form-control" placeholder="Enter Instagram Link" value="https://www.instagram.com/phdizoneresearch/" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Just Dial Branch Code</label>
                <input type="text" class="form-control" placeholder="Enter Just Dial Branch Code" value="PX452.X452.150529114611.E9O3" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter CIN No" value="U67190KA2012LLP012345" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-3 fs-6 fw-semibold">GST Type<span class="text-danger">*</span></label>
                <div class="d-block">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gst_type" checked>
                        <label class="form-check-label fs-6 fw-semibold text-black">Inclusive</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gst_type">
                        <label class="form-check-label fs-6 fw-semibold text-black">Exclusive</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">GST Percentage<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter GST Percentage" value="18" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">GST No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter GST No" value="29AAGFV1234M1Z6" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Pan No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Pan No" value="AAGFV1234M" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Tax No" value="3456789012" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Share (as %)<span class="text-danger">*</span></label>
                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Share For Brand In Percentage"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                <input type="text" class="form-control" placeholder="Enter Share (as %)" value="100" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Agreement Start Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="agree_stdt" placeholder="Select Date" class="form-control">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Agreement End Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="agree_eddt" placeholder="Select Date" class="form-control">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Opening Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="open_dt" placeholder="Select Date" class="form-control" value="06-May-1999">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Latitude<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Latitude" value="9.930456964894685" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Longitude<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Longitude" value="78.14626761197358" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Time Zone<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Time Zone</option>
                    <option value="1" selected>India (UTC +05:30)</option>
                    <option value="2">United States (UTC -04:00)</option>
                    <option value="3">United Kingdom (UTC +01:00)</option>
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Currency Format</option>
                    <option value="1" selected>INR - &#8377;</option>
                </select>
            </div>
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Collection Info</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Collection Closing Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="cllt_cl_dt" placeholder="Select Date" class="form-control" value="<?php echo date('25-M-Y'); ?>">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Registeration Closing Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="reg_cl_dt" placeholder="Select Date" class="form-control" value="<?php echo date('25-M-Y'); ?>">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount Receive<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Minimum Amount Receive" value="20000" />
            </div>
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Name" value="HDFC" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Branch Name" value="Anna Nagar" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account Holder" value="phdizone" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account No" value="6523145278745" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter IFSC Code" value="HDFC0002027" />
            </div>
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">API Details</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Cloud Call API Key</label>
                <textarea class="form-control" rows="1" placeholder="Enter Cloud Call API Key"></textarea>
            </div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control h-auto" placeholder="Enter Description">-</textarea>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2">
            <a href="{{url('/branch')}}" class="btn fw-bold btn-secondary me-3">Cancel</a>
            <a href="javascript:;" class="btn fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_update_branch" id="brch_fran_butt">
                Update Branch
            </a>
        </div>
    </div>
</div>




<!--begin::Modal - Update Branch-->
<div class="modal fade" id="kt_modal_update_branch" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                <span id="create_label"> Update Branch </span> ?
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <a href="{{url('/branch')}}" class="btn fw-bold btn-primary me-3">Yes</a>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Branch-->

<script>
    function branch_franchise_func(val) {
        if (val == '2') {
            document.getElementById("branch_tbox").style.display = "none";
            document.getElementById("bussiness_tbox").style.display = "block";
            document.getElementById("fran_tbox").style.display = "block";
            document.getElementById("brch_fran_tle").innerHTML = "Update Franchise";
            document.getElementById("brch_fran_butt").innerHTML = "Update Franchise";
            document.getElementById("create_label").innerHTML = "Update Franchise";

        } else {
            document.getElementById("branch_tbox").style.display = "block";
            document.getElementById("bussiness_tbox").style.display = "none";
            document.getElementById("fran_tbox").style.display = "none";
            document.getElementById("brch_fran_tle").innerHTML = "Update Branch";
            document.getElementById("brch_fran_butt").innerHTML = "Update Branch";
            document.getElementById("create_label").innerHTML = "Update Branch";
        }
    }
</script>

@endsection