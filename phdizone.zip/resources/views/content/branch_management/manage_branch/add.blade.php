@extends('layouts/layoutMaster')

@section('title', 'Create Branch')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<div class="card mb-2">
    @php
    $helper = new \App\Helpers\Helpers();
    @endphp
    <div class="card-header border-bottom pb-1">
        <h5 class="mb-1 text-black" id="brch_fran_tle">Create Branch</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Branch</a>
                </li>
            </ol>
        </nav>
    </div>
</div>
<div class="card">
    <form method="POST" action="{{ route('add_branch_franchise') }}" enctype="multipart/form-data" autocomplete="off" id="branch_form">
    @csrf
    <div class="card-body mb-2 px-4 pb-2">
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="company_id" id="company_id">
                    <option value="">Select Company</option>
                    <option value="1">Elysium Technologies Pvt Ltd</option>
                </select>
                <div class="text-danger" id="company_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="entity_id" id="entity_id">
                    <option value="">Select Entity</option>
                    <option value="1">phdizone</option>
                    <option value="2">Elysium Pro</option>
                    <option value="3">MyProjectBazaar</option>
                    <option value="4">ClickMyProject</option>
                </select>
                <div class="text-danger" id="entity_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input" type="radio" name="brch_fran_chk" id="branch_chk" checked onchange="branch_franchise_func(1);">
                    <label class="form-check-label fs-5 fw-bold" for="branch_chk">Branch</label>
                </div>
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input" type="radio" name="brch_fran_chk" id="franchise_chk" onchange="branch_franchise_func(2);">
                    <label class="form-check-label fs-5 fw-bold" for="franchise_chk">Franchise</label>
                </div>
                <input type="hidden" name="branch_franc" id="branch_franc">
            </div>
            <div class="col-lg-4 mb-3" id="branch_tbox">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Branch Name" id="branch_name" name="branch_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                <div class="text-danger" id="branch_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3" id="bussiness_tbox" style="display: none;">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Name" id="business_name" name="business_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                <div class="text-danger" id="business_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3" id="fran_tbox" style="display: none;">
                <label class="text-black mb-1 fs-6 fw-semibold">Franchise Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Franchise Name" id="franchise_name" name="franchise_name"  oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                <div class="text-danger" id="franchise_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Category<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="branch_category" name="branch_category">
                    <option value="">Select Branch Category</option>
                    @php
                    $get_branch_category_list = $helper->get_branch_category_list();
                    @endphp
                    @foreach ($get_branch_category_list as $br_list)
                    <option value="{{ $br_list->sno }}">
                        {{ $br_list->branchtype_name }}</option>
                    @endforeach
                </select>
                <div class="text-danger" id="branch_category_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="countryId" name="country">
                    <option value="">Select Country</option>
                </select>
                <div class="text-danger" id="countryId_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="stateId" name="state">
                    <option value="">Select State</option>
                </select>
                <div class="text-danger" id="stateId_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="cityId" name="city">
                    <option value="">Select City</option>
                </select>
                <div class="text-danger" id="cityId_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Area / Street" id="area_street" name="area_street"/>
                <div class="text-danger" id="area_street_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Door/Flat No" id="door_flat_no" name="door_flat_no" />
                <div class="text-danger" id="door_flat_no_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Pincode"
                 maxlength="7" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                 id="pincode" name="pincode" />
                <div class="text-danger" id="pincode_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">City Short Code<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter City Short Code"  maxlength="3" id="city_short_code"  name="city_short_code" oninput="this.value = this.value.toUpperCase().replace(/[^a-zA-Z]/g, '');" />
                <div class="text-danger" id="city_short_code_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Call Tracker Company ID</label>
                <input type="text" class="form-control" placeholder="Enter Call Tracker Company ID" maxlength="2" id="call_tracker_id" name="call_tracker_id" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Mobile No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Mobile No" id="business_mobile_no" name="business_mobile_no" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                <div class="text-danger" id="business_mobile_no_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Email ID<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Email ID" id="business_email_id" name="business_email_id" oninput=" this.value = this.value.toLowerCase();" />
                <div class="text-danger" id="business_email_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Communication Email ID<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Communication Email ID" id="comm_email_id" name="comm_email_id"  oninput=" this.value = this.value.toLowerCase();" />
                <div class="text-danger" id="comm_email_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Location URL" id="location_url" name="location_url" />
                <div class="text-danger" id="location_url_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Website URL"  id="website_url" name="website_url"/>
                <div class="text-danger" id="website_url_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Facebook Link</label>
                <input type="text" class="form-control" placeholder="Enter Facebook Link" id="fb_link" name="fb_link"/>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Instagram Link</label>
                <input type="text" class="form-control" placeholder="Enter Instagram Link" id="insta_link" name="insta_link" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Just Dial Branch Code</label>
                <input type="text" class="form-control" placeholder="Enter Just Dial Branch Code"  id="just_dial_id" name="just_dial_id"/>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                <input type="text" class="form-control" placeholder="Enter CIN No"  id="tax_no" name="tax_no"/>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                <input type="text" class="form-control" placeholder="Enter GST No" id="gst_no" name="gst_no" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Pan No</label>
                <input type="text" class="form-control" placeholder="Enter Pan No" id="pan_no" name="pan_no" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Share (as %)<span class="text-danger">*</span></label>
                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Share For Brand In Percentage"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                <input type="text" class="form-control" placeholder="Enter Share (as %)"  id="share_percentage" name="share_percentage"
                 maxlength="2" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                <div class="text-danger" id="share_percentage_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Agreement Start Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="agree_stdt" name="share_start_date" placeholder="Select Date" class="form-control">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Agreement End Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="agree_eddt" name="share_end_date" placeholder="Select Date" class="form-control">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Opening Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="open_dt" name="opening_date" placeholder="Select Date" class="form-control">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Latitude<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="latitude" name="latitude" placeholder="Enter Latitude" />
                <div class="text-danger" id="latitude_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Longitude<span class="text-danger">*</span></label>
                <input type="text" class="form-control"  id="longitude" name="longitude" placeholder="Enter Longitude" />
                <div class="text-danger" id="longitude_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Time Zone<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="time_zone" name="time_zone">
                    <option value="">Select Time Zone</option>
                </select>
                <div class="text-danger" id="time_zone_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="currency_format" name="currency_format">
                    <option value="">Select Currency Format</option>
                </select>
                <div class="text-danger" id="currency_format_err"></div>
            </div>
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Collection Info</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Collection Closing Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="cllt_cl_dt" name="collection_close" placeholder="Select Date" class="form-control">
                </div>
                <div class="text-danger" id="cllt_cl_dt_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Registeration Closing Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="reg_cl_dt" name="registeration_close" placeholder="Select Date" class="form-control">
                </div>
                <div class="text-danger" id="reg_cl_dt_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount Receive<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Minimum Amount Receive" id="min_amnt_receive" name="min_amnt_receive" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                <div class="text-danger" id="min_amnt_receive_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <input class="form-check-input" type="checkbox" id="bus_cls_dt" name="bus_closing_chk_month" onclick="bus_cls_dt_func();">
                <label class="text-black mb-1 fs-6 fw-semibold" id="bus_cls_dt_txt">Business Closing Date (In Count) <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="bus_cls_dt_tbox" name="bus_closing_day_count" placeholder="Enter Business Closing Date(In Count)" style="display: block !important;" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                <div class="text-danger" id="bus_cls_dt_tbox_err"></div>
            </div>
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Name" id="bank_name" name="bank_name" />
                <div class="text-danger" id="bank_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Branch Name" id="bank_branch" name="bank_branch"/>
                <div class="text-danger" id="bank_branch_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account Holder" id="bank_holder" name="bank_holder"/>
                <div class="text-danger" id="bank_holder_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account No" id="bank_account_no" name="bank_account_no"/>
                <div class="text-danger" id="bank_account_no_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter IFSC Code" id="bank_ifsc" name="bank_ifsc"/>
                <div class="text-danger" id="bank_ifsc_err"></div>
            </div>
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">API Details</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Cloud Call API Key</label>
                <textarea class="form-control" rows="1" placeholder="Enter Cloud Call API Key" id="cloud_call_api_key" name="cloud_call_api_key"></textarea>
            </div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control h-auto" placeholder="Enter Description" id="api_desc" name="api_desc"></textarea>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2">
            <a href="{{url('/branch')}}" class="btn fw-bold btn-secondary me-3">Cancel</a>
            <button type="button" class="btn fw-bold btn-primary"  data-bs-target="#kt_modal_create_branch" id="brch_fran_butt" onclick="branch_validate()">
                Create Branch
            </button>
        </div>
    </div>
    </form>
</div>




<!--begin::Modal - Create Branch-->
<div class="modal fade" id="kt_modal_create_branch" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                <span id="create_label"> Create Branch </span> ?
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <a href="{{url('/branch')}}" class="btn fw-bold btn-primary me-3">Yes</a>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Branch-->

<!-- validation Script -->
 <script>
    function branch_validate() {
        // Get input values
        var company_id = $('#company_id').val();
        var entity_id = $('#entity_id').val();
        var branch_name = $('#branch_name').val();
        var business_name = $('#business_name').val();
        var franchise_name = $('#franchise_name').val();
        var branch_category = $('#branch_category').val();
        var country = $('#countryId').val();
        var state = $('#stateId').val();
        var city = $('#cityId').val();
        var area_street = $('#area_street').val();
        var door_flat_no = $('#door_flat_no').val();
        var pincode = $('#pincode').val();
        var city_short_code = $('#city_short_code').val();
        var business_mobile_no = $('#business_mobile_no').val();
        var business_email_id = $('#business_email_id').val();
        var comm_email_id = $('#comm_email_id').val();
        var location_url = $('#location_url').val();
        var website_url = $('#website_url').val();
        var share_percentage = $('#share_percentage').val();
        var latitude = $('#latitude').val();
        var longitude = $('#longitude').val();



        // Clear previous error messages
        $('#company_id_err').text('');
        $('#entity_id_err').text('');
        $('#branch_name_err').text('');
        $('#business_name_err').text('');
        $('#franchise_name_err').text('');
        $('#branch_category_err').text('');
        $('#countryId_err').text('');
        $('#stateId_err').text('');
        $('#cityId_err').text('');
        $('#area_street_err').text('');
        $('#door_flat_no_err').text('');
        $('#pincode_err').text('');
        $('#city_short_code_err').text('');
       
        

        let err = false;

            if (company_id === '') {
                $('#company_id_err').text('Company Name is required.');
                err = true;
            }
            if (entity_id === '') {
                $('#entity_id_err').text('Entity Name is required.');
                err = true;
            }

        
        var branch_chk = document.getElementById("branch_chk");
        if (branch_chk.checked) {
            if (branch_name === '') {
                $('#branch_name_err').text('Branch Name is required.');
                err = true;
            }
            
        } else {
            if (business_name === '') {
                $('#business_name_err').text('Business Name is required.');
                err = true;
            }
            if (franchise_name === '') {
                $('#franchise_name_err').text('Franchise Name is required.');
                err = true;
            }
        }
        // Validate required fields
       
        if (branch_category === '') {
            $('#branch_category_err').text('Branch Category is required.');
            err = true;
        }
        if (country === '') {
            $('#countryId_err').text('Country is required.');
            err = true;
        }
        if (state === '') {
            $('#stateId_err').text('State is required.');
            err = true;
        }
        if (city === '') {
            $('#cityId_err').text('City is required.');
            err = true;
        }
        if (area_street === '') {
            $('#area_street_err').text('Area Street is required.');
            err = true;
        }
        if (door_flat_no === '') {
            $('#door_flat_no_err').text('Door Flat No is required.');
            err = true;
        }
        if (pincode === '') {
            $('#pincode_err').text('Pincode is required.');
            err = true;
        }

        if (city_short_code === '') {
            $('#city_short_code_err').text('City Short code is required.');
            err = true;
        }

            var modalElement = document.getElementById('kt_modal_create_branch');
            var modal = new bootstrap.Modal(modalElement);
        
            if (err) {
                return false;
            } else {
                modal.show();
            }
        }

 </script>

<script>
    function branch_franchise_func(val) {
        if (val == '2') {
            document.getElementById("branch_tbox").style.display = "none";
            document.getElementById("bussiness_tbox").style.display = "block";
            document.getElementById("fran_tbox").style.display = "block";
            document.getElementById("brch_fran_tle").innerHTML = "Create Franchise";
            document.getElementById("brch_fran_butt").innerHTML = "Create Franchise";
            document.getElementById("create_label").innerHTML = "Create Franchise";
            $('#branch_franc').val(val);

        } else {
            document.getElementById("branch_tbox").style.display = "block";
            document.getElementById("bussiness_tbox").style.display = "none";
            document.getElementById("fran_tbox").style.display = "none";
            document.getElementById("brch_fran_tle").innerHTML = "Create Branch";
            document.getElementById("brch_fran_butt").innerHTML = "Create Branch";
            document.getElementById("create_label").innerHTML = "Create Branch";
            $('#branch_franc').val(val);
        }
    }
</script>
<script>
    function bus_cls_dt_func() {
        var bus_cls_dt = document.getElementById("bus_cls_dt");
        var bus_cls_dt_txt = document.getElementById("bus_cls_dt_txt");
        var bus_cls_dt_tbox = document.getElementById("bus_cls_dt_tbox");

        if (bus_cls_dt.checked) {
            bus_cls_dt_txt.innerHTML = "Business Closing Date is Month End";
            bus_cls_dt_tbox.style.setProperty("display", "none", "important");
        } else {
            bus_cls_dt_txt.innerHTML = "Business Closing Date (In Count) <span class='text-danger'>*</span>";
            bus_cls_dt_tbox.style.setProperty("display", "block", "important");
        }
    }
</script>

@endsection