@extends('layouts/layoutMaster')

@section('title', 'Manage Entity')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Entity</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                    <span><i class="mdi mdi-filter-outline"></i></span>
                </a> -->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_create_entity">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Entity
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Entity</th>
                            <th class="min-w-100px">Company</th>
                            <th class="min-w-100px">Address</th>
                            <th class="min-w-100px">Contact Person / Mobile</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-100px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="text-truncate max-w-175px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Phdizone">Phdizone</div>
                                    <a href="https://elysiumtechnologies.com/" target="_blank" class="ms-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website URL">
                                        <i class="mdi mdi-web fs-4 text-dark"></i>
                                    </a>
                                    <a href="javascript:;" class="ms-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="presale@phdizone.com">
                                        <i class="mdi mdi-email-outline fs-4 text-dark"></i>
                                    </a>
                                </div>
                                <div class="d-block">
                                    <label class="badge bg-warning fs-8 text-black fw-bold">Brand 1</label>
                                </div>
                            </td>
                            <td>
                                <label>Elysium Technologies Pvt Ltd</label>
                            </td>
                            <td>
                                <div class="text-wrap max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="229, Ist & IInd Floor, A, Block, Elysium Campus, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020">229, Ist & IInd Floor, A, Block, Elysium Campus, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020</div>
                            </td>
                            <td>
                                <label>Muthumari A</label>
                                <div class="d-block">
                                    <label class="fs-8 text-black fw-semibold">9944793398</label>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td class="text-end">
                                <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_company">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                </a>
                                <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_update_company">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                </a>
                                <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_company">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Create Entity-->
<div class="modal fade" id="kt_modal_create_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Create Entity</h3>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Company</option>
                            <option value="1">Elysium Technologies Pvt Ltd</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Entity Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Brand<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Brand</option>
                            <option value="1">Brand 1</option>
                            <option value="2">Brand 2</option>
                            <option value="3">Brand 3</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Email ID" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Website URL" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Contact Person Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Country</option>
                            <option value="1">USA</option>
                            <option value="2">UAE</option>
                            <option value="3">India</option>
                            <option value="4">South Africa</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select State</option>
                            <option value="1">Tamilnadu</option>
                            <option value="2">Andhra Pradesh</option>
                            <option value="3">Kerala</option>
                            <option value="4">Karnataka</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select City</option>
                            <option value="1">Madurai</option>
                            <option value="2">Virudhunagar</option>
                            <option value="3">Thirunelveli</option>
                            <option value="4">Coimbatore</option>
                            <option value="5">Chennai</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Area / Street" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Door/Flat No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Pincode" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">GST No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter GST No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter CIN No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Pan No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Pan No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Tax No" />
                    </div>
                    <div class="col-lg-8 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control h-auto" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="divider">
                    <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Bank Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Bank Branch Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Account Holder" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Account No" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter IFSC Code" />
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Entity</button>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Create Entity-->


<!--begin::Modal - Update Entity-->
<div class="modal fade" id="kt_modal_update_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Entity</h3>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Company</option>
                            <option value="1" selected>Elysium Technologies Pvt Ltd</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Entity Name" value="PhDiZone" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Brand<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Brand</option>
                            <option value="1" selected>Brand 1</option>
                            <option value="2">Brand 2</option>
                            <option value="3">Brand 3</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Email ID" value="presale@phdizone.com" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Website URL" value="https://phdizone.com/" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Contact Person Name" value="Muthumari A" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" value="9944049888" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Country</option>
                            <option value="1">USA</option>
                            <option value="2">UAE</option>
                            <option value="3" selected>India</option>
                            <option value="4">South Africa</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select State</option>
                            <option value="1" selected>Tamilnadu</option>
                            <option value="2">Andhra Pradesh</option>
                            <option value="3">Kerala</option>
                            <option value="4">Karnataka</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select City</option>
                            <option value="1" selected>Madurai</option>
                            <option value="2">Virudhunagar</option>
                            <option value="3">Thirunelveli</option>
                            <option value="4">Coimbatore</option>
                            <option value="5">Chennai</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Area / Street" value="Ist & IInd Floor, A, Block, Elysium Campus, Church Rd, Anna Nagar" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Door/Flat No" value="229" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Pincode" value="625020" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">GST No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter GST No" value="29AAGFV1234M1Z6" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter CIN No" value="U67190KA2012LLP012345" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Pan No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Pan No" value="AAGFV1234M" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Tax No" value="3456789012" />
                    </div>
                    <div class="col-lg-8 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control h-auto" placeholder="Enter Description">-</textarea>
                    </div>
                </div>
                <div class="divider">
                    <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Bank Name" value="HDFC" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Bank Branch Name" value="Anna Nagar" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Account Holder" value="phdizone" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Account No" value="6523145278745" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter IFSC Code" value="HDFC0002027" />
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Entity</button>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Update Entity-->


<!--begin::Modal - View Entity-->
<div class="modal fade" id="kt_modal_view_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8">
                    <h3 class="mb-4 text-black text-center">View Entity</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mt-4">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Entity</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PhDiZone">PhDiZone</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Elysium Technologies">Elysium Technologies</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Brand</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Brand 1">Brand 1</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="presale@phdizone.com">presale@phdizone.com</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Website URL</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <a href="https://phdizone.com/" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="https://phdizone.com/">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold">https://phdizone.com/</div>
                                </a>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Contact Person</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Muthumari A">Muthumari A</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">C.P. Mobile No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">9944049888</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">229, Ist & IInd Floor, A, Block, Elysium Campus, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">GST No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="29AAGFV1234M1Z6">29AAGFV1234M1Z6</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">CIN No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="U67190KA2012LLP012345">U67190KA2012LLP012345</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Pan No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="AAGFV1234M">AAGFV1234M</div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Tax No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="3456789012">3456789012</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-6 fw-bold">&emsp;&emsp;&emsp; -</label>
                </div>
                <div class="divider">
                    <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                </div>
                <div class="row">
                    <div class="col-lg-6 mt-4">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Bank</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">HDFC</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Branch</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">Anna Nagar</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">IFSC Code</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">HDFC0002027</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Account Holder</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">phdizone</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Account No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">6523145278745</label>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Entity-->


<!--begin::Modal - Delete Entity-->
<div class=" modal fade" id="kt_modal_delete_company" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Entity?
                <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                    <label>phdizone</label>
                    <span class="ms-2 me-2">-</span>
                    <label>Elysium Technologies</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Entity-->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection