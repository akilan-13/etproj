@extends('layouts/layoutMaster')

@section('title', 'Manage Attendance')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Attendance</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-end align-items-center mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_add_staff_attendance">
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Attendance
            </a>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-2">
            <div class="d-flex align-items-cstify-center me-3">
                <label class="badge bg-success fw-bold text-black fw-bold rounded px-2 py-1"><span>P</span></label>
                <span class="fs-6 fw-semibold ms-1">Present</span>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-danger text-white rounded px-2 py-1"><span>A</span></label>
                <span class="fs-6 fw-semibold ms-1">Absent</span>
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave Without Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-info text-white rounded px-2 py-1"><span>L</span></label>
                <span class="fs-6 fw-semibold ms-1">Leave</span>
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave With Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-secondary text-white rounded px-2 py-1"><span>OD</span></label>
                <span class="fs-6 fw-semibold ms-1">On Duty</span>
                <div class="">
                    <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                    </a>
                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                        <div class="d-flex align-items-center mb-2 ">
                            <label><span class="badge bg-secondary rounded text-white px-2 py-1">30 M</span></label>
                            <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                            <label class="fs-6 fw-semibold">30 Minutes</label>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <label><span class="badge bg-secondary rounded text-white px-2 py-1">1 H</span></label>
                            <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                            <label class="fs-6 fw-semibold">1 Hour</label>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <label><span class="badge bg-secondary rounded text-white px-2 py-1">1.5 H</span></label>
                            <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                            <label class="fs-6 fw-semibold">1.5 Hours</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-primary text-white rounded px-2 py-1"><span>Pr</span></label>
                <span class="fs-6 fw-semibold ms-1">Permission</span>
                <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                </a>
                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                    <div class="d-flex align-items-center mb-2 ">
                        <label><span class="badge bg-primary rounded text-white px-2 py-1">30 M</span></label>
                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                        <label class="fs-6 fw-semibold">30 Minutes</label>
                    </div>
                    <div class="d-flex align-items-center mb-2">
                        <label><span class="badge bg-primary rounded text-white px-2 py-1">1 H</span></label>
                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                        <label class="fs-6 fw-semibold">1 Hour</label>
                    </div>
                    <div class="d-flex align-items-center mb-2">
                        <label><span class="badge bg-primary rounded text-white px-2 py-1">1.5 H</span></label>
                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                        <label class="fs-6 fw-semibold">Half Day</label>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge text-white rounded px-2 py-1" style="background-color:#f47507;"><span>WK</span></label>
                <span class="fs-6 fw-semibold ms-1">Week End</span>
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave With Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table_1 table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page ">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-200px text-center">Staff</th>
                            <th class="min-w-200px text-center">Branch</th>
                            <th class="min-w-25px text-center">01/09<br>Sun</th>
                            <th class="min-w-25px text-center">02/09<br>Mon</th>
                            <th class="min-w-25px text-center">03/09<br>Tue</th>
                            <th class="min-w-25px text-center">04/09<br>Wed</th>
                            <th class="min-w-25px text-center">05/09<br>Thu</th>
                            <th class="min-w-25px text-center">06/09<br>Fri</th>
                            <th class="min-w-25px text-center">07/09<br>Sat</th>
                            <th class="min-w-25px text-center">08/09<br>Sun</th>
                            <th class="min-w-25px text-center">09/09<br>Mon</th>
                            <th class="min-w-25px text-center">10/09<br>Tue</th>
                            <th class="min-w-25px text-center">11/09<br>Wed</th>
                            <th class="min-w-25px text-center">12/09<br>Thu</th>
                            <th class="min-w-25px text-center">13/09<br>Fri</th>
                            <th class="min-w-25px text-center">14/09<br>Sat</th>
                            <th class="min-w-25px text-center">15/09<br>Sun</th>
                            <th class="min-w-25px text-center">16/09<br>Mon</th>
                            <th class="min-w-25px text-center">17/09<br>Tue</th>
                            <th class="min-w-25px text-center">18/09<br>Wed</th>
                            <th class="min-w-25px text-center">19/09<br>Thu</th>
                            <th class="min-w-25px text-center">20/09<br>Fri</th>
                            <th class="min-w-25px text-center">21/09<br>Sat</th>
                            <th class="min-w-25px text-center">22/09<br>Sun</th>
                            <th class="min-w-25px text-center">23/09<br>Mon</th>
                            <th class="min-w-25px text-center">24/09<br>Tue</th>
                            <th class="min-w-25px text-center">25/09<br>Wed</th>
                            <th class="min-w-25px text-center">26/09<br>Thu</th>
                            <th class="min-w-25px text-center">27/09<br>Fri</th>
                            <th class="min-w-25px text-center">28/09<br>Sat</th>
                            <th class="min-w-25px text-center">29/09<br>Sun</th>
                            <th class="min-w-25px text-center">30/09<br>Mon</th>
                            <th class="min-w-25px text-center">31/09<br>Tue</th>
                            <th class="min-w-150px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold">
                        <tr>
                            <td>
                                <div class="d-flex px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1" title="Staff Name" data-bs-toggle="tooltip" data-bs-placement="bottom">Sabana Barveen</span>
                                        </label>
                                        <div class="d-block">
                                            <label class="badge bg-label-info text-info fw-bold fs-9" title="Department" data-bs-toggle="tooltip" data-bs-placement="bottom">Production</label>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7 text-black fw-bold">
                                    <label class="text-truncate min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="madurai - Anna Nagar">Madurai - Anna Nagar</label>
                                </label>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7 fw-bold">
                                <span class="badge rounded bg-danger text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">A</span>
                            </td>
                            <td class="">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-info rounded bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">L</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7 fw-bold">
                                <span class="badge rounded bg-primary text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">1 Hr</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-secondary fw-bold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">1 Hr</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7 fw-bold">
                                <span class="badge rounded bg-primary text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">0.5 D</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff_attendance">
                                        <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span></a>
                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_attendance" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                        <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                    </a>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1" title="Staff Name" data-bs-toggle="tooltip" data-bs-placement="bottom">Vidhuba</span>
                                        </label>
                                        <div class="d-block">
                                            <label class="d-block badge bg-label-info text-info fw-bold fs-9" title="Department" data-bs-toggle="tooltip" data-bs-placement="bottom">Sales</label>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fs-7 text-black fw-bold">
                                    <label class="text-truncate min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="madurai - Anna Nagar">Chennai - CIT Nagar</label>
                                </label>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7 fw-bold">
                                <span class="badge rounded bg-danger text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">A</span>
                            </td>
                            <td class="">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-info rounded bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="">L</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7 fw-bold">
                                <span class="badge rounded bg-primary text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">1 Hr</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-secondary fw-bold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">1 Hr</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7 fw-bold">
                                <span class="badge rounded bg-primary text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">0.5 D</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fw-bold">
                                <span class="badge rounded fs-9" style="background-color:#f47507;" data-bs-toggle="tooltip" data-bs-placement="bottom">WK</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td class="fs-7">
                                <span class="badge rounded bg-success fw-bold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom">P</span>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_lead">
                                        <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span></a>
                                    <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_attendance" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                        <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                    </a>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Staff Attendance-->
<div class="modal fade" id="kt_modal_add_staff_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Add Staff Attendance</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_dob" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Branch</option>
                            <option value="1">Madurai - Anna Nagar</option>
                            <option value="2">Chennai - CIT Nagar</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Department</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="2">IS</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select" multiple>
                            <option value="">Select Staff</option>
                            <option value="1">Sabanaa Barveen</option>
                            <option value="2">Vidhuba</option>
                            <option value="3">Kavi Priya</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Entry<span class="text-danger">*</span></label>
                        <select id="mark_attendance" name="mark_attendance" class="select3 form-select" onchange="entry_func();">
                            <option value="">Select Entry</option>
                            <option value="present">Present</option>
                            <option value="absent">Absent (Leave Without Intimation)</option>
                            <option value="leave">Leave (Leave With Intimation)</option>
                            <option value="permission">Permission</option>
                            <option value="on_duty">On Duty</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="start_time_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_start_time" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="end_time_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_end_time" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="absent_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                        <select id="type" name="type" class="select3 form-select" onchange="type_func();">
                            <option value="">Select Type</option>
                            <option value="today">Today</option>
                            <option value="another_days">Another Days</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="another_days_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Another Days<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="another_days_multi" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="leave_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Reason"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Add Attendance</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Staff Attendance-->

<!--begin::Modal - Edit Staff Attendance-->
<div class="modal fade" id="kt_modal_edit_staff_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Staff Attendance</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_att_date_edit" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Branch</option>
                            <option value="1">Madurai - Anna Nagar</option>
                            <option value="2">Chennai - CIT Nagar</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Department</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="2">IS</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Staff</option>
                            <option value="1" selected>Sabanaa Barveen</option>
                            <option value="2">Vidhuba</option>
                            <option value="3">Kavi Priya</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Entry<span class="text-danger">*</span></label>
                        <select id="mark_attendance_edit" name="mark_attendance_edit" class="select3 form-select" onchange="entry_edit_func();">
                            <option value="">Select Entry</option>
                            <option value="present">Present</option>
                            <option value="absent">Absent (Leave Without Intimation)</option>
                            <option value="leave">Leave (Leave With Intimation)</option>
                            <option value="permission">Permission</option>
                            <option value="on_duty">On Duty</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="start_time_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_start_time_edit" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="end_time_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_end_time_edit" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="absent_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                        <select id="type_edit" name="type_edit" class="select3 form-select" onchange="type_func_edit();">
                            <option value="">Select Type</option>
                            <option value="today">Today</option>
                            <option value="another_days">Another Days</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="another_days_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Another Days<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="another_days_multi" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="leave_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Attendance</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Staff Attendance--->

<!--begin::Modal - View Staff Attendance-->
<div class="modal fade" id="kt_modal_view_staff_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">View Staff Attendance</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <!-- <div class="col-lg-12">
                                <div class="d-flex px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1" title="Staff Name" data-bs-toggle="tooltip" data-bs-placement="bottom">Vidhuba</span>
                                        </label>
                                        <div class="d-block">
                                            <label class="d-block badge bg-label-info text-info fw-bold fs-9" title="Department" data-bs-toggle="tooltip" data-bs-placement="bottom">Sales</label>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <div class="col-lg-2">
                                <div class="row">
                                    <div class="align-items-sm-center gap-4">
                                        <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="row">
                                    <!-- <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">
                                                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-bold">
                                                <span>Priya Dharshini</span>
                                                <span class="badge bg-danger text-white fs-8 rounded">F</span>
                                            </label>
                                        </div>
                                    </div> -->
                                    <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date">
                                                <i class="mdi mdi-calendar-range fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-semibold">
                                                02-Sep-2024
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department">
                                                <i class="mdi mdi-graph-outline fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-semibold">
                                                Madurai - Anna Nagar
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department">
                                                <i class="mdi mdi-account-question-outline fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-semibold">
                                                Production
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="col-lg-12">
                                    <div class="justify-content-start">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Role">
                                            <i class="mdi mdi-shield-account-outline fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span class="badge bg-info">Developer</span></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="justify-content-start">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Role">
                                            <i class="mdi mdi-email-edit-outline fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">sabana@gmail.com</label>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="justify-content-start">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Role">
                                            <i class="mdi mdi-phone-outline fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">9876543210</label>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-danger text-white rounded px-2 py-1"><span>A</span></label>
                            <span class="fs-6 fw-semibold ms-1">Absent</span>
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave Without Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
                        </div>
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-info text-white rounded px-2 py-1"><span>L</span></label>
                            <span class="fs-6 fw-semibold ms-1">Leave</span>
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave With Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
                        </div>
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-secondary text-white rounded px-2 py-1"><span>OD</span></label>
                            <span class="fs-6 fw-semibold ms-1">On Duty</span>

                            <div class="">
                                <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                                </a>
                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                                    <div class="d-flex align-items-center mb-2 ">
                                        <label><span class="badge bg-secondary rounded text-white px-2 py-1">30 M</span></label>
                                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                        <label class="fs-6 fw-semibold">30 Minutes</label>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <label><span class="badge bg-secondary rounded text-white px-2 py-1">1 H</span></label>
                                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                        <label class="fs-6 fw-semibold">1 Hour</label>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <label><span class="badge bg-secondary rounded text-white px-2 py-1">1.5 H</span></label>
                                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                        <label class="fs-6 fw-semibold">1.5 Hours</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-primary text-white rounded px-2 py-1"><span>Pr</span></label>
                            <span class="fs-6 fw-semibold ms-1">Permission</span>
                            <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                            </a>
                            <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                                <div class="d-flex align-items-center mb-2 ">
                                    <label><span class="badge bg-primary rounded text-white px-2 py-1">30 M</span></label>
                                    <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                    <label class="fs-6 fw-semibold">30 Minutes</label>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <label><span class="badge bg-primary rounded text-white px-2 py-1">1 H</span></label>
                                    <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                    <label class="fs-6 fw-semibold">1 Hour</label>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <label><span class="badge bg-primary rounded text-white px-2 py-1">1.5 H</span></label>
                                    <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                    <label class="fs-6 fw-semibold">Half Day</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mt-4">
                        <table class="table_2 table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 view_list_page dataTables_scroll">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-150px">Date</th>
                                    <th class="min-w-150px">Attendance</th>
                                    <th class="min-w-100px">Timing</th>
                                    <th class="min-w-150px">Reason</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold">
                                <tr>
                                    <td class="fw-bold">
                                        <span class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom">04-Sep-2024</span>
                                        <div>
                                            <label>Wed</label>
                                        </div>
                                    </td>
                                    <td class="fs-7">
                                        <span class="badge rounded bg-danger fw-bold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">A</span>
                                    </td>
                                    <td class="fs-7">
                                        <label>-</label>
                                    </td>
                                    <td class="fs-7">
                                        <label>-</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">
                                        <span class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom">06-Sep-2024</span>
                                        <div>
                                            <label>Fri</label>
                                        </div>
                                    </td>
                                    <td class="fs-7">
                                        <span class="badge rounded bg-info fw-bold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">L</span>
                                    </td>
                                    <td class="fs-7">
                                        <label>-</label>
                                    </td>
                                    <td class="fs-7">
                                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Going To Temple">Going To Temple</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">
                                        <span class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom">17-Sep-2024</span>
                                        <div>
                                            <label>Tue</label>
                                        </div>
                                    </td>
                                    <td class="fs-7">
                                        <span class="badge rounded bg-primary fw-bold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">Pr</span>
                                    </td>
                                    <td class="fs-7">
                                        <label>09:00 AM</label>
                                        <label>12:00 AM</label>
                                    </td>
                                    <td class="fs-7">
                                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Going To Temple">Going To Temple</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">
                                        <span class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom">14-Sep-2024</span>
                                        <div>
                                            <label>sat</label>
                                        </div>
                                    </td>
                                    <td class="fs-7">
                                        <span class="badge rounded bg-secondary fw-bold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom">OD</span>
                                    </td>
                                    <td class="fs-7">
                                        <label>09:00 AM</label>
                                        <label>12:00 AM</label>
                                    </td>
                                    <td class="fs-7">
                                        <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Client Meeting">Client Meeting</label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Staff Attendance--->


<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    $(".view_list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +

            "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>"


    });
</script>

<style>
    .table_1-container {
        overflow-x: auto;
        overflow-y: auto;
        max-height: 600px;
        position: relative;
    }

    .table_1 {
        border-collapse: separate;
        border-spacing: 0;
        width: 100%;
    }

    .table_1 thead th,
    .table_1 tbody td {
        position: relative;
        z-index: 1;
        padding: 8px;
    }

    .table_1 thead th {
        position: sticky;
        top: 0;
        background: #099dda;
        color: #fff;
        z-index: 3;
    }

    .table_1 tbody td {
        background: #fff;
        color: #000;
    }

    .table_1 thead th:first-child,
    .table_1 thead th:nth-child(2),
    .table_1 thead th:nth-child(26),
    .table_1 thead th:nth-child(27),
    .table_1 thead th:nth-child(28),
    .table_1 thead th:nth-child(29),
    .table_1 thead th:last-child {
        position: sticky;
        background: #099dda;
        z-index: 4;
    }



    .table_1 tbody td:first-child,
    .table_1 tbody td:nth-child(2),
    .table_1 tbody td:last-child {
        position: sticky;
        background: #fff;
        z-index: 4;
    }

    .table_1 thead th:first-child,
    .table_1 tbody td:first-child {
        left: 0;
    }

    .table_1 thead th:nth-child(2),
    .table_1 tbody td:nth-child(2) {
        left: 200px;
    }

    .table_1 thead th:last-child,
    .table_1 tbody td:last-child {
        right: 0;
    }


    .table_1 tbody td {
        z-index: 2;
    }
</style>
<style>
    .table_2-container {
        max-height: 100px;
        /* Adjust the height as needed */
        overflow-y: scroll;
    }

    .table_2 thead th {
        position: sticky;
        top: 0;
    }
</style>

<script>
    function entry_func() {
        var mark_attendance = document.getElementById("mark_attendance").value;
        var leave = document.getElementById("leave");
        var present = document.getElementById("present");
        var permission = document.getElementById("permission");
        var on_duty = document.getElementById("on_duty");
        var absent = document.getElementById("absent");
        var another_days = document.getElementById("another_days");
        if (mark_attendance == "leave") {
            leave_view.style.display = "block";
            start_time_view.style.display = "none";
            end_time_view.style.display = "none";
            another_days_view.style.display = "none";
            absent_view.style.display = "none";
        } else if (mark_attendance == "permission") {
            start_time_view.style.display = "block";
            end_time_view.style.display = "block";
            leave_view.style.display = "block";
            absent_view.style.display = "none";
            another_days_view.style.display = "none";
        } else if (mark_attendance == "on_duty") {
            start_time_view.style.display = "block";
            end_time_view.style.display = "block";
            leave_view.style.display = "block";
            absent_view.style.display = "none";
            another_days_view.style.display = "none";
        } else if (mark_attendance == "absent") {
            start_time_view.style.display = "none";
            end_time_view.style.display = "none";
            leave_view.style.display = "none";
            absent_view.style.display = "block";
            another_days_view.style.display = "none";
        }
    }
</script>

<script>
    function type_func() {
        var type = document.getElementById("type").value;
        var today = document.getElementById("today");
        var another_days = document.getElementById("another_days");
        if (type == "today") {
            another_days_view.style.display = "none";
            leave_view.style.display = "block";
        } else if (type == "another_days") {
            another_days_view.style.display = "block";
            leave_view.style.display = "block";
        }
    }
</script>

<script>
    function entry_edit_func() {
        var mark_attendance_edit = document.getElementById("mark_attendance_edit").value;
        var leave = document.getElementById("leave");
        var present = document.getElementById("present");
        var permission = document.getElementById("permission");
        var on_duty = document.getElementById("on_duty");
        var absent = document.getElementById("absent");
        var another_days = document.getElementById("another_days");
        if (mark_attendance_edit == "leave") {
            leave_view_edit.style.display = "block";
            start_time_view_edit.style.display = "none";
            end_time_view_edit.style.display = "none";
            another_days_view_edit.style.display = "none";
            absent_view_edit.style.display = "none";
        } else if (mark_attendance_edit == "permission") {
            start_time_view_edit.style.display = "block";
            end_time_view_edit.style.display = "block";
            leave_view_edit.style.display = "block";
            absent_view_edit.style.display = "none";
            another_days_view_edit.style.display = "none";
        } else if (mark_attendance_edit == "on_duty") {
            start_time_view_edit.style.display = "block";
            end_time_view_edit.style.display = "block";
            leave_view_edit.style.display = "block";
            another_days_view_edit.style.display = "none";
            absent_view_edit.style.display = "none";
        } else if (mark_attendance_edit == "absent") {
            start_time_view_edit.style.display = "none";
            end_time_view_edit.style.display = "none";
            leave_view_edit.style.display = "none";
            absent_view_edit.style.display = "block";
            another_days_view_edit_edit.style.display = "none";
        }
    }
</script>
<script>
    function type_func_edit() {
        var type_edit = document.getElementById("type_edit").value;
        var today = document.getElementById("today");
        var another_days = document.getElementById("another_days");
        if (type_edit == "today") {
            another_days_view_edit.style.display = "none";
            leave_view_edit.style.display = "block";
        } else if (type_edit == "another_days") {
            another_days_view_edit.style.display = "block";
            leave_view_edit.style.display = "block";
        }
    }
</script>
@endsection