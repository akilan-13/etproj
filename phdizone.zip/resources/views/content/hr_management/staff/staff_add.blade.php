@extends('layouts/layoutMaster')

@section('title', 'Create Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/tagify/tagify.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms_tagify.js')
@vite('resources/assets/js/forms_file_upload.js')
@endsection

@section('content')
<!-- Staff Add -->
<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Staff</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Staff</a>
                </li>
            </ol>
        </nav>
    </div>
</div>

<!-- Staff Basic Information -->
<div class="card mb-2 px-4 py-2">
    <h5 class="title mt-4 fw-bold">Basic Information</h5>
    <div class="row mt-4">
        <div class="col-lg-4 mb-3" id="branch_add">
            <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
                <option value="">Select Branch Name</option>
                <option value="1">Madurai - Anna Nagar</option>
                <option value="2">Chennai - CIT Nagar</option>
                <option value="2">Coimbatore - Siddapudur</option>
            </select>
        </div>
        <div class="col-lg-4 mb-3" id="department">
            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
                <option value="">Select Department Name</option>
                <option value="1">Sales</option>
                <option value="2">Production</option>
                <option value="2">IS</option>
            </select>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">White Listed IP's</label>
            <input type="text" class="form-control" id="" placeholder="Enter White Listed IP's" value="192.168.03" disabled />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Staff Name" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                <label class="form-check-label" for="inlineRadio1">Male</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
                <label class="form-check-label" for="inlineRadio2">Female</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" />
                <label class="form-check-label" for="inlineRadio3">Others</label>
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Date of Birth<span class="text-danger">*</span></label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                <input type="text" id="staff_dob" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Mobile Number" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Alternate Mobile Number" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter E-Mail ID" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Contact Person Name" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Mobile Number<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" id="" placeholder="Enter Contact Person Mobile Number" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Marital Status</label>
            <select id="" class="select3 form-select">
                <option value="">Select Marital Status</option>
                <option value="1">Married</option>
                <option value="2">Un Married</option>
            </select>
        </div>
        <div class="col-lg-4">
            <label class="text-dark mb-1 fs-6 fw-semibold">Address</label>
            <textarea class="form-control" rows="3" id="" placeholder="Enter Description"></textarea>
        </div>
        <div class="col-lg-4">
            <div class="row">
                <label class="col-lg-6 text-dark fs-6 fw-semibold">Staff Image<span class="text-danger">*</span></label>
                <!-- <div class="col-lg-6"> -->
                <div class="align-items-sm-center gap-4">
                    <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                    <div class="button-wrapper">
                        <div class="d-flex align-items-start mt-2 mb-2">
                            <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                <i class="mdi mdi-tray-arrow-up"></i>
                                <input type="file" id="upload" class="file-in" hidden accept="image/png, image/jpeg" />
                            </label>
                            <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                                <i class="mdi mdi-reload"></i>
                            </button>
                        </div>
                        <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                    </div>
                </div>
                <!-- </div> -->
            </div>
        </div>
    </div>
</div>
<!-- End Staff Basic Information -->
<!-- Staff Educational Information -->
<div class="card px-4 py-2 mb-2">
    <h5 class="title mb-1 fw-bold mt-4">Educational Information</h5>
    <div class="row">
        <div class="form-repeater_edu_info">
            <div data-repeater-list="group-a_led_question">
                <div data-repeater-item>
                    <div class="row mt-4">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Qualification Type<span class="text-danger">*</span></label>
                                    <select id="" class="select3 form-select">
                                        <option value="">Select Qualification Type</option>
                                        <option value="1">Ph.D</option>
                                        <option value="2">M.Phil</option>
                                        <option value="2">Post Graduate</option>
                                        <option value="2">Under Graduate</option>
                                        <option value="2">Diploma</option>
                                        <option value="2">HSC</option>
                                        <option value="2">SSLC</option>
                                    </select>
                                </div>
                                <div class="col-lg-2 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Degree Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Degree Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Major<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Major Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">University / Instiute Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter University Name" />
                                </div>
                                <div class="col-lg-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_edu_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="staff_edu_del" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-1 mt-1">
            <button class="btn btn-primary staff_edu_info_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="staff_edu_info_add">
                <i class="mdi mdi-plus me-1"></i>
            </button>
        </div>
    </div>
    <h5 class="title mb-1 fw-bold mt-4">Work Information</h5>
    <div class="row mt-4">
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
            <select id="create_staff" name="create_staff" class="select3 form-select" onchange="staff_func();">
                <option value="">Select Type</option>
                <option value="fresher">Fresher</option>
                <option value="experience">Experience</option>
            </select>
        </div>
    </div>
    <div class="row" id="staff_experience" style="display: none !important;">
        <div class="form-repeater_staff_exp_add">
            <div data-repeater-list="group-a_led_question">
                <div data-repeater-item>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Position<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Position" />
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Years of Experience<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Years of Experience" />
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Company Name" />
                                </div>

                                <div class="col-lg-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_del_button" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="staff_del_button" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-1 mt-1">
            <button class="btn btn-primary staff_exp_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="staff_exp_add">
                <i class="mdi mdi-plus me-1"></i>
            </button>
        </div>
    </div>
</div>
<!-- End Staff Educational Information -->
<!-- Staff Knowledge Information -->
<div class="card px-4 py-2 mb-2">
    <h5 class="title mb-1 fw-bold mt-4">Knowledge Information</h5>
    <div class="row mt-4">
        <label class="text-dark mb-1 fs-6 fw-semibold">Knowledge Tag<span class="text-danger">*</span></label>
        <div class="form-floating form-floating-outline">
            <input id="KnowledgeTag" name="KnowledgeTag" class="form-control h-auto" placeholder="Select Knowledge Tags" value="Python - Full Stack Developer">
        </div>
    </div>
</div>
<!-- End Staff Knowledge Information -->
<!-- Staff Designation Information -->
<div class="card px-4 py-2 mb-2">
    <h5 class="title mb-1 fw-bold mt-4">Designation Information</h5>
    <div class="row mt-4">
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Nick Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Nick Name" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Date of Joining<span class="text-danger">*</span></label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                <input type="text" id="staff_doj" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
            <select id="job_role" class="select3 form-select">
                <option value="">Select Job Role</option>
                <option value="1">Developer</option>
                <option value="2">Content Writer</option>
                <option value="3">Sales</option>
            </select>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Basic Salary<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Basic Salary" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Per Hour Cost<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Per Hour Cost" />
        </div>
        <!-- <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
            <select id="" class="select3 form-select">
                <option value="">Select Role</option>
                <option value="1">Admin</option>
                <option value="2">PC</option>
                <option value="3">CRE</option>
                <option value="4">BH</option>
            </select>
        </div> -->
        <div class="col-lg-4 mb-3">
            <input class="form-check-input" type="checkbox" id="create_user" name="create_user" onclick="username_func();" />
            <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger" style="display: none !important;" id="user_mandatory" name="user_mandatory">*</span></label>
            <input type="text" class="form-control" id="user_name" name="user_name" placeholder="Enter User Name" style="display: none !important;" />
        </div>
        <div class="col-lg-4 mb-3">
            <!-- <input class="form-check-input" type="checkbox" id="create_pass" name="create_pass" onclick="password_func();" /> -->
            <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger" style="display: none !important;" id="pass_mandatory" name="pass_mandatory">*</span></label>
            <div class="form-password-toggle" id="pass_word" name="pass_word" style="display: none !important;">
                <div class="input-group input-group-merge">
                    <input type="password" class="form-control" id="password" placeholder="Enter Password" aria-describedby="password" />
                    <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
                </div>
            </div>
        </div>
        <!-- <div class="col-lg-12 mb-4">
            <div class="card-action">
                <div class="card-header bg-gray-300">
                    <div class="card-action-title">
                        <div class="row w-100">
                            <label class="col-lg-10 text-black fs-6 fw-bold">Manage Users Role</label>
                            <div class="col-lg-2 d-flex align-items-center">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="" name="" />
                                    <label class="text-black fs-6 fw-bold">Select All</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-action-element">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                                <a href="javascript:;" class="mnge_user_role"><i class="mdi mdi-chevron-up fs-3"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="collapse mnge_user_role_body border">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 mb-4">
                            <div class="card-action">
                                <div class="card-header" style="background-color: #70e2ef !important;">
                                    <div class="card-action-title">
                                        <div class="d-flex align-items-center">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                <label class="text-black fs-6 fw-bold">Dashboards</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-action-element">
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item">
                                                <a href="javascript:;" class="staff_add_dashboards"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="collapse staff_add_dashboards_body border">
                                <div class="card-body">

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="card-action">
                                <div class="card-header" style="background-color: #70e2ef !important;">
                                    <div class="card-action-title">
                                        <div class="d-flex align-items-center">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                <label class="text-black fs-6 fw-bold">Marketing</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-action-element">
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item">
                                                <a href="javascript:;" class="staff_add_marketing"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="collapse staff_add_marketing_body border">
                                <div class="card-body">

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="card-action">
                                <div class="card-header" style="background-color: #70e2ef !important;">
                                    <div class="card-action-title">
                                        <div class="d-flex align-items-center">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                <label class="text-black fs-6 fw-bold">Sales</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-action-element">
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item">
                                                <a href="javascript:;" class="staff_add_sales"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="collapse staff_add_sales_body border">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-12 mb-4">
                                            <div class="card-action">
                                                <div class="card-header" style="background-color: #c7c7c7 !important;">
                                                    <div class="card-action-title">
                                                        <div class="d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-bold">Raw Lead</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-action-element">
                                                        <ul class="list-inline mb-0">
                                                            <li class="list-inline-item">
                                                                <a href="javascript:;" class="staff_add_sales_raw_lead"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="collapse staff_add_sales_raw_lead_body border">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">List</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Edit</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Import</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Export</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="raw_lead_view" id="view_all" />
                                                                <label class="text-black fs-6 fw-semibold">View All</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="raw_lead_view" id="view_self" checked />
                                                                <label class="text-black fs-6 fw-semibold">View Self</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-4">
                                            <div class="card-action">
                                                <div class="card-header" style="background-color: #c7c7c7 !important;">
                                                    <div class="card-action-title">
                                                        <div class="d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-bold">Lead</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-action-element">
                                                        <ul class="list-inline mb-0">
                                                            <li class="list-inline-item">
                                                                <a href="javascript:;" class="staff_add_sales_lead"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="collapse staff_add_sales_lead_body border">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">List</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Quick Lead</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Add</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Edit</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Delete</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">View</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Followup</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Check List</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Customer</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Chat</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Import</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Export</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="lead_view" id="view_all" />
                                                                <label class="text-black fs-6 fw-semibold">View All</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="lead_view" id="view_self" checked />
                                                                <label class="text-black fs-6 fw-semibold">View Self</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-4">
                                            <div class="card-action">
                                                <div class="card-header" style="background-color: #c7c7c7 !important;">
                                                    <div class="card-action-title">
                                                        <div class="d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-bold">Customer</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-action-element">
                                                        <ul class="list-inline mb-0">
                                                            <li class="list-inline-item">
                                                                <a href="javascript:;" class="staff_add_sales_customer"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="collapse staff_add_sales_customer_body border">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">List</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Edit</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Delete</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">View</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Add Course</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Add Batch</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Payment</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Import</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" name="" id="" checked />
                                                                <label class="text-black fs-6 fw-semibold">Export</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="customer_view" id="view_all" />
                                                                <label class="text-black fs-6 fw-semibold">View All</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="customer_view" id="view_self" checked />
                                                                <label class="text-black fs-6 fw-semibold">View Self</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="col-lg-12 mb-4">
            <div class="card-action">
                <div class="card-header bg-gray-300">
                    <div class="card-action-title">
                        <div class="row w-100">
                            <label class="col-lg-10 text-black fs-6 fw-bold">Credentials</label>
                            <div class="col-lg-2 d-flex align-items-center">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="credential_check_all" name="credential_check_all" onclick="select_func();" />
                                    <label class="text-black fs-6 fw-bold">Select All</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-action-element">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                                <a href="javascript:;" class="credentials_acrd"><i class="mdi mdi-chevron-up fs-3"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="collapse credentials_acrd_body border">
                <div class="card-body">
                    <div class="row mt-2">
                        <div class="col-lg-12 mb-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="skype_id" name="skype_id" onclick="skype_func();" />

                                <label class="text-dark mb-1 fs-6 fw-semibold">Skype</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="spark_id" name="spark_id" onclick="spark_func();" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Spark</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="firewall_id" name="firewall_id" onclick="firewall_func();" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Firewall</label>
                            </div>
                        </div>
                        <div class="mb-2" id="skype_cred" name="skype_cred" style="display: none !important;">
                            <h5 class="title fw-bold mt-2">Skype Credentials</h5>
                            <div class="row mt-2">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                    <div class="form-password-toggle">
                                        <div class="input-group input-group-merge">
                                            <input type="password" class="form-control" id="password" placeholder="Enter Password" aria-describedby="password" />
                                            <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3" id="spark_cred" name="spark_cred" style="display: none !important;">
                            <h5 class="title fw-bold mt-2">Spark Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                    <div class="form-password-toggle">
                                        <div class="input-group input-group-merge">
                                            <input type="password" class="form-control" id="password" placeholder="Enter Password" aria-describedby="password" />
                                            <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3" id="firewall_cred" name="firewall_cred" style="display: none !important;">
                            <h5 class="title fw-bold mt-2">Firewall Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                    <div class="form-password-toggle">
                                        <div class="input-group input-group-merge">
                                            <input type="password" class="form-control" id="password" placeholder="Enter Password" aria-describedby="password" />
                                            <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4 px-2 py-2">
        <div class="col-lg-6">
            <div class="row">
                <label class="text-dark fs-6 fw-semibold mt-2">Other Attachment</label>
                <div action="/upload" class="dropzone needsclick" id="dropzone-multi">
                    <div class="dz-message needsclick fs-6">
                        <div class="text-center me-3">Drop files here or click to upload</div>
                    </div>
                    <div class="fallback">
                        <input name="file" type="file" />
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" id="" placeholder="Enter Description">-</textarea>
        </div>
    </div>
    <div class="d-flex justify-content-end align-items-center mt-4">
        <a href="{{url ('/hr_management/staff')}}" class="btn btn-secondary me-3">Cancel</a>
        <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_confirmation_staff">Create Staff</a>
    </div>
</div>
<!-- End Staff Designation Information -->

<!--begin::Modal - Confirmation Staff-->
<div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Create Staff ?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Yasmin</label>
                    <span class="ms-2 me-2">-</span>
                    <label>EASTA-0001/24</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <a href="{{url ('/hr_management/staff')}}" class="btn btn-primary me-3">Yes</a>
                <a href="#" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirmation Staff-->

<!-- <script>
    function branch_func() {
        var branch = document.getElementById("branch");
        var franchise = document.getElementById("franchise");
        var branch_add = document.getElementById("branch_add");
        var franchise_add = document.getElementById("franchise_add");
        if (branch.checked) {
            branch_add.style.display = "block";
            franchise_add.style.display = "none";
        } else if (franchise.checked) {
            franchise_add.style.display = "block";
            branch_add.style.display = "none";
        } else {

        }
    }
</script> -->

<script>
    function franchise_func() {
        var branch = document.getElementById("branch");
        var franchise = document.getElementById("franchise");
        var branch_add = document.getElementById("branch_add");
        var franchise_add = document.getElementById("franchise_add");
        if (franchise.checked) {
            branch_add.style.display = "none";
            franchise_add.style.display = "block";
        } else if (branch.checked) {
            franchise_add.style.display = "block";
            branch_add.style.display = "none";
        } else {

        }
    }
</script>

<script>
    function select_func() {
        var credential_check_all = document.getElementById("credential_check_all");
        var skype_id = document.getElementById("skype_id");
        var skype_cred = document.getElementById("skype_cred");
        var spark_id = document.getElementById("spark_id");
        var spark_cred = document.getElementById("spark_cred");
        var firewall_id = document.getElementById("firewall_id");
        var firewall_cred = document.getElementById("firewall_cred");

        if (credential_check_all.checked) {
            skype_cred.style.display = "block";
            spark_cred.style.display = "block";
            firewall_cred.style.display = "block";
        } else {
            skype_cred.style.display = "none";
            spark_cred.style.display = "none";
            firewall_cred.style.display = "none";

        }
    }

    function skype_func() {
        var skype_id = document.getElementById("skype_id");
        var skype_cred = document.getElementById("skype_cred");

        if (skype_id.checked) {
            skype_cred.style.display = "block";

        } else {
            skype_cred.style.display = "none";

        }
    }

    function spark_func() {
        var spark_id = document.getElementById("spark_id");
        var spark_cred = document.getElementById("spark_cred");

        if (spark_id.checked) {
            spark_cred.style.display = "block";

        } else {
            spark_cred.style.display = "none";

        }
    }

    function firewall_func() {
        var firewall_id = document.getElementById("firewall_id");
        var firewall_cred = document.getElementById("firewall_cred");

        if (firewall_id.checked) {
            firewall_cred.style.display = "block";

        } else {
            firewall_cred.style.display = "none";

        }
    }
</script>


<script>
    function cred_func() {
        var create_cred = document.getElementById("create_cred").value;
        var skype_cred = document.getElementById("skype_cred");
        var spark_cred = document.getElementById("spark_cred");
        var firewall_cred = document.getElementById("firewall_cred");
        if (create_cred == "skype") {
            skype_cred.style.display = "block";
            spark_cred.style.display = "none";
            firewall_cred.style.display = "none";
        } else if (create_cred == "spark") {
            skype_cred.style.display = "none";
            spark_cred.style.display = "block";
            firewall_cred.style.display = "none";
        } else if (create_cred == "firewall") {
            skype_cred.style.display = "none";
            spark_cred.style.display = "none";
            firewall_cred.style.display = "block";
        } else {
            skype_cred.style.display = "none";
            spark_cred.style.display = "none";
            firewall_cred.style.display = "none";
        }
    }
</script>

<script>
    function staff_func() {
        var create_staff = document.getElementById("create_staff").value;
        var staff_experience = document.getElementById("staff_experience");
        if (create_staff == "experience") {
            staff_experience.style.display = "block";
        } else {
            staff_experience.style.display = "none";
        }
    }
</script>
<script>
    function username_func() {
        var create_user = document.getElementById("create_user");
        var user_name = document.getElementById("user_name");
        var user_mandatory = document.getElementById("user_mandatory");
        var create_pass = document.getElementById("create_pass");
        var pass_word = document.getElementById("pass_word");
        var pass_mandatory = document.getElementById("pass_mandatory");
        if (create_user.checked) {
            user_name.style.display = "block";
            user_mandatory.style.display = "inline";
            pass_word.style.display = "block";
            pass_mandatory.style.display = "inline";
        } else {
            user_name.style.display = "none";
            user_mandatory.style.display = "none";
            pass_word.style.display = "none";
            pass_mandatory.style.display = "none";
        }
    }
</script>
<script>
    function password_func() {
        var create_pass = document.getElementById("create_pass");
        var pass_word = document.getElementById("pass_word");
        var pass_mandatory = document.getElementById("pass_mandatory");
        if (create_pass.checked) {
            pass_word.style.display = "block";
            pass_mandatory.style.display = "inline";
        } else {
            pass_word.style.display = "none";
            pass_mandatory.style.display = "none";
        }
    }
</script>
<script>
    function Question_func() {
        var question_lead = document.getElementById("question_lead").value;
        var lead_check_box = document.getElementById("lead_check_box");
        var lead_radio_button = document.getElementById("lead_radio_button");
        var lead_list_box = document.getElementById("lead_list_box");

        if (question_lead == "check_box") {
            lead_check_box.style.display = "block";
            lead_radio_button.style.display = "none";
            lead_list_box.style.display = "none";
        } else if (question_lead == "radio_button") {
            lead_check_box.style.display = "none";
            lead_radio_button.style.display = "block";
            lead_list_box.style.display = "none";
        } else if (question_lead == "list_box") {
            lead_check_box.style.display = "none";
            lead_radio_button.style.display = "none";
            lead_list_box.style.display = "block";
        } else {
            lead_check_box.style.display = "none";
            lead_radio_button.style.display = "none";
            lead_list_box.style.display = "none";
        }
    }
</script>

<script>
    $('.staff_exp_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_staff_exp_add').length);
        let $clone = $('.form-repeater_staff_exp_add').first().clone().hide();
        $clone.insertBefore('.form-repeater_staff_exp_add:first').slideDown();
        if (bt == 1) {
            $('.staff_del_button').attr('style', 'display: block !important');
        } else {
            $('.staff_del_button').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_staff_exp_add .staff_del_button', e => {
        var bt = parseFloat($('.staff_del_button').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_staff_exp_add').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.staff_del_button').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    $('.staff_edu_info_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_edu_info').length);
        let $clone = $('.form-repeater_edu_info').first().clone().hide();
        $clone.insertBefore('.form-repeater_edu_info:first').slideDown();
        if (bt == 1) {
            $('.staff_edu_del').attr('style', 'display: block !important');
        } else {
            $('.staff_edu_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_edu_info .staff_edu_del', e => {
        var bt = parseFloat($('.staff_edu_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_edu_info').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.staff_edu_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    $('.cred_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_cred_add').length);
        let $clone = $('.form-repeater_cred_add').first().clone().hide();
        $clone.insertBefore('.form-repeater_cred_add:first').slideDown();
        if (bt == 1) {
            $('.cred_del_button').attr('style', 'display: block !important');
        } else {
            $('.cred_del_button').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_cred_add .cred_del_button', e => {
        var bt = parseFloat($('.cred_del_button').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_cred_add').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.cred_del_button').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    $('#credential_check_all').change(function() {
        $('.cred_check').prop('checked', this.checked);
    });

    $('.cred_check').change(function() {
        if ($('.cred_check:checked').length == $('.cred_check').length) {
            $('#credential_check_all').prop('checked', true);
        } else {
            $('#credential_check_all').prop('checked', false);
        }

    });
</script>

<!--Staff Add Manage Users Role Start-->
<script>
    'use strict';

    (function() {
        const mnge_user_role = [].slice.call(document.querySelectorAll('.mnge_user_role'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (mnge_user_role) {
            mnge_user_role.map(function(mnge_user_role_Element) {
                mnge_user_role_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(mnge_user_role_Element.closest('.card').querySelector('.collapse.mnge_user_role_body'));
                    // Toggle collapsed class in `.card-header` element
                    mnge_user_role_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(mnge_user_role_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Manage Users Role End-->
<!--Staff Add Dashboards Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_add_dashboards = [].slice.call(document.querySelectorAll('.staff_add_dashboards'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_add_dashboards) {
            staff_add_dashboards.map(function(staff_add_dashboards_Element) {
                staff_add_dashboards_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_add_dashboards_Element.closest('.card').querySelector('.collapse.staff_add_dashboards_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_add_dashboards_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_add_dashboards_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Dashboards Accordion End-->
<!--Staff Add Marketing Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_add_marketing = [].slice.call(document.querySelectorAll('.staff_add_marketing'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_add_marketing) {
            staff_add_marketing.map(function(staff_add_marketing_Element) {
                staff_add_marketing_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_add_marketing_Element.closest('.card').querySelector('.collapse.staff_add_marketing_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_add_marketing_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_add_marketing_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Marketing Accordion End-->
<!--Staff Add Sales Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_add_sales = [].slice.call(document.querySelectorAll('.staff_add_sales'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_add_sales) {
            staff_add_sales.map(function(staff_add_sales_Element) {
                staff_add_sales_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_add_sales_Element.closest('.card').querySelector('.collapse.staff_add_sales_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_add_sales_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_add_sales_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Sales Accordion End-->
<!--Staff Add Sales -> Raw Lead Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_add_sales_raw_lead = [].slice.call(document.querySelectorAll('.staff_add_sales_raw_lead'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_add_sales_raw_lead) {
            staff_add_sales_raw_lead.map(function(staff_add_sales_raw_lead_Element) {
                staff_add_sales_raw_lead_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_add_sales_raw_lead_Element.closest('.card').querySelector('.collapse.staff_add_sales_raw_lead_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_add_sales_raw_lead_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_add_sales_raw_lead_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Sales -> Raw Lead Accordion End-->
<!--Staff Add Sales -> Lead Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_add_sales_lead = [].slice.call(document.querySelectorAll('.staff_add_sales_lead'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_add_sales_lead) {
            staff_add_sales_lead.map(function(staff_add_sales_lead_Element) {
                staff_add_sales_lead_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_add_sales_lead_Element.closest('.card').querySelector('.collapse.staff_add_sales_lead_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_add_sales_lead_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_add_sales_lead_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Sales -> Lead Accordion End-->
<!--Staff Add Sales -> Customer Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_add_sales_customer = [].slice.call(document.querySelectorAll('.staff_add_sales_customer'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_add_sales_customer) {
            staff_add_sales_customer.map(function(staff_add_sales_customer_Element) {
                staff_add_sales_customer_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_add_sales_customer_Element.closest('.card').querySelector('.collapse.staff_add_sales_customer_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_add_sales_customer_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_add_sales_customer_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Sales -> Customer Accordion End-->

<!--Staff Add Credentials Accordion Start-->
<script>
    'use strict';

    (function() {
        const credentials_acrd = [].slice.call(document.querySelectorAll('.credentials_acrd'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (credentials_acrd) {
            credentials_acrd.map(function(credentials_acrd_Element) {
                credentials_acrd_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(credentials_acrd_Element.closest('.card').querySelector('.collapse.credentials_acrd_body'));
                    // Toggle collapsed class in `.card-header` element
                    credentials_acrd_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(credentials_acrd_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Add Credentials Accordion End-->
@endsection