@extends('layouts/layoutMaster')

@section('title', 'Manage Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/js/dropdown-hover.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Staff</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-end align-items-center mb-2">
            <a href="/hr_management/staff/staff_add" class="btn btn-sm fw-bold btn-primary">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Staff
            </a>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Staff</th>
                            <th class="min-w-100px">Job Role</th>
                            <th class="min-w-100px">Knowledge Tag</th>
                            <th class="min-w-80px">Income</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-80px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        <tr>
                            <td>
                                <div class="d-flex  px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Nick Name">
                                            <span class="fs-7 me-1">Yasmin</span>
                                            <span class="badge bg-danger text-white fs-8 rounded">F</span>
                                        </label>
                                        <div class="d-flex text-dark fs-8">
                                            <div class="text-black fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">Sabana</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9 text-secondary"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Name</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Yasmin</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Nick Name</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Sabana</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Mob No</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">9876543210
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Email ID</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">sabana@gmail.com
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Work Info</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Fresher
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Edu Info</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">M.SC Computer Science
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="badge fs-8 text-black fw-bold" style="background-color:#beb91b;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Role">
                                    <span class="fs-7 ">Developer</span>
                                </label>
                            </td>
                            <td>
                                <label class="text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Python - Machine Learning, Python - Deep Learning">Python - Machine Learning, Python - Deep Learning</label>
                            </td>
                            <td align="right">
                                <label class="badge bg-success fs-8 text-black fw-bold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Avg Income">
                                    <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                    <span class="fs-7">10,000</span>
                                </label>
                                <!-- <div class="d-block">
                                    <label class="badge bg-warning fs-8 text-black fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="10X Eligibility Income">
                                        <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                        <span class="fs-7 ">1,10,000.00</span>
                                    </label>
                                </div> -->
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/hr_management/staff/staff_view')}}" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/hr_management/staff/staff_edit')}}" class="dropdown-item">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                            Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_staff">
                                            <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex  px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
                                            <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label>
                                            <span class="fs-7 me-1">Naveen</span>
                                            <span class="badge bg-info text-white fs-8 rounded">M</span>
                                        </label>
                                        <div class="d-flex text-black fs-8">
                                            <div class="text-black fs-8" title="Nick Name">Nirmal</div>
                                            <div class="">
                                                <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9 text-secondary"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Name</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">Naveen</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Nick Name</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Nirmal</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Mob No</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">9876543219
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Email ID</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">naveen@gmail.com
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Work Info</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">Experience
                                                        </label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Edu Info</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">M.SC Computer Science
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="badge fs-8 text-white fw-bold" style="background-color:#5f2c70;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Role">
                                    <span class="fs-7 ">Content Writer</span>
                                </label>
                            </td>
                            <td>
                                <label class="text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Python - Machine Learning, Python - Deep Learning">Python - Machine Learning, Python - Deep Learning</label>
                            </td>
                            <td align="right">
                                <label class="badge bg-success fs-8 text-black fw-bold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Avg Income">
                                    <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                    <span class="fs-7">15,000</span>
                                </label>
                                <!-- <div class="d-block">
                                    <label class="badge bg-warning fs-8 text-black fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="10X Eligibility Income">
                                        <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                        <span class="fs-7 ">2,15,000.00</span>
                                    </label>
                                </div> -->
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{url('/hr_management/staff/staff_view')}}" class="dropdown-item">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                        <a href="{{url('/hr_management/staff/staff_edit')}}" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                            Edit</a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_staff">
                                            <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Staff-->
<div class="modal fade" id="kt_modal_add_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Staff</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Staff Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Nick Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Nick Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                            <label class="form-check-label" for="inlineRadio1">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
                            <label class="form-check-label" for="inlineRadio2">Female</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" />
                            <label class="form-check-label" for="inlineRadio3">Others</label>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date of Birth<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_dob" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Mobile Number" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Alternate Mobile Number" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date of Joining<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_doj" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Marital Status</label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Marital Status</option>
                            <option value="1">Married</option>
                            <option value="2">Un Married</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter E-Mail ID" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Country</option>
                            <option value="1">Afghanistan</option>
                            <option value="2">Bolivia</option>
                            <option value="3">Canada</option>
                            <option value="4">India</option>
                            <option value="5">Japan</option>
                            <option value="6">Kuwait</option>
                            <option value="7">Libya</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select State</option>
                            <option value="1">Andhra Pradesh</option>
                            <option value="2">Goa</option>
                            <option value="3">Karnataka</option>
                            <option value="4">Kerala</option>
                            <option value="5">Tamil Nadu</option>
                            <option value="6">Telangana</option>
                            <option value="7">Uttarakhand</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select City</option>
                            <option value="1">Chennai</option>
                            <option value="2">Vellore</option>
                            <option value="3">Salem</option>
                            <option value="4">Tirunelveli</option>
                            <option value="5">Madurai</option>
                            <option value="6">Dindigul</option>
                            <option value="7">Sivakasi</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Area / Street" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Qualificatio Type<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Qualification Type</option>
                            <option value="1">UG</option>
                            <option value="2">PG</option>
                            <option value="2">M.Phil</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Qualification Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Qualification Name" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Fresher / Experience<span class="text-danger">*</span></label>
                        <select id="create_staff" name="create_staff" class="select3 form-select" onchange="staff_func();">
                            <option value="">Select Fresher / Experience</option>
                            <option value="fresher">Fresher</option>
                            <option value="experience">Experience</option>
                        </select>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Description<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Staff</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Slot-->

<!--begin::Modal - Edit Slot-->
<div class="modal fade" id="kt_modal_edit_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Lead</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Created Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_create_up" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Lead Name" value="Priya" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                            <label class="form-check-label" for="inlineRadio1">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" checked />
                            <label class="form-check-label" for="inlineRadio2">Female</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" />
                            <label class="form-check-label" for="inlineRadio3">Others</label>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date of Birth<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_dob_up" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Mobile Number" value="9876543210" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Alternate Mobile Number" value="8976543210" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Marital Status</label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Marital Status</option>
                            <option value="1">Married</option>
                            <option value="2" selected>Un Married</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter E-Mail ID" value="priya@gmail.com" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Country</option>
                            <option value="1">Afghanistan</option>
                            <option value="2">Bolivia</option>
                            <option value="3">Canada</option>
                            <option value="4" selected>India</option>
                            <option value="5">Japan</option>
                            <option value="6">Kuwait</option>
                            <option value="7">Libya</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select State</option>
                            <option value="1">Andhra Pradesh</option>
                            <option value="2">Goa</option>
                            <option value="3">Karnataka</option>
                            <option value="4">Kerala</option>
                            <option value="5" selected>Tamil Nadu</option>
                            <option value="6">Telangana</option>
                            <option value="7">Uttarakhand</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select City</option>
                            <option value="1">Chennai</option>
                            <option value="2">Vellore</option>
                            <option value="3">Salem</option>
                            <option value="4">Tirunelveli</option>
                            <option value="5" selected>Madurai</option>
                            <option value="6">Dindigul</option>
                            <option value="7">Sivakasi</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" id="" placeholder="Enter Area / Street" value="227, IInd Floor, B Block, Elysium Campus, Church Rd, Anna Nagar" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Course Name</label>
                        <select id="" class="select3 form-select" multiple>
                            <option value="">Select Course Name</option>
                            <option value="1" selected>Python For Data Science</option>
                            <option value="2">Core java</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Lead Type</option>
                            <option value="1">Employee</option>
                            <option value="2" checked>Student</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Lead Source</option>
                            <option value="1">Email</option>
                            <option value="2" selected>Website</option>
                            <option value="2">Facebook</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Potential Type<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Potential Type</option>
                            <option value="1" selected>Good</option>
                            <option value="2">Moderate</option>
                            <option value="2">Worst</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Last Follow Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_lfd_up" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Comments<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Comments">Also Interested in Java Course</textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Slot-->

<!--begin::Modal - Delete Slot-->
<div class="modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                delete Staff ?</div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Lead-->
<!--begin::Modal - View Lead-->
<div class="modal fade" id="kt_modal_view_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6 text-center">
                    <h3 class="text-center mb-4 text-black">View Lead</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Created Date</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">02/02/2024</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Lead Name</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Priya</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Gender</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Female</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Date of Birth</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">13-May-2024</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Email ID</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">priya@gmail.com</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Mobile Number</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">9876543210</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Alternate Number</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">8976543210</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Lead Type</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Student</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Lead Source</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Website</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Potential Type</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Good</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Last Follow Date </label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">13-May-2024</label>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Marital Status</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Un Married</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Course Name</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Python For Data Science</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Country</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">India</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">State</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Tamil Nadu</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">City</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Madurai</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Area / street</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">227, IInd Floor, B Block, Elysium Campus, Church
                                Rd, Anna Nagar</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Address</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">227, IInd Floor, B Block, Elysium Campus, Church
                                Rd, Anna Nagar, Madurai, Tamil Nadu, India. </label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-7 fw-semibold">Comments</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-7 text-dark fs-6 fw-bold">Also Interested in java Course</label>
                        </div>
                    </div>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="kt_modal_follow_up_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Follow Up</h3>
                </div>
                <div class="row">
                    <!-- Basic -->
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Current Follow Up<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_create_follow" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Next Follow Up</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_create_follow_next" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Conversation</label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Conversation"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Follow Up</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="kt_modal_check_list" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Check List</h3>
                </div>
                <div class="row mt-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Customer is interested to join course or not ?
                        <span class="text-danger">*</span></label>
                    <div class="col-lg-12 mt-2">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option1" />
                            <label class="form-check-label text-dark mb-1 fs-6 fw-semibold" for="inlineRadio3">Interested</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" checked />
                            <label class="form-check-label text-dark mb-1 fs-6 fw-semibold" for="inlineRadio2">Not
                                Interested</label>
                        </div>
                    </div>
                </div>
                <div class="row mt-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Customer is ?
                        <span class="text-danger">*</span></label>
                    <div class="col-lg-12 mt-2">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input fac_ver_chk_up" type="checkbox" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">School Student</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input fac_ver_chk_up" type="checkbox" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">College Student</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input fac_ver_chk_up" type="checkbox" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Employee</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input fac_ver_chk_up" type="checkbox" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">House Wife</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Check List</button>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <label>
                        <span class="text-dark mb-1 fs-5 fw-semibold">Score</span>
                        <span class="text-dark mb-1 fs-5 fw-semibold">:</span>
                        <span class="text-danger mb-1 fs-5 fw-semibold">2/2</span>
                    </label>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<script>
    function staff_func() {
        var create_staff = document.getElementById("create_staff").value;
        var staff_experience = document.getElementById("staff_experience");
        if (create_staff == "experience") {
            staff_experience.style.display = "block";
        } else {}
    }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection