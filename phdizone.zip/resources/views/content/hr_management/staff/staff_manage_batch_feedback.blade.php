@extends('layouts/layoutMaster')

@section('title', 'Course Feedback')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js'
])
@endsection

@section('page-script')
@vite([
'resources/assets/js/accordian.js',
'resources/assets/js/sliders.js'
])
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Course Feedback</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Staff</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-6 mb-3 flex-wrap">
                <h3 class="fw-bold mb-1">
                    <div class="d-flex">
                        <div class="justify-content-start align-items-center me-1">
                            <label class="btn btn-icon" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Name">
                                <i class="mdi mdi-book fs-1"></i>
                            </label>
                        </div>
                        <div class="d-block">
                            <label class="fs-3 fw-semibold">Core Java & Concepts Course</label>
                            <div class="d-block fs-6 text-muted fw-semibold">
                                <label>Crash Course</label>
                                <label class="me-1 ms-1"> - </label>
                                <label class="badge bg-info fs-8 rounded">V 2.5</label>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex fw-semibold">
                        <div class="justify-content-start align-items-center me-4">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course SR.Code">
                                <i class="mdi mdi-code-block-tags fs-3"></i>
                            </label>
                            <label class="fs-7 align-items-center text-black">EAPL/SOLA/2022/SLAD3</label>
                        </div>
                        <div class="justify-content-start align-items-center">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Code">
                                <i class="mdi mdi-code-block-brackets fs-3"></i>
                            </label>
                            <label class="fs-7 align-items-center text-black">EACJC</label>
                        </div>
                    </div>
                </h3>
            </div>
            <div class="col-lg-6 mb-3 flex-wrap">
                <h3 class="fw-semibold mb-1">
                    <div class="d-flex fw-semibold">
                        <div class="me-2">
                            <label class="btn btn-icon" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Category & Sub Category">
                                <i class="mdi mdi-application-array-outline fs-1"></i>
                            </label>
                        </div>
                        <div>
                            <label class="align-items-center">
                                <span class="fs-3 fw-semibold">Programming Training</span>
                                <span class="d-block fs-6 text-muted">Application Development</span>
                            </label>
                        </div>
                    </div>
                    <div class="d-flex fw-semibold">
                        <div class="justify-content-start align-items-center me-4">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Duration"><i class="mdi mdi-timer-outline fs-3"></i></label>
                            <label class="fs-7 align-items-center text-black">
                                <span>45</span>
                                <span> Days</span>
                                <span class="me-1 ms-1"> | </span>
                                <span>65</span>
                                <span>Hours</span>
                            </label>
                        </div>
                        <div class="justify-content-start align-items-center me-4">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Theory Hours"><i class="mdi mdi-human-male-board fs-3"></i></label>
                            <label class="fs-7 align-items-center text-black badge bg-light rounded">
                                <span>12</span>
                                <span> Hours</span>
                            </label>
                        </div>
                        <div class="justify-content-start align-items-center">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Practical Hours"><i class="mdi mdi-laptop fs-3"></i></label>
                            <label class="fs-7 align-items-center text-white badge bg-secondary rounded">
                                <span>53</span>
                                <span> Hours</span>
                            </label>
                        </div>
                    </div>
                    <div class="d-flex fw-semibold mt-2">
                        <a href="javascript:;" class="btn btn-sm btn-light me-2" data-bs-toggle="offcanvas" data-bs-target="#course_description">Description</a>
                        <a href="javascript:;" class="btn btn-sm btn-light me-2" data-bs-toggle="offcanvas" data-bs-target="#course_goals">Goals</a>
                        <a href="javascript:;" class="btn btn-sm btn-light" data-bs-toggle="offcanvas" data-bs-target="#course_future_scope">Future Scope</a>
                    </div>
                </h3>
            </div>
            <div class="col-lg-12 mb-3 flex-wrap">
                <div class="accordion" id="chapter_acccordion">
                    <div class="accordion-item mb-2">
                        <h2 class="accordion-header" id="chapter_acccordion">
                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#chapter_acrdion" aria-expanded="false" aria-controls="chapter_acrdion" role="tabpanel">
                                <label class="me-4">
                                    <input type="checkbox" class="form-check-input" id="check-all-topics">
                                </label>
                                <div class=" row w-100">
                                    <div class="col-lg-1 align-middle text-center px-2">
                                        <div>
                                            <i class="mdi mdi-file-certificate fs-1"></i>
                                        </div>
                                        <div class="d-block fs-6 fw-semibold text-black">Chapter</div>
                                        <div class="d-block fs-5 fw-semibold text-black">01</div>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="row">
                                            <div class="col-lg-12 mb-1">
                                                <label class="text-black fs-5 fw-semibold">BASICS OF JAVA</label>
                                            </div>
                                            <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1">
                                                <a href="#" class="btn btn-icon rounded border border-primary border-solid w-75 h-75 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Exam">
                                                    <div class="px-0 py-0">
                                                        <img src="{{asset('assets/phdizone_images/icon/exam_icon.svg')}}" alt="Exam Icon" class="rounded w-30px h-30px">
                                                        <label class="fs-3 fw-semibold text-black text-center">0</label>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1">
                                                <a href="#" class="btn btn-icon rounded border border-primary border-solid w-75 h-75 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Manual">
                                                    <div class="px-0 py-0">
                                                        <img src="{{asset('assets/phdizone_images/icon/manual_icon.svg')}}" alt="Manual Icon" class="rounded w-30px h-30px">
                                                        <label class="fs-3 fw-semibold text-black text-center">1</label>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1">
                                                <a href="#" class="btn btn-icon rounded border border-primary border-solid w-75 h-75 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Cheat Sheet">
                                                    <div class="px-0 py-0">
                                                        <img src="{{asset('assets/phdizone_images/icon/cheat_sheet_icon.svg')}}" alt="Cheat Sheet Icon" class="rounded w-30px h-30px">
                                                        <label class="fs-3 fw-semibold text-black text-center">1</label>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1">
                                                <a href="#" class="btn btn-icon rounded border border-primary border-solid w-75 h-75 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Work Sheet">
                                                    <div class="px-0 py-0">
                                                        <img src="{{asset('assets/phdizone_images/icon/work_sheet_icon.svg')}}" alt="Work Sheet Icon" class="rounded w-30px h-30px">
                                                        <label class="fs-3 fw-semibold text-black text-center">0</label>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1">
                                                <a href="#" class="btn btn-icon rounded border border-primary border-solid w-75 h-75 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lab Sheet">
                                                    <div class="px-0 py-0">
                                                        <img src="{{asset('assets/phdizone_images/icon/lab_sheet_icon.svg')}}" alt="Lab Sheet Icon" class="rounded w-30px h-30px">
                                                        <label class="fs-3 fw-semibold text-black text-center">0</label>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-1 text-center">
                                        <div class="fs-6 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Knowledge Level">Beginner</div>
                                        <div class="d-flex justify-content-center align-items-center">
                                            <a href="#" class="me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Theory Hours">
                                                <div class="text-center"><i class="mdi mdi-human-male-board fs-2"></i>
                                                </div>
                                                <div class="fs-7 align-items-center text-black badge bg-light rounded">
                                                    <span>01</span>
                                                    <span> Hours</span>
                                                </div>
                                            </a>
                                            <a href="#" class="me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Practical Hours">
                                                <div class="text-center"><i class="mdi mdi-laptop fs-2"></i></div>
                                                <div class="fs-7 align-items-center text-white badge bg-secondary rounded">
                                                    <span>01</span>
                                                    <span> Hours</span>
                                                </div>
                                            </a>
                                            <a href="#" class="btn btn-icon" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Section Count">
                                                <div class="px-0 py-0 mt-1">
                                                    <span class="badge badge-center rounded-pill bg-primary fs-4 w-35px h-35px">02</span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                    <!-- <div class="col-lg-1 d-flex justify-content-center align-items-center mb-1">
                    <a href="#" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Theory Hours">
                      <div class="text-center"><i class="mdi mdi-human-male-board fs-2"></i></div>
                      <div class="fs-7 align-items-center text-black badge bg-light rounded">
                        <span>01</span>
                        <span> Hours</span>
                      </div>
                    </a>
                  </div>
                  <div class="col-lg-1 d-flex justify-content-center align-items-center mb-1">
                    <a href="#" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Practical Hours">
                      <div class="text-center"><i class="mdi mdi-laptop fs-2"></i></div>
                      <div class="fs-7 align-items-center text-white badge bg-secondary rounded">
                        <span>01</span>
                        <span> Hours</span>
                      </div>
                    </a>
                  </div>
                  <div class="col-lg-1 d-flex justify-content-center align-items-center mb-1">
                    <a href="#" class="btn btn-icon" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Section Count">
                      <div class="px-0 py-0 mt-1">
                        <span class="badge badge-center rounded-pill bg-primary fs-4 w-35px h-35px">02</span>
                      </div>
                    </a>
                  </div> -->
                                </div>
                            </button>
                        </h2>
                        <div id="chapter_acrdion" class="accordion-collapse collapse" data-bs-parent="#chapter_acccordion">
                            <div class="accordion-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-center">
                                            <label class="me-4">
                                                <input type="checkbox" class="form-check-input" id="check-topic-1">
                                            </label>
                                            <div class=" btn btn-icon me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Section">
                                                <i class="mdi mdi-set-center fs-2 text-black"></i>
                                            </div>
                                            <div class="text-black mb-1 fs-5 fw-semibold">
                                                <label class="me-1">01.</label>
                                                <label>Basics: Internal path setting</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-center">
                                            <label class="me-4">
                                                <input type="checkbox" class="form-check-input" id="check-topic-2">
                                            </label>
                                            <div class=" btn btn-icon me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Section">
                                                <i class="mdi mdi-set-center fs-2 text-black"></i>
                                            </div>
                                            <div class="text-black mb-1 fs-5 fw-semibold">
                                                <label class="me-1">02.</label>
                                                <label>Environment Setup:</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="d-flex align-items-center ms-20">
                                                    <div class=" btn btn-icon me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Topic">
                                                        <i class="mdi mdi-newspaper-check fs-3 text-black" data-bs-target="#kt_modal_feedback" data-bs-toggle="modal">
                                                        </i>
                                                    </div>
                                                    <div class="text-dark mb-1 fs-6 fw-semibold me-2">
                                                        <label class="me-1">a.</label>
                                                        <label>Download Links:</label>
                                                    </div>
                                                    <a href="javascript:;" class="btn btn-icon rounded border border-secondary border-solid" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Cheat Sheet">
                                                        <div class="px-0 py-0">
                                                            <img src="{{asset('assets/phdizone_images/icon/cheat_sheet_icon.svg')}}" alt="Cheat Sheet Icon" class="rounded w-20px h-20px">
                                                        </div>
                                                    </a>
                                                    <div>
                                                        <label class="fs-6 fw-semibold ms-2 badge badge-warning rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Percentage of completion of course topic">
                                                            <label class="badge bg-warning text-black fw-semibold rounded-circle px-2 py-2">50%
                                                            </label></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="d-flex align-items-center ms-20">
                                                    <label class="me-4">
                                                        <input type="checkbox" class="form-check-input" id="check-subtopic-2">
                                                    </label>
                                                    <div class=" btn btn-icon me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Topic">
                                                        <i class="mdi mdi-newspaper-check fs-3 text-black" data-bs-target="#kt_modal_feedback" data-bs-toggle="modal"></i>
                                                    </div>
                                                    <div class="text-dark mb-1 fs-6 fw-semibold me-2">
                                                        <label class="me-1">b.</label>
                                                        <label>Method and installation of Java on windows</label>
                                                    </div>
                                                    <a href="javascript:;" class="btn btn-icon rounded border border-secondary border-solid" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Manual">
                                                        <div class="px-0 py-0">
                                                            <img src="{{asset('assets/phdizone_images/icon/manual_icon.svg')}}" alt="Manual Icon" class="rounded w-20px h-20px">
                                                        </div>
                                                    </a>
                                                    <div>
                                                        <label class="fs-6 fw-semibold ms-2 text-warning" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Percentage of
                                                            completion of course topic"> <label class="badge bg-warning text-black fw-semibold rounded-circle px-2 py-2">100%
                                                            </label></label></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end mb-4">
            <a href="http://127.0.0.1:8000/hr_management/staff/staff_manage_batch" target="_blank" class="btn btn-secondary me-3">Cancel</a>
            <a href="http://127.0.0.1:8000/hr_management/staff/staff_manage_batch" target="_blank" class="btn btn-primary">Update Feedback</a>
        </div>
    </div>
</div>

<!-- Course Description -->
<div class="offcanvas offcanvas-end" id="course_description" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="offcanvas-header border-bottom mb-3">
        <h5 class="offcanvas-title">Course Description</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <div class="row">
            <div class="col-lg-12 mb-3">
                <div class="d-block text-black mb-1 fs-6 fw-semibold">&emsp;&emsp;Java is essential to have a solid
                    grasp of Core Java. Core Java, as its name indicates, focuses on the essentials of the Java language
                    and leaves away the numerous libraries that are part of the established Java ecosystem.</div>
            </div>
        </div>
    </div>
</div>
<!-- /Course Description -->

<!-- Course Goals -->
<div class="offcanvas offcanvas-end" id="course_goals" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="offcanvas-header border-bottom mb-3">
        <h5 class="offcanvas-title">Course Goals</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <div class="row">
            <div class="col-lg-12 mb-3">
                <div class="d-block text-black mb-1 fs-6 fw-semibold">&emsp;&emsp;This can be accessed by anyone with an
                    internet connection from any corner of the world. This includes creating simple to comples
                    applications. It Enables the use of computer language by web developers to provide dynamic,
                    changeable content and services.</div>
            </div>
        </div>
    </div>
</div>
<!-- /Course Goals -->

<!-- Course Future Scope -->
<div class="offcanvas offcanvas-end" id="course_future_scope" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="offcanvas-header border-bottom mb-3">
        <h5 class="offcanvas-title">Course Future Scope</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <div class="row">
            <div class="col-lg-12 mb-3">
                <div class="d-block text-black mb-1 fs-6 fw-semibold">&emsp;&emsp;For all the game development, smart
                    device development, online development, big data processing, Internet of Things apps,cloud-based
                    applications, and other uses, Java is the way to go. When you learn how to create websites,
                    applications, and visual designs, you can accomplish so much more with Java. Never before has JAVA'S
                    future in web development been more certain. Java has a stronghold on the market, and many IT
                    companies support it. The future of web development is JAVA.</div>
            </div>
        </div>
    </div>
</div>
<!-- /Course Future Scope -->

<!--begin::Modal - Feedback-->
<div class="modal fade" id="kt_modal_feedback" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Course Feedback</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Completed Topics (%)
                            <span class="text-danger">*</span></label>
                        <div class="noUi-primary mb-6 fw-semibold" id="course_feedback"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason</label>
                        <span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="4" id="" placeholder="Enter Reason"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Session</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Feedback-->
<script>
    $(document).ready(function() {
        $('#check-all-topics').click(function() {
            $('input[type=checkbox]').prop('checked', this.checked);
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('#check-topic-2').click(function() {
            $('input#check-subtopic-1, input#check-subtopic-2').prop('checked', this.checked);
        });
    });
</script>

@endsection