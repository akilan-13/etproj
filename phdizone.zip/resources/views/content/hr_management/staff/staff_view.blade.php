@extends('layouts/layoutMaster')

@section('title', 'View Staff')

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">View Staff Details</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Staff</a>
                </li>
            </ol>
        </nav>
    </div>

    <div class="card-body">
        <h5 class="title mb-1 fw-bold">Basic Information</h5>
        <div class="row mt-4">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Staff Photo</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">
                        <div class="row">
                            <div class="align-items-sm-center gap-4">
                                <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                            </div>
                        </div>
                    </label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Branch</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">Madurai - Anna Nagar</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Department</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">Sales</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">White Listed IP's</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">192.168.03</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">Sabana Barveen</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Gender</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">Female</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Date of Birth</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">13-May-2024</label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Mobile Number</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Alternate Number</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Email ID</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">priya@gmail.com</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Marital Status</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">Married</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Contact Person</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">Sana</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Contact Person No</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">8976543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Address</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">12, IInd Floor, B Block, Elysium Campus, Church
                        Rd, Anna Nagar, Madurai, Tamil Nadu, India Pincode-625012. </label>
                </div>
            </div>
        </div>
        <h5 class="title mb-1 fw-bold mt-4">Educational Information</h5>
        <div class="row mt-4">
            <div class="col-xl-6 mb-2">
                <div class="card">
                    <a class="card-body" id="batch1_card">
                        <div class="row">
                            <div class="col-12 text-end">
                                <label class="badge bg-info rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Under Graduate</label>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Degree Name">
                                        <i class="mdi mdi-account-school-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-7 align-items-center text-black fw-semibold">
                                        <span>Bachelor of Science</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Major">
                                        <i class="mdi mdi-book-open-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-7 align-items-center text-black fw-semibold">
                                        <span>Computer Science</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="University / Instiute Name">
                                        <i class="mdi mdi-town-hall fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-7 align-items-center text-black fw-semibold" title="Madurai Kamarajar University">
                                        <span class="max-w-350px text-truncate" title="Madurai Kamarajar University">Madurai Kamarajar University</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-xl-6 mb-2">
                <div class="card">
                    <a class="card-body" id="batch1_card">
                        <div class="row">
                            <div class="col-12 text-end">
                                <label class="badge bg-info rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Qualification Type">Post Graduate</label>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Degree Name">
                                        <i class="mdi mdi-account-school-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-7 align-items-center text-black fw-semibold">
                                        <span>Master of Science</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Major">
                                        <i class="mdi mdi-book-open-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-7 align-items-center text-black fw-semibold">
                                        <span>Computer Science</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="University / Instiute Name">
                                        <i class="mdi mdi-town-hall fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-7 align-items-center text-black fw-semibold">
                                        <span class="max-w-350px text-truncate" title="Madurai Kamarajar University">Madurai Kamarajar University</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <h5 class="title mt-4 fw-bold">Work Information
            <label class="ms-4 badge bg-danger rounded fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Type">Experience</label>
        </h5>
        <div class="row mt-4">
            <div class="col-xl-6">
                <div class="card">
                    <a class="card-body" id="batch1_card">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label class="col-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Position">
                                        <i class="mdi mdi-account-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="col-10 fs-7 align-items-center text-black fw-semibold">
                                        <span>Front End Developer</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label class="col-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Years of Experience">
                                        <i class="mdi mdi-calendar-account fs-3 text-black"></i>
                                    </label>
                                    <label class="col-10 fs-7 align-items-center text-black fw-semibold">
                                        <span>4 Years Experience</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="justify-content-start">
                                    <label class="col-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Company Name">
                                        <i class="mdi mdi-domain fs-3 text-black"></i>
                                    </label>
                                    <label class="col-10 fs-7 align-items-center text-black fw-semibold" title="Company Name">
                                        <span class="max-w-350px text-truncate" title="Madurai Kamarajar University">ABC Company</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <h5 class="title mt-4 fw-bold">Designation Information</h5>
        <div class="row mt-4">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Nick Name</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">Yasmin</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Date of Joining</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">1/01/2023</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Job Role</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">
                        <span class="badge" style="background-color:#beb91b;">Developer</span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Per Hour Cost</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 fs-6 fw-bold">
                        <span class="badge bg-success">
                            <span class="mdi mdi-currency-rupee text-black fw-bold"></span>
                            <span class="text-black fw-bold">750</span>
                        </span>
                    </label>
                </div>
                <div class="col-lg-6 mb-4">
                    <h4 class="text-dark fs-7 fw-semibold">Attachment</h4>
                    <div class="border border-gray-600 border-dashed rounded py-1 px-1">
                        <div class="d-flex mb-1 align-items-center">
                            <div class="d-block overlay text-center me-1 px-2 py-2">
                                <label class="fs-7 fw-semibold">GST Document</label>
                                <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" download>
                                    <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="h-100px w-100px" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">User Name</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">staff123</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Password</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">staff@123</label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Basic Salary</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 fs-6 fw-bold">
                        <span class="badge bg-info">
                            <span class="mdi mdi-currency-rupee text-white fw-bold"></span>
                            <span class="">10,000</span>
                        </span>
                    </label>
                </div>
                <div class="row mb-4">
                    <label class="col-4 text-dark fs-7 fw-semibold">Description</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold text-truncate max-w-250px" title="">-</label>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-4">
                <div class="card-action">
                    <div class="card-header bg-gray-300">
                        <div class="card-action-title">
                            <div class="row w-100">
                                <label class="col-lg-10 text-black fs-6 fw-bold">Manage Users Role</label>
                                <div class="col-lg-2 d-flex align-items-center">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" name="" checked disabled />
                                        <label class="text-black fs-6 fw-bold">Select All</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-action-element">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <a href="javascript:;" class="mnge_user_role_edit"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="collapse mnge_user_role_edit_body border">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 mb-4">
                                <div class="card-action">
                                    <div class="card-header" style="background-color: #70e2ef !important;">
                                        <div class="card-action-title">
                                            <div class="d-flex align-items-center">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                    <label class="text-black fs-6 fw-bold">Dashboards</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-action-element">
                                            <ul class="list-inline mb-0">
                                                <li class="list-inline-item">
                                                    <a href="javascript:;" class="staff_edit_dashboards"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="collapse staff_edit_dashboards_body border">
                                    <div class="card-body">

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <div class="card-action">
                                    <div class="card-header" style="background-color: #70e2ef !important;">
                                        <div class="card-action-title">
                                            <div class="d-flex align-items-center">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                    <label class="text-black fs-6 fw-bold">Marketing</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-action-element">
                                            <ul class="list-inline mb-0">
                                                <li class="list-inline-item">
                                                    <a href="javascript:;" class="staff_edit_marketing"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="collapse staff_edit_marketing_body border">
                                    <div class="card-body">

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <div class="card-action">
                                    <div class="card-header" style="background-color: #70e2ef !important;">
                                        <div class="card-action-title">
                                            <div class="d-flex align-items-center">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                    <label class="text-black fs-6 fw-bold">Sales</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-action-element">
                                            <ul class="list-inline mb-0">
                                                <li class="list-inline-item">
                                                    <a href="javascript:;" class="staff_edit_sales"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="collapse staff_edit_sales_body border">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12 mb-4">
                                                <div class="card-action">
                                                    <div class="card-header" style="background-color: #c7c7c7 !important;">
                                                        <div class="card-action-title">
                                                            <div class="d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-bold">Raw Lead</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="card-action-element">
                                                            <ul class="list-inline mb-0">
                                                                <li class="list-inline-item">
                                                                    <a href="javascript:;" class="staff_edit_sales_raw_lead"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="collapse staff_edit_sales_raw_lead_body border">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">List</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Edit</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Import</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Export</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" name="raw_lead_view" id="view_all" disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View All</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" name="raw_lead_view" id="view_self" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View Self</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-4">
                                                <div class="card-action">
                                                    <div class="card-header" style="background-color: #c7c7c7 !important;">
                                                        <div class="card-action-title">
                                                            <div class="d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-bold">Lead</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="card-action-element">
                                                            <ul class="list-inline mb-0">
                                                                <li class="list-inline-item">
                                                                    <a href="javascript:;" class="staff_edit_sales_lead"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="collapse staff_edit_sales_lead_body border">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">List</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Quick Lead</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Add</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Edit</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Delete</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Followup</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Check List</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Customer</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Chat</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Import</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Export</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" name="lead_view" id="view_all" disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View All</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" name="lead_view" id="view_self" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View Self</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-4">
                                                <div class="card-action">
                                                    <div class="card-header" style="background-color: #c7c7c7 !important;">
                                                        <div class="card-action-title">
                                                            <div class="d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-bold">Customer</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="card-action-element">
                                                            <ul class="list-inline mb-0">
                                                                <li class="list-inline-item">
                                                                    <a href="javascript:;" class="staff_edit_sales_customer"><i class="mdi mdi-chevron-up fs-3"></i></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="collapse staff_edit_sales_customer_body border">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">List</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Edit</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Delete</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Add Course</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Add Batch</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Payment</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Import</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="checkbox" name="" id="" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">Export</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" name="customer_view" id="view_all" disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View All</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" name="customer_view" id="view_self" checked disabled />
                                                                    <label class="text-black fs-6 fw-semibold">View Self</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <h5 class="title mt-4 fw-bold">Credentials</h5>
        <div class="row">
            <div class="col-lg-4">
                <label class="text-dark fs-6 fw-bold">Skype</label>
                <div class="col-lg-12">
                    <label class="col-3 text-dark fs-7 fw-semibold">Username</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">skype@123</label>
                </div>
                <div class="col-lg-12">
                    <label class="col-3 text-dark fs-7 fw-semibold">Password</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">skype123</label>
                </div>
            </div>
            <div class="col-lg-4">
                <label class="text-dark fs-6 fw-bold">Spark</label>
                <div class="col-lg-12">
                    <label class="col-3 text-dark fs-7 fw-semibold">Username</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">spark@123</label>
                </div>
                <div class="col-lg-12">
                    <label class="col-3 text-dark fs-7 fw-semibold">Password</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">spark123</label>
                </div>
            </div>
            <div class="col-lg-4">
                <label class="text-dark fs-6 fw-bold">Firewall</label>
                <div class="col-lg-12">
                    <label class="col-3 text-dark fs-7 fw-semibold">URL</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold text-truncate max-w-150px" title="https://192.168.3.1/sonicui/7/login/">https://192.168.3.1/sonicui/7/login/</label>
                </div>
                <div class="col-lg-12">
                    <label class="col-3 text-dark fs-7 fw-semibold">Username</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">firewall@123</label>
                </div>
                <div class="col-lg-12">
                    <label class="col-3 text-dark fs-7 fw-semibold">Password</label>
                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                    <label class="col-7 text-dark fs-6 fw-bold">firewall123</label>
                </div>
            </div>
        </div>
        <h5 class="title mt-4 fw-bold">Knowledge Information</h5>
        <div class="row">
            <div class="col-lg-4">
                <ul class="">
                    <li class="text-dark fs-6 fw-bold">Python - Data Mining</li>
                </ul>
            </div>
            <div class="col-lg-4">
                <ul>
                    <li class="text-dark fs-6 fw-bold">Python - Image Processing</li>
                </ul>
            </div>
            <div class="col-lg-4">
                <ul>
                    <li class="text-dark fs-6 fw-bold">
                        Python - Flask</li>
                </ul>
            </div>
        </div>
    </div>
</div>





<!--Staff Edit Manage Users Role Start-->
<script>
    'use strict';

    (function() {
        const mnge_user_role_edit = [].slice.call(document.querySelectorAll('.mnge_user_role_edit'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (mnge_user_role_edit) {
            mnge_user_role_edit.map(function(mnge_user_role_edit_Element) {
                mnge_user_role_edit_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(mnge_user_role_edit_Element.closest('.card').querySelector('.collapse.mnge_user_role_edit_body'));
                    // Toggle collapsed class in `.card-header` element
                    mnge_user_role_edit_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(mnge_user_role_edit_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Edit Manage Users Role End-->
<!--Staff Edit Dashboards Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_edit_dashboards = [].slice.call(document.querySelectorAll('.staff_edit_dashboards'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_edit_dashboards) {
            staff_edit_dashboards.map(function(staff_edit_dashboards_Element) {
                staff_edit_dashboards_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_edit_dashboards_Element.closest('.card').querySelector('.collapse.staff_edit_dashboards_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_edit_dashboards_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_edit_dashboards_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Edit Dashboards Accordion End-->
<!--Staff Edit Marketing Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_edit_marketing = [].slice.call(document.querySelectorAll('.staff_edit_marketing'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_edit_marketing) {
            staff_edit_marketing.map(function(staff_edit_marketing_Element) {
                staff_edit_marketing_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_edit_marketing_Element.closest('.card').querySelector('.collapse.staff_edit_marketing_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_edit_marketing_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_edit_marketing_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Edit Marketing Accordion End-->
<!--Staff Edit Sales Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_edit_sales = [].slice.call(document.querySelectorAll('.staff_edit_sales'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_edit_sales) {
            staff_edit_sales.map(function(staff_edit_sales_Element) {
                staff_edit_sales_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_edit_sales_Element.closest('.card').querySelector('.collapse.staff_edit_sales_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_edit_sales_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_edit_sales_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Edit Sales Accordion End-->
<!--Staff Edit Sales -> Raw Lead Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_edit_sales_raw_lead = [].slice.call(document.querySelectorAll('.staff_edit_sales_raw_lead'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_edit_sales_raw_lead) {
            staff_edit_sales_raw_lead.map(function(staff_edit_sales_raw_lead_Element) {
                staff_edit_sales_raw_lead_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_edit_sales_raw_lead_Element.closest('.card').querySelector('.collapse.staff_edit_sales_raw_lead_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_edit_sales_raw_lead_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_edit_sales_raw_lead_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Edit Sales -> Raw Lead Accordion End-->
<!--Staff Edit Sales -> Lead Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_edit_sales_lead = [].slice.call(document.querySelectorAll('.staff_edit_sales_lead'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_edit_sales_lead) {
            staff_edit_sales_lead.map(function(staff_edit_sales_lead_Element) {
                staff_edit_sales_lead_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_edit_sales_lead_Element.closest('.card').querySelector('.collapse.staff_edit_sales_lead_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_edit_sales_lead_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_edit_sales_lead_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Edit Sales -> Lead Accordion End-->
<!--Staff Edit Sales -> Customer Accordion Start-->
<script>
    'use strict';

    (function() {
        const staff_edit_sales_customer = [].slice.call(document.querySelectorAll('.staff_edit_sales_customer'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (staff_edit_sales_customer) {
            staff_edit_sales_customer.map(function(staff_edit_sales_customer_Element) {
                staff_edit_sales_customer_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(staff_edit_sales_customer_Element.closest('.card').querySelector('.collapse.staff_edit_sales_customer_body'));
                    // Toggle collapsed class in `.card-header` element
                    staff_edit_sales_customer_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(staff_edit_sales_customer_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Staff Edit Sales -> Customer Accordion End-->
@endsection