@extends('layouts/layoutMaster')

@section('title', 'Students Attendance')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/nouislider/nouislider.js'
])
@endsection

@section('page-script')
@vite([
'resources/assets/js/sliders.js'
])
@endsection

@section('content')
<!-- Attendance -->
<div class="row">
    <div class="col-xl-12">
        <div class="card mb-2">
            <div class="card-header border-bottom pb-1 mb-2">
                <h5 class="card-title mb-1">Students Attendance</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Staff</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <!--begin::Nav Tabs-->
            <div class="nav-align-top mb-2 ms-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_current_schedule" aria-controls="tab_current_batch" aria-selected="true">Current
                            Schedule
                        </button>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_feedback_pending_schedule" aria-controls="tab_pending_batch" aria-selected="false">Feedback Pending
                            Schedule</button>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_completed_schedule" aria-controls="tab_completed" aria-selected="false">Completed
                            Schedule</button>
                    </li>
                </ul>
            </div>
            <!--end::Nav Tabs-->
        </div>
        <div class="card-body">
            <div class="tab-content p-0">
                <!--begin::Current Schedule-->
                <div class="tab-pane fade show active" role="tabpanel" id="tab_current_schedule">
                    <div class="row">
                        <div class="col-xl-4 mb-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-7 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 1</label>
                                            </div>
                                        </div>
                                        <div class="col-5 d-flex align-items-center justify-content-end mb-1">
                                            <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">03</label>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=" col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 mb-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-7 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 2</label>
                                            </div>
                                        </div>
                                        <div class="col-5 d-flex align-items-center justify-content-end mb-1">
                                            <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">03</label>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=" col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 mb-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-7 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 3</label>
                                            </div>
                                        </div>
                                        <div class="col-5 d-flex align-items-center justify-content-end mb-1">
                                            <label class="badge bg-warning text-black rounded fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">03</label>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=" col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Current Schedule-->
                <!--begin::Feedback Pending Schedule-->
                <div class="tab-pane fade" role="tabpanel" id="tab_feedback_pending_schedule">
                    <div class="row">
                        <div class="col-xl-4 mb-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-7 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 4</label>
                                            </div>
                                        </div>
                                        <div class="col-5 d-flex align-items-center justify-content-end mb-1">
                                            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance">
                                                <a href="javascript:void(0);" class="rounded me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance">
                                                    <span>
                                                        <i class="mdi mdi-clipboard-account-outline fs-2"></i>
                                                    </span>
                                                </a>
                                            </div>
                                            <label class="rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Feedback">
                                                <a href="http://127.0.0.1:8000/hr_management/staff/staff_manage_batch/feedback" target="_blank">
                                                    <span>
                                                        <i class="mdi mdi-message-alert-outline fs-2"></i>
                                                    </span>
                                                </a>
                                            </label>
                                            <div>
                                                <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">03</label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=" col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 mb-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-7 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 5</label>
                                            </div>
                                        </div>
                                        <div class="col-5 d-flex align-items-center justify-content-end mb-1">
                                            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance">
                                                <a href="javascript:void(0);" class="rounded me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance">
                                                    <span>
                                                        <i class="mdi mdi-clipboard-account-outline fs-2"></i>
                                                    </span>
                                                </a>
                                            </div>
                                            <label class="rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Feedback">
                                                <a href="http://127.0.0.1:8000/hr_management/staff/staff_manage_batch/feedback" target="_blank">
                                                    <span>
                                                        <i class="mdi mdi-message-alert-outline fs-2"></i>
                                                    </span>
                                                </a>
                                            </label>
                                            <div>
                                                <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">03</label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=" col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 mb-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-7 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 6</label>
                                            </div>
                                        </div>
                                        <div class="col-5 d-flex align-items-center justify-content-end mb-1">
                                            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance">
                                                <a href="javascript:void(0);" class="rounded me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance">
                                                    <span>
                                                        <i class="mdi mdi-clipboard-account-outline fs-2 text-danger"></i>
                                                    </span>
                                                </a>
                                            </div>
                                            <label class="rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Feedback">
                                                <a href="http://127.0.0.1:8000/hr_management/staff/staff_manage_batch/feedback" target="_blank">
                                                    <span>
                                                        <i class="mdi mdi-message-alert-outline fs-2 text-danger"></i>
                                                    </span>
                                                </a>
                                            </label>
                                            <div>
                                                <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">03</label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=" col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin::Feedback Pending Schedule-->
                <!--begin::Completed Schedule-->
                <div class="tab-pane fade" role="tabpanel" id="tab_completed_schedule">
                    <div class="row">
                        <div class="col-xl-4 mb-2">
                            <div class="card bg-light-success">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-8 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 7
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-4 text-end mb-1">
                                            <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">03</label>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=" col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 mb-2">
                            <div class="card bg-light-success">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-8 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 8</label>
                                            </div>
                                        </div>
                                        <div class="col-4 text-end mb-1">
                                            <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">05</label>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 mb-2">
                            <div class="card bg-light-success">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-8 mb-1">
                                            <div>
                                                <label class="text-black fw-bold fs-6">Batch 9</label>
                                            </div>
                                        </div>
                                        <div class="col-4 text-end mb-1">
                                            <label class="badge bg-warning rounded fs-6 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count">
                                                <span>03</span>
                                            </label>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Title">
                                                    <i class="mdi mdi-book fs-3"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Core Java and Concepts Course</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Type">
                                                    <i class="mdi mdi-book-clock fs-3 text-dark"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Crash Course</span>
                                                    <span class="me-1 ms-1">-</span>
                                                    <label class="badge bg-info fs-8 rounded">V 2.5</label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="justify-content-start">
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot">
                                                    <i class="mdi mdi-sun-clock-outline fs-3 text-black"></i>
                                                </label>
                                                <label class="fs-7 align-items-center text-black fw-semibold">
                                                    <span>Morning Slot</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch Duration">
                                                        <i class="mdi mdi-calendar-clock fs-3 text-black"></i>
                                                    </label>
                                                    <div class="fs-7 align-items-center text-black fw-semibold">
                                                        <label class="fs-7">31-May-2024</label>
                                                        <span class="me-1 ms-1"> | </span>
                                                        <label class="fs-7">31-Jul-2024</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-center">
                                                    <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">
                                                        <i class="mdi mdi-calendar-check fs-3 text-black"></i>
                                                    </label>
                                                    <label class="fs-7 align-items-center text-black fw-semibold text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Monday, Tuesday, Wednesday, Thursday, Friday">Mon,
                                                        Tue, Wed, Thu, Fri</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-success fs-5 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start time">
                                                        <span>11:00 AM</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-6 mb-1 text-center">
                                                <div class="fs-5 align-items-center text-black fw-semibold">
                                                    <label class="badge bg-danger fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End time">
                                                        <span>12:30 PM</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin::Completed Schedule-->
            </div>
        </div>
    </div>
</div>

<!--begin::Modal Attendance-->
<div class="modal fade" id="kt_modal_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">Students Attendance</h3>
                </div>
                <!-- Attendance -->
                <div class="row mb-4">
                    <div class="col-lg-12 mb-2">
                        <div class="d-flex fw-bold">
                            <div class="justify-content-start align-items-center">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Batch">
                                    <i class="mdi mdi-calendar-range fs-3 text-black"></i>
                                </label>
                                <label class="fs-5 align-items-center text-black">Batch 01</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 flex-wrap">
                        <h3 class="fw-bold mb-2">
                            <div class="d-flex">
                                <div class="d-flex justify-content-start align-items-center">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Name">
                                        <i class="mdi mdi-book fs-2"></i>
                                    </label>
                                    <div class=" d-block">
                                        <label class="fs-6 fw-semibold text-black">Core Java & Concepts
                                            Course</label>
                                        <div class="d-block fs-8 text-muted fw-semibold">
                                            <label>Crash Course</label>
                                            <label class="me-1 ms-1"> - </label>
                                            <label class="badge bg-info fs-9 rounded">V 2.5</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </h3>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <div class="row">
                            <div class="col-lg-6">
                                <label class="fs-6 fw-semibold text-black align-items-center">
                                    <span><i class="mdi mdi-calendar-blank fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Current Date"></i></span>
                                    <span>12-Jun-2024</span>
                                    <span>(Wed)</span>
                                </label>
                            </div>
                            <div class="col-lg-6">
                                <label class="text-black fs-6 fw-semibold">
                                    <span><i class="mdi mdi-account-group-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Student Count"></i></span>
                                    03
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <div class="align-items-center">
                            <label class="fs-6 text-black">
                                <span><i class="mdi mdi-sun-clock-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slot"></i></span>
                                <span class="text-black fw-semibold">Morning Slot</span>
                            </label>
                        </div>

                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6">
                                <label class="fs-5 text-black d-flex align-items-center">
                                    <label>
                                        <span><i class="mdi mdi-clipboard-clock-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Time"></i></span>
                                        <span class="badge bg-success text-black rounded">11: 00 AM</span>
                                        <span class="badge bg-danger text-white rounded">12: 30 PM</span>
                                    </label>
                                </label>
                            </div>
                            <div class="col-lg-6">
                                <label>
                                    <span><i class="mdi mdi-calendar-check fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Days"></i></span>
                                    <span class="text-black fw-semibold fs-6">20 / 45</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="scroll-y mb-2 px-4 py-4 max-h-200px">
                    <div class="mb-2 row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body px-2 py-2">
                                    <div class="row mb-2">
                                        <div class="col-lg-4">
                                            <div class="d-flex align-items-center justify-content-start">
                                                <div class="align-items-center me-2">
                                                    <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user" class="w-50px h-50px rounded-circle">
                                                </div>
                                                <div class="d-block">
                                                    <div class="d-flex align-items-center justify-content-center ">
                                                        <label class="fs-6 me-2 fw-semibold text-black" title="Student Name">Priya</label>
                                                        <label class="badge bg-danger text-white rounded fw-bold fs-8" title="Female">F
                                                        </label>
                                                    </div>
                                                    <div class="d-block">
                                                        <label class="text-primary fs-8 text-black" title="Student ID">LD-0003/24</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="d-block">
                                                <label class="text-black mb-1">Attendance</label>
                                                <div>
                                                    <div class="form-check form-check-inline fw-semibold">
                                                        <input class="form-check-input" type="radio" name="attendance-1" id="present-radio-1" value="present" checked>
                                                        <label class="form-check-label">Present</label>
                                                    </div>
                                                    <div class="form-check form-check-inline fw-semibold">
                                                        <input class="form-check-input" type="radio" name="attendance-1" id="absent-radio-1" value="absent">
                                                        <label class="form-check-label">Absent</label>
                                                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leave with intimation"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                    </div>
                                                    <div class="form-check form-check-inline fw-semibold">
                                                        <input class="form-check-input" type="radio" name="attendance-1" id="leave-radio-1" value="absent">
                                                        <label class="form-check-label">Leave</label>
                                                        <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leave without intimation"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="d-block">
                                                <label class="text-black mb-1">Total Duration (in Hrs)</label>
                                                <div class="text-black fw-semibold">
                                                    <span>30</span>
                                                    <span>|</span>
                                                    <span>65</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body bg-gray-200 border border-danger px-2 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Fill the Course Feedback to markk attendance">
                                <div class="row mb-2">
                                    <div class="col-lg-4">
                                        <div class="d-flex align-items-center justify-content-start">
                                            <div class="align-items-center me-2">
                                                <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="" class="w-50px h-50px rounded-circle">
                                            </div>
                                            <div class="d-block">
                                                <div class="d-flex align-items-center justify-content-center ">
                                                    <label class="fs-6 me-2 fw-semibold text-black" title="Student Name">Nandhini</label>
                                                    <label class="badge bg-danger text-white rounded fw-bold fs-8" title="Female">F
                                                    </label>
                                                </div>
                                                <div class="d-block">
                                                    <label class="text-primary fs-8 text-black" title="Student ID">LD-0002/24</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5">
                                        <div class="d-block">
                                            <label class="text-black mb-1">Attendance</label>
                                            <div>
                                                <div class="form-check form-check-inline fw-semibold">
                                                    <input class="form-check-input" type="radio" name="attendance-2" id="present-radio-2" value="present" disabled>
                                                    <label class="form-check-label">Present</label>
                                                </div>
                                                <div class="form-check form-check-inline fw-semibold">
                                                    <input class="form-check-input" type="radio" name="attendance-2" id="absent-radio-2" value="absent" disabled>
                                                    <label class="form-check-label">Absent</label>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leave with intimation"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                                <div class="form-check form-check-inline fw-semibold">
                                                    <input class="form-check-input" type="radio" name="attendance-2" id="leave-radio-1" value="absent" disabled>
                                                    <label class="form-check-label">Leave</label>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leave without intimation"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="d-block">
                                            <label class="mb-1 text-black">Total Duration (in Hrs)</label>
                                            <div class="text-black fw-semibold">
                                                <span>10</span>
                                                <span>|</span>
                                                <span>65</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body px-2 py-2">
                                <div class="row mb-2">
                                    <div class="col-lg-4">
                                        <div class="d-flex align-items-center justify-content-start">
                                            <div class="align-items-center me-2">
                                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="" class="w-50px h-50px rounded-circle">
                                            </div>
                                            <div class="d-block ">
                                                <div class="d-flex align-items-center justify-content-center ">
                                                    <label class="fs-6 me-2 fw-semibold text-black" title="Student Name">Praveen</label>
                                                    <label class="badge bg-info text-white rounded fw-bold fs-8" title="Male">M
                                                    </label>
                                                </div>
                                                <div class="d-block">
                                                    <label class="text-primary fs-8 text-black" title="Student ID">LD-0001/24</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5">
                                        <div class="d-block">
                                            <label class="mb-1 text-black">Attendance</label>
                                            <div>
                                                <div class="form-check form-check-inline fw-semibold">
                                                    <input class="form-check-input" type="radio" name="attendance-3" id="present-radio-3" value="present" checked>
                                                    <label class="form-check-label">Present</label>
                                                </div>
                                                <div class="form-check form-check-inline fw-semibold">
                                                    <input class="form-check-input" type="radio" name="attendance-3" id="absent-radio-3" value="absent">
                                                    <label class="form-check-label">Absent</label>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leave with intimation"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                                <div class="form-check form-check-inline fw-semibold">
                                                    <input class="form-check-input" type="radio" name="attendance-3" id="leave-radio-3" value="absent">
                                                    <label class="form-check-label">Leave</label>
                                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Leave without intimation"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="d-block">
                                            <label class="text-black mb-1">Total Duration (in Hrs)</label>
                                            <div class="text-black fw-semibold">
                                                <span>25</span>
                                                <span>|</span>
                                                <span>65</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="d-flex justify-content-end mt-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Mark
                        Attendance</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Attendance-->

<!--begin::Modal - Mark Attendance confirmation-->
<div class=" modal fade" id="kt_modal_mark_attendance" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">!</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you
                sure want
                mark attendance ?</div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <a href="http://127.0.0.1:8000/hr_management/staff/staff_manage_batch" type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</a>
                <span class="btn btn-secondary text-white" data-bs-dismiss="modal">No,
                    Cancel</span>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal -Mark Attendance confirmation-->

<script>
    $(".list_page").DataTable({
        "dom": "<'table-responsive'tr>"
    });
</script>

<script>
    $(".list_page").DataTable({
        // "ordering": false,
        // "aaSorting":[],
        "sorting": false,
        "fixedColumns": {
            "left": 1,
            "right": 1
        },
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        // "pageLength": 5,
        "dom": "<'row'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection