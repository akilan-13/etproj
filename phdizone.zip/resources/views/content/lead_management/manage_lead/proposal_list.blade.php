@extends('layouts/layoutMaster')

@section('title', 'Manage Lead Quotation')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('page-script')
@endsection
@section('content')

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Lead Quotation</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Lead Managements</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 py-0">
        <div class="row mt-4">
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name">
                                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
                            </label>
                            <label class="fs-5 align-items-center text-black fw-bold">
                                <span>Priya Dharshini</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">
                                <i class="mdi mdi-laptop fs-3 text-black"></i>
                            </label>
                            <label class="fs-8 align-items-center badge bg-info text-white fw-bold">
                                <span>Development Service</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mail Id">
                                        <i class="mdi mdi-email-check-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-6 align-items-center text-black fw-bold">
                                        <span>priya@gmail.com</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Phone No">
                                        <i class="mdi mdi-phone-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-6 align-items-center text-black fw-bold">
                                        <span>9876543210</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">
                                <i class="mdi mdi-desktop-classic fs-3 text-black"></i>
                            </label>
                            <label class="fs-6 align-items-center text-black fw-bold">
                                <span>Computer Science- BlockChain technology-ML/DL</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-6">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <div class="row">
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-200px">Estimated No</th>
                                        <th class="min-w-150px">Date</th>
                                        <th class="min-w-150px">Amount</th>
                                        <th class="min-w-100px">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated No">EST-003670/07/2024</label>
                                                <!-- <div class="d-block">
                                                    <span class="badge bg-success text-black fw-bold">Accepted</span>
                                                </div> -->
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated  Date">12-JUL-2024</label>
                                            <div class="d-block">
                                                <label class="d-block text-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">20-Jul-2024</label>
                                            </div>
                                        </td>
                                        <td align="right">
                                            <label class="fs-8 text-black fw-bold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Quotation Amount">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">80,000.00</span>
                                            </label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="{{url('/manage_proposal/proposal_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_proposal/proposal_view')}}" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                                    <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_proposal/proposal_print')}}" class="btn btn-icon btn-sm me-2">
                                                    <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i></span></a>
                                                <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_invoice">
                                                    <span> <i class="mdi mdi-invoice-check-outline fs-3 text-black me-1"></i></span></a>
                                            </span>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated No">EST-003669/07/2024</label>
                                                <!-- <div class="d-block">
                                                    <span class="badge bg-success text-black fw-bold">Accepted</span>
                                                </div> -->
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimated  Date">21-JUL-2024</label>
                                            <div class="d-block">
                                                <label class="d-block text-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">23-Jul-2024</label>
                                            </div>
                                        </td>
                                        <td align="right">
                                            <label class="fs-8 text-black fw-bold mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Quotation Amount">
                                                <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                                <span class="fs-7">85,000.00</span>
                                            </label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="{{url('/manage_proposal/proposal_edit')}}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_proposal/proposal_view')}}" class="btn btn-icon btn-sm me-2" title="View" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                                    <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="{{url('/manage_proposal/proposal_print')}}" class="btn btn-icon btn-sm me-2">
                                                    <span> <i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i></span></a>
                                                <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_invoice">
                                                    <span> <i class="mdi mdi-invoice-check-outline fs-3 text-black me-1"></i></span></a>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal - Add Staff Confirmation-->
    <div class="modal fade" id="kt_modal_staff_confirmation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Staff Confirmation</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                            <select id="job_role" name="job_role" class="select3 form-select">
                                <option value="">Select Job Role</option>
                                <option value="1">Developer</option>
                                <option value="2">Content Writer</option>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="staff" name="staff" class="select3 form-select">
                                <option value="">Select Staff</option>
                                <option value="1">Sabana Barveen</option>
                                <option value="2">Alamelu Mangai</option>
                                <option value="3">Vasanth Kumar</option>
                                <option value="3">Shyamala Devi</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="/manage_requirements" class="btn btn-primary me-3">
                            Staff Confirmation
                        </a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal Add Staff Confirmation- -->

    <!--begin::Modal - Add Staff Confirmation-->
    <div class="modal fade" id="kt_modal_edit_staff_confirmation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Update Staff Confirmation</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                            <select id="job_role_edit" name="job_role_edit" class="select3 form-select">
                                <option value="">Select Job Role</option>
                                <option value="1" selected>Developer</option>
                                <option value="2">Content Writer</option>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="staff_edit" name="staff_edit" class="select3 form-select">
                                <option value="">Select Staff</option>
                                <option value="1" selected>Sabana Barveen</option>
                                <option value="2">Alamelu Mangai</option>
                                <option value="3">Vasanth Kumar</option>
                                <option value="3">Shyamala Devi</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="/manage_requirements" class="btn btn-primary me-3">
                            Update Staff Confirmation
                        </a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal Add Staff Confirmation- -->

    <!--begin::Modal -Invoice-->
    <div class="modal fade" id="kt_modal_lead_invoice" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Generate Invoice?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>LD-0006/24</label>
                    </div>
                </div>

                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/manage_invoice/invoice_add" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Invoice-->
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +


                "<'table-responsive'tr>"


        });
    </script>

    <script>
        let lead_image_edit = document.getElementById('lead_image_edit');
        const lead_image_edit_fileInput = document.querySelector('.lead_image_edit_cls'),
            lead_image_edit_resetFileInput = document.querySelector('.lead_image_edit-reset');

        if (lead_image_edit) {
            const fav_resetImage = lead_image_edit.src;
            lead_image_edit_fileInput.onchange = () => {
                if (lead_image_edit_fileInput.files[0]) {
                    lead_image_edit.src = window.URL.createObjectURL(lead_image_edit_fileInput.files[0]);
                }
            };
            lead_image_edit_resetFileInput.onclick = () => {
                lead_image_edit_fileInput.value = '';
                lead_image_edit.src = fav_resetImage;
            };
        }
    </script>

    @endsection