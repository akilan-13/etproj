@extends('layouts/layoutMaster')

@section('title', 'Create Work List')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
])
@endsection

@section('page-script')
@endsection
@section('content')

<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Work List</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Customer Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mt-4">
            <div class="accordion" id="acc_service">
                <div class="accordion-item active">
                    <h2 class="accordion-header" id="headingOne">
                        <button type="button" class="accordion-button" data-bs-toggle="collapse" data-bs-target="#accordionOne" aria-expanded="true" aria-controls="accordionOne" role="tabpanel">
                            <div class="row w-100">
                                <label class="col-8 fw-bold">
                                    <label class="justify-content-start me-2">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">
                                            <i class="mdi mdi-laptop fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span>Development Services</span>
                                        </label>
                                    </label>
                                    <label class="">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">
                                            <i class="mdi mdi-desktop-classic fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span>Python Development</span>
                                        </label>
                                    </label>
                                </label>
                                <label class="col-4 text-end">
                                    <label>
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment">
                                            <i class="mdi mdi-cash-clock fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span class="text-info">Partially Paid</span>
                                        </label>
                                    </label>
                                    <label><label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add On Services">
                                            <i class="ms-2 mdi mdi-table-plus fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span class="badge bg-danger">Yes</span>
                                        </label></label>
                                </label>
                            </div>
                        </button>
                    </h2>
                    <div id="accordionOne" class="accordion-collapse collapse show" data-bs-parent="#acc_service">
                        <div class="accordion-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row mt-4">
                                                <h5 class="fw-bold text-black">Service Check List</h5>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="form-repeater_service_question">
                                                    <div data-repeater-list="group-a_service_question">
                                                        <div data-repeater-item>
                                                            <div class="row">
                                                                <div class="col-lg-11 mb-1">
                                                                    <div class="row">
                                                                        <div class="col-lg-11">
                                                                            <input type="text" class="form-control" id="" placeholder="Enter Work Check List" />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-1 mb-1">
                                                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question" style="display: none !important;">
                                                                        <i class="mdi mdi-delete fs-4"></i>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-1 mt-1">
                                                    <button class="btn btn-primary service_butt_add_Question" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_Question">
                                                        <i class="mdi mdi-plus me-1"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-end align-items-center mt-4">
                                                <a href="{{url('/manage_customer')}}" class="btn btn-secondary me-3">Cancel</a>
                                                <a href="{{url('/manage_customer')}}" class="btn btn-primary">Create Work List</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="acc_service_add">
                        <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accordionTwo" aria-expanded="false" aria-controls="accordionTwo" role="tabpanel">
                            <div class="row w-100">
                                <label class="col-8 fw-bold">
                                    <label class="justify-content-start me-2">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">
                                            <i class="mdi mdi-laptop fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span>Writing Services</span>
                                        </label>
                                    </label>
                                    <label class="">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">
                                            <i class="mdi mdi-desktop-classic fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span>Thesis Writing</span>
                                        </label>
                                    </label>
                                </label>
                                <label class="col-4 text-end">
                                    <label>
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment">
                                            <i class="mdi mdi-cash-clock fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span class="text-info">Partially Paid</span>
                                        </label>
                                    </label>
                                    <label><label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add On Services">
                                            <i class="ms-2 mdi mdi-table-plus fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span class="badge bg-danger">Yes</span>
                                        </label></label>
                                </label>
                            </div>
                        </button>
                    </h2>
                    <div id="accordionTwo" class="accordion-collapse collapse" aria-labelledby="acc_service_add" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="row mt-4">
                                        <h5 class="fw-bold text-black">Service Check List</h5>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="form-repeater_service_question_service">
                                            <div data-repeater-list="group-a_service_question_service">
                                                <div data-repeater-item>
                                                    <div class="row">
                                                        <div class="col-lg-11 mb-1">
                                                            <input type="text" class="form-control" id="" placeholder="Enter Work Check List" />
                                                        </div>
                                                        <div class="col-lg-1 mb-1">
                                                            <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 service_butt_del_question_service" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question_service" style="display: none !important;">
                                                                <i class="mdi mdi-delete fs-4"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mb-1 mt-1">
                                            <button class="btn btn-primary service_butt_add_Question_service" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_Question_service">
                                                <i class="mdi mdi-plus me-1"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-end align-items-center mt-4">
                                        <a href="{{url('/manage_customer')}}" class="btn btn-secondary me-3">Cancel</a>
                                        <a href="{{url('/manage_customer')}}" class="btn btn-primary">Create Work List</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    $('.service_butt_add_Question_service').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_question_service').length);
        let $clone = $('.form-repeater_service_question_service').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_question_service:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_question_service').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_question_service').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_question_service .service_butt_del_question_service', e => {
        var bt = parseFloat($('.service_butt_del_question_service').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_question_service').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_question_service').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    $('.service_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_question').length);
        let $clone = $('.form-repeater_service_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_question:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_question .service_butt_del_question', e => {
        var bt = parseFloat($('.service_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>


@endsection