@extends('layouts/layoutMaster')

@section('title', 'Manage Lead')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 9999;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap gap-2">
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #c2fbb6 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Customer</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #fcff66 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Followup Lead</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #6fd1fb !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Hot Lead</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: lightpink !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Followup Pending</label>
                    </div>
                    <div class="btn-group">
                        <button class="btn btn-label-warning btn-sm fs-7 border border-gray-400i dropdown-toggle"
                            type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false" style="color: #000000 !important;">
                            <span>Potential Type</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end w-225px px-3 pt-2 pb-1"
                            aria-labelledby="dropdownMenuButton">
                            <li>
                                <div class="d-flex align-items-center border-bottom mb-1 pb-1">
                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/potential/premium.png') }}"
                                            alt="Premium Potential Icon" class="w-25px h-25px text-black fw-bold">
                                    </div>
                                    <div>Premium Potential</div>
                                </div>
                            </li>
                            <li>
                                <div class="d-flex align-items-center border-bottom mb-1 pb-1">
                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/potential/high.png') }}"
                                            alt="High Potential Icon" class="w-25px h-25px text-black fw-bold">
                                    </div>
                                    <div>High Potential</div>
                                </div>
                            </li>
                            <li>
                                <div class="d-flex align-items-center border-bottom mb-1 pb-1">
                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/potential/good.png') }}"
                                            alt="Good Potential Icon" class="w-25px h-25px text-black fw-bold">
                                    </div>
                                    <div>Good Potential</div>
                                </div>
                            </li>
                            <li>
                                <div class="d-flex align-items-center border-bottom mb-1 pb-1">
                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/potential/medium.png') }}"
                                            alt="Medium Potential Icon" class="w-25px h-25px text-black fw-bold">
                                    </div>
                                    <div>Medium Potential</div>
                                </div>
                            </li>
                            <li>
                                <div class="d-flex align-items-center border-bottom mb-1 pb-1">
                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/potential/critical.png') }}"
                                            alt="Critical Potential Icon" class="w-25px h-25px text-black fw-bold">
                                    </div>
                                    <div>Critical Potential</div>
                                </div>
                            </li>
                            <li>
                                <div class="d-flex align-items-center mb-1 pb-1">
                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/potential/low.png') }}"
                                            alt="Low Potential Icon" class="w-25px h-25px text-black fw-bold">
                                    </div>
                                    <div>Low Potential</div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a   href="{{url('/raw_lead')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 ">
                                        <img src="{{ asset('assets/phdizone_images/lead/raw_lead.ico') }}"
                                            alt="Raw Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Raw Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalLeadCount) }}</span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_lead_bank"
                                        aria-controls="tab_lead_bank" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_bank.ico') }}"
                                            alt="Lead Bank Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead Bank</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">01</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/manage_lead')}}"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 active"manage_lead>
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_icn.ico') }}" alt="Lead Icon"
                                            class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">02</span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_spam_lead"
                                        aria-controls="tab_spam_lead" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}"
                                            alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Spam Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">03</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_dead_lead"
                                        aria-controls="tab_dead_lead" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}"
                                            alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Dead Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">04</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_internal_calls"
                                        aria-controls="tab_internal_calls" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/internal_call.ico') }}"
                                            alt="Internal Calls Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Internal Calls</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">01</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        style="background-color: #FCFF66 !important;" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#tab_today_followup" aria-controls="tab_today_followup"
                                        aria-selected="true" id="tdy_flwup">
                                        <img src="{{ asset('assets/phdizone_images/lead/today_followup.ico') }}"
                                            alt="Today Followup Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2" id="tdy_flwup_txt">Today Followup</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">02</span>
                                    </button>
                                </li>
                            </div>
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade" id="tab_raw_lead" role="tabpanel">
                                <div class="d-flex justify-content-between align-items-center flex-wrap my-1">
                                    <div class="text-center border border-gray-500 rounded px-3 py-1">
                                        <div class="text-black fs-6 fw-semibold mb-1">Total Leads Upto <span
                                                class="text-info">( <?php echo date('M-Y'); ?> )</span></div>
                                        <div class="text-dark fs-2 fw-bold mb-1">2,014</div>
                                    </div>
                                    <div class="mb-0">
                                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2"
                                            data-bs-toggle="modal" data-bs-target="#kt_modal_raw_lead_import">
                                            <span class="me-1"><i
                                                    class="mdi mdi-calendar-import-outline fs-5"></i></span> Import
                                        </a>
                                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2">
                                            <span class="me-1"><i class="mdi mdi-transfer fs-5"></i></span> Bulk
                                            Conversion
                                        </a>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-25px">
                                                        <input class="form-check-input border border-gray-300 me-1"
                                                            type="checkbox" name="all" id="bulk_checkall">
                                                        <span class="fs-7">All</span>
                                                    </th>
                                                    <th class="min-w-100px">Lead</th>
                                                    <th class="min-w-100px">Mobile</th>
                                                    <th class="min-w-80px">Lead Group </th>
                                                    <th class="min-w-80px">Lead Source </th>
                                                    <th class="min-w-50px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Priya</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">9876543210</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-success fw-semibold fs-8 rounded-pill">New</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Group">Raw Data March</label>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Source">Google Ads</label>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_convert_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-arrow-right fs-3 text-black me-1"></i></span>
                                                                    <span>Convert Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_spam_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-alert fs-3 text-black me-1"></i></span>
                                                                    <span>Spam Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_lead_bank">
                                                                    <span><i
                                                                            class="mdi mdi-bank-transfer-in fs-3 text-black me-1"></i></span>
                                                                    <span>Lead Bank</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Kathiravan S</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">9791974840</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-danger fw-semibold fs-8 rounded-pill">Exists</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Group">Raw Data March</label>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Source">Google Ads</label>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_convert_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-arrow-right fs-3 text-black me-1"></i></span>
                                                                    <span>Convert Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_spam_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-alert fs-3 text-black me-1"></i></span>
                                                                    <span>Spam Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_lead_bank">
                                                                    <span><i
                                                                            class="mdi mdi-bank-transfer-in fs-3 text-black me-1"></i></span>
                                                                    <span>Lead Bank</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Maheshwari</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">05-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">9345251316</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-success fw-semibold fs-8 rounded-pill">New</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Group">March 2025</label>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Source">Direct Call</label>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_convert_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-arrow-right fs-3 text-black me-1"></i></span>
                                                                    <span>Convert Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_spam_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-alert fs-3 text-black me-1"></i></span>
                                                                    <span>Spam Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_lead_bank">
                                                                    <span><i
                                                                            class="mdi mdi-bank-transfer-in fs-3 text-black me-1"></i></span>
                                                                    <span>Lead Bank</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Sathya</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">05-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">9342434961</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-success fw-semibold fs-8 rounded-pill">New</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Group">March 2025</label>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Source">Direct Call</label>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_convert_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-arrow-right fs-3 text-black me-1"></i></span>
                                                                    <span>Convert Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_spam_lead">
                                                                    <span><i
                                                                            class="mdi mdi-account-alert fs-3 text-black me-1"></i></span>
                                                                    <span>Spam Lead</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_lead_bank">
                                                                    <span><i
                                                                            class="mdi mdi-bank-transfer-in fs-3 text-black me-1"></i></span>
                                                                    <span>Lead Bank</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab_lead_bank" role="tabpanel">
                                <div class="d-flex justify-content-between align-items-center flex-wrap my-1">
                                    <div class="text-center border border-gray-500 rounded px-3 py-1">
                                        <div class="text-black fs-6 fw-semibold mb-1">Your Lead Credit <span
                                                class="text-info">( <?php echo date('M-Y'); ?> )</span></div>
                                        <div class="text-dark fs-2 fw-bold mb-1">50</div>
                                    </div>
                                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2">
                                        <span class="me-1"><i class="mdi mdi-transfer fs-5"></i></span> Bulk Conversion
                                    </a>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-25px">
                                                        <input class="form-check-input border border-gray-300 me-1"
                                                            type="checkbox" name="all" id="bulk_checkall">
                                                        <span class="fs-7">All</span>
                                                    </th>
                                                    <th class="min-w-100px">Lead</th>
                                                    <th class="min-w-100px">Mobile</th>
                                                    <th class="min-w-80px">Lead Group </th>
                                                    <th class="min-w-80px">Lead Source </th>
                                                    <th class="min-w-50px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Vetri K</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">05-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">98765xxxxx</label>
                                                    </td>
                                                    <td>
                                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Group">Raw Data March</label>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Source">Google Ads</label>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a href="javascript:;"
                                                                class="btn btn-sm fw-bold btn-label-primary border border-gray-400i fs-7 px-3 py-0"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_bank_to_lead_transfer">
                                                                <span class="me-1"><i
                                                                        class="mdi mdi-account-arrow-right fs-3"></i></span>
                                                                Lead Transfer
                                                            </a>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Kumaresan E</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">03-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">97919xxxxx</label>
                                                    </td>
                                                    <td>
                                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Group">Raw Data March</label>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Source">Google Ads</label>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a href="javascript:;"
                                                                class="btn btn-sm fw-bold btn-label-primary border border-gray-400i fs-7 px-3 py-0"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_bank_to_lead_transfer">
                                                                <span class="me-1"><i
                                                                        class="mdi mdi-account-arrow-right fs-3"></i></span>
                                                                Lead Transfer
                                                            </a>
                                                        </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade show active" id="tab_lead" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-8 d-flex flex-wrap align-items-center mb-2">
                                        <a href="#" class="text-center border border-2 p-2 me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Total Number of Leads">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Total Leads</div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/lead.png') }}"
                                                    alt="Lead Icon" class="w-80px h-50px text-black fw-bold">
                                            </div>
                                            <div class="d-block">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">1,010</div>
                                            </div>
                                        </a>
                                        <a href="#" class="text-center border border-2 p-2 me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Current Month Leads">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Leads (<?php echo date('F'); ?>)</div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/month.png') }}"
                                                    alt="Current Month Lead Icon"
                                                    class="w-55px h-50px text-black fw-bold">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">10,000</div>
                                            </div>
                                        </a>
                                        <a href="#" class="text-center border border-2 p-2 me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Average Conversion Rate">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Total ACR</div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/convertion.png') }}"
                                                    alt="Avg. Conversion Icon" class="w-55px h-50px text-black fw-bold">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">90 %</div>
                                            </div>
                                        </a>
                                        <a href="#" class="text-center border border-2 p-2 me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Current Month Conversion">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Conversion (<?php echo date('F'); ?>)
                                            </div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/calendar.png') }}"
                                                    alt="Current Month Conversion Icon"
                                                    class="w-55px h-50px text-black fw-bold">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">80 %</div>
                                            </div>
                                        </a>
                                        <a href="#" class="text-center border border-2 p-2">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Pending Followup</div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/pending_followup.png') }}"
                                                    alt="Pending Followup Icon" class="w-55px h-50px text-black fw-bold">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">01</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="d-flex align-items-center justify-content-end flex-wrap">
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Export"><i class="mdi mdi-calendar-export-outline"></i></span>
                                            </a>
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                                id="filter">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Filter"><i
                                                        class="mdi mdi-filter-outline text-center"></i></span>
                                            </a>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-end flex-wrap">
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary fs-7 me-1 mb-2">
                                                <span class="me-1"><i class="mdi mdi-transfer fs-5"></i></span> Bulk
                                                Transfer
                                            </a>
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_add_spam_lead">
                                                <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Spam
                                            </a>
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead">
                                                <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Lead
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="filter_tbox" style="display: none;">
                                    <div class="row py-1">
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead</label>
                                            <select class="select3 form-select">
                                                <option value="" selected>All</option>
                                                <option value="1">Priya</option>
                                                <option value="2">Iniya</option>
                                                <option value="3">Sabana</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Gender</label>
                                            <select class="select3 form-select">
                                                <option value="" selected>All</option>
                                                <option value="1">Male</option>
                                                <option value="2">Female</option>
                                                <option value="3">Others</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type</label>
                                            <select class="select3 form-select">
                                                <option value="" selected>All</option>
                                                <option value="1">Employee</option>
                                                <option value="2">Student</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source</label>
                                            <select class="select3 form-select">
                                                <option value="" selected>All</option>
                                                <option value="1">Website</option>
                                                <option value="2">Email</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Potential Type</label>
                                            <select class="select3 form-select">
                                                <option value="" selected>All</option>
                                                <option value="1">Good</option>
                                                <option value="2">Some Potential</option>
                                                <option value="3">Moderate</option>
                                                <option value="4">Very Worst</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                                            <select class="select3 form-select">
                                                <option value="" selected>All</option>
                                                <option value="1">Active</option>
                                                <option value="2">Inactive</option>
                                                <option value="3">Customer</option>
                                                <option value="4">Drop</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                                            <select class="select3 form-select" name="dt_fill_issue_rpt"
                                                id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                                <option value="all">All</option>
                                                <option value="today">Today</option>
                                                <option value="week">This Week</option>
                                                <option value="monthly">This Month</option>
                                                <option value="custom_date">Custom Date</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text bg-gray-200"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_today_dt_fill" placeholder="Select Date"
                                                    class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text bg-gray-200"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_week_st_dt_fill" placeholder="Select Date"
                                                    class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text bg-gray-200"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_week_ed_dt_fill" placeholder="Select Date"
                                                    class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_this_month_dt_fill"
                                                    placeholder="Select Date" class="form-control this_month_dt_fill"
                                                    value="<?php echo date('M-Y'); ?>" />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_custom_from_dt_fill"
                                                    placeholder="Select Date" class="form-control"
                                                    value="<?php echo date('d-M-Y'); ?>" />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_custom_to_dt_fill"
                                                    placeholder="Select Date" class="form-control"
                                                    value="<?php echo date('d-M-Y'); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-top table-row-dashed table-striped table-hover gy-1 gs-2 lead_list list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-25px">
                                                        <input class="form-check-input border border-gray-300 me-1"
                                                            type="checkbox" name="all">
                                                        <span class="fs-7">All</span>
                                                    </th>
                                                    <th class="min-w-150px">Lead</th>
                                                    <!-- <th class="min-w-100px">Mobile / LFD</th> -->
                                                    <th class="min-w-100px text-center">Mobile / LFD / Calls</th>
                                                    <th class="min-w-80px">Sales Person</th>
                                                    <th class="min-w-100px">Potential Type</th>
                                                    <th class="min-w-100px text-center">Proposal</th>
                                                    <th class="min-w-100px">Status</th>
                                                    <th class="min-w-80px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">Priya</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Registered Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                9876543210</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_verify">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Mobile No Verified"><i
                                                                        class="mdi mdi-check-decagram fs-4 text-primary"></i></span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Life Time">10 Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">17-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">01</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">01</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">01</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">03</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Aarav">Aarav</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Website</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-label-danger border border-gray-400 rounded text-white fw-semibold fs-8 px-1 py-0"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false"
                                                            style="background-color: #F0913D !important;">
                                                            <span><i class="mdi mdi-plus fs-5"></i></span>
                                                            <span>Add Potential</span>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_premium_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/premium.png') }}"
                                                                            alt="Premium Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Premium Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_high_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/high.png') }}"
                                                                            alt="High Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>High Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_good_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/good.png') }}"
                                                                            alt="Good Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Good Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_medium_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/medium.png') }}"
                                                                            alt="Medium Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Medium Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_critical_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/critical.png') }}"
                                                                            alt="Critical Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Critical Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_low_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/low.png') }}"
                                                                            alt="Low Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Low Potential</div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">-
                                                        <!-- <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_quotation">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal"><i class="mdi mdi-note-plus-outline fs-3"></i></span>
                                                        </a> -->
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white rounded fw-bold fs-8"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            Active
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_inactivate">Inactivate</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_appointment">
                                                                    <span><i
                                                                            class="mdi mdi-clipboard-account-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Appointment</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_internal_calls">
                                                                    <span><i
                                                                            class="mdi mdi-call-split fs-3 text-black me-1"></i></span>
                                                                    <span>Internal Calls</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_assign_requirements">
                                                                    <span><i
                                                                            class="mdi mdi-file-chart-check-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Requirments</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_view_lead">
                                                                    <span><i
                                                                            class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                                    <span>View</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_edit_lead">
                                                                    <span><i
                                                                            class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Edit</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <!-- <div class="fs-5 ms-n3 mb-n3">
                                                            <img src="{{ asset('assets/phdizone_images/lead/new.png') }}" alt="New Lead Icon" class="w-50px h-25px text-black fw-bold animation-blink" data-bs-toggle="tooltip" data-bs-placement="bottom" title="New Lead">
                                                        </div> -->
                                                        <div class="mb-0">
                                                            <label class="fs-7 text-black fw-semibold">Nandhini</label>
                                                            <div class="d-block">
                                                                <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Registered Date">05-Mar-2025</label>
                                                            </div>
                                                        </div>
                                                        <div id="leadBoom"
                                                            class="d-block boom badge text-black rounded fw-semibold fs-8 py-0 mt-1"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Appointment Onprogress"
                                                            style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">
                                                            New Lead</div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                8865432100</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_verify">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Mobile No Verified"><i
                                                                        class="mdi mdi-check-decagram fs-4 text-primary"></i></span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Life Time">12 Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">16-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">01</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">02</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Vishnu">Vishnu</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Email</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex mt-2">
                                                            <a href="javascript:;"
                                                                class="border border-gray-500i rounded px-1 py-0 mb-0 me-2"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Premium Potential">
                                                                <img src="{{ asset('assets/phdizone_images/potential/premium.png') }}"
                                                                    alt="Premium Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </a>
                                                            <div class="avatar avatar-sm me-2">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_follow_up_lead">
                                                                    <div class="border border-gray-500i rounded"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Not Yet Followed">
                                                                        <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                            alt="Premium Potential Icon"
                                                                            class="w-30px h-30px text-black fw-bold">
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="javascript:;"
                                                            class="d-inline-flex position-relative btn btn-icon btn-sm mt-2 text-black fw-bold"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_lead_quotation">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Proposal"><i
                                                                    class="text-black mdi mdi-note-plus-outline fs-3"></i></span>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white rounded fw-bold fs-8"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            Active
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_inactivate">Inactivate</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_appointment">
                                                                    <span><i
                                                                            class="mdi mdi-clipboard-account-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Appointment</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_internal_calls">
                                                                    <span><i
                                                                            class="mdi mdi-call-split fs-3 text-black me-1"></i></span>
                                                                    <span>Internal Calls</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_assign_requirements">
                                                                    <span><i
                                                                            class="mdi mdi-file-chart-check-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Requirments</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_view_lead">
                                                                    <span><i
                                                                            class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                                    <span>View</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_edit_lead">
                                                                    <span><i
                                                                            class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Edit</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr style="background-color: #E9EC5E !important;">
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <div class="animation-blink" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Appointment Onprogress">
                                                                <img src="{{ asset('assets/phdizone_images/lead/appointment.ico') }}"
                                                                    alt="Appointment Onprogress Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </div>
                                                            <div class="ms-1 mb-0">
                                                                <label class="fs-7 text-black fw-semibold">Madhan</label>
                                                                <div class="d-block">
                                                                    <label class="text-dark fs-8"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Registered Date">03-Mar-2025</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                8865432187</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_not_verify">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Mobile No. Not Verified">
                                                                    <svg class="w-20px h-20px"
                                                                        enable-background="new 0 0 500 500"
                                                                        viewBox="0 0 500 500"
                                                                        id="hand-draw-white-cross-mark-on-red-circle">
                                                                        <rect id="Layer_1" fill="#fff0f0"
                                                                            display="none"></rect>
                                                                        <g id="Layer_2">
                                                                            <circle cx="250" cy="250"
                                                                                r="200" fill="#f32f45"></circle>
                                                                            <path fill="#f32f45" d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                            l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                            c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                            c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                            c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                            c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                            C345.6,381.2,345.6,381.2,345.6,381.2z"></path>
                                                                            <path fill="#fff"
                                                                                d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                            </path>
                                                                        </g>
                                                                    </svg>
                                                                </span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Lead Life Time">14
                                                                    Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">16-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">03</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">04</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Vishnu">Vishnu</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Email</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex mt-2">
                                                            <a href="javascript:;"
                                                                class="border border-gray-500i rounded px-1 py-0 mb-0 me-2"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="High Potential">
                                                                <img src="{{ asset('assets/phdizone_images/potential/high.png') }}"
                                                                    alt="High Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </a>
                                                            <div class="avatar avatar-sm me-2">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_follow_up_lead_schedule">
                                                                    <div class="border border-gray-500i rounded"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Followup">
                                                                        <img src="{{ asset('assets/phdizone_images/lead/on_followup.gif') }}"
                                                                            alt="Premium Potential Icon"
                                                                            class="w-30px h-30px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Followup Count"
                                                                        style="background-color: #10ff00 !important;">2</span>
                                                                    <span
                                                                        class="position-absolute animation-blink top-100 start-100 translate-middle badge badge-center rounded-pill border bg-danger text-white ms-1"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Followup Pending">!</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="javascript:;"
                                                            class="d-inline-flex position-relative btn btn-icon btn-sm mt-2 text-black fw-bold"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_view_quotation"><i
                                                                class="mdi mdi-note-plus-outline fs-3"></i>
                                                            <div class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Proposal Count"><span class="fs-9">02</span>
                                                            </div>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white rounded fw-bold fs-8"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            Active
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_inactivate">Inactivate</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_hot_lead">Hot Lead</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                data-bs-toggle="dropdown" aria-haspopup="true"
                                                                aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_appointment">
                                                                    <span><i
                                                                            class="mdi mdi-clipboard-account-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Appointment</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_internal_calls">
                                                                    <span><i
                                                                            class="mdi mdi-call-split fs-3 text-black me-1"></i></span>
                                                                    <span>Internal Calls</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_assign_requirements">
                                                                    <span><i
                                                                            class="mdi mdi-file-chart-check-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Requirments</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_view_lead">
                                                                    <span><i
                                                                            class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                                    <span>View</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_edit_lead">
                                                                    <span><i
                                                                            class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Edit</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr style="background-color: #E9EC5E !important;">
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">Vivek</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Registered Date">02-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                7358110788</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_not_verify">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Mobile No. Not Verified">
                                                                    <svg class="w-20px h-20px"
                                                                        enable-background="new 0 0 500 500"
                                                                        viewBox="0 0 500 500"
                                                                        id="hand-draw-white-cross-mark-on-red-circle">
                                                                        <rect id="Layer_1" fill="#fff0f0"
                                                                            display="none"></rect>
                                                                        <g id="Layer_2">
                                                                            <circle cx="250" cy="250"
                                                                                r="200" fill="#f32f45"></circle>
                                                                            <path fill="#f32f45" d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                            l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                            c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                            c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                            c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                            c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                            C345.6,381.2,345.6,381.2,345.6,381.2z"></path>
                                                                            <path fill="#fff"
                                                                                d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                            </path>
                                                                        </g>
                                                                    </svg>
                                                                </span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Lead Life Time">14
                                                                    Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">16-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">03</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">04</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Aarav">Aarav</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex mt-2">
                                                            <a href="javascript:;"
                                                                class="border border-gray-500i rounded px-1 py-0 mb-0 me-2"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="High Potential">
                                                                <img src="{{ asset('assets/phdizone_images/potential/high.png') }}"
                                                                    alt="High Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </a>
                                                            <div class="avatar avatar-sm me-2">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_again_follow_up_lead_schedule">
                                                                    <div class="border border-gray-500i rounded"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Followup">
                                                                        <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                            alt="Premium Potential Icon"
                                                                            class="w-30px h-30px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Followup Count"
                                                                        style="background-color: #10ff00 !important;">1</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="javascript:;"
                                                            class="d-inline-flex position-relative btn btn-icon btn-sm mt-2 text-black fw-bold"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_view_quotation"><i
                                                                class="mdi mdi-note-plus-outline fs-3"></i>
                                                            <div class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Proposal Count"><span class="fs-9">02</span>
                                                            </div>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white rounded fw-bold fs-8"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            Active
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_inactivate">Inactivate</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_hot_lead">Hot Lead</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_drop">Drop Lead</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_spam">Spam Lead</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                data-bs-toggle="dropdown" aria-haspopup="true"
                                                                aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_appointment">
                                                                    <span><i
                                                                            class="mdi mdi-clipboard-account-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Appointment</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_internal_calls">
                                                                    <span><i
                                                                            class="mdi mdi-call-split fs-3 text-black me-1"></i></span>
                                                                    <span>Internal Calls</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_assign_requirements">
                                                                    <span><i
                                                                            class="mdi mdi-file-chart-check-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Requirments</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_view_lead">
                                                                    <span><i
                                                                            class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                                    <span>View</span>
                                                                </a>
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_edit_lead">
                                                                    <span><i
                                                                            class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Edit</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr style="background-color: #C2FBB6 !important;">
                                                    <td></td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">Prakash</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Registered Date">01-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                9876590900</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_verify">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Mobile No Verified"><span
                                                                        class="mdi mdi-check-decagram fs-4 text-primary"></span></span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Lead Life Time">16
                                                                    Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">15-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">03</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">04</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Vishnu">Vishnu</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Email</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex mt-2">
                                                            <a href="javascript:;"
                                                                class="border border-gray-500i rounded px-1 py-0 mb-0 me-2"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Good Potential">
                                                                <img src="{{ asset('assets/phdizone_images/potential/good.png') }}"
                                                                    alt="Good Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </a>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="javascript:;"
                                                            class="d-inline-flex position-relative btn btn-icon btn-sm mt-2 text-black fw-bold"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_view_only_quotation"><i
                                                                class="mdi mdi-note-plus-outline fs-3"></i>
                                                            <div class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Proposal Count"><span class="fs-9">02</span>
                                                            </div>
                                                            <div class="position-absolute top-0 start-0 translate-middle badge badge-center border rounded-pill bg-success w-10px h-15px"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Proposal Accepted"><i class="mdi mdi-check"></i>
                                                            </div>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success text-black rounded fw-semibold fs-8"
                                                            title="">Customer</label>
                                                    </td>
                                                    <td>
                                                        <span class="text-end">
                                                            <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                data-bs-toggle="dropdown" aria-haspopup="true"
                                                                aria-expanded="false">
                                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_view_lead">
                                                                    <span><i
                                                                            class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                                </a>
                                                            </div>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <tr style="background-color: #e25e5e9e !important;">
                                                    <td></td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">Iniya</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Registered Date">01-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                98765XXXXX</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_verify">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Mobile No Verified"><span
                                                                        class="mdi mdi-check-decagram fs-4 text-primary"></span></span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Lead Life Time">16
                                                                    Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">15-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">03</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">04</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Aarav">Aarav</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Website</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex mt-2">
                                                            <a href="javascript:;"
                                                                class="border border-gray-500i rounded px-1 py-0 mb-0 me-2"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Medium Potential">
                                                                <img src="{{ asset('assets/phdizone_images/potential/medium.png') }}"
                                                                    alt="Medium Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </a>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">-
                                                        <!-- <a href="javascript:;" class="d-inline-flex position-relative btn btn-icon btn-sm mt-2 text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_view_quotation"><i class="mdi mdi-note-plus-outline fs-3"></i>
                                                            <div class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal"><span class="fs-9">01</span></div>
                                                        </a> -->
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-danger text-white rounded fw-bold fs-8">Dead
                                                            Lead Awaiting</label>
                                                    </td>
                                                    <td></td>
                                                </tr>
                                                <tr style="background-color: #C6C6C6 !important;">
                                                    <td></td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">Ananth</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Registered Date">28-Feb-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                98555XXXXX</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_verify">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Mobile No Verified"><span
                                                                        class="mdi mdi-check-decagram fs-4 text-primary"></span></span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Lead Life Time">17
                                                                    Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">15-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">03</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">04</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Aarav">Aarav</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex mt-2">
                                                            <a href="javascript:;"
                                                                class="border border-gray-500i rounded px-1 py-0 mb-0 me-2"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Medium Potential">
                                                                <img src="{{ asset('assets/phdizone_images/potential/medium.png') }}"
                                                                    alt="Medium Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </a>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">-</td>
                                                    <td>
                                                        <label class="badge bg-dark text-white rounded fw-bold fs-8">Spam
                                                            Awaiting</label>
                                                    </td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input class="form-check-input bulk_chk" type="checkbox">
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">Yamini</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Registered Date">27-Feb-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <label class="fs-7 text-black fw-semibold me-1">+91
                                                                XXXXXXXXXX</label>
                                                            <a href="javascript:;"
                                                                class="fs-7 text-black fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_mob_no_verify">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Mobile No Verified"><span
                                                                        class="mdi mdi-check-decagram fs-4 text-primary"></span></span>
                                                            </a>
                                                            <a href="javascript:;"
                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_transfer_log">
                                                                <span data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Lead Life Time">18
                                                                    Days</span>
                                                            </a>
                                                            <div class="ms-1 me-2">|</div>
                                                            <div class="badge bg-body text-danger fs-7"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Last Follow Up Date">13-Mar-2025</div>
                                                        </div>
                                                        <hr
                                                            class="border-bottom border-dashed border-gray-400 mt-1 mb-5 me-3">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between gap-3 me-3 mt-3 mb-0">
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_incoming_calls">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Incoming Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                                            alt="Incoming Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border bg-success text-black fs-8 mt-n1">0</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_outgoing_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #FFA500 !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_missed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Missed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/missed_call.ico') }}"
                                                                            alt="Missed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                        style="background-color: #4CD2FC !important;">02</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_reject_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Rejected Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                                            alt="Rejected Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color: #9F0A22 !important;">03</span>
                                                                </a>
                                                            </div>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_dialed_call">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Dialed Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                                            alt="Dialed Call Icon"
                                                                            class="w-20px h-20px text-black fw-bold pe-1">
                                                                    </div>
                                                                    <span
                                                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-white fs-8 mt-n1"
                                                                        style="background-color:rgb(24, 85, 253) !important;">04</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="text-truncate max-w-125px fw-semibold fs-7 text-black">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Vishnu">Vishnu</span>
                                                        </div>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-secondary text-white rounded fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Email</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex mt-2">
                                                            <a href="javascript:;"
                                                                class="border border-gray-500i rounded px-1 py-0 mb-0 me-2"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Low Potential">
                                                                <img src="{{ asset('assets/phdizone_images/potential/low.png') }}"
                                                                    alt="Low Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </a>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">-</td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-warning text-black rounded fw-bold fs-8"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            Inactive
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_lead_activate">Activate</a>
                                                        </div>
                                                    </td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab_spam_lead" role="tabpanel">
                                <div class="d-flex align-items-center flex-wrap mb-2">
                                    <a href="#" class="text-center border border-2 p-2 me-2"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        title="Verified Spam Lead">
                                        <div class="text-dark fw-semibold fs-6 mb-1">Verified Spam</div>
                                        <div class="mb-3">
                                            <img src="{{ asset('assets/phdizone_images/lead/user_verify.png') }}"
                                                alt="Verified Spam Lead Icon" class="w-55px h-50px text-black fw-bold">
                                        </div>
                                        <div class="d-block mt-2">
                                            <div class="badge bg-gray-600i rounded fw-bold fs-5">02</div>
                                        </div>
                                    </a>
                                    <a href="#" class="text-center border border-2 p-2" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Not Verified Spam Lead">
                                        <div class="text-dark fw-semibold fs-6 mb-1">Not Verify Spam</div>
                                        <div class="mb-3">
                                            <img src="{{ asset('assets/phdizone_images/lead/user_not_verify.png') }}"
                                                alt="Not Verified Spam Lead Icon"
                                                class="w-55px h-50px text-black fw-bold">
                                        </div>
                                        <div class="d-block mt-2">
                                            <div class="badge bg-gray-600i rounded fw-bold fs-5">03</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-100px">Lead</th>
                                                    <th class="min-w-80px">Mobile</th>
                                                    <th class="min-w-100px">Sales Person</th>
                                                    <th class="min-w-150px">Reason</th>
                                                    <th class="min-w-100px">TL Status</th>
                                                    <th class="min-w-100px">BH Status</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Suman</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 7428502897</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Irrelevant Call">Irrelevant Call</div>
                                                        <div class="text-truncate max-w-200px text-dark fw-semibold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Looking for job related to washing machine, fridge service">
                                                            [ Looking for job related to washing machine, fridge service ]
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_spm_verify_spam">Verify Spam</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_spm_convert_lead">Convert
                                                                Lead</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-secondary fw-semibold rounded fs-7">Waiting
                                                            for TL Approval</label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Sithik</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 8524897443</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Hindi Calls">Hindi Calls</div>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_spm_verify_spam">Verify Spam</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_spm_convert_lead">Convert
                                                                Lead</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-secondary fw-semibold rounded fs-7">Waiting
                                                            for TL Approval</label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Kabileshwari</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">05-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 8807366854</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Varathan</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Whatsapp</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Hindi Calls">Hindi Calls</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_spm_verify_spam">Verify Spam</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_spm_convert_lead">Convert
                                                                Lead</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Harish</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">04-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 8122697498</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Varathan</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Others">Others</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Santhoshika</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">04-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 6374240992</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Vishnu</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="No Enquiry From Lead">No Enquiry From Lead</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab_dead_lead" role="tabpanel">
                                <div class="d-flex align-items-center flex-wrap mb-2">
                                    <a href="#" class="text-center border border-2 p-2 me-2">
                                        <div class="text-dark fw-semibold fs-6 mb-1">Verified Dead Lead</div>
                                        <div class="mb-3">
                                            <img src="{{ asset('assets/phdizone_images/lead/user_verify.png') }}"
                                                alt="Verified Spam Lead Icon" class="w-55px h-50px text-black fw-bold">
                                        </div>
                                        <div class="d-block mt-2">
                                            <div class="badge bg-gray-600i rounded fw-bold fs-5">01</div>
                                        </div>
                                    </a>
                                    <a href="#" class="text-center border border-2 p-2">
                                        <div class="text-dark fw-semibold fs-6 mb-1">Not Verify Dead Lead</div>
                                        <div class="mb-3">
                                            <img src="{{ asset('assets/phdizone_images/lead/user_not_verify.png') }}"
                                                alt="Not Verified Spam Lead Icon"
                                                class="w-55px h-50px text-black fw-bold">
                                        </div>
                                        <div class="d-block mt-2">
                                            <div class="badge bg-gray-600i rounded fw-bold fs-5">04</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-100px">Lead</th>
                                                    <th class="min-w-80px">Mobile</th>
                                                    <th class="min-w-100px">Sales Person</th>
                                                    <th class="min-w-150px">Reason</th>
                                                    <th class="min-w-100px">TL Status</th>
                                                    <th class="min-w-100px">BH Status</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Mahalakshmi</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 9894075505</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="No Response from Lead">No Response from Lead</div>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_verify_dead">Verify Drop</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_convert_dead">Convert
                                                                Lead</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-secondary fw-semibold rounded fs-7">Waiting
                                                            for TL Approval</label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Vignesh</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 6379729214</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Said Don't Call Me Again">Lead Said Don't Call Me
                                                            Again</div>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_verify_dead">Verify Drop</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_convert_dead">Convert
                                                                Lead</a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="badge bg-secondary fw-semibold rounded fs-7">Waiting
                                                            for TL Approval</label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Hariharasuthan</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">05-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 9363093436</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Varathan</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Whatsapp</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="No Response from Lead">No Response from Lead</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for TL Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_verify_dead">Verify Drop</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_convert_dead">Convert
                                                                Lead</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Subathra</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">04-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 6381633923</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Varathan</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="No Response from Lead">No Response from Lead</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for TL Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_verify_dead">Verify Drop</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_dd_convert_dead">Convert
                                                                Lead</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Naresh Kumar</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">04-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 8838348595</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Vishnu</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Said Don't Call Me Again">Lead Said Don't Call Me
                                                            Again</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab_internal_calls" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-100px">Lead</th>
                                                    <th class="min-w-80px">Mobile</th>
                                                    <th class="min-w-100px">Sales Person</th>
                                                    <th class="min-w-150px">Reason / Comments</th>
                                                    <th class="min-w-100px">Status</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Yogalakshmi</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 8122374265</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="No Response from Lead">No Response from Lead</div>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary fw-semibold text-white rounded fs-7"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Waiting for Approval</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_int_call_approve">Approve</a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_int_call_reject">Reject</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Aashika</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 7550160895</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Said Don't Call Me Again">Lead Said Don't Call Me
                                                            Again</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-success fw-semibold rounded fs-7">Approved</label>
                                                        <a href="javascript:;" class="fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Lead Said Don't Call Me Again">
                                                            <i class="mdi mdi-information-slab-circle text-dark"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <label class="fs-7 me-2">Karthick</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 9360152493</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Projects">Projects</div>
                                                    </td>
                                                    <td>
                                                        <label
                                                            class="badge bg-danger fw-semibold rounded fs-7">Reject</label>
                                                        <a href="javascript:;" class="fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="I need some clarification for content writing">
                                                            <i class="mdi mdi-information-slab-circle text-dark"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab_today_followup" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-200px">Lead</th>
                                                    <th class="min-w-150px">Mobile</th>
                                                    <th class="min-w-150px">Sales Person</th>
                                                    <th class="min-w-80px">Followup Time</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                <tr style="background-color: #FCFF66 !important;">
                                                    <td>
                                                        <label class="fs-7 me-2">Siva subramaniyan</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 7708983305</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-black fw-semibold fs-7">12:00 PM</div>
                                                    </td>
                                                </tr>
                                                <tr style="background-color: #FCFF66 !important;">
                                                    <td>
                                                        <label class="fs-7 me-2">Ramesh</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Register Date">07-Mar-2025</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 text-black fw-semibold">+91 8778953607</label>
                                                    </td>
                                                    <td>
                                                        <label class="fs-7 me-2">Aarav</label>
                                                        <div class="d-block">
                                                            <label
                                                                class="badge bg-warning fw-semibold rounded text-black fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">Direct Call</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-black fw-semibold fs-7">11:45 AM</div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>






    <!--begin::Modal - Import Raw Lead-->
    <div class="modal fade" id="kt_modal_raw_lead_import" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-1 text-black">Import Raw Lead</h3>
                    </div>
                    <div class="text-end">
                        <a href="{{ asset('assets/phdizone_images/lead_sample_import.xlsx') }}" download>
                            <span>Sample Download For Lead Import</span>
                            <span><i class="mb-1 mdi mdi-download-circle fs-3 text-danger"
                                    title="Click Here to Download"></i></span>
                        </a>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Group<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Group" />
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Source</option>
                                <option value="1">Whatsapp</option>
                                <option value="2">Facebook</option>
                                <option value="3">Google Business</option>
                                <option value="4">Reference</option>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <form action="/upload" class="dropzone needsclick" id="dropzone-basic">
                                <div class="dz-message needsclick justify-content-center align-items-center">
                                    <span class="note needsclick">
                                        <h4>Click Here To Upload The Lead Data</h4>
                                    </span>
                                </div>
                                <div class="d-block text-muted fs-6">
                                    Max File Size(5 MB)
                                </div>
                                <div class="fallback">
                                    <input name="file" type="file" accept=".xls" />
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Import</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Import Raw Lead-->

    <!--begin::Modal - Convert Lead-->
    <div class="modal fade" id="kt_modal_convert_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Convert To Lead</h3>
                    </div>
                    <div class="text-dark mb-4 fs-6 fw-bold text-center">Are you sure you want to Convert<span
                            class="text-danger ms-1 me-1">Ravi Kumar R</span> Raw Lead ?</div>
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Source</option>
                                <option value="1">Email</option>
                                <option value="2">Website</option>
                                <option value="2">Facebook</option>
                            </select>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Convert Lead</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Lead-->

    <!--begin::Modal - Spam Lead-->
    <div class="modal fade" id="kt_modal_spam_lead" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    Convert to Spam Lead ?
                    <div class="d-block fw-bold fs-5 text-danger py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>9876543210</label>
                    </div>
                </div>
                <div class="row px-10">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Reason</option>
                            <option value="1">No Enquiry From Lead</option>
                            <option value="2">Irrelevant Call</option>
                            <option value="3">Competitor</option>
                            <option value="4">Fake Enquiry</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Spam Lead-->

    <!--begin::Modal - Lead Bank-->
    <div class="modal fade" id="kt_modal_lead_bank" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    Move Raw Lead to Lead Bank ?
                    <div class="d-block fw-bold fs-5 text-danger py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>9876543210</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Bank-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Lead Bank to Convert Lead-->
    <div class="modal fade" id="kt_modal_lead_bank_to_lead_transfer" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Transfer</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Lead Transfer</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Bank to Convert Lead-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Add Spam Lead-->
    <div class="modal fade" id="kt_modal_add_spam_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Spam Lead</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Name" />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Mobile Number<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Mobile Number" />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Reason</option>
                                <option value="1">No Enquiry From Lead</option>
                                <option value="2">Irrelevant Call</option>
                                <option value="3">Competitor</option>
                                <option value="4">Fake Enquiry</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Spam
                            Lead</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Spam Lead-->


    <!--begin::Modal - Add Lead-->
    <div class="modal fade" id="kt_modal_add_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Lead</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span
                                    class="text-danger">*</span></label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                    id="inlineRadio1" value="option1" />
                                <label class="form-check-label" for="inlineRadio1">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                    id="inlineRadio2" value="option2" />
                                <label class="form-check-label" for="inlineRadio2">Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                    id="inlineRadio3" value="option3" />
                                <label class="form-check-label" for="inlineRadio3">Others</label>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cllt_cl_dt" placeholder="Select Date"
                                    class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Mobile Number<span
                                    class="text-danger">*</span></label>
                            <div class="input-group">
                                <button class="btn btn-outline-primary dropdown-toggle border border-gray-400i"
                                    type="button" data-bs-toggle="dropdown" aria-expanded="false"
                                    id="countryDropdownButton" name="countryDropdownButton">IN - +91</button>
                                <ul class="dropdown-menu" id="countryDropdownMenu" name="countryDropdownMenu"
                                    style="max-height: 250px; overflow-y: auto;">
                                    <li>
                                        <input type="text" id="countrySearch" name="countrySearch"
                                            class="form-control border-1" placeholder="Search Country - Code"
                                            style="width: 100%; border: none; padding: 5px;">
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">AF - +93</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">AL - +355</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">DZ - +213</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">AS - +1684</a>
                                    </li>
                                </ul>
                                <input type="text" class="form-control" id="lead_mobile_create"
                                    placeholder="Enter Mobile Number">
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                            <input type="text" class="form-control me-2"
                                placeholder="Enter Alternate Mobile Number" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Marital Status</label>
                            <select class="select3 form-select">
                                <option value="">Select Marital Status</option>
                                <option value="1">Married</option>
                                <option value="2">Un Married</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Email ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country</label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">Afghanistan</option>
                                <option value="2">Bolivia</option>
                                <option value="3">Canada</option>
                                <option value="4">India</option>
                                <option value="5">Japan</option>
                                <option value="6">Kuwait</option>
                                <option value="7">Libya</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State</label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1">Andhra Pradesh</option>
                                <option value="2">Goa</option>
                                <option value="3">Karnataka</option>
                                <option value="4">Kerala</option>
                                <option value="5">Tamil Nadu</option>
                                <option value="6">Telangana</option>
                                <option value="7">Uttarakhand</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City</label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1">Chennai</option>
                                <option value="2">Vellore</option>
                                <option value="3">Salem</option>
                                <option value="4">Tirunelveli</option>
                                <option value="5">Madurai</option>
                                <option value="6">Dindigul</option>
                                <option value="7">Sivakasi</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Area / Street" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door No / Flat No</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Door No / Flat No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Pincode" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service Category<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Service Category</option>
                                <option value="1">Reasearch Services</option>
                                <option value="2">PHD Services</option>
                                <option value="3">Writing Services</option>
                                <option value="4">Development Services</option>
                                <option value="5">Analysis Services</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Services<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Services</option>
                                <option value="1">Thesis Writing</option>
                                <option value="2">Python Development</option>
                                <option value="3">Java Development</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">University</label>
                            <select class="select3 form-select">
                                <option value="">Select University</option>
                                <option value="1">Madurai Kamarajar University</option>
                                <option value="2">Dindugal Anna University</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Potential Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Potential Type</option>
                                <option value="1">Premium Potential</option>
                                <option value="2">High Potential</option>
                                <option value="3">Good Potential</option>
                                <option value="4">Medium Potential</option>
                                <option value="5">Critical Potential</option>
                                <option value="6">Low Potential</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Type</option>
                                <option value="1">Employee</option>
                                <option value="2">Student</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Source</option>
                                <option value="1">Email</option>
                                <option value="2">Website</option>
                                <option value="2">Facebook</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Comments</label>
                            <textarea class="form-control" rows="1" placeholder="Enter Comments"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Lead</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Lead-->

    <!--begin::Modal - Edit Lead-->
    <div class="modal fade" id="kt_modal_edit_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Update Lead</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Name"
                                value="Priya" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span
                                    class="text-danger">*</span></label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender_edit" />
                                <label class="form-check-label">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender_edit" checked />
                                <label class="form-check-label">Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender_edit" />
                                <label class="form-check-label">Others</label>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cllt_cl_dt_edit" placeholder="Select Date"
                                    class="form-control" value="24-Apr-1998">
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Mobile Number<span
                                    class="text-danger">*</span></label>
                            <div class="input-group">
                                <button class="btn btn-outline-primary dropdown-toggle border border-gray-400i"
                                    type="button" data-bs-toggle="dropdown" aria-expanded="false"
                                    id="countryDropdownButton_edit" name="countryDropdownButton_edit">IN - +91</button>
                                <ul class="dropdown-menu" id="countryDropdownMenu_edit"
                                    name="countryDropdownMenu_edit" style="max-height: 250px; overflow-y: auto;">
                                    <li>
                                        <input type="text" id="countrySearch_edit" name="countrySearch_edit"
                                            class="form-control border-1" placeholder="Search Country - Code"
                                            style="width: 100%; border: none; padding: 5px;">
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">AF - +93</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">AL - +355</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">DZ - +213</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item waves-effect" href="javascript:void(0);">AS - +1684</a>
                                    </li>
                                </ul>
                                <input type="text" class="form-control" id="lead_mobile_edit"
                                    placeholder="Enter Mobile Number" value="9876543210">
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                            <input type="text" class="form-control me-2"
                                placeholder="Enter Alternate Mobile Number" value="8976543210" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Marital Status</label>
                            <select class="select3 form-select">
                                <option value="">Select Marital Status</option>
                                <option value="1">Married</option>
                                <option value="2" selected>Un Married</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Email ID"
                                value="priya@gmail.com" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country</label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">Afghanistan</option>
                                <option value="2">Bolivia</option>
                                <option value="3">Canada</option>
                                <option value="4" selected>India</option>
                                <option value="5">Japan</option>
                                <option value="6">Kuwait</option>
                                <option value="7">Libya</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State</label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1">Andhra Pradesh</option>
                                <option value="2">Goa</option>
                                <option value="3">Karnataka</option>
                                <option value="4">Kerala</option>
                                <option value="5" selected>Tamil Nadu</option>
                                <option value="6">Telangana</option>
                                <option value="7">Uttarakhand</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City</label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1">Chennai</option>
                                <option value="2">Vellore</option>
                                <option value="3">Salem</option>
                                <option value="4">Tirunelveli</option>
                                <option value="5" selected>Madurai</option>
                                <option value="6">Dindigul</option>
                                <option value="7">Sivakasi</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Area / Street"
                                value="Bharathiyar Street" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door No / Flat No</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Door No / Flat No"
                                value="1" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode</label>
                            <input type="text" class="form-control me-2" placeholder="Enter Pincode"
                                value="625012" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service Category<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Service Category</option>
                                <option value="1">Reasearch Services</option>
                                <option value="2">PHD Services</option>
                                <option value="3">Writing Services</option>
                                <option value="4" selected>Development Services</option>
                                <option value="5">Analysis Services</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Services<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Services</option>
                                <option value="1">Thesis Writing</option>
                                <option value="2" selected>Python Development</option>
                                <option value="3">Java Development</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">University</label>
                            <select class="select3 form-select">
                                <option value="">Select University</option>
                                <option value="1" selected>Madurai Kamarajar University</option>
                                <option value="2">Dindugal Anna University</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Potential Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Potential Type</option>
                                <option value="1" selected>Premium Potential</option>
                                <option value="2">High Potential</option>
                                <option value="3">Good Potential</option>
                                <option value="4">Medium Potential</option>
                                <option value="5">Critical Potential</option>
                                <option value="6">Low Potential</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Type</option>
                                <option value="1">Employee</option>
                                <option value="2" selected>Student</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Source</option>
                                <option value="1">Email</option>
                                <option value="2" selected>Website</option>
                                <option value="2">Facebook</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Comments</label>
                            <textarea class="form-control" rows="1" placeholder="Enter Comments">-</textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Lead</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit Lead-->

    <!--begin::Modal - View Lead-->
    <div class="modal fade" id="kt_modal_view_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">
                            <label>View Lead</label>
                            <label class="ms-1 me-1">-</label>
                            <label class="badge bg-info rounded fw-semibold fs-4">Active</label>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 text-black fs-5 fw-bold">Basic Information</div>
                        <div class="col-lg-6 text-end">
                            <div class="badge bg-secondary text-end fs-6 text-white fw-semibold rounded">LD-0003/24</div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Registered Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">07-Mar-2025</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Priya</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Female</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">DOB</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">24-Apr-1998</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="priya@gmail.com">priya@gmail.com</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">1, Bharathiyar Street, Madurai, Tamil Nadu,
                                    India - 625012</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">9876543210</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Alternate Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">8976543210</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Marital Status</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Un Married</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="text-black fs-5 fw-bold">Service Information</label>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Development Services</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Service</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Computer Science- BlockChain
                                    technology-ML/DL</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-black fs-5 fw-bold">Lead Information</div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Student</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Potential Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7 text-black fs-6 fw-bold">
                                    <div class="d-flex align-items-center">
                                        <div class="me-1">
                                            <img src="{{ asset('assets/phdizone_images/potential/premium.png') }}"
                                                alt="Premium Potential Icon" class="w-25px h-25px text-black fw-bold">
                                        </div>
                                        <label class="text-black fs-6 fw-bold">Premium Potential</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Source</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Website</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">University</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Madurai Kamarajar University</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <label class="text-dark fs-6 fw-semibold mb-2">Comments</label>
                            <div class="d-block">
                                <label class="text-black fs-7 fw-bold">&emsp;&emsp;-</label>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Lead-->


    <!--begin::Modal - Lead Appointment-->
    <div class="modal fade" id="kt_modal_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Create Appointment</span>
                            <span class="ms-1 me-1">-</span>
                            <span class="badge bg-info rounded fs-5">Priya</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Category<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="aptment" onchange="apmt_func();">
                                <option value="">Select Appointment Category</option>
                                <option value="1">Walk-In</option>
                                <option value="online">Online</option>
                                <option value="3">Offline</option>
                                <option value="4">Video</option>
                                <option value="5">Payment</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="apt_dt" placeholder="Select Date" class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department <span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Department </option>
                                <option value="1">Collection Executive</option>
                                <option value="2">CRE</option>
                                <option value="3">PC</option>
                                <option value="4">Internal Support</option>
                                <option value="5">Sales</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="1" placeholder="Enter Appointment Reason"></textarea>
                        </div>
                        <div class="col-lg-4 mb-3" id="onl_link_tbox" style="display: none;">
                            <label class="text-black mb-1 fs-6 fw-semibold">Meeting Link<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Meeting Link" />
                        </div>
                        <div class="col-lg-4 mb-3" id="onl_link_pw_tbox" style="display: none;">
                            <label class="text-black mb-1 fs-6 fw-semibold">Meeting Password</label>
                            <div class="form-password-toggle">
                                <div class="input-group input-group-merge">
                                    <input type="password" class="form-control" id="password"
                                        placeholder="Enter Password" aria-describedby="password" />
                                    <span class="input-group-text cursor-pointer"><i
                                            class="mdi mdi-eye-off-outline fs-4"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" placeholder="Enter Description"></textarea>
                        </div>

                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create
                            Appointment</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Appointment-->

    <!--begin::Modal -  Internal Calls-->
    <div class="modal fade" id="kt_modal_internal_calls" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    Convert to Internal Calls ?
                    <div class="d-block fw-bold fs-5 text-danger py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>9876543210</label>
                    </div>
                </div>
                <div class="row px-10">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Reason</option>
                            <option value="1">Embedded School</option>
                            <option value="2">Elysian Skill</option>
                            <option value="3">Academy Placements</option>
                            <option value="4">Projects</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Internal Calls-->

    <!--begin::Modal - Assign Requirements-->
    <div class="modal fade" id="kt_modal_assign_requirements" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Assign Requirments</h3>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">Priya</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Lead Mobile</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">+91 9876543210</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Service Category</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">Development Service</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Service</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">Computer Science- BlockChain
                            technology-ML/DL</label>
                    </div>
                    <div class="form-repeater_reqts mt-6">
                        <div data-repeater-list="group-a_led_question">
                            <div data-repeater-item>
                                <div class="row mt-4">
                                    <div class="col-lg-7 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Requirements Point 1<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control"
                                            placeholder="Enter Requirements Point 1" />
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                                        <div class="d-flex align-items-sm-center">
                                            <img src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                alt="user-avatar"
                                                class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid"
                                                id="uploadedlogo" />
                                            <div class="ms-1 button-wrapper">
                                                <div class="d-flex align-items-start mt-2 mb-2">
                                                    <label for="upload" class="btn btn-sm btn-primary me-2"
                                                        tabindex="0" data-bs-toggle="tooltip"
                                                        data-bs-placement="top" title="Upload Logo">
                                                        <i class="mdi mdi-tray-arrow-up"></i>
                                                        <input type="file" id="upload" class="file-in" hidden
                                                            accept="image/png, image/jpeg" />
                                                    </label>
                                                    <button type="button"
                                                        class="btn btn-sm btn-outline-danger file-reset"
                                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                                        title="Reset Logo">
                                                        <i class="mdi mdi-reload"></i>
                                                    </button>
                                                </div>
                                                <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size of 5MB</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1">
                                        <a href="javascript:;"
                                            class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                            id="staff_reqts_del" style="display: none !important;">
                                            <i class="mdi mdi-delete fs-4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-1 mt-1">
                        <button class="btn btn-sm btn-primary staff_reqts_add px-2 py-1" data-bs-toggle="tooltip"
                            data-bs-placement="top" title="Add" data-repeater-create id="staff_reqts_add">
                            <i class="mdi mdi-plus me-1"></i>Add More
                        </button>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="/manage_requirements" class="btn btn-primary me-3">
                            Assign Requirments
                        </a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Assign Requirements- -->

    <!--begin::Modal - Mobile No Verified-->
    <div class="modal fade" id="kt_modal_mob_no_verify" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Mobile Number Verification Details</h3>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">Priya</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Mobile</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">+91 9876543210</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Carrier</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">Bharti Airtel Ltd</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Line Type</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">Mobile</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Location</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">Tamil Nadu</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Status</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 fs-5 fw-bold text-success">Valid Number</label>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Mobile No Verified-->

    <!--begin::Modal - Mobile No Not Verified-->
    <div class="modal fade" id="kt_modal_mob_no_not_verify" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Mobile Number Verification Details</h3>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">Priya</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Mobile</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">+91 9876543210</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Status</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 fs-5 fw-bold text-danger">IN-Valid Number</label>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Mobile No Not Verified-->

    <!--begin::Modal - Lead Transfer Log-->
    <div class="modal fade" id="kt_modal_lead_transfer_log" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Transfer Log Details</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Priya</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Source</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Website</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">+91 9876543210</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Registered Date">Registered Dt</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 fs-6 fw-bold text-black">07-Mar-2025</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Staff</th>
                                        <th class="min-w-150px">Transfered From</th>
                                        <th class="min-w-150px">End Date</th>
                                        <th class="min-w-50px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Aarav">
                                                Aarav</div>
                                        </td>
                                        <td>
                                            <div class="text-truncate fs-7 fw-semibold max-w-150px"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Direct Lead">Direct Lead</div>
                                        </td>
                                        <td>
                                            <div class="text-black fs-7 fw-semibold">-</div>
                                        </td>
                                        <td>
                                            <div class="text-black fs-7 fw-semibold">0 Days</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Transfer Log-->

    <!--begin::Modal - Incoming Call Log-->
    <div class="modal fade" id="kt_modal_incoming_calls" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Incoming Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/incoming_call.ico') }}"
                                                        alt="Incoming Call Icon"
                                                        class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">10:41:33 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">10:41:41 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:08</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Incoming Call Log-->

    <!--begin::Modal - Outgoing Call Log-->
    <div class="modal fade" id="kt_modal_outgoing_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Outgoing Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                        alt="Outgoing Call Icon"
                                                        class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">02:20:00 PM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">02:21:20 PM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:01:20</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                        alt="Outgoing Call Icon"
                                                        class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:00:02 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:01:10 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:01:08</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Incoming Call Log-->

    <!--begin::Modal - Missed Call Log-->
    <div class="modal fade" id="kt_modal_missed_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Missed Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr style="background-color: #ecc093 !important;">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                        alt="Reject Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-info text-white fs-7 fw-semibold">10:40:05 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-danger text-white fs-7 fw-semibold">10:40:07 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:02</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Call Log-->

    <!--begin::Modal - Reject Call Log-->
    <div class="modal fade" id="kt_modal_reject_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Reject Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr style="background-color: #ff00004f !important;">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                        alt="Reject Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-info text-white fs-7 fw-semibold">10:40:10 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-danger text-white fs-7 fw-semibold">10:40:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:10</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Call Log-->

    <!--begin::Modal - Dialed Call Log-->
    <div class="modal fade" id="kt_modal_dialed_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Dialed Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:03:21 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:03:21 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:01:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:01:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:00:04 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:00:04 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Dialed Call Log-->

    <!--begin::Modal - Appointment Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Schedule</h3>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">Nandhini
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">+91
                                8865432100</div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="lead_apt_sch" placeholder="Select Date"
                                    class="form-control" value="30-May-2024" />
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Time<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="HH:MM" id="apt_time" />
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Schedule</button>
                        </div>
                    </div>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Appointment Schedule-->

    <!--begin::Modal - Pending Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">Madhan
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">+91
                                8865432187</div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">
                                05-Mar-2025</div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">10.00 AM
                            </div>
                        </div>
                        <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                            <div class="text-black fs-5 fw-semibold">
                                <span>Reschedule Count</span>
                                <span class="badge bg-danger fs-6 text-white rounded">01</span>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span
                                    class="text-danger">*</span></label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="progressed" id="prog_yes"
                                    onclick="progress_func('yes');" checked />
                                <label class="form-check-label">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="progressed" id="prog_no"
                                    onclick="progress_func('no');" />
                                <label class="form-check-label">No</label>
                            </div>
                        </div>
                    </div>
                    <div id="message">
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold d-block">Conversation Message<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="flw_conversation" />
                                    <label class="text-black mb-1 fs-6 fw-semibold">Positive</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="flw_conversation" />
                                    <label class="text-black mb-1 fs-6 fw-semibold">Negative</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="flw_conversation" />
                                    <label class="text-black mb-1 fs-6 fw-semibold">Neutral</label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <textarea class="form-control" rows="3" placeholder="Enter Conversation Message"></textarea>
                            </div>
                        </div>
                        <div class="border-bottom mb-3 mt-2"></div>
                    </div>
                    <div id="reason" style="display: none !important;">
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select">
                                    <option value="">Select Reason</option>
                                    <option value="1">Call Disconnected</option>
                                    <option value="2">Number is Not Reachable</option>
                                    <option value="3">Network Error</option>
                                </select>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i
                                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="re_app_date" placeholder="Select Date"
                                            class="form-control" value="14-Aug-1999" />
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Time</label>
                                    <input type="text" class="form-control " placeholder="HH:MM" id="re_app_time"
                                        value="10.00 AM" />
                                </div>
                            </div>
                        </div>
                        <div class="border-bottom mb-3 mt-2"></div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="accordion">
                                <div class="accordion-item mb-2 active">
                                    <h2 class="accordion-header" id="headingPopoutOne">
                                        <button type="button" class="accordion-button" data-bs-toggle="collapse"
                                            data-bs-target="#accordionPopoutOne" aria-expanded="true"
                                            aria-controls="accordionPopoutOne">
                                            <span class="text-black fw-semibold fs-6">Followup History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6">02</span>
                                        </button>
                                    </h2>
                                    <div id="accordionPopoutOne" class="accordion-collapse collapse show"
                                        aria-labelledby="headingPopoutOne" data-bs-parent="#accordionPopout">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                <th class="min-w-125px">Last Followup<br>Date / Time</th>
                                                                <th class="min-w-125px">Followed By</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8">
                                                            <tr>
                                                                <td>
                                                                    <label
                                                                        class="fs-8 text-black fw-semibold">05-Mar-2025</label>
                                                                    <div class="d-block">
                                                                        <label class="text-dark fs-8"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Last Followup Date">10:00 AM</label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <label
                                                                        class="text-black fw-semibold fs-7">Aarav</label>
                                                                </td>
                                                                <td>
                                                                    <div class="text-truncate max-w-150px">-</div>
                                                                </td>
                                                                <td>
                                                                    <div class="text-truncate max-w-150px">-</div>
                                                                </td>
                                                            </tr>
                                                            <tr class="bg-danger">
                                                                <td>
                                                                    <label
                                                                        class="fs-8 text-black fw-semibold">04-Mar-2025</label>
                                                                    <div class="d-block text-dark fs-8"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Last Followup Date">11:00 AM</div>
                                                                </td>
                                                                <td>
                                                                    <label
                                                                        class="text-black fw-semibold fs-7">Aarav</label>
                                                                </td>
                                                                <td>-</td>
                                                                <td>
                                                                    <div class="text-truncate max-w-150px"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Call Not Picked by lead">Call Not Picked by
                                                                        lead</div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-2">
                                    <h2 class="accordion-header" id="headingPopoutTwo">
                                        <button type="button" class="accordion-button collapsed"
                                            data-bs-toggle="collapse" data-bs-target="#accordionPopoutTwo"
                                            aria-expanded="false" aria-controls="accordionPopoutTwo">
                                            <span class="text-black fw-semibold fs-6">Appointment History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6">02</span>
                                        </button>
                                    </h2>
                                    <div id="accordionPopoutTwo" class="accordion-collapse collapse"
                                        aria-labelledby="headingPopoutTwo" data-bs-parent="#accordionPopout">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                <th class="min-w-100px">Date / Time</th>
                                                                <th class="min-w-100px">Category</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                                <th class="min-w-100px">Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8">
                                                            <tr>
                                                                <td>
                                                                    <label
                                                                        class="fs-8 text-black fw-semibold">05-Mar-2025</label>
                                                                    <div class="d-block">
                                                                        <label class="text-dark fs-8"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Last Followup Date">10:00 AM</label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <label
                                                                        class="text-black fw-semibold fs-7">Walk-in</label>
                                                                </td>
                                                                <td>
                                                                    <div class="text-truncate max-w-150px"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Accepted for thesis writing services.">
                                                                        Accepted for thesis writing services.</div>
                                                                </td>
                                                                <td>-</td>
                                                                <td>
                                                                    <div class="badge bg-success fw-semibold fs-7">
                                                                        Completed</div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <label
                                                                        class="fs-8 text-black fw-semibold">04-Mar-2025</label>
                                                                    <div class="d-block text-dark fs-8"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Last Followup Date">11:00 AM</div>
                                                                </td>
                                                                <td>
                                                                    <label
                                                                        class="text-black fw-semibold fs-7">Walk-in</label>
                                                                </td>
                                                                <td>-</td>
                                                                <td>
                                                                    <div class="text-truncate max-w-150px"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Call Not Picked by lead">Call Not Picked by
                                                                        lead</div>
                                                                </td>
                                                                <td>
                                                                    <div class="badge bg-danger fw-semibold fs-7">
                                                                        Cancelled</div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Submit
                                Report</button>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Pending Followup Lead Schedule-->

    <!--begin::Modal - Again Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_again_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">New Followup</h3>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">Vivek
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">+91
                                7358110788</div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="again_lead_apt_sch" placeholder="Select Date"
                                    class="form-control" value="30-May-2024" />
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                            <input type="text" class="form-control" placeholder="HH:MM" id="again_apt_time" />
                        </div>
                        <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                            <div class="text-black fs-5 fw-semibold">
                                <span>Reschedule Count</span>
                                <span class="badge bg-danger fs-6 text-white rounded">0</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="accordion">
                                <div class="accordion-item mb-2">
                                    <h2 class="accordion-header" id="again_flw_headingPopoutOne">
                                        <button type="button" class="accordion-button collapsed"
                                            data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutOne"
                                            aria-expanded="false" aria-controls="again_flw_accordionPopoutOne">
                                            <span class="text-black fw-semibold fs-6">Followup History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6">01</span>
                                        </button>
                                    </h2>
                                    <div id="again_flw_accordionPopoutOne" class="accordion-collapse collapse"
                                        aria-labelledby="again_flw_headingPopoutOne">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                <th class="min-w-125px">Last Followup<br>Date / Time</th>
                                                                <th class="min-w-125px">Followed By</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8">
                                                            <tr>
                                                                <td>
                                                                    <label
                                                                        class="fs-8 text-black fw-semibold">03-Mar-2025</label>
                                                                    <div class="d-block text-dark fs-8"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Last Followup Date">11:00 AM</div>
                                                                </td>
                                                                <td>
                                                                    <label
                                                                        class="text-black fw-semibold fs-7">Aarav</label>
                                                                </td>
                                                                <td>-</td>
                                                                <td>
                                                                    <div class="text-truncate max-w-150px"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Call Not Picked by lead">Call Not Picked by
                                                                        lead</div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-2">
                                    <h2 class="accordion-header" id="again_flw_headingPopoutTwo">
                                        <button type="button" class="accordion-button collapsed"
                                            data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutTwo"
                                            aria-expanded="false" aria-controls="again_flw_accordionPopoutTwo">
                                            <span class="text-black fw-semibold fs-6">Appointment History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6">0</span>
                                        </button>
                                    </h2>
                                    <div id="again_flw_accordionPopoutTwo" class="accordion-collapse collapse"
                                        aria-labelledby="again_flw_headingPopoutTwo">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                <th class="min-w-100px">Date / Time</th>
                                                                <th class="min-w-100px">Category</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                                <th class="min-w-100px">Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8">
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Schedule</button>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Again Followup Lead Schedule-->

    <!--begin::Modal - Customer Inactivate-->
    <div class="modal fade" id="kt_modal_lead_inactivate" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want
                    To Change Status to Inactivate?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>LD-0006/24</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/sales/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer Inactivate-->

    <!--begin::Modal - Generate Quotation-->
    <div class="modal fade" id="kt_modal_lead_quotation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want
                    To Generate Proposal?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>LD-0006/24</label>
                    </div>
                </div>

                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/manage_proposal/proposal_add" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Generate Quotation-->

    <!--begin::Modal -Lead Drop-->
    <div class="modal fade" id="kt_modal_lead_drop" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want
                    To Change Status to Drop?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>LD-0006/24</label>
                    </div>
                </div>

                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/sales/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Drop-->

    <!--begin::Modal - Activate Lead-->
    <div class="modal fade" id="kt_modal_lead_activate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want
                    To Change Status to Activate?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>LD-0006/24</label>
                    </div>
                </div>

                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/sales/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Activate Lead-->

    <!--begin::Modal - Proposal Details-->
    <div class="modal fade" id="kt_modal_view_quotation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Proposal Detail
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">02</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003670/04/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">02-Apr-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">07-Apr-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,21,068</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <a href="{{ url('/manage_proposal/proposal_edit') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Edit Proposal">
                                                    <span> <i
                                                            class="mdi mdi-square-edit-outline fs-3 text-dark"></i></span>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                        <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                    </a> -->
                                                <a href="{{ url('/manage_proposal/proposal_print') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">01</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003669/03/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">27-Mar-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">31-Mar-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,36,998</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                        <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                    </a> -->
                                                <a href="{{ url('/manage_proposal/proposal_print') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Proposal Details-->

    <!--begin::Modal - View Only Proposal Details-->
    <div class="modal fade" id="kt_modal_view_only_quotation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Proposal Detail
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="bg-label-success rounded-circle fw-semibold"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Proposal Accepted"><i
                                                class="mdi mdi-check-decagram fs-1 fw-bold opacity-1 text-success"></i></label>
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">02</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003670/04/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">02-Apr-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">07-Apr-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,21,068</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                        <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                    </a> -->
                                                <a href="{{ url('/manage_proposal/proposal_print') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">01</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003669/03/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">27-Mar-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">31-Mar-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,36,998</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                        <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                    </a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Only Proposal Details-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Spam Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_spm_verify_spam" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Verify Spam - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to confirm this lead is
                        spam ?</div>
                    <div class="text-center text-danger mb-4 fs-5 fw-semibold">Suman [ +91 7428502897 ]</div>
                    <div class="text-dark mb-1 fs-5 fw-semibold"><u>Reason</u> &nbsp; :</div>
                    <div class="text-black mb-6 fs-6 fw-semibold ms-4">Irrelevant Call [ Looking for job related to
                        washing machine, fridge service ]</div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Verification Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Verification Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <a href="javascript:;" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</a>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Spam Lead (Verify Status)- -->

    <!--begin::Modal - Convert Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_spm_convert_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Convert Lead - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to convert this lead ?
                    </div>
                    <div class="text-center text-danger mb-6 fs-5 fw-semibold">Suman [ +91 7428502897 ]</div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-5 fw-semibold">Before Staff &emsp; : &emsp;</label>
                        <label class="col-7 text-info fs-4 fw-semibold">Aarav</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Convert Lead</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Lead (Verify Status)- -->


    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Dead Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_dd_verify_dead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Verify Drop - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to confirm this lead is
                        Drop ?</div>
                    <div class="text-center text-danger mb-4 fs-5 fw-semibold">Mahalakshmi [ +91 9894075505 ]</div>
                    <div class="text-dark mb-1 fs-5 fw-semibold"><u>Reason</u> &nbsp; :</div>
                    <div class="text-black mb-6 fs-6 fw-semibold ms-4">No Response from Lead</div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Verification Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Verification Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <a href="javascript:;" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</a>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Dead Lead (Verify Status)- -->

    <!--begin::Modal - Convert Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_dd_convert_dead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Convert Lead - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to convert this lead ?
                    </div>
                    <div class="text-center text-danger mb-6 fs-5 fw-semibold">Suman [ +91 7428502897 ]</div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-5 fw-semibold">Before Staff &emsp; : &emsp;</label>
                        <label class="col-7 text-info fs-4 fw-semibold">Aarav</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Convert Lead</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Lead (Verify Status)- -->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Internal Calls (Approve Status)-->
    <div class="modal fade" id="kt_modal_int_call_approve" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Approve Internal Calls</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to approve this lead as
                        Internal Call?</div>
                    <div class="text-center text-danger mb-4 fs-5 fw-semibold">Yogalakshmi [ +91 8122374265 ]</div>
                    <div class="text-dark mb-1 fs-5 fw-semibold"><u>Reason</u> &nbsp; :</div>
                    <div class="text-black mb-6 fs-6 fw-semibold ms-4">No Response from Lead</div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Verification Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Verification Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <a href="javascript:;" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</a>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Internal Calls (Approve Status) -->

    <!--begin::Modal - Internal Calls (Reject Status)-->
    <div class="modal fade" id="kt_modal_int_call_reject" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Reject Internal Calls</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to reject this call ?</div>
                    <div class="text-center text-danger mb-6 fs-5 fw-semibold">Yogalakshmi [ +91 8122374265 ]</div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-5 fw-semibold">Sales Staff &emsp; : &emsp;</label>
                        <label class="col-7 text-info fs-4 fw-semibold">Aarav</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Rejected Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Rejected Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Reject</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Internal Calls (Reject Status)- -->













    <script>
        function apmt_func() {
            var aptment = document.getElementById('aptment').value;
            var onl_link_tbox = document.getElementById('onl_link_tbox');
            var onl_link_pw_tbox = document.getElementById('onl_link_pw_tbox');

            if (aptment == 'online') {
                onl_link_tbox.style.display = "block";
                onl_link_pw_tbox.style.display = "block";
            } else {
                onl_link_tbox.style.display = "none";
                onl_link_pw_tbox.style.display = "none";
            }
        }
    </script>
    <script>
        $('.staff_reqts_add').on('click', e => {
            var bt = parseFloat($('.form-repeater_reqts').length);
            let $clone = $('.form-repeater_reqts').first().clone().hide();
            $clone.insertBefore('.form-repeater_reqts:first').slideDown();
            if (bt == 1) {
                $('.staff_reqts_del').attr('style', 'display: block !important');
            } else {
                $('.staff_reqts_del').attr('style', 'display: block !important');
            }
        });

        $(document).on('click', '.form-repeater_reqts .staff_reqts_del', e => {
            var bt = parseFloat($('.staff_reqts_del').length);
            // alert(bt);
            $(e.target).closest('.form-repeater_reqts').slideUp(400, function() {
                $(this).remove()
            });
            if (bt == 2) {
                $('.staff_reqts_del').attr('style', 'display: none !important');
            } else {}
        });
    </script>

    <script>
        const leadBoom = document.getElementById('leadBoom');

        setInterval(() => {
            leadBoom.classList.add('boom-animate');

            setTimeout(() => {
                leadBoom.classList.remove('boom-animate');
            }, 500);
        }, 2000);
    </script>
    <script>
        document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', function(event) {
                const tdy_flwup = document.getElementById("tdy_flwup");

                if (tdy_flwup.classList.contains('active')) {
                    document.getElementById("tdy_flwup_txt").setAttribute("style",
                        "Color:rgb(0, 0, 0) !important;");
                    tdy_flwup.setAttribute("style", "background-color: #faff00 !important;");
                } else {
                    document.getElementById("tdy_flwup_txt").setAttribute("style",
                        "Color:#4b4b4b !important;");
                    tdy_flwup.setAttribute("style", "background-color: #FCFF66 !important;");
                }
            });
        });
    </script>
    <script>
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>
    <script>
        function progress_func(prog_val) {

            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";

            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        $(".list_page_1").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
