@extends('layouts/layoutMaster')

@section('title', 'Create Work List')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
])
@endsection

@section('page-script')
@endsection
@section('content')

<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">View Work List</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Customer Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name">
                                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
                            </label>
                            <label class="fs-5 align-items-center text-black fw-semibold">
                                <span>Priya Dharshini</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div class="row">
                            <div class="col-lg-6 align-items-center">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment">
                                    <i class="mdi mdi-cash-clock fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-semibold">
                                    <span class="text-info">Partially Paid</span>
                                </label>
                            </div>
                            <div class="col-lg-6">
                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add On Services">
                                    <i class="mdi mdi-table-plus fs-3 text-black"></i>
                                </label>
                                <label class="fs-6 align-items-center text-black fw-semibold">
                                    <span class="badge bg-danger">Yes</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Category">
                                        <i class="mdi mdi-laptop fs-3 text-black"></i>
                                    </label>
                                    <label class="fs-6 align-items-center text-black fw-semibold">
                                        <span>Development Service</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="justify-content-start">
                                    <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Duration">
                                        <i class="mdi mdi-calendar-today-outline fs-3 text-black"></i>
                                    </label>
                                    <label class="badge bg-success fs-7 text-black fw-semibold">
                                        <span>15 - 20 Working Days</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-1">
                        <div class="justify-content-start">
                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Name">
                                <i class="mdi mdi-desktop-classic fs-3 text-black"></i>
                            </label>
                            <label class="fs-6 align-items-center text-black fw-semibold">
                                <span>Computer Science- BlockChain technology-ML/DL</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="row mt-4">
                <h5 class="fw-bold text-black">Service Check List</h5>
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-lg-12 mb-1">
                <div class="row mb-3">
                    <div class="col-lg-12">
                        <input type="text" class="form-control" id="" placeholder="Enter Work Check List" value="Title, Abstract 250 words" />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-12">
                        <input type="text" class="form-control" id="" placeholder="Enter Work Check List" value="Identify the aims and objectives of your research. The aims are the problems your project intends to solve." />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-12">
                        <input type="text" class="form-control" id="" placeholder="Enter Work Check List" value="solve a problem, current gap in knowledge, social or practical benefits" />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-12">
                        <input type="text" class="form-control" id="" placeholder="Enter Work Check List" value="Sample/Population, Methods ,Data Collection, Data Analysis, Ethical Considerations" />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-12">
                        <input type="text" class="form-control" id="" placeholder="Enter Work Check List" value="Analysis Result, Thesis" />
                    </div>
                </div>
            </div>
            <div class="col-lg-1 mb-1">
                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 service_butt_del_question" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="service_butt_del_question" style="display: none !important;">
                    <i class="mdi mdi-delete fs-4"></i>
                </a>
            </div>
            <!-- <div class="mb-1 mt-1">
                <button class="btn btn-primary service_butt_add_Question" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="service_butt_add_Question">
                    <i class="mdi mdi-plus me-1"></i>
                </button>
            </div> -->
        </div>
        <!-- <div class="d-flex justify-content-end align-items-center mt-4">
            <a href="{{url('/manage_customer')}}" class="btn btn-secondary me-3">Cancel</a>
            <a href="{{url('/manage_customer')}}" class="btn btn-primary">Create Work List</a>
        </div> -->
    </div>
</div>

<script>
    $(".list_page").DataTable({

        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +

            "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>"

    });
</script>
<script>
    function Question_func() {
        var question_cat = document.getElementById("question_cat").value;
        var service_check_box = document.getElementById("service_check_box");
        var service_radio_button = document.getElementById("service_radio_button");
        var service_list_box = document.getElementById("service_list_box");

        if (question_cat == "check_box") {
            service_check_box.style.display = "block";
            service_radio_button.style.display = "none";
            service_list_box.style.display = "none";
        } else if (question_cat == "radio_button") {
            service_check_box.style.display = "none";
            service_radio_button.style.display = "block";
            service_list_box.style.display = "none";
        } else if (question_cat == "list_box") {
            service_check_box.style.display = "none";
            service_radio_button.style.display = "none";
            service_list_box.style.display = "block";
        } else {
            service_check_box.style.display = "none";
            service_radio_button.style.display = "none";
            service_list_box.style.display = "none";
        }
    }
</script>
<script>
    $('.service_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_service').length);
        let $clone = $('.form-repeater_service').first().clone().hide();
        $clone.insertBefore('.form-repeater_service:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service .service_butt_del', e => {
        var bt = parseFloat($('.service_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_butt_add_radio').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_radio').length);
        let $clone = $('.form-repeater_service_radio').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_radio:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_radio').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_radio').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_radio .service_butt_del_radio', e => {
        var bt = parseFloat($('.service_butt_del_radio').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_radio').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_radio').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_butt_add_list').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_list').length);
        let $clone = $('.form-repeater_service_list').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_list:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_list').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_list').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_list .service_butt_del_list', e => {
        var bt = parseFloat($('.service_butt_del_list').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_list').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_list').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_question').length);
        let $clone = $('.form-repeater_service_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_question:first').slideDown();
        if (bt == 1) {
            $('.service_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.service_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_question .service_butt_del_question', e => {
        var bt = parseFloat($('.service_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    function Question_opt_func() {
        var question_opt = document.getElementById("question_opt").value;
        var service_opt_check_box = document.getElementById("service_opt_check_box");
        var service_opt_radio_button = document.getElementById("service_opt_radio_button");
        var service_opt_list_box = document.getElementById("service_opt_list_box");

        if (question_opt == "check_box") {
            service_opt_check_box.style.display = "block";
            service_opt_radio_button.style.display = "none";
            service_opt_list_box.style.display = "none";
        } else if (question_opt == "radio_button") {
            service_opt_check_box.style.display = "none";
            service_opt_radio_button.style.display = "block";
            service_opt_list_box.style.display = "none";
        } else if (question_opt == "list_box") {
            service_opt_check_box.style.display = "none";
            service_opt_radio_button.style.display = "none";
            service_opt_list_box.style.display = "block";
        } else {
            service_opt_check_box.style.display = "none";
            service_opt_radio_button.style.display = "none";
            service_opt_list_box.style.display = "none";
        }
    }
</script>
<script>
    $('.service_opt_butt_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_opt').length);
        let $clone = $('.form-repeater_service_opt').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_opt:first').slideDown();
        if (bt == 1) {
            $('.service_opt_butt_del').attr('style', 'display: block !important');
        } else {
            $('.service_opt_butt_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_opt .service_opt_butt_del', e => {
        var bt = parseFloat($('.service_opt_butt_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_opt').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_opt_butt_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_opt_butt_add_radio').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_opt_radio').length);
        let $clone = $('.form-repeater_service_opt_radio').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_opt_radio:first').slideDown();
        if (bt == 1) {
            $('.service_opt_butt_del_radio').attr('style', 'display: block !important');
        } else {
            $('.service_opt_butt_del_radio').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_opt_radio .service_opt_butt_del_radio', e => {
        var bt = parseFloat($('.service_opt_butt_del_radio').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_opt_radio').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_opt_butt_del_radio').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_opt_butt_add_list').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_opt_list').length);
        let $clone = $('.form-repeater_service_opt_list').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_opt_list:first').slideDown();
        if (bt == 1) {
            $('.service_opt_butt_del_list').attr('style', 'display: block !important');
        } else {
            $('.service_opt_butt_del_list').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_opt_list .service_opt_butt_del_list', e => {
        var bt = parseFloat($('.service_opt_butt_del_list').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_opt_list').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_opt_butt_del_list').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    $('.service_opt_butt_add_Question').on('click', e => {
        var bt = parseFloat($('.form-repeater_service_opt_question').length);
        let $clone = $('.form-repeater_service_opt_question').first().clone().hide();
        $clone.insertBefore('.form-repeater_service_opt_question:first').slideDown();
        if (bt == 1) {
            $('.service_opt_butt_del_question').attr('style', 'display: block !important');
        } else {
            $('.service_opt_butt_del_question').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_service_opt_question .service_opt_butt_del_question', e => {
        var bt = parseFloat($('.service_opt_butt_del_question').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_service_opt_question').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.service_opt_butt_del_question').attr('style', 'display: none !important');
        } else {}
    });
</script>

@endsection