@extends('layouts/layoutMaster')

@section('title', 'Manage Lead')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 9999;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
        
    <div class="card card-action">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a   href="{{url('/raw_lead')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 active">
                                        <img src="{{ asset('assets/phdizone_images/lead/raw_lead.ico') }}"
                                            alt="Raw Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Raw Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalLeadCount) }}</span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_lead_bank"
                                        aria-controls="tab_lead_bank" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_bank.ico') }}"
                                            alt="Lead Bank Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead Bank</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">01</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/manage_lead')}}"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"manage_lead>
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_icn.ico') }}" alt="Lead Icon"
                                            class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">02</span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_spam_lead"
                                        aria-controls="tab_spam_lead" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}"
                                            alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Spam Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">03</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_dead_lead"
                                        aria-controls="tab_dead_lead" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}"
                                            alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Dead Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">04</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        role="tab" data-bs-toggle="tab" data-bs-target="#tab_internal_calls"
                                        aria-controls="tab_internal_calls" aria-selected="true">
                                        <img src="{{ asset('assets/phdizone_images/lead/internal_call.ico') }}"
                                            alt="Internal Calls Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Internal Calls</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">01</span>
                                    </button>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <button type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        style="background-color: #FCFF66 !important;" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#tab_today_followup" aria-controls="tab_today_followup"
                                        aria-selected="true" id="tdy_flwup">
                                        <img src="{{ asset('assets/phdizone_images/lead/today_followup.ico') }}"
                                            alt="Today Followup Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2" id="tdy_flwup_txt">Today Followup</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">02</span>
                                    </button>
                                </li>
                            </div>
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade show active" id="tab_raw_lead" role="tabpanel">
                                <div class="d-flex justify-content-between align-items-center flex-wrap my-1">
                                    <div class="text-center border border-gray-500 rounded px-3 py-1">
                                        <div class="text-black fs-6 fw-semibold mb-1">Total Leads Upto <span
                                                class="text-info">( <?php echo date('M-Y'); ?> )</span></div>
                                        <div class="text-dark fs-2 fw-bold mb-1"> {{ sprintf('%02d', $totalLeadCount) }}</div>
                                    </div>
                                    <div class="mb-0">
                                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2"
                                        data-bs-toggle="modal" data-bs-target="#kt_modal_lead_import" title="Import">
                                            <span class="me-1"><i
                                                    class="mdi mdi-calendar-import-outline fs-5"></i></span> Import
                                        </a>
                                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2">
                                            <span class="me-1"><i class="mdi mdi-transfer fs-5"></i></span> Bulk
                                            Conversion
                                        </a>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row mb-4">
                                        @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                        <div class="col-lg-2">
                                            <span>Show</span>
                                            <br>
                                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                                @php
                                                $options = [10, 25, 100, 500]; // Define available options
                                                @endphp
                                                @php foreach ($options as $option): @endphp
                                                <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                    @php echo $option; @endphp
                                                </option>
                                                @php endforeach; @endphp
                                            </select>
                                        </div>
                                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                            <form id="search_form" method="POST" action="/raw_lead">
                                                @csrf
                                              <div class="d-flex align-items-center gap-2 mt-2">
                                                <div>
                                                  <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                                  <input type="hidden" name="filter_on" value="1">
                                                  <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                                  <input
                                                    type="text"
                                                    class="form-control"
                                                    id="lead_grp_fill" name="lead_grp_fill" value="{{ $lead_grp_fill ?? "" }}"
                                                    placeholder="Enter Lead - Name/ Date/ Lead group"
                                                  />
                                                </div>
                                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                                              </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <input type="hidden" id="view_edit_id" />
                                        <form id="bulk_request_pay_form" method="POST">
                                            @csrf
                                            <input type="hidden" name="bulk_lead_source_id" id="bulk_lead_source_id">
                                            <input type="hidden" name="bulk_assign_staff_id" id="bulk_assign_staff_id">
                                            <table
                                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                                <thead>
                                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                        <th class="min-w-25px">
                                                            <input class="form-check-input border border-gray-300 me-1"
                                                                type="checkbox" name="all" id="bulk_checkall">
                                                            <span class="fs-7">All</span>
                                                        </th>
                                                        <th class="min-w-100px">Lead</th>
                                                        <th class="min-w-100px">Mobile</th>
                                                        <th class="min-w-80px">Lead Group </th>
                                                        <th class="min-w-80px">Lead Source </th>
                                                        <th class="min-w-50px">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="text-gray-600 fw-semibold fs-7">
                                                    @if (isset($rawLeads))
                                                        @foreach ($rawLeads as $i=> $category)
                                                            <tr>
                                                                <td>
                                                                    @if (!$category->mobile_exists)
                                                                        <input class="form-check-input bulk_chk" type="checkbox" id="checked{{ $i }}" name="checked[{{ $i }}]" value="{{ $category->sno }}">
                                                                    @endif
                                                                </td>            
                                                                <td>
                                                                    <div class="mb-0 align-items-center">
                                                                        <label>
                                                                            <span class="fs-7 me-2">{{ $category->lead_name }}</span>
                                                                            <div class="d-block text-dark fs-8" title="Registered Date">{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) :''}}</div>
                                                                        </label>
                                                                        
                                                                    </div>
                                                                </td>
                                                                <td class="text-start">
                                                                    <div class="mb-0 align-items-center">
                                                                        <label>
                                                                            <span title="Mobile No" class="fw-bold">{{ $category->lead_mobile }}</span><br/>
                                                                            <span class="badge fw-semibold fs-8 rounded-pill badge mt-2 {{ $category->mobile_exists ? 'bg-danger' : 'bg-success' }}">
                                                                            {{ $category->mobile_exists ? 'Exists' : 'New' }}</span>
                                                                        </label>
                                                                        
                                                                    </div>
                                                                </td>   
                                                                <td>
                                                                    <label title="Lead Type">{{ $category->lead_group ?? '-'}}</label>
                                                                </td>
                                                                <td>
                                                                    <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">{{ $category->lead_source_name }}</label>
                                                                </td>
                                                                <td>
                                                                    <span class="text-end">
                                                                        <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                                        </a>
                                                                        <div class="dropdown-menu dropdown-menu-end">
                                                                            @if (!$category->mobile_exists)
                                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_convert_raw_to_lead" onclick="confirmConvertRawtoLead('{{ $category->sno }}', '{{ $category->lead_name }}','{{ $category->lead_mobile }}')" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Convert">
                                                                                <i class="mdi mdi-account-arrow-right fs-3 text-black"></i> Convert Lead
                                                                            </a>
                                                                            @endif
                                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_raw_lead_spam" onclick="confirmSpamLead('{{ $category->sno }}', '{{ $category->lead_name }}')" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Spam Lead">
                                                                                <i class="mdi mdi-account-alert fs-3 text-black"></i> Spam Lead
                                                                            </a>
                                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_raw_lead_drop" onclick="confirmDropLead('{{ $category->sno }}', '{{ $category->lead_name }}')" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Convert">
                                                                               <i class="mdi mdi-account-remove fs-3 text-black"></i> Dead Lead
                                                                            </a>
                                                                            @if (!$category->mobile_exists)
                                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_convert_raw_to_bank" onclick="confirmLeadBank('{{ $category->sno }}', '{{ $category->lead_name }}')" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Convert">
                                                                                <i class="mdi mdi-bank-transfer-in fs-3 text-black"></i> Lead Bank
                                                                            </a>
                                                                            @endif
                                                                        </div>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    @endif
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                    <div class="mt-4">
                                        {{ $rawLeads->appends(request()->except(['page', '_token']))->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!--begin::Modal - Import Lead-->
    <div class="modal fade" id="kt_modal_lead_import" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Import Lead</h3>
                    </div>
                    <div class="text-end">
                        <span>
                            <label>Sample Download For Lead Import</label>
                            <a href="javascript:;" download="Lead Data"  class="hover-warning cursor-pointer" title="Click To Download" id="sample_excel">
                                <i class="mb-1 mdi mdi-download-circle fs-3 text-danger" title="Click Here to Download"></i>
                            </a>
                        </span>
                    </div>
                    <form id="leadImportForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                        @csrf <!-- Include CSRF token for security -->
                        <div class="row">
                            <!--<div class="col-lg-6 mb-1">-->
                            <!--    <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>-->
                            <!--    <select id="lead_type_import" name="lead_type_id"  class="select3 form-select" data-placeholder="Select Lead Type">-->
                            <!--        <option value="">Select Lead Type</option>-->
                            <!--    </select>-->
                            <!--</div>-->
                            <div class="col-lg-6 mb-1">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Group<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lead_group" name="lead_group" placeholder="Enter Lead Group" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" required/>
                            </div>

                            <div class="col-lg-6 mb-1">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
                                <select id="lead_source_import" name="lead_source_id" class="select3 form-select" required>
                                    <option value="">Select Lead Source</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div id="dropArea" class="border border-4 border-dashed p-5 text-center rounded">
                                <p class="mb-2">Drag & Drop your (.xls) files here or click to select</p>
                                <input
                                    type="file"
                                    id="fileInput"
                                    name="file_import"
                                    class="d-none"
                                    accept=".xls" required
                                />
                                <button
                                    type="button"
                                    class="btn btn-outline-primary"
                                    onclick="document.getElementById('fileInput').click()"
                                >
                                    Browse (.xls) Files
                                </button>
                            </div>
                              <div id="fileList" class="text-muted"></div>
                              <div class="text-danger" id="err_mssg"></div>
                            </div>
                        <div class="row">
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Import</button>
                            </div>
                        </div>

                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Import Lead-->

    <!--begin::Modal - Import Raw Lead-->
    <div class="modal fade" id="kt_modal_raw_lead_import" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-1 text-black">Import Raw Lead</h3>
                    </div>
                    <div class="text-end">
                        <a href="{{ asset('assets/phdizone_images/lead_sample_import.xlsx') }}" download>
                            <span>Sample Download For Lead Import</span>
                            <span><i class="mb-1 mdi mdi-download-circle fs-3 text-danger"
                                    title="Click Here to Download"></i></span>
                        </a>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Group<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Group" />
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Source</option>
                                <option value="1">Whatsapp</option>
                                <option value="2">Facebook</option>
                                <option value="3">Google Business</option>
                                <option value="4">Reference</option>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <form action="/upload" class="dropzone needsclick" id="dropzone-basic">
                                <div class="dz-message needsclick justify-content-center align-items-center">
                                    <span class="note needsclick">
                                        <h4>Click Here To Upload The Lead Data</h4>
                                    </span>
                                </div>
                                <div class="d-block text-muted fs-6">
                                    Max File Size(5 MB)
                                </div>
                                <div class="fallback">
                                    <input name="file" type="file" accept=".xls" />
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Import</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Import Raw Lead-->

    <!-- start Bootstrap Modal for showing messages -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Import Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="modalMessageContent" class="alert" role="alert">
                        <!-- Dynamic content will be injected here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="closeModalButton" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end Bootstrap Modal for showing messages -->

     <!--begin::Modal - Customer Spam-->
     <div class="modal fade" id="kt_modal_raw_lead_spam" tabindex="-1" aria-hidden="true" aria-hidden="true"
     data-bs-keyboard="false" data-bs-backdrop="static">
     <!--begin::Modal dialog-->
         <div class="modal-dialog modal-m">
             <!--begin::Modal content-->
             <div class="modal-content rounded">
                 <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                     <div class="swal2-icon-content">?</div>
                 </div>
                 <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                     convert to Spam Lead?</div>
                 <div class="text-center">
                     <label class="text-danger fw-bold fs-5 raw-lead-name"></label>
                 </div>
                 <form id="drop_reason_form" method="POST" action="{{ url('/submit_raw_spam_reason') }}">
                     @csrf
                     <div class="d-block mx-4 my-4">
                         <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                 class="text-danger">*</span></label>
                         <select id="spam_reason_edit" name="spam_reason_edit" class="select3 form-select"
                             onchange="toggleInputField_spam(this.value)">
                             <option value="">Select Reason</option>
                             @if (isset($reasonList) && count($reasonList) > 0)
                             @foreach ($reasonList as $s_reason)
                             <option value="{{ $s_reason->reason_name }}"
                                 data-comments-check="{{ $s_reason->comments_check }}">
                                 {{ $s_reason->reason_name }}
                             </option>
                             @endforeach
                             @endif
                             <option value="1">Others</option>
                         </select>
                         <div class="text-danger" id="spam_reason_edit_select_err"></div>
                         <div class="mt-4" id="spam_reason_div" style="display: none;">
                             <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                     class="text-danger">*</span></label>
                             <input type="text" class="form-control" name="spam_reason_text" id="spam_reason_text"
                                 value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                         </div>
                         <div class="mt-4" id="spam_comments_div" style="display: none;">
                             <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                     class="text-danger">*</span></label>
                             <input type="text" class="form-control" name="spam_comments_text" id="spam_comments_text"
                                 value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                         </div>
                         <div class="text-danger" id="spam_reason_edit_err"></div>
                         <div class="text-danger" id="spam_comments_edit_err"></div>
                     </div>
                     <!-- Hidden field for lead ID -->
                     <input type="hidden" name="rawlead_id_spam" id="rawlead_id_spam">
                     <input type="hidden" name="rawlead_name_spam" id="rawlead_name_spam">
                     <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                         <button type="submit" class="btn btn-primary me-3">Yes</button>
                         <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                     </div>
                 </form>
             </div>
             <!--end::Modal content-->
         </div>
     <!--end::Modal dialog-->
 </div>
 <!--end::Modal - Customer Spam-->

 <!--begin::Modal -Lead Drop-->
 <div class="modal fade" id="kt_modal_raw_lead_drop" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
     data-bs-backdrop="static">
     <!--begin::Modal dialog-->
     <div class="modal-dialog modal-m">
         <!--begin::Modal content-->
         <div class="modal-content rounded">
             <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                 <div class="swal2-icon-content">?</div>
             </div>
             <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                 Convert to Dead Lead?</div>
             <div class="text-center">
                 <label class="text-danger fw-bold fs-5 lead-name"></label>
             </div>
             <form id="drop_reason_form" method="POST" action="{{ url('/raw_drop') }}">
                 @csrf
                 <div class="d-block mx-4 my-4">
                     <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                             class="text-danger">*</span></label>
                     <select id="reason_edit" name="reason_edit" class="select3 form-select"
                         onchange="toggleInputField(this.value)">
                         <option value="">Select Reason</option>
                         @if (isset($reasonList_drop) && count($reasonList_drop) > 0)
                         @foreach ($reasonList_drop as $d_reason)
                         <option value="{{ $d_reason->reason_name }}"
                             data-comments-check="{{ $d_reason->comments_check }}">
                             {{ $d_reason->reason_name }}
                             @endforeach
                             @endif
                         <option value="1">Others</option>
                     </select>
                     <div class="text-danger" id="reason_edit_select_err"></div>
                     <div class="mt-4" id="drop_reason_div" style="display: none;">
                         <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                 class="text-danger">*</span></label>
                         <input type="text" class="form-control" name="drop_reason_text" id="drop_reason_text"
                             value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                     </div>
                     <div class="text-danger" id="reason_edit_err"></div>
                     <div class="mt-4" id="drop_comments_div" style="display: none;">
                         <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                 class="text-danger">*</span></label>
                         <input type="text" class="form-control" name="drop_comments_text" id="drop_comments_text"
                             value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                     </div>
                     <div class="text-danger" id="drop_comments_edit_err"></div>
                 </div>
                 <!-- Hidden field for lead ID -->
                 <input type="hidden" name="rawlead_id_drop" id="rawlead_id_drop">
                 <input type="hidden" name="rawlead_name_drop" id="rawlead_name_drop">
                 <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                     <button type="submit" class="btn btn-primary me-3">Yes</button>
                     <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                 </div>
             </form>
         </div>
         <!--end::Modal content-->
     </div>
     <!--end::Modal dialog-->
 </div>
 <!--end::Modal - Lead Drop-->

 
  <!--begin::Modal - Customer Inactivate-->
 <div class="modal fade" id="kt_modal_convert_raw_to_bank" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
     <!--begin::Modal dialog-->
     <div class="modal-dialog modal-m">
         <!--begin::Modal content-->
         <div class="modal-content rounded">
             <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                 <div class="swal2-icon-content">?</div>
             </div>
             <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Move Raw Lead to Lead Bank?</div>
             <div class="text-center">
                 <label class="text-danger fw-bold fs-5 lead-name"></label>
             </div>
             <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                 <a href="/raw_lead" class="btn btn-primary me-3">
                     Yes
                 </a>
                 <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                 <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
             </div>
         </div>
         <!--end::Modal content-->
     </div>
     <!--end::Modal dialog-->
 </div>
 <!--end::Modal - Customer Inactivate-->
     <!--begin::Modal - Convert Raw Lead-->
     <div class="modal fade" id="kt_modal_convert_raw_to_lead" tabindex="-1" aria-hidden="true"   data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
             <div class="modal-content rounded p-2">
                    <h3 class="my-4 text-center fs-4 fw-bold text-danger">Convert To Lead</h3>

                    <div class="container" id="swal2-html-container" style="display: block;">
                      <div class="mb-4 fw-bold fs-6 text-center">
                        <span id="convert_message"></span>
                      </div>
                      <div class="row mb-4">
                        <div class="col-lg-6 ">
                          <label class="text-dark fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
                          <div>
                            <select id="lead_source_id_single_convert" name="lead_source_id_single_convert" class="select3 form-select">

                            </select>
                            <div class="text-danger mb-4 text-center" id="lead_source_id_single_convert_err"></div>
                          </div>
                        </div>

                        <div class="col-lg-6">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span class="text-danger">*</span></label>
                          <select id="assg_staff_add" name="assg_staff_add" class="select3 form-select">
                          </select>
                          <div class="text-danger" id="assg_staff_add_err"></div>
                        </div>

                      </div>
                    <div class="text-center">
                      <button type="submit" class="btn btn-danger me-3" onclick="convert_to_lead()">Yes,
                        Convert!</button>
                      <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                    </div>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Raw Lead-->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Blinking text animation */
        .blink {
            animation: blinker 1.5s linear infinite;
            /* font-weight: bold; */
            color: white; /* White text for better contrast */
        }

        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }

        /* Cute background and style for the 'New!' label */
        .new-label {
            background-color: #ff7eb9; /* Soft pink color */
            padding: 4px 8px;
            border-radius: 12px; /* Rounded corners */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
            font-size: 0.3rem; /* Slightly larger text */
            text-transform: uppercase;
            position: relative;
        }

        /* Adding a cute icon or star effect */
        .new-label::before {
            content: '✨'; /* You can replace this with any icon or emoji */
            position: absolute;
            top: -8px;
            right: -10px; /* Changed from left to right */
            font-size: 0.9rem;
            animation: bounce 2s infinite;
        }


        /* Bounce animation for cute effect */
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-8px);
            }
            60% {
                transform: translateY(-4px);
            }
        }
    </style>
    <style>
        #modalMessageContent {
            font-size: 1.2rem; /* Make font larger */
            padding: 10px; /* Add padding */
            border-radius: 5px; /* Rounded corners */
        }

        /* Example styles for success, warning, and error */
        .text-successs {
            background-color: #d4edda;
            color: #155724;
        }
        .text-dangers {
            background-color: #f8d7da;
            color: #721c24;
        }
        .text-warnings {
            background-color: #fff3cd;
            color: #856404;
        }
    </style>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
    <style>
        #dropArea {
            cursor: pointer;
        }
        #dropArea.bg-light {
            background-color: #f8f9fa;
        }
        #fileList p {
            margin: 0;
            font-size: 0.8rem;
        }
      </style>

<script>
    //raw lead to lead Conversion

function confirmConvertRawtoLead(id, name, mobile) { 
    // alert(id)
    $.ajax({
        url: '/check-mobile-exists',  // Adjust this URL if needed
        type: 'POST',
        data: { mobile: mobile },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') // Ensure CSRF token is included
        },
        success: function(response) {
            if (response.exists) {
                // If mobile exists, show warning and hide convert button
                $('#convert_message').html(
                    "<b class='text-danger'>This lead already exists!</b><br>Please check before converting."
                );
                $('.btn-danger').hide();
            } else {
                // Show confirmation message and enable convert button
                $('#convert_message').html(
                    "Are you sure you want to Convert <b class='text-danger'>" + name + "</b> Raw Lead?"
                );
                $('.btn-danger').show().attr('data-id', id);
            }
            $('#kt_modal_convert_raw_to_lead').modal('show');
        }
    });
}

function convert_to_lead() {
      var categoryId = document.querySelector('#kt_modal_convert_raw_to_lead .btn-danger').getAttribute('data-id');
      // Create a modal instance
    //   alert(categoryId);

      document.getElementById('lead_source_id_single_convert_err').innerHTML = '';
      document.getElementById('assg_staff_add_err').innerHTML = '';
      // alert(categoryId)
      var lead_source_conver=$('#lead_source_id_single_convert').val();
      var assign_staff_conver=$('#assg_staff_add').val() || 1;
        //  alert(lead_source_conver)

      var err =0;
      if(!lead_source_conver){
        document.getElementById('lead_source_id_single_convert_err').innerHTML = 'Lead Source is required...!';
        err++;

      }
      if(!assign_staff_conver){
        document.getElementById('assg_staff_add_err').innerHTML = 'Staff is required...!';
        err++;
      }
      if(err==0){
        $('#kt_modal_convert_raw_to_lead').modal('hide');
        var modalElement_con = document.getElementById('kt_modal_convert_raw_to_lead');
        var modal_con = new bootstrap.Modal(modalElement_con);
        fetch('/convert_raw_to_lead/' + categoryId, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
                lead_source_id: lead_source_conver,
                assg_staff_add: assign_staff_conver
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success(data.message);
                location.reload();
                // Pass the returned lead ID to the populateEditModal function
                if (data.data && data.data.lead_id) {                    
                    // $('#view_edit_id').val(data.data.lead_id);
                    // populateEditModal();
                    // Show the edit modal
                    // $('#kt_modal_edit_lead').modal('show');
                }
            } else {
                console.error(data.error_msg);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
      }

  }

</script>

<script>
    $(document).ready(function() {
       // for bulk conversion
      $.ajax({
           url: "{{ route('lead_source') }}",
           type: "GET",
           success: function(response) {
               if (response.status === 200 && response.data) {
                   // Populate the select dropdown with fetched course categories
                   var selectDropdown = $('select[name="bulk_lead_source_id_convert"]');
                   selectDropdown.empty();
                   selectDropdown.append($(
                       '<option value="">Select Lead source</option>'));
                   response.data.forEach(function(level) {
                       selectDropdown.append($('<option></option>').attr('value', level.sno)
                           .text(level.lead_source_name));
                   });
               }
           },
           error: function(error) {
               console.error('Error fetching course categories:', error);
           }
       });
      $.ajax({
           url: "{{ route('lead_source') }}",
           type: "GET",
           success: function(response) {
               if (response.status === 200 && response.data) {
                   // Populate the select dropdown with fetched course categories
                   var selectDropdown = $('select[name="lead_source_id_single_convert"]');
                   selectDropdown.empty();
                   selectDropdown.append($(
                       '<option value="">Select Lead source</option>'));
                   response.data.forEach(function(level) {
                       selectDropdown.append($('<option></option>').attr('value', level.sno)
                           .text(level.lead_source_name));
                   });
               }
           },
           error: function(error) {
               console.error('Error fetching course categories:', error);
           }
       });
   });
</script>
<script>
    function confirmSpamLead(id, leadName) {
        $('#kt_modal_raw_lead_spam').modal('show');
        $('#kt_modal_raw_lead_spam .raw-lead-name').text(leadName);

        $('#rawlead_id_spam').val(id);
        $('#rawlead_name_spam').val(leadName);

        $('#kt_modal_raw_lead_spam .btn-primary').off('click').on('click', function() {            
            // Validate the reason selection
            const reason = $('#spam_reason_edit').val();
            const otherReason = $('#spam_reason_text').val();
            const comments = $('#spam_comments_text').val();

            if (!reason) {
                $('#spam_reason_edit_select_err').text('Reason is Required');
                return false;
            }else {
                $('#spam_reason_edit_select_err').text('');
            }
            // Check if the selected reason's comments_check is 1 before validating comments
            const selectedReasonOption = $('#spam_reason_edit option:selected');
            const commentsCheck = selectedReasonOption.data('comments-check');

            if (commentsCheck == 1 && (!comments || comments.trim() === "")) {  
                $('#spam_comments_edit_err').text('Comments are required');
                return false;
            }else {
                $('#spam_comments_edit_err').text('');
            }

            if (reason == '1' && !otherReason.trim()) {
                $('#spam_reason_edit_err').text('Other Reason is required');
                return false;
            }else {
                $('#spam_reason_edit_err').text('');
            }
        });
    }

    function confirmDropLead(id, leadName) {
        $('#kt_modal_raw_lead_drop').modal('show');
        $('#kt_modal_raw_lead_drop .lead-name').text(leadName);

        $('#rawlead_id_drop').val(id);
        $('#rawlead_name_drop').val(leadName);

        $('#kt_modal_raw_lead_drop .btn-primary').off('click').on('click', function() {
            const reason = $('#reason_edit').val();
            const otherReason = $('#drop_reason_text').val();
            const comments = $('#drop_comments_text').val();

            if (!reason) {
                $('#reason_edit_select_err').text('Reason is Required');
                return false;
            }else {
                $('#reason_edit_select_err').text('');
            }
            // Check if the selected reason's comments_check is 1 before validating comments
            const selectedReasonOption = $('#reason_edit option:selected');
            const commentsCheck = selectedReasonOption.data('comments-check');

            if (commentsCheck == 1 && (!comments || comments.trim() === "")) {  
                $('#drop_comments_edit_err').text('Comments are required');
                return false;
            }else {
                $('#drop_comments_edit_err').text('');
            }

            if (reason == '1' && !otherReason.trim()) {
                $('#reason_edit_err').text('Other Reason is required');
                return false;
            }else {
                $('#reason_edit_err').text('');
            }
        });
    }

    function confirmLeadBank(id, leadName) {
        // alert(id, leadName);
        $('#kt_modal_convert_raw_to_bank').modal('show');
        $('#kt_modal_convert_raw_to_bank .lead-name').text(leadName);
        $('#kt_modal_convert_raw_to_bank .btn-primary').off('click').on('click', function() {
            // alert(id);
            rawLeadStatus(id, 7); 
        });
    }
    function rawLeadStatus(statusId, status) {
        // alert(statusId, status);
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        fetch(`/future_lead_status/${statusId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: JSON.stringify({
                status: status
            }),
        })
        .then(response => response.json())  // Parse the response as JSON
        .then(data => {
            console.log('Response:', data);  // Log the full response
            if (data.status === 200) {
                // alert(data.message);  // Show the success message
                // toastr.success(data.message);
                location.reload();
            } else {
                // alert('Error: ' + data.error_msg);  // Handle error message
                // toastr.error(data.error_msg);
            }
        })
        .catch(error => {
            console.error('Error:', error);  // Log any errors during the fetch
        });
    }

</script>

<script>
    function toggleInputField_spam(value) {
        var spamReasonDiv = document.getElementById('spam_reason_div');
        var spamReasonText = document.getElementById('spam_reason_text');
        var spamCommentsDiv = document.getElementById('spam_comments_div');
        var selectedOption = document.querySelector('#spam_reason_edit option:nth-child(' + (document.getElementById('spam_reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            spamReasonDiv.style.display = 'block';
            spamReasonText.setAttribute('required', 'required');
        } else {
            spamReasonDiv.style.display = 'none';
            spamReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            spamCommentsDiv.style.display = 'block';
        } else {
            spamCommentsDiv.style.display = 'none';
        }
    }
</script>

<script>
    function toggleInputField(value) {
        var dropReasonDiv = document.getElementById('drop_reason_div');
        var dropReasonText = document.getElementById('drop_reason_text');
        var dropCommentsDiv = document.getElementById('drop_comments_div');
        var selectedOption = document.querySelector('#reason_edit option:nth-child(' + (document.getElementById('reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            dropReasonDiv.style.display = 'block';
            dropReasonText.setAttribute('required', 'required');
        } else {
            dropReasonDiv.style.display = 'none';
            dropReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            dropCommentsDiv.style.display = 'block';
        } else {
            dropCommentsDiv.style.display = 'none';
        }
    }
</script>

<script>
    const dropArea = document.getElementById("dropArea");
    const fileInput = document.getElementById("fileInput");
    const fileList = document.getElementById("fileList");
  
    // Highlight drop area when dragging files
    dropArea.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropArea.classList.add("bg-light");
    });
  
    dropArea.addEventListener("dragleave", () => {
        dropArea.classList.remove("bg-light");
    });
  
    // Handle file drop
    dropArea.addEventListener("drop", (e) => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
  
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            displayFileNames(Array.from(e.dataTransfer.files));
        }
    });
  
    // Display selected file names
    fileInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
            displayFileNames(Array.from(e.target.files));
        }
    });
  
    function displayFileNames(files) {
        fileList.innerHTML = files
            .map((file, index) => `<span>${index + 1}. ${file.name} </span>`)
            .join("");
    }
  </script>
    <script>
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
<script>
    // Function to export table data to Excel
    function exportToExcel() {
        // Replace with your server endpoint for exporting to Excel
        let url = '/lead/export-excel';

        // Example AJAX call to trigger export
        $.ajax({
            url: url,
            type: 'GET',
            success: function(response) {
                // Handle success, such as downloading the file
                window.location.href = url; // Redirect to download link
            },
            error: function(xhr, status, error) {
                // Handle errors
                console.error('Error exporting to Excel:', error);
            }
        });
    }

    // Event listener for Excel export button
    $('#export_excel').on('click', function(e) {
        e.preventDefault();
        exportToExcel();
    });

    function sampleToExcel() {
        // Replace with your server endpoint for exporting to Excel
        let url = '/lead/sample-excel';

        // Example AJAX call to trigger export
        $.ajax({
            url: url,
            type: 'GET',
            success: function(response) {
                // Handle success, such as downloading the file
                window.location.href = url; // Redirect to download link
               
            },
            error: function(xhr, status, error) {
                // Handle errors
                console.error('Error exporting to Excel:', error);
            }
        });
        //  location.reload();
    }

    // Event listener for Excel export button
    $('#sample_excel').on('click', function(e) {
        // e.preventDefault();
        // alert('dgsdgsdgsd')
        sampleToExcel();
         setTimeout(function() {
            console.log('This message will appear after 2 seconds');
            // location.reload();
        }, 2000); // 2000 milliseconds = 2 seconds           
    });
    // Similarly, add event listeners for CSV and PDF exports
    // Example: $('#export_csv').on('click', function(e) { ... });
    // Example: $('#export_pdf').on('click', function(e) { ... });

</script>
<script>
    $(document).ready(function() {
        $.ajax({
            url: "{{ route('lead_source') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    // Populate the select dropdown with fetched course categories
                    var selectDropdown = $('select[name="lead_source_id"]');
                    selectDropdown.empty();
                    selectDropdown.append($(
                        '<option value="">Select Lead source</option>'));
                    response.data.forEach(function(level) {
                        selectDropdown.append($('<option></option>').attr('value', level.sno)
                            .text(level.lead_source_name));
                    });
                }
            },
            error: function(error) {
                console.error('Error fetching course categories:', error);
            }
        });
    });
</script>
<script>
    document.getElementById('leadImportForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        const form = event.target;
        const formData = new FormData(form);
        fetch('{{ route("lead_import") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
            },
            body: formData
        })
        .then(response => response.json()) // assuming the backend returns a JSON response
        .then(data => {
            // Handle success or error response
            let modalMessage = '';
            if (data.status === 'success') {
                modalMessage = `<span class="text-success">${data.message}</span>`;
            } else if (data.status === 'partial_success') {  // Handle partial success
                modalMessage = `<span class="text-warnings">${data.message}<br>${data.error_msg.join(', ')}</span>`; // Join error messages
            } else if (data.status === 'error') {  // Make sure to define error handling on the backend
                modalMessage = `<span class="text-dangers">${data.error_msg}</span>`;
            }

            // Set the modal message content
            document.getElementById('modalMessageContent').innerHTML = modalMessage;

            // Close the import modal in case of error as well
            var importModal = bootstrap.Modal.getInstance(document.getElementById('kt_modal_lead_import'));
            if (importModal) {
                importModal.hide();
            }
            // Show the message modal
            var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
            messageModal.show();

            // Reload the page after a short delay
            // setTimeout(() => {
            //     location.reload();
            // }, 8000); // 2-second delay to allow the user to read the message
        })
        .catch(error => {
            // Handle any errors
            console.error('Error:', error);
            document.getElementById('modalMessageContent').innerHTML = '<span class="text-danger">An error occurred while importing leads.</span>';

            // Close the import modal in case of error as well
            var importModal = bootstrap.Modal.getInstance(document.getElementById('kt_modal_lead_import'));
            if (importModal) {
                importModal.hide();
            }

            // Show the error message in the message modal
            var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
            messageModal.show();

            // Reload the page after a short delay
            // setTimeout(() => {
            //     location.reload();
            // }, 8000); // 2-second delay to allow the user to read the error message
        });
    });
    // Reload the page when the close button is clicked
    document.getElementById('closeModalButton').addEventListener('click', function() {
        location.reload(); // Reload the page when the close button is clicked
    });
</script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
      document.querySelector("form#leadDropzone").addEventListener("submit", function(e) {
          e.preventDefault();
          e.stopPropagation();

          let formData = new FormData(this);
          formData.append("_token", document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

          fetch("{{ route('lead_import') }}", {
              method: "POST",
              body: formData,
          })
          .then(response => response.json())
          .then(data => {
              if (data.status === 200) {
                  toastr.success(data.message); // Display success message
                  // setTimeout(() => {
                  //     window.location.reload(); // Refresh page to show success message
                  // }, 1500);
              } else {
                  // Handle error response
                  if (data.status === 401 || data.status === 400) {
                      if (data.error_msg) {
                          toastr.error(data.error_msg.join("<br>")); // Join and display validation errors
                      } else {
                          toastr.error(data.message); // General error message
                      }
                  } else {
                      toastr.error("An unexpected error occurred.");
                  }
              }
          })
          .catch(error => {
              toastr.error("An error occurred while processing the request: " + error.message);
          });
      });
  });
</script>
    <script>
    function sort_filter(val) {
        if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
        } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
        }
    }
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>
    <script>
        function progress_func(prog_val) {

            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";

            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        $(".list_page_1").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
