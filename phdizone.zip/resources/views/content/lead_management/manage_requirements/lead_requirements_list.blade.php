@extends('layouts/layoutMaster')

@section('title', 'Manage Lead Requirements')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('page-script')
@endsection
@section('content')

<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 7px !important;
    }
</style>

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Requirements</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Lead Managements</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 py-0">
        <div class="row mt-6">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <div class="row">
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Lead</th>
                                        <th class="min-w-100px">Service</th>
                                        <th class="min-w-50px text-center">Requirements</th>
                                        <th class="min-w-100px">Confirmed By</th>
                                        <th class="min-w-150px">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <label class="fs-7 me-2">Priya</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Register Date">07-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-wrap max-w-75" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Computer Science- BlockChain technology-ML/DL">Computer Science- BlockChain technology-ML/DL</div>
                                            <div class="d-block">
                                                <div class="text-wrap max-w-75 fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Development Services">Development Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download">
                                                <i class="mdi mdi-download-circle-outline fs-2 text-success"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="javascript:;" class="border border-gray-400 rounded px-1 py-2" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_confirmation">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Staff">
                                                    <i class="mdi mdi-account-plus fs-4 text-gray"></i>
                                                </span>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="javascript:;" class="badge text-black rounded fw-bold fs-8" style="background-color:#ffaa17;" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Waiting
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_req_app">Approved</a>
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_req_cancelled">Cancelled</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fs-7 text-black fw-semibold">Nandhini</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">05-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-wrap max-w-75" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Java Development">Java Development</div>
                                            <div class="d-block">
                                                <div class="text-wrap max-w-75 fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Development Services">Development Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download">
                                                <i class="mdi mdi-download-circle-outline fs-2 text-success"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div>
                                                <label class="badge bg-info text-white fw-bold">Developer</label>
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff"><i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i></span>
                                                </a>
                                            </div>
                                            <label class="text-black">Sabana Barveen</label>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-bold fs-8" style="background-color:#2C5530;">Approved</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fs-7 text-black fw-semibold">Praveen</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">03-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-wrap max-w-75" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                            <div class="d-block">
                                                <div class="text-wrap max-w-75 fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Services">Writing Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download">
                                                <i class="mdi mdi-download-circle-outline fs-2 text-success"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div>
                                                <label class="badge bg-info text-white fw-bold">Content Writer</label>
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff">
                                                        <i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i>
                                                    </span>
                                                </a>
                                            </div>
                                            <label class="text-black">Shyamala Devi</label>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-bold fs-8" style="background-color:#d22513;">Cancelled</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fs-7 text-black fw-semibold">Madhan</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">03-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-wrap max-w-75" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                            <div class="d-block">
                                                <div class="text-wrap max-w-75 fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Services">Writing Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download">
                                                <i class="mdi mdi-download-circle-outline fs-2 text-success"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div>
                                                <label class="badge bg-info text-white fw-bold">Developer</label>
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff">
                                                        <i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i>
                                                    </span>
                                                </a>
                                            </div>
                                            <label class="text-black">Vasanth Kumar</label>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-bold fs-8" style="background-color:#2C5530;">Approved</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Staff Confirmation-->
<div class="modal fade" id="kt_modal_staff_confirmation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Staff Confirmation</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role" name="job_role" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1">Developer</option>
                            <option value="2">Content Writer</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                        <select id="staff" name="staff" class="select3 form-select">
                            <option value="">Select Staff</option>
                            <option value="1">Sabana Barveen</option>
                            <option value="2">Alamelu Mangai</option>
                            <option value="3">Vasanth Kumar</option>
                            <option value="3">Shyamala Devi</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="/manage_requirements" class="btn btn-primary me-3">
                        Staff Confirmation
                    </a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Add Staff Confirmation- -->

<!--begin::Modal - Add Staff Confirmation-->
<div class="modal fade" id="kt_modal_edit_staff_confirmation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Staff Confirmation</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role_edit" name="job_role_edit" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1" selected>Developer</option>
                            <option value="2">Content Writer</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                        <select id="staff_edit" name="staff_edit" class="select3 form-select">
                            <option value="">Select Staff</option>
                            <option value="1" selected>Sabana Barveen</option>
                            <option value="2">Alamelu Mangai</option>
                            <option value="3">Vasanth Kumar</option>
                            <option value="3">Shyamala Devi</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="/manage_requirements" class="btn btn-primary me-3">
                        Update Staff Confirmation
                    </a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Add Staff Confirmation- -->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

@endsection