@extends('layouts/layoutMaster')

@section('title', 'Manage Proposal')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('page-script')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 8px !important;
    }
</style>
<!-- Proposal List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Proposal</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 py-0">
        <div class="row mt-6">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <!-- <div class="d-flex justify-content-end align-items-center flex-wrap">
                        <a href="{{url('/manage_proposal/proposal_add')}}" class="btn btn-sm fw-bold btn-primary me-2 mb-2">
                            <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Proposal
                        </a>
                    </div> -->
                    <div class="row">
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Proposal No</th>
                                        <th class="min-w-80px">Proposal Date</th>
                                        <th class="min-w-100px">Lead</th>
                                        <th class="min-w-50px">Proposal</th>
                                        <th class="min-w-80px">Amount</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7">PRO-003670/04/2025</label>
                                                <div class="d-block">
                                                    <span class="badge bg-warning text-black fw-bold">Invoice Generated</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal  Date">02-Apr-2025</label>
                                            <div class="d-block">
                                                <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Validity Date">07-Apr-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7">Priya</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">priya@gmail.com</label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">02</label>
                                        </td>
                                        <td align="right">
                                            <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 1,21,068</label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="dropdown-item">
                                                        <span><i class="mdi mdi-printer-pos-outline fs-4 text-black me-1"></i>Print</span>
                                                    </a>
                                                    <a href="{{url('/manage_proposal/proposal_view')}}" target="_blank" class="dropdown-item">
                                                        <span> <i class="mdi mdi-eye-outline fs-4 text-black me-1"></i>View</span>
                                                    </a>
                                                    <a href="{{url('/manage_proposal/proposal_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-4 text-black me-1"></i></span>Edit</a>
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fs-7">PRO-003669/03/2025</label>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal  Date">27-Mar-2025</label>
                                            <div class="d-block">
                                                <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">31-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7">Dharshini</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">dharshini@gmail.com</label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">02</label>
                                        </td>
                                        <td align="right">
                                            <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 69,000</label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="dropdown-item">
                                                        <span><i class="mdi mdi-printer-pos-outline fs-4 text-black me-1"></i>Print</span>
                                                    </a>
                                                    <a href="{{url('/manage_proposal/proposal_view')}}" target="_blank" class="dropdown-item">
                                                        <span> <i class="mdi mdi-eye-outline fs-4 text-black me-1"></i>View</span></a>
                                                    <a href="{{url('/manage_proposal/proposal_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-4 text-black me-1"></i></span>Edit</a>
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div>
                                                <label class="fs-7">PRO-003668/03/2025</label>
                                                <div class="d-block">
                                                    <span class="badge bg-warning text-black fw-bold">Invoice Generated</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal  Date">22-Jul-2024</label>
                                            <div class="d-block">
                                                <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">30-Jul-2024</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7">Praveen</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">praveen@gmail.com</label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="badge bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">01</label>
                                        </td>
                                        <td align="right">
                                            <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 80,254</label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="dropdown-item">
                                                        <span><i class="mdi mdi-printer-pos-outline fs-4 text-black me-1"></i>Print</span>
                                                    </a>
                                                    <a href="{{url('/manage_proposal/proposal_view')}}" target="_blank" class="dropdown-item">
                                                        <span> <i class="mdi mdi-eye-outline fs-4 text-black me-1"></i>View</span></a>
                                                    <a href="{{url('/manage_proposal/proposal_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-4 text-black me-1"></i></span>Edit</a>
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal - Proposal Chat-->
    <div class="modal fade" id="kt_modal_quotation_chat" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Send Proposal</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">From</label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter Email" value="presale@phdizone.com" />
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">To</label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter Email" value="priya@gmail.com" />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Subject</label>
                            <input type="text" class="form-control me-2" id="" placeholder="Enter Email" value="Proposal" />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Message</label>
                            <textarea class="form-control" rows="5" id="" placeholder="Enter Message">Thank you for your Project Assign, always a pleasure to work with you! We have generated a new Proposal in the amount of 80,0000</textarea>
                        </div>
                        <div class="mb-3">
                            <span class="badge bg-label-primary rounded-pill">
                                <i class="mdi mdi-link-variant mdi-14px me-1"></i>
                                <span class="align-middle">Proposal Attached</span>
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3 d-flex flex-wrap align-items-center grid gap-5">
                        <a href="#" class="mb-3" id="whatsapp" name="whatsapp" onclick="whatsapp_func();">
                            <label class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Whatsapp">
                                <span>
                                    <i class="mdi mdi-whatsapp text-success fs-2"></i>
                                </span>
                            </label>
                        </a>
                        <a href="#" class="mb-3" id="whatsapp_on" name="whatsapp_on" style="display: none !important;" onclick="whatsapp_func1();">
                            <label class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Whatsapp">
                                <i class="mdi mdi-whatsapp text-success fs-2"></i>
                                <span class="position-absolute top-0 start-100 translate-middle">
                                    <i class="mdi mdi-check-circle ms-1 mt-1 fs-4"></i>
                                </span>
                            </label>
                        </a>

                        <a href="#" class="mb-3" id="email" name="email" onclick="email_func();">
                            <label class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email">
                                <i class="mdi mdi-email-newsletter text-danger fs-2"></i>
                            </label>
                        </a>
                        <a href="#" class="mb-3" id="email_on" name="email_on" style="display: none !important;" onclick="email_func1();">
                            <label href="#" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email">
                                <i class="mdi mdi-email-newsletter text-danger fs-2"></i>
                                <span class="position-absolute top-0 start-100 translate-middle">
                                    <i class="mdi mdi-check-circle ms-1 mt-1 fs-4"></i>
                                </span>
                            </label>
                        </a>

                        <div class="mb-3" id="linked" name="linked" onclick="linked_func();">
                            <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Message">
                                <i class="mdi mdi-email-outline text-info fs-2"></i>
                            </a>
                        </div>
                        <div class="mb-3" id="linked_on" name="linked_on" style="display: none !important;" onclick="linked_func1();">
                            <a href="#" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Message">
                                <i class="mdi mdi-email-outline text-info fs-2"></i>
                                <span class="position-absolute top-0 start-100 translate-middle">
                                    <i class="mdi mdi-check-circle ms-1 mt-1 fs-4"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Send Proposal</button>
                    </div>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Proposal Chat-->

    <!--begin::Modal - Delete Proposal-->
    <div class="modal fade" id="kt_modal_delete_quotation" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                    delete Proposal ?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label>Priya Dharshini</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Proposal-->

    <script>
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>
    <script>
        function onlyOne(checkbox) {
            var checkboxes = document.getElementsByName('check')
            checkboxes.forEach((item) => {
                if (item !== checkbox) item.checked = false
            })
        }
    </script>
    <script>
        function whatsapp_func() {
            var whatsapp = document.getElementById("whatsapp");
            var whatsapp_on = document.getElementById("whatsapp_on");

            if (whatsapp.click) {
                whatsapp_on.style.display = "block";
                whatsapp.style.display = "none";

            } else {
                whatsapp_on.style.display = "none";
                whatsapp.style.display = "block";
            }
        }
    </script>

    <script>
        function whatsapp_func1() {
            var whatsapp = document.getElementById("whatsapp");
            var whatsapp_on = document.getElementById("whatsapp_on");

            if (whatsapp_on.click) {
                whatsapp.style.display = "block";
                whatsapp_on.style.display = "none";

            } else {
                whatsapp.style.display = "none";
                whatsapp_on.style.display = "block";
            }
        }
    </script>

    <script>
        function facebook_func() {
            var facebook = document.getElementById("facebook");
            var facebook_on = document.getElementById("facebook_on");

            if (facebook.click) {
                facebook_on.style.display = "block";
                facebook.style.display = "none";

            } else {
                facebook_on.style.display = "none";
                facebook.style.display = "block";
            }
        }
    </script>

    <script>
        function facebook_func1() {
            var facebook = document.getElementById("facebook");
            var facebook_on = document.getElementById("facebook_on");

            if (facebook_on.click) {
                facebook.style.display = "block";
                facebook_on.style.display = "none";

            } else {
                facebook.style.display = "none";
                facebook_on.style.display = "block";
            }
        }
    </script>

    <script>
        function email_func() {
            var email = document.getElementById("email");
            var email_on = document.getElementById("email_on");

            if (email.click) {
                email_on.style.display = "block";
                email.style.display = "none";

            } else {
                email_on.style.display = "none";
                email.style.display = "block";
            }
        }
    </script>

    <script>
        function email_func1() {
            var email = document.getElementById("email");
            var email_on = document.getElementById("email_on");

            if (email_on.click) {
                email.style.display = "block";
                email_on.style.display = "none";

            } else {
                email.style.display = "none";
                email_on.style.display = "block";
            }
        }
    </script>

    <script>
        function insta_func() {
            var insta = document.getElementById("insta");
            var insta_on = document.getElementById("insta_on");

            if (insta.click) {
                insta_on.style.display = "block";
                insta.style.display = "none";

            } else {
                insta_on.style.display = "none";
                insta.style.display = "block";
            }
        }
    </script>

    <script>
        function insta_func1() {
            var insta = document.getElementById("insta");
            var insta_on = document.getElementById("insta_on");

            if (insta_on.click) {
                insta.style.display = "block";
                insta_on.style.display = "none";

            } else {
                insta.style.display = "none";
                insta_on.style.display = "block";
            }
        }
    </script>
    <script>
        function pinin_func() {
            var pinin = document.getElementById("pinin");
            var pinin_on = document.getElementById("pinin_on");

            if (pinin.click) {
                pinin_on.style.display = "block";
                pinin.style.display = "none";

            } else {
                pinin_on.style.display = "none";
                pinin.style.display = "block";
            }
        }
    </script>

    <script>
        function pinin_func1() {
            var pinin = document.getElementById("pinin");
            var pinin_on = document.getElementById("pinin_on");

            if (pinin_on.click) {
                pinin.style.display = "block";
                pinin_on.style.display = "none";

            } else {
                pinin.style.display = "none";
                pinin_on.style.display = "block";
            }
        }
    </script>
    <script>
        function linked_func() {
            var linked = document.getElementById("linked");
            var linked_on = document.getElementById("linked_on");

            if (linked.click) {
                linked_on.style.display = "block";
                linked.style.display = "none";

            } else {
                linked_on.style.display = "none";
                linked.style.display = "block";
            }
        }
    </script>

    <script>
        function linked_func1() {
            var linked = document.getElementById("linked");
            var linked_on = document.getElementById("linked_on");

            if (linked_on.click) {
                linked.style.display = "block";
                linked_on.style.display = "none";

            } else {
                linked.style.display = "none";
                linked_on.style.display = "block";
            }
        }
    </script>
    <script>
        function yes_func() {
            var prog_yes = document.getElementById("prog_yes");
            var message = document.getElementById("message");
            var reason = document.getElementById("reason");

            if (prog_yes.click) {
                message.style.display = "block";
                reason.style.display = "none";

            } else {
                message.style.display = "none";
                // linked_on.style.display = "block";
            }
        }
    </script>
    <script>
        function no_func() {
            var prog_no = document.getElementById("prog_no");
            var reason = document.getElementById("reason");

            if (prog_no.click) {
                reason.style.display = "block";
                message.style.display = "none";

            } else {
                reason.style.display = "none";
                // linked_on.style.display = "block";
            }
        }
    </script>

    <script>
        let logofile = document.getElementById('lead_image');
        const fileInput = document.querySelector('.upload-in'),
            resetFileInput = document.querySelector('.currency_reset');

        if (logofile) {
            const resetImage = logofile.src;
            fileInput.onchange = () => {
                if (fileInput.files[0]) {
                    logofile.src = window.URL.createObjectURL(fileInput.files[0]);
                }
            };
            resetFileInput.onclick = () => {
                fileInput.value = '';
                logofile.src = resetImage;
            };
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    <script>
        let lead_image_edit = document.getElementById('lead_image_edit');
        const lead_image_edit_fileInput = document.querySelector('.lead_image_edit_cls'),
            lead_image_edit_resetFileInput = document.querySelector('.lead_image_edit-reset');

        if (lead_image_edit) {
            const fav_resetImage = lead_image_edit.src;
            lead_image_edit_fileInput.onchange = () => {
                if (lead_image_edit_fileInput.files[0]) {
                    lead_image_edit.src = window.URL.createObjectURL(lead_image_edit_fileInput.files[0]);
                }
            };
            lead_image_edit_resetFileInput.onclick = () => {
                lead_image_edit_fileInput.value = '';
                lead_image_edit.src = fav_resetImage;
            };
        }
    </script>

    <script>
        $(".list_page_1").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    @endsection