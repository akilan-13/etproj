@extends('layouts/blankLayout')

@section('title', 'Print Estimation')
@section('content')

<style>
    /* page[size="A4"] {
        width: 210mm !important;
        height: 297mm !important;
        box-sizing: border-box;
        margin: 0 auto;
        margin-bottom: 0.5cm;
    } */

    @media print {
        /* @page {
            margin-top: 10px;
        } */

        body {
            background-color: white !important;
            margin: 0px !important;
            padding: 0px !important;
            page-break-before: auto;
            /* padding-top: 100px !important; */
        }

        /* .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            z-index: 1000;
        } */

        .print-container::before {
            content: "";
            display: block;
            height: 150px;
        }

        .start_cont {
            background: none !important;
            /* padding-top: 180px; */
            /* counter-reset: page; */
        }

        .page-break {
            page-break-before: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            /* overflow-x: visible !important; */
        }

        th,
        tr,
        td {
            border: 1px solid #ddd;
            padding: 5px;
            break-inside: avoid !important;
        }

    }

    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }
</style>
<center>
    <div style="width: 210mm !important;height: 297mm !important;">
        <div class="header">
            <div style="font-size:30px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:30px;">
                <label>Estimation &nbsp;-&nbsp;</label>
                <label>02</label>
            </div>
            <div style='display:flex;align-items:start !important;margin-left:10px;margin-right:10px;padding-top:10px;'>
                <div style="width:100% !important;margin-left: 10px !important;margin-right: 10px !important;">
                    <table style='width:100% !important;'>
                        <thead>
                            <tr>
                                <th rowspan="2" style="width: 25% !important;">
                                    <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" style="height: 80px;width: 180px;">
                                </th>
                                <th style="text-align: center; width: 75% !important;" colspan="3">
                                    <label style="font-size:16px;font-weight:700;margin-left:50px;color:black;"># PRO-003669/03/2025</label>
                                </th>
                            </tr>
                            <tr>
                                <th style="text-align: center !important;width: 20% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Estimated Date</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:black;">19-Sep-2024</label>
                                    </div>
                                </th>
                                <th style="text-align: center !important;width: 20% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Validity Date</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:red;">24-Sep-2024</label>
                                    </div>
                                </th>
                                <th style="text-align: center !important;width: 60% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Sale Agent</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:black;">Ananya D</label>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <div class="start_cont" style='text-align:left;display:flex; margin-top:10px;margin-left:20px;margin-right:20px;'>
            <div style="width: 50%; border: 1px solid #ccc; border-radius: 4px; padding: 20px;margin-right:30px;background-color:#e0f3f9;">
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Proposal By</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:600;color:black;">PhDiZone</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Church Road , Annanagar</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Madurai, Tamilnadu, India</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">presale@phdizone.com</label>
                </div>
                <div style="margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%;">
                        9944049888</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">GST Number</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">33AACCE2334E1ZA</label>
                </div>
            </div>
            <div style="width: 50%; border: 1px solid #ccc; border-radius: 4px; padding: 20px;background-color:#e0f3f9;">
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Proposal To</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Priya</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">1, Bharathiyar Street, Avaniyapuram</label>
                </div>
                <div style=" margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Madurai ,Tamilnadu, India</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">priya@gmail.com</label>
                </div>
                <div style="margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">
                        9876543210</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Currency Format</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">INR</label>
                </div>
            </div>
        </div>
        <div style="font-size:20px; font-weight:bold;color:black;margin-top:20px;text-align:left;margin-left:20px;margin-right:20px;">
            <label>Service Details</label>
        </div>
        <div style="margin-left:20px;margin-right:20px;margin-top:10px;">
            <table style="width:100%;border-collapse:collapse;border: 1px solid #ddd;padding:30px;">
                <thead style="font-weight:bold; font-size:16px;background-color:#1397c7;color:white;vertical-align:top !important;">
                    <tr>
                        <th style="width:5%">S.No</th>
                        <th style="width:60%">Work</th>
                        <th style="width:5%">Qty</th>
                        <th style="width:15%">Rate</th>
                        <th style="width:15%">Amount</th>
                    </tr>
                </thead>
                <tbody style="vertical-align:top !important;">
                    <tr style="color:black">
                        <td style="text-align:center;">
                            <div>1</div>
                        </td>
                        <td>
                            <div>
                                <label>
                                    <div style="font-weight:bold">Writing Services</div>
                                    <div style="font-weight:600">Thesis Writing</div>
                                    <div style="font-weight:500">Scopue Q1/Q2 Research Paper
                                        <label>(&#8377; 50,000)</label>
                                    </div>
                                    <label style="font-weight:bold;margin-top:10px;">Add On Services</label>
                                    <div>
                                        <div>Literature Writing
                                            <label>(&#8377; 1,000)</label>
                                        </div>
                                        <div>Plagiarism Checking
                                            <label>(&#8377; 1,000)</label>
                                        </div>
                                        <div>Grammer Checking
                                            <label></label>
                                        </div>
                                        <div>Proof Reading
                                            <label></label>
                                        </div>
                                    </div>
                                    <div style="font-weight:bold;margin-top:10px;">Deliverables</div>
                                    <div style="display:block;">
                                        <span style="display:block;"></span>
                                        <span>
                                            1.Technical discussion<br>
                                            2.Flow of the work (Novelty and Data Set)<br>
                                            3.Source Code<br>
                                            4.Pseudo Code<br>
                                            5.Demo through Running video<br>
                                            6.Results As per client specification-As per the Description<br>
                                            7.Software Installation<br>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </td>
                        <td style="text-align:center;">
                            <div>1</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 52,000</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 52,000</div>
                        </td>
                    </tr>
                    <tr style="color:black;">
                        <td style="text-align:center;">
                            <div>2</div>
                        </td>
                        <td>
                            <div>
                                <label>
                                    <div style="font-weight:bold">Development Services</div>
                                    <div style="font-weight:600">Python Development</div>
                                    <div style="font-weight:500">Computer Science-
                                        BlockChain technology-ML/DL
                                        <label>(&#8377; 60,000)</label>
                                    </div>
                                    <label style="font-weight:bold;margin-top:10px;">Add On Services</label>
                                    <div>
                                        <div>Literature Writing
                                            <label>(&#8377; 1,000)</label>
                                        </div>
                                        <div>Plagiarism Checking
                                            <label>(&#8377; 1,000)</label>
                                        </div>
                                        <div>Grammer Checking
                                            <label></label>
                                        </div>
                                        <div>Proof Reading
                                            <label></label>
                                        </div>
                                    </div>
                                    <div style="font-weight:bold;margin-top:10px;">Deliverables</div>
                                    <div style="display:block;">
                                        <span style="display:block;"></span>
                                        <span>
                                            1.Technical discussion<br>
                                            2.Flow of the work (Novelty and Data Set)<br>
                                            3.Source Code<br>
                                            4.Pseudo Code<br>
                                            5.Demo through Running video<br>
                                            6.Results As per client specification-As per the Description<br>
                                            7.Software Installation<br>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </td>
                        <td style="text-align:center;">
                            <div>1</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 62,000</div>
                        </td>
                        <td align="right">
                            <div>&#8377; 62,000</div>
                        </td>
                    </tr>
                    <!-- <tr style="color:black;">
                        <td style="text-align:center;">
                            <div class="print-container">2</div>
                        </td>
                        <td>
                            <div class="print-container">
                                <label>
                                    <div style="font-weight:bold">Development Services</div>
                                    <div style="font-weight:600">Python Development</div>
                                    <div style="font-weight:500">Computer Science-
                                        BlockChain technology-ML/DL
                                        <label>(&#8377; 60,000)</label>
                                    </div>
                                    <label style="font-weight:bold;margin-top:10px;">Add On Services</label>
                                    <div>
                                        <div>Literature Writing
                                            <label>(&#8377; 1,000)</label>
                                        </div>
                                        <div>Plagiarism Checking
                                            <label>(&#8377; 1,000)</label>
                                        </div>
                                        <div>Grammer Checking
                                            <label></label>
                                        </div>
                                        <div>Proof Reading
                                            <label></label>
                                        </div>
                                    </div>
                                    <div style="font-weight:bold;margin-top:10px;">Deliverables</div>
                                    <div style="display:block;">
                                        <span style="display:block;"></span>
                                        <span>
                                            1.Technical discussion<br>
                                            2.Flow of the work (Novelty and Data Set)<br>
                                            3.Source Code<br>
                                            4.Pseudo Code<br>
                                            5.Demo through Running video<br>
                                            6.Results As per client specification-As per the Description<br>
                                            7.Software Installation<br>
                                        </span>
                                    </div>
                                </label>
                            </div>
                        </td>
                        <td style="text-align:center;">
                            <div class="print-container">1</div>
                        </td>
                        <td align="right">
                            <div class="print-container">&#8377; 62,000</div>
                        </td>
                        <td align="right">
                            <div class="print-container">&#8377; 62,000</div>
                        </td>
                    </tr> -->
                </tbody>
                <tfoot>
                    <thead>
                        <tr>
                            <th colspan="4" style="font-size:16px;color:black;text-align:end;font-weight:600;">Sub Total</th>
                            <th style="font-size:16px;color:black;text-align:end;font-weight:600;">&#8377; 1,14,000</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">Discount (10%)</th>
                            <th style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">&#8377; 11,400</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">GST (18%)</th>
                            <th style="font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">&#8377; 18,468</th>
                        </tr>
                        <tr>
                            <th colspan="4" style="font-size:19px;color:black;text-align:end;font-weight:600;">Grand Total</th>
                            <th style="font-size:19px;color:black;text-align:end;font-weight:600;">&#8377; 1,21,068</th>
                        </tr>
                        <tr>
                            <th colspan="5" style="font-size:14px;color:#2c2c2c;text-align:start;font-weight:600;">
                                <label>Amount In Words &nbsp;:&nbsp;</label>
                                <label style="color:black">One Lakh Twenty One Thousand Sixty Eight Only</label>
                            </th>
                        </tr>
                    </thead>
                </tfoot>
            </table>
        </div>
        <div class="page-break" style="width:100%;">
            <div style="font-size:16px;font-weight:bold;color:black;margin-top:10px;text-align:left !important;margin-left:20px;margin-right:20px;">Note:
            </div>
            <div>
                <label style="font-size:14px;color:black;margin-top:5px;text-align:left;margin-left:20px;margin-right:20px;font-weight:500;">&emsp;&nbsp;This is computer generated invoice, signature not required. 100 % payment against delivery Cheques subject to realization Jurisdiction at Madurai</label>
            </div>
            <div style="font-size:16px; font-weight:bold;color:black;margin-top:10px;text-align:left !important;margin-left:20px;margin-right:20px;">Terms & Conditions:
            </div>
            <div style="font-size:14px; font-weight:500;color:black;margin-top:5px;text-align:left !important;margin-left:20px;margin-right:20px;">
                <ul>
                    <li>The payment is not refundable, Once registered</li>
                    <li>Only the registered candidates can communicate with the staff. Others should not be involved in the work</li>
                    <li>The requirements should be submitted as a document. Verbal conversation is not allowed for modification</li>
                    <li>Your work is a more confidential one. It won't be shared or discussed anybody else.</li>
                </ul>
            </div>
            <div style="margin-left:20px;margin-right:20px;margin-top:5px;float: right !important;">
                <img src="{{asset('assets/phdizone_images/signature.png')}}" alt="user-avatar" id="uploadedlogo" />
                <div style="display:block !important;font-size:16px;font-weight:600;color:black;margin-top:5px;margin-left:20px;margin-right:20px;">Authorized Signature</div>
            </div>
        </div>
    </div>
</center>


@endsection