@extends('layouts/blankLayout')

@section('title', 'Login')

@section('page-style')
@vite([
'resources/assets/vendor/scss/pages/page-auth.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js'
])
@endsection

@section('content')
<style>
  .log_bg_img {
    background-image: url('assets/phdizone_images/login/login_bg.png');
    /* rotate: 180 deg; */
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover !important;
    /* width: 100% !important;
    height: 100% !important; */
  }
</style>
<div class="authentication-wrapper authentication-cover">
  <!-- Logo -->
  <!-- <a href="{{url('/')}}" class="auth-cover-brand d-flex align-items-center gap-2">
    <span class="app-brand-logo demo">@include('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'])</span>
    <span class="app-brand-text demo text-heading fw-bold">{{config('variables.templateName')}}</span>
  </a> -->
  <!-- /Logo -->
  <div class="authentication-inner row m-0">
    <!-- /Left Section -->
    <div class="d-flex col-12 col-lg-5 col-xl-5 align-items-center authentication-bg position-relative py-sm-5 px-4 py-4">
      <div class="w-px-400 mx-auto pt-lg-0">
        <div class="d-flex align-items-center justify-content-center px-2 pb-4">
          <img src="{{asset('assets/phdizone_images/phdizone_logo.png') }}" class="auth-cover-illustration w-300px " alt="auth-illustration" />
        </div>
        <h3 class="mb-6 text-center fw-bold">Research Gateway Hub</h3>
        <!-- <form id="formAuthentication" class="mb-3" action="{{url('/')}}" method="GET"> -->
        <div class="mb-3">
          <label class="text-dark mb-1 fs-6 fw-semibold">Username<span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="email" name="email-username" placeholder="Enter Username" autofocus />
        </div>
        <div class="mb-3">
          <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
          <div class="form-password-toggle">
            <div class="input-group input-group-merge">
              <input type="password" class="form-control" id="password" placeholder="Enter Password" aria-describedby="password" />
              <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
            </div>
          </div>
        </div>
        <div class="mb-3 d-flex justify-content-between">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="remember-me">
            <label class="" for="remember-me">
              Remember Me
            </label>
          </div>
          <a href="{{url('/get_staff')}}" class="float-end mb-1">
            <span>Forgot Password?</span>
          </a>
        </div>
        <a href="{{url('/dashboards')}}" class="btn btn-primary d-grid w-100">
          Login
        </a>
        <!-- </form> -->
      </div>
    </div>
    <div class="d-none d-lg-flex col-lg-7 col-xl-7 align-items-center justify-content-center log_bg_img p-5 pb-2">
      <!-- <img src="{{asset('assets/img/illustrations/auth-login-illustration-light.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" data-app-light-img="illustrations/auth-login-illustration-light.png" data-app-dark-img="illustrations/auth-login-illustration-dark.png" />
      <img src="{{asset('assets/img/illustrations/auth-cover-login-mask-light.png') }}" class="authentication-image" alt="mask" data-app-light-img="illustrations/auth-cover-login-mask-light.png" data-app-dark-img="illustrations/auth-cover-login-mask-dark.png" /> -->
      <div class="d-flex align-items-center pt-15 ms-5">
        <img src="{{asset('assets/phdizone_images/login/login_img.gif') }}" class="auth-cover-illustration w-550px h-450px" alt="auth-illustration" style="max-inline-size: 100% !important;" />
      </div>
      <!-- <img src="{{asset('assets/eapl_images/student_login/login/login.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" /> -->
      <!-- <img src="{{asset('assets/eapl_images/student_login/5.jpg') }}" class="authentication-image opacity-25 h-100" alt="auth-illustration" /> -->
    </div>
    <!-- /Left Section -->
    <!-- Login -->
    <!-- /Login -->
  </div>
</div>
@endsection