@extends('layouts/blankLayout')

@section('title', 'Get Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection


@section('page-style')
@vite([
'resources/assets/vendor/scss/pages/page-auth.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js',
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite([
'resources/assets/js/pages_auth_two_steps.js',
'resources/assets/js/forms_date_time_pickers.js'
])
@endsection

@section('content')
<div class="authentication-wrapper authentication-cover">
  <!-- Logo -->
  <!-- <a href="{{url('/')}}" class="auth-cover-brand d-flex align-items-center gap-2">
    <span class="app-brand-logo demo">@include('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'])</span>
    <span class="app-brand-text demo text-heading fw-bold">{{config('variables.templateName')}}</span>
  </a> -->
  <!-- /Logo -->
  <div class="authentication-inner row m-0">
    <!-- /Left Section -->
    <div class="d-none d-lg-flex col-lg-7 col-xl-7 align-items-center justify-content-center p-5 pb-2">
      <!-- <img src="{{asset('assets/img/illustrations/auth-login-illustration-light.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" data-app-light-img="illustrations/auth-login-illustration-light.png" data-app-dark-img="illustrations/auth-login-illustration-dark.png" />
      <img src="{{asset('assets/img/illustrations/auth-cover-login-mask-light.png') }}" class="authentication-image" alt="mask" data-app-light-img="illustrations/auth-cover-login-mask-light.png" data-app-dark-img="illustrations/auth-cover-login-mask-dark.png" /> -->
      <img src="{{asset('assets/eapl_images/bg_image/get_staff.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" />
      <!-- <img src="{{asset('assets/eapl_images/student_login/5.jpg') }}" class="authentication-image opacity-25 h-100" alt="auth-illustration" /> -->
    </div>
    <!-- /Left Section -->

    <!-- Login -->
    <div class="d-flex col-12 col-lg-5 col-xl-5 align-items-center authentication-bg position-relative py-sm-5 px-4 py-4">
      <div class="w-px-400 mx-auto pt-5 pt-lg-0">
        <h3 class="mb-6 text-center fw-bold">Get Staff?</h3>
        <!-- <form id="formAuthentication" class="mb-3" action="{{url('/')}}" method="GET"> -->
        <div class="mb-3">
          <label class="text-dark mb-1 fs-6 fw-semibold">Employee ID<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Employee ID" id="log_emp_id" name="log_emp_id" autofocus />
        </div>
        <div class="mb-6">
          <label class="text-dark mb-1 fs-6 fw-semibold">DOB<span class="text-danger">*</span></label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="log_dob" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
        <a href="{{url('/forgot_password')}}" class="btn btn-primary d-grid w-100 mb-4">Verify Staff</a>
        <a href="{{url('/')}}" class="btn btn-secondary bg-gray-300 text-black w-100 mb-4">
          <i class="mdi mdi-chevron-left fs-4 me-1"></i>Back to login
        </a>
        <!-- </form> -->
      </div>
    </div>
    <!-- /Login -->
  </div>
</div>

<script>
  function send_otp_func() {
    // if ($('#log_mob_no').val().length == 10) {
    document.getElementById("otp_tbox").style.display = "block";
    document.getElementById("send_otp").setAttribute('style', 'display:none !important');
    document.getElementById("resd_otp_timer").setAttribute('style', 'display:block !important');
    start_timer();
    document.getElementById("vfy_otp").setAttribute('style', 'display:block !important');
    // } else {}
  }

  // function otp_tbox_hide_func() {
  //   document.getElementById("otp_tbox").style.display = "none";
  //   document.getElementById("vfy_otp").setAttribute('style', 'display:none !important');
  //   document.getElementById("send_otp").setAttribute('style', 'display:block !important');
  // }

  function resend_otp_func() {
    document.getElementById("resd_otp_link").setAttribute('style', 'display:none !important');
    document.getElementById("otp_timer").setAttribute('style', 'display:inline !important');
    start_timer();
  }
</script>

<script>
  var refreshIntervalId;

  function startTimer(duration, display) {
    var start = Date.now(),
      diff, hours, minutes, seconds;

    function timer() {
      diff = duration - (((Date.now() - start) / 1000) | 0);
      hours = (diff / 3600) | 0;
      minutes = ((diff % 3600) / 60) | 0;
      seconds = (diff % 60) | 0;

      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      // display.textContent = hours + ":" + minutes + ":" + seconds;
      display.textContent = minutes + ":" + seconds;

      if (diff <= 0) {
        start = Date.now() + 1000;
        clearInterval(refreshIntervalId);
        setTimeout(function() {
          $("#otp_timer").fadeOut("slow");
          document.getElementById("resd_otp_link").setAttribute('style', 'display:block !important');
        }, 1000);

      }
    };
    timer();
    refreshIntervalId = setInterval(timer, 1000);
    // clearInterval(refreshIntervalId);
  }

  function start_timer() {
    // window.onload = function() {
    // var timing = 60 * 60 * 5, // ( 60 seconds * 60 minutes * 5 hours )in seconds
    var timing = 60 * 1, // ( 60 seconds * 60 minutes * 5 hours )in seconds
      display = document.querySelector('#otp_timer');
    startTimer(timing, display);
  };
</script>
@endsection