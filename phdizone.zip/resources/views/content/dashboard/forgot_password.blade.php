@extends('layouts/blankLayout')

@section('title', 'Forgot Password')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection


@section('page-style')
@vite([
'resources/assets/vendor/scss/pages/page-auth.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js',
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('page-script')
@vite([
'resources/assets/js/pages_auth_two_steps.js'
])
@endsection

@section('content')
<div class="authentication-wrapper authentication-cover">
  <!-- Logo -->
  <!-- <a href="{{url('/')}}" class="auth-cover-brand d-flex align-items-center gap-2">
    <span class="app-brand-logo demo">@include('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'])</span>
    <span class="app-brand-text demo text-heading fw-bold">{{config('variables.templateName')}}</span>
  </a> -->
  <!-- /Logo -->
  <div class="authentication-inner row m-0">
    <!-- /Left Section -->
    <div class="d-none d-lg-flex col-lg-7 col-xl-7 align-items-center justify-content-center p-5 pb-2">
      <!-- <img src="{{asset('assets/img/illustrations/auth-login-illustration-light.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" data-app-light-img="illustrations/auth-login-illustration-light.png" data-app-dark-img="illustrations/auth-login-illustration-dark.png" />
      <img src="{{asset('assets/img/illustrations/auth-cover-login-mask-light.png') }}" class="authentication-image" alt="mask" data-app-light-img="illustrations/auth-cover-login-mask-light.png" data-app-dark-img="illustrations/auth-cover-login-mask-dark.png" /> -->
      <img src="{{asset('assets/eapl_images/bg_image/forgot_password.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" />
      <!-- <img src="{{asset('assets/eapl_images/student_login/5.jpg') }}" class="authentication-image opacity-25 h-100" alt="auth-illustration" /> -->
    </div>
    <!-- /Left Section -->

    <!-- Login -->
    <div class="d-flex col-12 col-lg-5 col-xl-5 align-items-center authentication-bg position-relative py-sm-5 px-4 py-4">
      <div class="w-px-400 mx-auto pt-5 pt-lg-0">
        <h3 class="mb-6 text-center fw-bold">Forgot Password?</h3>
        <!-- <form id="formAuthentication" class="mb-3" action="{{url('/')}}" method="GET"> -->
        <div class="mb-3 fs-6">
          <label>Your Employee ID <b>EGC04004</b></label>
          <!-- <label>98******10</label> -->
        </div>
        <div class="mb-6 fs-6">
          <label>We Sent a Verification Code to Your <b>Reporting Authority</b> Mobile No <b>98******10</b></label>
          <!-- <label>98******10</label> -->
        </div>
        <div class="fw-semibold text-dark mb-1">
          <label class="fw-semibold text-dark me-3 fs-6">Enter your 6 digit security code</label>
          <label class="text-danger rounded w-80px fs-6 fw-bold" id="otp_timer"></label>
        </div>
        <div class="mb-3">
          <div class="auth-input-wrapper d-flex align-items-center justify-content-sm-between numeral-mask-wrapper">
            <input type="tel" class="form-control auth-input h-px-25 text-center numeral-mask fs-6 mx-1" oninput="this.value = this.value.replace(/[^0-9. ]/g, '').replace(/(\..*)\./g, '$1');" maxlength="1" autofocus>
            <input type="tel" class="form-control auth-input h-px-25 text-center numeral-mask fs-6 mx-1" oninput="this.value = this.value.replace(/[^0-9. ]/g, '').replace(/(\..*)\./g, '$1');" maxlength="1">
            <input type="tel" class="form-control auth-input h-px-25 text-center numeral-mask fs-6 mx-1" oninput="this.value = this.value.replace(/[^0-9. ]/g, '').replace(/(\..*)\./g, '$1');" maxlength="1">
            <input type="tel" class="form-control auth-input h-px-25 text-center numeral-mask fs-6 mx-1" oninput="this.value = this.value.replace(/[^0-9. ]/g, '').replace(/(\..*)\./g, '$1');" maxlength="1">
            <input type="tel" class="form-control auth-input h-px-25 text-center numeral-mask fs-6 mx-1" oninput="this.value = this.value.replace(/[^0-9. ]/g, '').replace(/(\..*)\./g, '$1');" maxlength="1">
            <input type="tel" class="form-control auth-input h-px-25 text-center numeral-mask fs-6 mx-1" oninput="this.value = this.value.replace(/[^0-9. ]/g, '').replace(/(\..*)\./g, '$1');" maxlength="1">
          </div>
        </div>
        <div class="text-center mb-3 fw-semibold text-dark" id="resd_otp_link" style="display: none !important;">Didn't get the code?
          <a href="javascript:;" class="text-info fw-bold" id="resend_link" onclick="resend_otp_func();">Resend</a>
        </div>
        <a href="{{url('/change_password')}}" class="btn btn-primary d-grid w-100 mb-4" id="vfy_otp">Verify OTP</a>
        <div class="w-100 gap-2">
          <a href="{{url('/get_staff')}}" class="btn btn-secondary mb-4 bg-gray-300 text-black">
            <i class="mdi mdi-account-key-outline fs-4 me-2"></i>Another Staff
          </a>
          <a href="{{url('/')}}" class="btn btn-secondary mb-4 bg-gray-300 text-black float-end">
            <i class="mdi mdi-chevron-left fs-4 me-1"></i>Back to login
          </a>
        </div>
        <!-- </form> -->
      </div>
    </div>
    <!-- /Login -->
  </div>
</div>

<script>
  function resend_otp_func() {
    document.getElementById("resd_otp_link").setAttribute('style', 'display:none !important');
    document.getElementById("otp_timer").setAttribute('style', 'display:inline !important');
    start_timer();
  }
</script>

<script>
  var refreshIntervalId;

  function startTimer(duration, display) {
    var start = Date.now(),
      diff, hours, minutes, seconds;

    function timer() {
      diff = duration - (((Date.now() - start) / 1000) | 0);
      hours = (diff / 3600) | 0;
      minutes = ((diff % 3600) / 60) | 0;
      seconds = (diff % 60) | 0;

      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      // display.textContent = hours + ":" + minutes + ":" + seconds;
      display.textContent = minutes + ":" + seconds;

      if (diff <= 0) {
        start = Date.now() + 1000;
        clearInterval(refreshIntervalId);
        setTimeout(function() {
          $("#otp_timer").fadeOut("slow");
          document.getElementById("resd_otp_link").setAttribute('style', 'display:block !important');
        }, 1000);

      }
    };
    timer();
    refreshIntervalId = setInterval(timer, 1000);
    // clearInterval(refreshIntervalId);
  }

  function start_timer() {
    // window.onload = function() {
    // var timing = 60 * 60 * 5, // ( 60 seconds * 60 minutes * 5 hours )in seconds
    var timing = 60 * 1, // ( 60 seconds * 60 minutes * 5 hours )in seconds
      display = document.querySelector('#otp_timer');
    startTimer(timing, display);
  };
  window.onload = function() {
    // var timing = 60 * 60 * 5, // ( 60 seconds * 60 minutes * 5 hours )in seconds
    var timing = 60 * 1, // ( 60 seconds * 60 minutes * 5 hours )in seconds
      display = document.querySelector('#otp_timer');
    startTimer(timing, display);
  };
</script>
@endsection