@extends('layouts/blankLayout')

@section('title', 'New Password')


@section('page-style')
@vite([
'resources/assets/vendor/scss/pages/page-auth.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js'
])
@endsection

@section('content')
<div class="authentication-wrapper authentication-cover">
  <!-- Logo -->
  <!-- <a href="{{url('/')}}" class="auth-cover-brand d-flex align-items-center gap-2">
    <span class="app-brand-logo demo">@include('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'])</span>
    <span class="app-brand-text demo text-heading fw-bold">{{config('variables.templateName')}}</span>
  </a> -->
  <!-- /Logo -->
  <div class="authentication-inner row m-0">
    <!-- /Left Section -->
    <div class="d-none d-lg-flex col-lg-7 col-xl-7 align-items-center justify-content-center p-5 pb-2">
      <!-- <img src="{{asset('assets/img/illustrations/auth-login-illustration-light.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" data-app-light-img="illustrations/auth-login-illustration-light.png" data-app-dark-img="illustrations/auth-login-illustration-dark.png" />
      <img src="{{asset('assets/img/illustrations/auth-cover-login-mask-light.png') }}" class="authentication-image" alt="mask" data-app-light-img="illustrations/auth-cover-login-mask-light.png" data-app-dark-img="illustrations/auth-cover-login-mask-dark.png" /> -->
      <img src="{{asset('assets/eapl_images/bg_image/reset_password.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" />
      <!-- <img src="{{asset('assets/eapl_images/student_login/5.jpg') }}" class="authentication-image opacity-25 h-100" alt="auth-illustration" /> -->
    </div>
    <!-- /Left Section -->

    <!-- Login -->
    <div class="d-flex col-12 col-lg-5 col-xl-5 align-items-center authentication-bg position-relative py-sm-5 px-4 py-4">
      <div class="w-px-400 mx-auto pt-5 pt-lg-0">
        <h3 class="mb-6 text-center fw-bold">Reset Password?</h3>
        <!-- <form id="formAuthentication" class="mb-3" action="{{url('/')}}" method="GET"> -->
        <div class="d-flex align-items-center mb-3">
          <div class="symbol symbol-35px me-2  border border-info rounded">
            <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
              <img src="{{asset('assets/eapl_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
            </div>
          </div>
          <div class="align-items-center mb-0">
            <label class="text-black fs-6 fw-semibold">Yasmin</label>
            <label class="d-block text-primary fs-8 fw-semibold">EGC04004</label>
          </div>
        </div>
        <div class="mb-3">
          <label class="text-dark mb-1 fs-6 fw-semibold">New Password<span class="text-danger">*</span></label>
          <div class="form-password-toggle">
            <div class="input-group input-group-merge">
              <input type="password" class="form-control" id="password" placeholder="Enter New Password" aria-describedby="password" />
              <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
            </div>
          </div>
        </div>
        <div class="mb-6">
          <label class="text-dark mb-1 fs-6 fw-semibold">Confirm Password<span class="text-danger">*</span></label>
          <div class="form-password-toggle">
            <div class="input-group input-group-merge">
              <input type="password" class="form-control" id="password" placeholder="Enter Confirm Password" aria-describedby="password" />
              <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
            </div>
          </div>
        </div>
        <a href="{{url('/dashboards')}}" class="btn btn-primary d-grid w-100 mb-4">Change Password</a>
        <a href="{{url('/')}}" class="btn btn-secondary bg-gray-300 text-black w-100 mb-4">
          <i class="mdi mdi-chevron-left fs-4 me-1"></i>Back to login
        </a>
        <!-- </form> -->
      </div>
    </div>
    <!-- /Login -->
  </div>
</div>
@endsection